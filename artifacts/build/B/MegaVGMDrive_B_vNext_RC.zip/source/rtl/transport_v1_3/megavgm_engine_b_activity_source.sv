// SPDX-License-Identifier: GPL-2.0-or-later
//
// Engine B channel-activity observer. This block is display-only: it consumes
// already-existing accepted writes and sound-core status, and has no fanout
// into parser, timing, memory, or audio control.

module megavgm_engine_b_activity_source (
	input  logic        clk,
	input  logic        reset,
	input  logic        parser_write_accepted,
	input  logic        parser_write_port,
	input  logic [7:0]  parser_write_address,
	input  logic [7:0]  parser_write_data,
	input  logic [7:0]  psg_a,
	input  logic [7:0]  psg_b,
	input  logic [7:0]  psg_c,
	input  logic [5:0]  adpcma_command,
	input  logic        adpcma_command_stop,
	input  logic        adpcma_command_accepted,
	input  logic [5:0]  adpcma_eos,
	input  logic        adpcmb_active,
	output logic [15:0] channel_activity
);

	logic [5:0] fm_keyon_event;
	logic [5:0] adpcma_active_shadow;
	logic [5:0] adpcma_active_next;

	// YM2610B key-on selector codes are 0, 1, 2, 4, 5, and 6. Codes 3 and
	// 7 are reserved. Key-off writes do not create an activity event.
	always_comb begin
		fm_keyon_event = 6'b0;
		if(parser_write_accepted && !parser_write_port &&
		   parser_write_address == 8'h28 && parser_write_data[7:4] != 4'h0) begin
			unique case(parser_write_data[2:0])
				3'd0: fm_keyon_event[0] = 1'b1;
				3'd1: fm_keyon_event[1] = 1'b1;
				3'd2: fm_keyon_event[2] = 1'b1;
				3'd4: fm_keyon_event[3] = 1'b1;
				3'd5: fm_keyon_event[4] = 1'b1;
				3'd6: fm_keyon_event[5] = 1'b1;
				default: fm_keyon_event = 6'b0;
			endcase
		end
	end

	// The JT10 en_ch signal is a time-multiplexed processing phase, not a
	// six-channel active bitmap. Track only commands actually consumed by the
	// ADPCM-A driver, and clear completed channels from its existing EOS flags.
	always_comb begin
		adpcma_active_next = adpcma_active_shadow & ~adpcma_eos;
		if(adpcma_command_accepted) begin
			if(adpcma_command_stop)
				adpcma_active_next = adpcma_active_next & ~adpcma_command;
			else
				adpcma_active_next = adpcma_active_next | adpcma_command;
		end
	end

	always_ff @(posedge clk) begin
		if(reset)
			adpcma_active_shadow <= 6'b0;
		else
			adpcma_active_shadow <= adpcma_active_next;
	end

	always_comb begin
		channel_activity[5:0] = fm_keyon_event;
		channel_activity[8:6] = {|psg_c, |psg_b, |psg_a};
		channel_activity[14:9] = adpcma_active_shadow;
		channel_activity[15] = adpcmb_active;
	end

endmodule
