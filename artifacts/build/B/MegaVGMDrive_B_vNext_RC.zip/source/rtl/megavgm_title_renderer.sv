// SPDX-License-Identifier: GPL-2.0-or-later
//
// Two-line native prepared-name panel renderer.
//
// Coordinates are native active-picture coordinates. Each printable ASCII
// character occupies a 6x7 cell containing one 5x7 glyph plus one blank
// horizontal pixel.

module megavgm_title_renderer (
	input  logic [9:0] h_count,
	input  logic [8:0] v_count,
	input  logic       drawing_active,

	input  logic       title_valid,
	input  logic [5:0] directory_length,
	input  logic [5:0] basename_length,
	output logic [6:0] title_read_addr,
	input  logic [7:0] title_read_data,
`ifdef MEGAVGMDRIVE_ENGINE_B_CHANNEL_ACTIVITY_OSD
	input  logic       channel_activity_visible,
	input  logic [15:0] channel_activity,
	input  logic [1:0] player_state,
`endif

	output logic       text_pixel,
	output logic       panel_pixel,
	output logic [23:0] panel_rgb
);

	// Center the historical 320x240 player surface in the Template's
	// 529x240 active picture. The 288-pixel basename has 16-pixel margins.
	localparam logic [9:0] PANEL_LEFT = 10'd104;
	localparam logic [9:0] PANEL_RIGHT = 10'd423;
	localparam logic [8:0] PANEL_BOTTOM = 9'd239;
	localparam logic [9:0] TEXT_X = 10'd120;
	localparam logic [8:0] DIRECTORY_Y = 9'd24;
	localparam logic [8:0] BASENAME_Y = 9'd34;
`ifdef MEGAVGMDRIVE_ENGINE_B_CHANNEL_ACTIVITY_OSD
	localparam logic [8:0] CHIP_Y = 9'd54;
	localparam logic [8:0] FM_Y = 9'd70;
	localparam logic [8:0] SSG_Y = 9'd96;
	localparam logic [8:0] ADPCMA_Y = 9'd122;
	localparam logic [8:0] ADPCMB_Y = 9'd148;
	// Reuse the historical channel-label character slots. Activity occupies
	// the complete 6-pixel character slot and starts on the same text row.
	localparam logic [9:0] CHARACTER_CELL_WIDTH = 10'd6;
	localparam logic [9:0] CHANNEL_SLOT_FIRST = 10'd12;
	localparam logic [9:0] CHANNEL_SLOT_STEP = 10'd3;
	localparam logic [9:0] INDICATOR_X =
		TEXT_X + (CHANNEL_SLOT_FIRST * CHARACTER_CELL_WIDTH);
	localparam logic [9:0] INDICATOR_STEP_X =
		CHANNEL_SLOT_STEP * CHARACTER_CELL_WIDTH;
	localparam logic [9:0] INDICATOR_LAST_X = 10'd5;
	localparam logic [8:0] INDICATOR_LAST_Y = 9'd4;
	localparam logic [9:0] STATUS_BADGE_X = 10'd388;
	localparam logic [8:0] STATUS_BADGE_Y = 9'd224;
	localparam logic [23:0] ACTIVITY_OFF_COLOR = 24'h102838;
	localparam logic [23:0] ACTIVITY_ON_COLOR = 24'h40c5d8;
`endif

	logic [7:0] character;
	logic [2:0] glyph_x;
	logic [2:0] glyph_y;
	logic       cell_visible;
	logic       glyph_pixel;
	logic [9:0] relative_x;
	logic [6:0] character_index;
	logic [9:0] character_cell_x;
`ifdef MEGAVGMDRIVE_ENGINE_B_CHANNEL_ACTIVITY_OSD
	logic [2:0] activity_line;
	logic [8:0] activity_text_y;
	logic       activity_text_valid;
	logic       indicator_pixel;
	logic       indicator_on;
	logic [3:0] indicator_index;
	logic       status_badge_cell;
	logic       status_badge_pixel;
	logic [1:0] status_badge_index;
	logic [23:0] status_badge_color;

	function automatic logic [7:0] status_badge_character(
		input logic [1:0] state,
		input logic [1:0] index
	);
		begin
			status_badge_character = " ";
			unique case(state)
				2'd0: unique case(index)
					0: status_badge_character = "S"; 1: status_badge_character = "T";
					2: status_badge_character = "O"; 3: status_badge_character = "P";
				endcase
				2'd1: unique case(index)
					0: status_badge_character = "L"; 1: status_badge_character = "O";
					2: status_badge_character = "A"; 3: status_badge_character = "D";
				endcase
				2'd2: unique case(index)
					0: status_badge_character = "P"; 1: status_badge_character = "L";
					2: status_badge_character = "A"; 3: status_badge_character = "Y";
				endcase
				default: status_badge_character = " ";
			endcase
		end
	endfunction

	function automatic logic [7:0] activity_character(
		input logic [2:0] line,
		input logic [6:0] index
	);
		begin
			activity_character = " ";
			unique case(line)
				3'd0: unique case(index)
					0: activity_character = "Y"; 1: activity_character = "M";
					2: activity_character = "2"; 3: activity_character = "6";
					4: activity_character = "1"; 5: activity_character = "0";
					6: activity_character = "B";
					default: activity_character = " ";
				endcase
				3'd1: unique case(index)
					0: activity_character = "F"; 1: activity_character = "M";
					default: activity_character = " ";
				endcase
				3'd2: unique case(index)
					0: activity_character = "S"; 1: activity_character = "S";
					2: activity_character = "G";
					default: activity_character = " ";
				endcase
				3'd3: unique case(index)
					0: activity_character = "A"; 1: activity_character = "D";
					2: activity_character = "P"; 3: activity_character = "C";
					4: activity_character = "M"; 5: activity_character = "-";
					6: activity_character = "A";
					default: activity_character = " ";
				endcase
				3'd4: unique case(index)
					0: activity_character = "A"; 1: activity_character = "D";
					2: activity_character = "P"; 3: activity_character = "C";
					4: activity_character = "M"; 5: activity_character = "-";
					6: activity_character = "B";
					default: activity_character = " ";
				endcase
				default: activity_character = " ";
			endcase
		end
	endfunction
`endif

	megavgm_font5x7 font (
		.character(character),
		.glyph_x(glyph_x),
		.glyph_y(glyph_y),
		.pixel(glyph_pixel)
	);

	always @* begin
		character = " ";
		glyph_x = 0;
		glyph_y = 0;
		title_read_addr = 0;
		cell_visible = 1'b0;
		relative_x = 0;
		character_index = 0;
		character_cell_x = 0;
`ifdef MEGAVGMDRIVE_ENGINE_B_CHANNEL_ACTIVITY_OSD
		activity_line = 0;
		activity_text_y = 0;
		activity_text_valid = 1'b0;
		indicator_pixel = 1'b0;
		indicator_on = 1'b0;
		indicator_index = 0;
		status_badge_cell = 1'b0;
		status_badge_pixel = 1'b0;
		status_badge_index = 2'd0;
		status_badge_color = (player_state == 2'd0) ?
			ACTIVITY_OFF_COLOR : ACTIVITY_ON_COLOR;
`endif
		panel_pixel =
			drawing_active &&
			(h_count >= PANEL_LEFT) && (h_count <= PANEL_RIGHT) &&
			(v_count <= PANEL_BOTTOM);
		panel_rgb = panel_pixel ? 24'h000818 : 24'h000000;

`ifdef MEGAVGMDRIVE_ENGINE_B_CHANNEL_ACTIVITY_OSD
		if(channel_activity_visible) begin
			if(v_count >= CHIP_Y && v_count < CHIP_Y + 9'd7) begin
				activity_line = 3'd0; activity_text_y = CHIP_Y; activity_text_valid = 1'b1;
			end else if(v_count >= FM_Y && v_count < FM_Y + 9'd7) begin
				activity_line = 3'd1; activity_text_y = FM_Y; activity_text_valid = 1'b1;
			end else if(v_count >= SSG_Y && v_count < SSG_Y + 9'd7) begin
				activity_line = 3'd2; activity_text_y = SSG_Y; activity_text_valid = 1'b1;
			end else if(v_count >= ADPCMA_Y && v_count < ADPCMA_Y + 9'd7) begin
				activity_line = 3'd3; activity_text_y = ADPCMA_Y; activity_text_valid = 1'b1;
			end else if(v_count >= ADPCMB_Y && v_count < ADPCMB_Y + 9'd7) begin
				activity_line = 3'd4; activity_text_y = ADPCMB_Y; activity_text_valid = 1'b1;
			end

			if(v_count >= FM_Y && v_count <= FM_Y + INDICATOR_LAST_Y) begin
				if(h_count >= INDICATOR_X && h_count <= INDICATOR_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd0; end
				else if(h_count >= INDICATOR_X + INDICATOR_STEP_X && h_count <= INDICATOR_X + INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd1; end
				else if(h_count >= INDICATOR_X + 10'd2 * INDICATOR_STEP_X && h_count <= INDICATOR_X + 10'd2 * INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd2; end
				else if(h_count >= INDICATOR_X + 10'd3 * INDICATOR_STEP_X && h_count <= INDICATOR_X + 10'd3 * INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd3; end
				else if(h_count >= INDICATOR_X + 10'd4 * INDICATOR_STEP_X && h_count <= INDICATOR_X + 10'd4 * INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd4; end
				else if(h_count >= INDICATOR_X + 10'd5 * INDICATOR_STEP_X && h_count <= INDICATOR_X + 10'd5 * INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd5; end
			end
			else if(v_count >= SSG_Y && v_count <= SSG_Y + INDICATOR_LAST_Y) begin
				if(h_count >= INDICATOR_X && h_count <= INDICATOR_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd6; end
				else if(h_count >= INDICATOR_X + INDICATOR_STEP_X && h_count <= INDICATOR_X + INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd7; end
				else if(h_count >= INDICATOR_X + 10'd2 * INDICATOR_STEP_X && h_count <= INDICATOR_X + 10'd2 * INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd8; end
			end
			else if(v_count >= ADPCMA_Y && v_count <= ADPCMA_Y + INDICATOR_LAST_Y) begin
				if(h_count >= INDICATOR_X && h_count <= INDICATOR_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd9; end
				else if(h_count >= INDICATOR_X + INDICATOR_STEP_X && h_count <= INDICATOR_X + INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd10; end
				else if(h_count >= INDICATOR_X + 10'd2 * INDICATOR_STEP_X && h_count <= INDICATOR_X + 10'd2 * INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd11; end
				else if(h_count >= INDICATOR_X + 10'd3 * INDICATOR_STEP_X && h_count <= INDICATOR_X + 10'd3 * INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd12; end
				else if(h_count >= INDICATOR_X + 10'd4 * INDICATOR_STEP_X && h_count <= INDICATOR_X + 10'd4 * INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd13; end
				else if(h_count >= INDICATOR_X + 10'd5 * INDICATOR_STEP_X && h_count <= INDICATOR_X + 10'd5 * INDICATOR_STEP_X + INDICATOR_LAST_X) begin indicator_pixel = panel_pixel; indicator_index = 4'd14; end
			end
			else if(v_count >= ADPCMB_Y && v_count <= ADPCMB_Y + INDICATOR_LAST_Y &&
			        h_count >= INDICATOR_X && h_count <= INDICATOR_X + INDICATOR_LAST_X) begin
				indicator_pixel = panel_pixel;
				indicator_index = 4'd15;
			end

			if(indicator_pixel) begin
				indicator_on = channel_activity[indicator_index];
				panel_rgb = indicator_on ? ACTIVITY_ON_COLOR : ACTIVITY_OFF_COLOR;
			end
		end
`endif

`ifdef MEGAVGMDRIVE_ENGINE_B_CHANNEL_ACTIVITY_OSD
		if(panel_pixel &&
		   (h_count >= STATUS_BADGE_X) && (h_count < STATUS_BADGE_X + 10'd24) &&
		   (v_count >= STATUS_BADGE_Y) && (v_count < STATUS_BADGE_Y + 9'd7)) begin
			status_badge_cell = 1'b1;
			if(h_count < STATUS_BADGE_X + 10'd6) begin
				status_badge_index = 2'd0;
				glyph_x = h_count - STATUS_BADGE_X;
			end else if(h_count < STATUS_BADGE_X + 10'd12) begin
				status_badge_index = 2'd1;
				glyph_x = h_count - (STATUS_BADGE_X + 10'd6);
			end else if(h_count < STATUS_BADGE_X + 10'd18) begin
				status_badge_index = 2'd2;
				glyph_x = h_count - (STATUS_BADGE_X + 10'd12);
			end else begin
				status_badge_index = 2'd3;
				glyph_x = h_count - (STATUS_BADGE_X + 10'd18);
			end
			glyph_y = v_count - STATUS_BADGE_Y;
			character = status_badge_character(player_state, status_badge_index);
			cell_visible = 1'b1;
		end
		else
`endif
		if(panel_pixel && (h_count >= TEXT_X)) begin
			relative_x = h_count - TEXT_X;
			/* verilator lint_off WIDTHTRUNC */
			character_index = relative_x / 10'd6;
			character_cell_x = character_index * 10'd6;
			glyph_x = relative_x - character_cell_x;
			/* verilator lint_on WIDTHTRUNC */

			if((v_count >= DIRECTORY_Y) && (v_count < DIRECTORY_Y + 9'd7) &&
			   title_valid && (character_index < {1'b0, directory_length})) begin
				/* verilator lint_off WIDTHTRUNC */
				glyph_y = v_count - DIRECTORY_Y;
				/* verilator lint_on WIDTHTRUNC */
				title_read_addr = character_index;
				character = title_read_data;
				cell_visible = 1'b1;
			end
			else if((v_count >= BASENAME_Y) && (v_count < BASENAME_Y + 9'd7) &&
			        title_valid && (character_index < {1'b0, basename_length})) begin
				/* verilator lint_off WIDTHTRUNC */
				glyph_y = v_count - BASENAME_Y;
				/* verilator lint_on WIDTHTRUNC */
				title_read_addr = 7'd32 + character_index;
				character = title_read_data;
				cell_visible = 1'b1;
			end
`ifdef MEGAVGMDRIVE_ENGINE_B_CHANNEL_ACTIVITY_OSD
			else if(channel_activity_visible && activity_text_valid) begin
				/* verilator lint_off WIDTHTRUNC */
				glyph_y = v_count - activity_text_y;
				/* verilator lint_on WIDTHTRUNC */
				character = activity_character(activity_line, character_index);
				cell_visible = 1'b1;
			end
`endif
		end

`ifdef MEGAVGMDRIVE_ENGINE_B_CHANNEL_ACTIVITY_OSD
		status_badge_pixel = status_badge_cell && (glyph_x < 5) && glyph_pixel;
		if(status_badge_pixel)
			panel_rgb = status_badge_color;
		text_pixel = !status_badge_cell && cell_visible && (glyph_x < 5) && glyph_pixel;
`else
		text_pixel = cell_visible && (glyph_x < 5) && glyph_pixel;
`endif
	end

endmodule
