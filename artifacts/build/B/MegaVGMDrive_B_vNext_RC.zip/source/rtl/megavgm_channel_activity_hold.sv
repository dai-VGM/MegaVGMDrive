// SPDX-License-Identifier: GPL-2.0-or-later
//
// Frame-rate hold for Engine B channel activity. Activity and video timing
// share clk_sys, so no clock-domain crossing storage is required.

module megavgm_channel_activity_hold #(
	parameter int WIDTH = 14
) (
	input  logic             clk,
	input  logic             reset,
	input  logic             vblank_start,
	input  logic [WIDTH-1:0] activity_event,
	output logic [WIDTH-1:0] activity_visible
);

	logic [WIDTH-1:0] frame_accumulator;
	logic [WIDTH-1:0] current_frame;
	logic [WIDTH-1:0] previous_frame;

	always_ff @(posedge clk) begin
		if(reset) begin
			frame_accumulator <= '0;
			current_frame <= '0;
			previous_frame <= '0;
		end
		else if(vblank_start) begin
			previous_frame <= current_frame;
			current_frame <= frame_accumulator | activity_event;
			frame_accumulator <= '0;
		end
		else begin
			frame_accumulator <= frame_accumulator | activity_event;
		end
	end

	always_comb activity_visible = current_frame | previous_frame;

endmodule
