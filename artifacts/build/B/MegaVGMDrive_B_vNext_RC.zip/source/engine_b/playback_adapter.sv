// Thin translation only. Combined bus/cache acceptance is supplied by integration.
module engine_b_vnext_playback_adapter (
 input logic enabled, valid,
 input vgm_scheduler_vnext_pkg::scheduled_fact_t event_data,
 output logic ready, write_valid, write_port,
 output logic [7:0] write_address, write_data,
 input logic write_ready,
 output logic accepted, invalid_target
);
 import vgm_parser_vnext_event_pkg::*;
 import vgm_scheduler_vnext_pkg::*;
 write_descriptor_t descriptor;
 assign descriptor=event_data.fact.payload[134:80];
 assign invalid_target=valid && (event_data.fact.kind!=S_WRITE ||
     descriptor.chip!=CHIP_YM2610_FAMILY || descriptor.instance_id ||
     descriptor.access_kind!=ACCESS_REGISTER || descriptor.address[15:8]!=0);
 assign write_valid=enabled && valid && !invalid_target;
 assign ready=enabled && write_ready && !invalid_target;
 assign write_port=descriptor.port;
 assign write_address=descriptor.address[7:0];
 assign write_data=descriptor.data;
 assign accepted=write_valid && write_ready;
endmodule
