// Candidate raw-command runway. Indexed reads reuse the prepared store;
// this buffer owns neither physical DDR transactions nor loop/clock policy.
module engine_b_vnext_prefix_word_prefetch #(parameter int DEPTH=1, STORE_WORDS=256)(
 input logic clk,reset,prepared,prefix_ready,prefix_replay,
 input logic[31:0]epoch,file_extent,prefix_start,prefix_end,
 input logic[$clog2(STORE_WORDS):0]store_count,
 output logic fetch_valid,fetch_urgent,output logic[$clog2(STORE_WORDS)-1:0]fetch_slot,
 input logic fetch_ready,fetch_rsp_valid,fetch_rsp_command,
 input logic[31:0]fetch_rsp_address,fetch_rsp_epoch,input logic[63:0]fetch_rsp_data,
 input logic request,input logic[31:0]address,
 output logic selected,ready,response_valid,word_valid,
 output logic[7:0]response_byte,output logic[63:0]response_word,
 output logic[31:0]response_address,response_epoch,output logic fault
);
 localparam int PTR=DEPTH>1 ? $clog2(DEPTH) : 1;
 logic[63:0]data[DEPTH];logic[31:0]tags[DEPTH];
 logic[PTR-1:0]head,tail;logic[$clog2(DEPTH+1)-1:0]count;
 logic[$clog2(STORE_WORDS):0]next_slot;
 logic pending,replay_q,reply_word,reply_byte;
 logic[31:0]owner_epoch,owner_start,owner_end,owner_extent;
 wire identity_change=epoch!=owner_epoch || prefix_start!=owner_start || prefix_end!=owner_end || file_extent!=owner_extent;
 wire rewind=replay_q && !prefix_replay;
 wire clear=reset || identity_change || rewind;
 wire usable=prepared && prefix_ready && prefix_start<prefix_end && prefix_end<=file_extent && !clear;
 assign selected=usable && prefix_replay && address>=prefix_start && address<prefix_end;
 wire hit=count!=0 && tags[head]=={address[31:3],3'd0};
 wire discard=selected && request && count!=0 && tags[head]<{address[31:3],3'd0};
 assign ready=selected && hit && !reply_word && !reply_byte;
 wire take=request && ready;
 wire pop=take || discard;
 wire push=fetch_rsp_valid && pending && fetch_rsp_epoch==epoch && fetch_rsp_command && !clear;
 assign fetch_valid=usable && !pending && next_slot<store_count && int'(count)<DEPTH;
 assign fetch_urgent=int'(count)<=1;
 assign fetch_slot=next_slot[$clog2(STORE_WORDS)-1:0];
 assign word_valid=reply_word && !clear;
 assign response_valid=reply_byte && !clear;
 function automatic[PTR-1:0]advance(input logic[PTR-1:0]p);
  advance=int'(p)==DEPTH-1 ? '0 : p+1'b1;
 endfunction
 always_ff @(posedge clk)begin
  replay_q<=prefix_replay;reply_word<=0;reply_byte<=reply_word;
  if(clear)begin
   head<=0;tail<=0;count<=0;next_slot<=0;pending<=0;fault<=0;reply_word<=0;reply_byte<=0;
   owner_epoch<=epoch;owner_start<=prefix_start;owner_end<=prefix_end;owner_extent<=file_extent;
   response_byte<=0;response_word<=0;response_address<=0;response_epoch<=epoch;
  end else begin
   if(fetch_valid && fetch_ready)begin pending<=1;next_slot<=next_slot+1'b1;end
   if(fetch_rsp_valid && pending && fetch_rsp_epoch==epoch)pending<=0;
   if(push)begin data[tail]<=fetch_rsp_data;tags[tail]<=fetch_rsp_address;tail<=advance(tail);end
   if(pop)head<=advance(head);
   case({push,pop})2'b10:count<=count+1'b1;2'b01:count<=count-1'b1;default:begin end endcase
   if(take)begin
    reply_word<=1;response_word<=data[head];response_byte<=data[head][address[2:0]*8+:8];
    response_address<=address;response_epoch<=epoch;
   end
   // Missing captured word is a preparation fault, never synthetic byte data.
   if(selected && request && !pending && next_slot==store_count && count==0)fault<=1;
   if(selected && request && count!=0 && tags[head]>{address[31:3],3'd0})fault<=1;
  end
 end
endmodule
