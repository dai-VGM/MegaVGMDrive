// Simulation candidate composition; Golden upload/backend remains external.
// PASS1 resources are prepared before the retained chip/timeline start fence.
module engine_b_vnext_strict_playback_binding #(
 parameter int SYS_CLK_HZ=20000000, SCHEDULER_DEPTH=16, PREFIX_BUFFER_WORDS=1,
 parameter bit ENABLE_YM2610B=1,RESOURCE_PREPARE=1,LOOP_PREFIX=1,
 parameter logic[28:0]DDRAM_BASE_ADDR=29'd0
)(
 input logic clk,power_reset,hard_reset,soft_reset,download_active,load_done_pulse,
 input logic [31:0] file_size,epoch,
 input logic backend_loaded,backend_load_error,
 input logic transport_halt_loop,transport_finish,
 output logic transport_parser_done,transport_audio_ready,transport_loop_entry,transport_loop_boundary,
 output logic signed [15:0] audio_l,audio_r,
 output logic audio_sample,external_mute,start_pulse,fatal_active,
 output logic [7:0] fatal_code,
 output logic [3:0] load_state,
 output logic golden_request,output logic [22:0] golden_byte_address,
 input logic golden_ready,golden_valid,golden_read,golden_write,
 input logic [28:0] golden_address,input logic [7:0] golden_be,golden_burst,
 output logic golden_busy,avalon_read,
 output logic [28:0] avalon_address,output logic [7:0] avalon_be,avalon_burst,
 input logic avalon_busy,avalon_valid,input logic [63:0] avalon_data,
 output logic backend_response_valid,output logic[63:0]backend_response_data,
 output logic fault_valid,
 output vgm_reader_vnext_pkg::read_response_t fault_response,
 output logic [15:0] channel_activity,
 output logic [31:0] loop_count,playback_samples,start_count,scanner_start_count,command_count,
 output wire loop_valid,
 output logic logical_active,drain_blocked,boundary_fault
);
 logic prefix_fetch_valid,prefix_fetch_urgent,prefix_fetch_ready,prefix_fetch_rsp_valid,prefix_fetch_rsp_command,local_wait;
 logic[7:0]prefix_fetch_slot;logic[31:0]prefix_fetch_rsp_address,prefix_fetch_rsp_epoch;
 logic[63:0]prefix_fetch_rsp_data;logic[8:0]prepared_word_count;
 logic prefix_capture,prefix_replay,prefix_ready,command_read_owner,owned_command,owned_prefix;
 logic[31:0]prefix_start,prefix_end,owned_address;
 logic word_valid;logic[31:0]word_address,word_epoch;logic[63:0]word_data;
 logic req,ready,valid;logic[22:0]address;logic[7:0]data;
 logic prepared,prepare_fault,warm_req,warm_ready,warm_valid,query_hit,store_fault;
 logic[22:0]warm_address,query_address;
 logic source_req,source_ready,source_valid,captured,source_owned,owned_warm,select_warm;
 logic[22:0]source_address;logic[31:0]owned_epoch;
 logic bridge_read,bridge_busy,bridge_valid,read_hit,local_valid;
 logic[63:0]bridge_data,local_data;
 logic soft_q;logic[31:0]epoch_q;
 wire reload=soft_reset && !soft_q;
 wire lifecycle=hard_reset || download_active || reload || epoch!=epoch_q;
 wire current_fault=boundary_fault || (fault_valid && fault_response.epoch==epoch && !lifecycle);
 // The owner is captured at logical issue, not inferred from the retained
 // arbiter's last completed/pending owner before its nonblocking ACK update.
 assign select_warm=source_owned ? owned_warm : warm_req;
 assign source_req=select_warm ? warm_req : req;
 assign source_address=select_warm ? warm_address : address;
 assign ready=source_ready && !select_warm;
 assign warm_ready=source_ready && select_warm;
 assign valid=source_valid && !owned_warm;
 assign warm_valid=source_valid && owned_warm;
 assign avalon_read=bridge_read && !read_hit;
 assign bridge_busy=read_hit ? local_wait : avalon_busy;
 assign bridge_valid=avalon_valid || local_valid;
 assign bridge_data=local_valid ? local_data : avalon_data;
 // Both frozen backend and observer must see the same actual/local completion.
 // Otherwise Golden retains RD_WAIT after a local hit and its timer/ready leaks
 // into the next request, despite the logical ledger already being complete.
 assign backend_response_valid=bridge_valid;
 assign backend_response_data=bridge_data;
 always_ff @(posedge clk)begin
  if(power_reset)begin soft_q<=0;epoch_q<=epoch;source_owned<=0;owned_warm<=0;owned_epoch<=epoch;owned_address<=0;owned_command<=0;owned_prefix<=0;end
  else begin
   soft_q<=soft_reset;epoch_q<=epoch;
   if(captured)begin
    source_owned<=1;owned_warm<=select_warm;owned_epoch<=epoch;owned_address<={9'd0,source_address};
    owned_command<=!select_warm && command_read_owner;
    owned_prefix<=!select_warm && command_read_owner && prefix_capture;
   end
   if(source_valid || fault_valid)source_owned<=0;
  end
 end
 engine_b_vnext_playback_core #(.SYS_CLK_HZ(SYS_CLK_HZ),.ENABLE_YM2610B(ENABLE_YM2610B),.SCHEDULER_DEPTH(SCHEDULER_DEPTH),.PREFIX_BUFFER_WORDS(PREFIX_BUFFER_WORDS),.STRICT_READER_BINDING(1),.COMMAND_WORD_FILL(1),.RESOURCE_PREPARE(RESOURCE_PREPARE),.LOOP_PREFIX(LOOP_PREFIX)) core(
  .prefix_fetch_valid,.prefix_fetch_urgent,.prefix_fetch_slot,.prefix_fetch_ready,.prefix_fetch_rsp_valid,.prefix_fetch_rsp_command,
  .prefix_fetch_rsp_address,.prefix_fetch_rsp_epoch,.prefix_fetch_rsp_data,.prepared_word_count,
  .clk,.hard_reset(hard_reset || power_reset),.soft_reset,.ioctl_download(download_active),.load_done_pulse,
  .file_size,.load_generation(epoch[7:0]),.mem_req(req),.mem_addr(address),.mem_ready(ready),.mem_valid(valid),.mem_data(data),
  .prewarm_ready(prepared),.prewarm_fault(prepare_fault),.prewarm_mem_req(warm_req),.prewarm_mem_addr(warm_address),
  .prewarm_mem_ready(warm_ready),.prewarm_mem_valid(warm_valid),.prewarm_query_address(query_address),.prewarm_query_hit(query_hit),.prewarm_store_fault(store_fault),
  .prefix_capture,.prefix_replay,.prefix_ready,.prefix_start,.prefix_end,.command_read_owner,
  .read_epoch(epoch),.word_valid,.word_address,.word_epoch,.word_data,.strict_memory_fault(current_fault),.audio_l,.audio_r,.audio_sample,.external_mute,.start_pulse,.fatal_active,.fatal_code,.load_state,
  .channel_activity,.loop_count,.parser_samples(playback_samples),.start_count,.scanner_start_count,.parser_command_count(command_count),
`ifdef GOLDEN_TRANSPORT_V1_2
  .transport_loop_valid(loop_valid),
`endif
  .transport_halt_loop,.transport_finish,.transport_parser_done,.transport_audio_ready,.transport_loop_entry,.transport_loop_boundary);
 engine_b_vnext_shared_reader_binding reader(
  .clk,.power_reset,.backend_reset(hard_reset),.download_active,.session_reload(reload || epoch!=epoch_q),.current_epoch(epoch),
  .file_extent(file_size),.backend_loaded,.backend_load_error,.request_valid(source_req),.request_ready(source_ready),.request_address({9'd0,source_address}),
  .response_valid(source_valid),.response_byte(data),.fault_valid,.fault_response,.request_captured(captured),
  .golden_request,.golden_byte_address,.golden_ready,.golden_valid,.golden_read,.golden_write,.golden_address,.golden_be,.golden_burst,
  .golden_busy,.avalon_read(bridge_read),.avalon_address,.avalon_be,.avalon_burst,.avalon_busy(bridge_busy),.avalon_valid(bridge_valid),.avalon_data(bridge_data),
  .word_valid,.word_address,.word_epoch,.word_data,.logical_active,.drain_blocked,.boundary_fault);
 generate if(RESOURCE_PREPARE)begin : with_prepared_words
  engine_b_vnext_prepared_word_store #(.DDRAM_BASE(DDRAM_BASE_ADDR),.LOOP_PREFIX(LOOP_PREFIX),.PREFETCH_PORT(PREFIX_BUFFER_WORDS>0),.SHARE_PREP_LOOKUP(1)) store(
   .fetch_valid(prefix_fetch_valid),.fetch_urgent(prefix_fetch_urgent),.fetch_slot(prefix_fetch_slot),.fetch_ready(prefix_fetch_ready),
   .fetch_rsp_valid(prefix_fetch_rsp_valid),.fetch_rsp_command(prefix_fetch_rsp_command),
   .fetch_rsp_address(prefix_fetch_rsp_address),.fetch_rsp_epoch(prefix_fetch_rsp_epoch),.fetch_rsp_data(prefix_fetch_rsp_data),.local_wait,
   .clk,.power_reset,.new_track(lifecycle || load_state==4'd2),.prepared,
   .epoch,.file_extent(file_size),.prefix_start,.prefix_end,
   .prefix_use(prefix_replay && prefix_ready && owned_command),.read_byte_address(owned_address),
   .fill_prefix(owned_prefix),
   .fill_valid(word_valid && (owned_warm || (LOOP_PREFIX && owned_prefix)) && owned_epoch==epoch && !lifecycle),.fill_address(word_address),.fill_data(word_data),
   .query_address,.query_hit,.bridge_read,.bridge_address(avalon_address),.bridge_busy,.read_hit,.local_valid,.local_data,.fault(store_fault),.word_count(prepared_word_count),.resource_count(),.prefix_count());
 end else begin : without_prepared_words
  assign prefix_fetch_ready=0;assign prefix_fetch_rsp_valid=0;assign prefix_fetch_rsp_command=0;
  assign prefix_fetch_rsp_address=0;assign prefix_fetch_rsp_epoch=0;assign prefix_fetch_rsp_data=0;assign prepared_word_count=0;assign local_wait=0;
  assign query_hit=0;assign store_fault=0;assign read_hit=0;assign local_valid=0;assign local_data=0;
 end endgenerate
`ifndef GOLDEN_TRANSPORT_V1_2
 assign loop_valid=0;
`endif
endmodule
