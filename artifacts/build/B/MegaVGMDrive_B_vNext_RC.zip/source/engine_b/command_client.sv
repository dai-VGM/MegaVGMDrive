// Simulation candidate: one immutable Common decoder used for both transactions.
// Header snoop uses public accepted byte addresses; no second command grammar.
module engine_b_vnext_command_client #(
 parameter int ADDR_WIDTH=23, SCHEDULER_DEPTH=16, PREFIX_BUFFER_WORDS=0,
 parameter bit ENABLE_YM2610B=1, COMMAND_WORD_FILL=0, RESOURCE_PREPARE=0, LOOP_PREFIX=0
)(
 input logic clk,reset,preflight_start,playback_reset,playback_start,sample_tick,
 output logic prefix_fetch_valid,prefix_fetch_urgent,output logic[7:0]prefix_fetch_slot,
 input logic prefix_fetch_ready,prefix_fetch_rsp_valid,prefix_fetch_rsp_command,
 input logic[31:0]prefix_fetch_rsp_address,prefix_fetch_rsp_epoch,
 input logic[63:0]prefix_fetch_rsp_data,input logic[8:0]prepared_word_count,

 input logic [31:0] file_size,read_epoch,
 input logic word_valid,input logic [31:0] word_address,word_epoch,input logic [63:0] word_data,
 output logic scan_req, output logic [ADDR_WIDTH-1:0] scan_addr,
 input logic scan_ready,scan_valid, input logic [7:0] scan_data,
 output logic play_req, output logic [ADDR_WIDTH-1:0] play_addr,
 input logic play_ready,play_valid, input logic [7:0] play_data,
 output logic preflight_busy,preflight_done,preflight_accepted,
 output logic [3:0] classification, output logic [7:0] reject_code,
 output logic [31:0] original_size,data_start,chip_clock,loop_target,
 output logic variant_b,
 output logic [31:0] total_samples,total_writes,port0_writes,port1_writes,
 output logic [31:0] b_only_writes,unknown_writes,first_bad_pc,first_bad_sample,
 output logic first_bad_port,output logic [7:0] first_bad_address,first_bad_data,
 output logic [3:0] first_bad_semantic,output logic [2:0] first_bad_target,
 output logic [3:0] descriptor_a_count,descriptor_b_count,
 output logic map_req_ready,map_rsp_valid,map_rsp_hit,
 input logic map_req_valid,map_space_b,input logic [23:0] map_logical_addr,
 output logic [ADDR_WIDTH-1:0] map_rsp_file_addr,
 output logic prewarm_ready,prewarm_fault,prewarm_mem_req,
 output logic[ADDR_WIDTH-1:0]prewarm_mem_addr,prewarm_query_address,
 input logic prewarm_mem_ready,prewarm_mem_valid,prewarm_query_hit,prewarm_store_fault,
 output logic resource_quiesce,
 output logic prefix_capture,prefix_replay,prefix_ready,
 output logic[31:0]prefix_start,prefix_end,
 output logic write_valid,write_port,output logic [7:0] write_address,write_data,
 input logic write_ready,transport_halt_loop,transport_finish,
 output logic running,finished,error,loop_entry,loop_boundary,
 output logic [31:0] pc,samples,writes,p0,p1,loop_count,command_count,
 output logic [7:0] opcode,
 output logic trace_valid,output logic [31:0] trace_pc,trace_sample,
 output logic [63:0] due_time,playback_time,
 output logic [$clog2(SCHEDULER_DEPTH):0] queue_level
);
 import vgm_parser_vnext_event_pkg::*;
 import vgm_scheduler_vnext_pkg::*;
 logic playback,decode_start,decoder_done,decoder_loop_present,entry_seen;
 logic header_running,pf_started,pf_busy,pf_start,replay_prepare;logic [31:0] extent;
 logic req,ready,rsp,range_fault,owned_read;
 logic memory_req,memory_ready,memory_rsp;
 logic external_memory_req,local_selected,local_ready,local_rsp,local_word_valid,local_fault;
 logic[7:0]local_byte;logic[63:0]local_word;logic[31:0]local_address,local_epoch;logic [31:0] memory_address;logic[7:0] memory_data;logic [31:0] address,owned_addr;
 logic decoder_request,metadata_active,metadata_pending,metadata_done_start;
 logic [1:0] metadata_index;logic [31:0] decoder_address;
 logic [7:0] byte_data;
 logic [31:0] raw_clock,version,raw_data_offset,loop_pc;
 logic ev_valid,ev_ready,df_valid,dac_valid,lt_valid,fact_valid,fact_ready,pf_ready;
 decode_event_t ev;write_descriptor_t wi;data_event_t df;dac_stream_fact_t dac;
 normalized_fact_t fact;
 decode_event_t prefix_event;
 assign prefix_event=fact.payload[79:0];
 logic [31:0] pf_commands,pf_end,pf_loop;
 logic barrier_valid,barrier_ready,scheduler_fault,loop_waiting,release_pulse,halted,terminal;
 logic [2:0] scheduler_reason;logic [63:0] sequence_id;
 logic [4:0] commit_valid,commit_ready;
 scheduled_fact_t commits[5],barrier,lane_event;
 assign lane_event=commits[4];
 write_descriptor_t resource_head;
 assign resource_head=lane_event.fact.payload[134:80];
 logic [$clog2(SCHEDULER_DEPTH):0] levels[5];
 logic adapter_accepted,invalid_target,decision_valid,decision_halt,resume_valid,resume_ready,resume_fault;
 logic [31:0] resume_pc;logic start_timeline,timeline_started;
 // No early WRITE/prewarm: reserve the speculative lookup window only.
 assign resource_quiesce=RESOURCE_PREPARE && playback && !playback_reset && timeline_started && levels[4]!=0 &&
     lane_event.fact.kind==S_WRITE && resource_head.chip==CHIP_YM2610_FAMILY &&
     lane_event.due_time>playback_time && lane_event.due_time-playback_time<=64'd1 &&
     ((resource_head.port && resource_head.address==16'h00 && !resource_head.data[7] && |resource_head.data[5:0]) ||
      (!resource_head.port && resource_head.address==16'h10 && resource_head.data[7] && !resource_head.data[0]));
 logic scheduler_ready,adapter_ready;
 logic plan_fact_ready,warm_busy,warm_map_req,warm_map_ready,warm_map_space,warm_map_valid,warm_map_hit;
 logic[23:0]warm_map_logical;logic[ADDR_WIDTH-1:0]warm_map_file;
 // Pre-PLAY resource-only replay carries terminal register shadows into
 // the validated loop. No Transport policy, chip reset or timeline pause.
 logic loop_planning,plan_resume_pending,plan_finish,resource_plan_fault;
 logic continuation_resume_valid;logic[31:0]continuation_resume_pc;
 logic pf_map_ready,pf_map_valid,pf_map_hit;logic[ADDR_WIDTH-1:0]pf_map_file;
 wire selected_map_req=warm_busy ? warm_map_req : map_req_valid;
 wire selected_map_space=warm_busy ? warm_map_space : map_space_b;
 wire[23:0]selected_map_logical=warm_busy ? warm_map_logical : map_logical_addr;
 assign warm_map_ready=warm_busy && pf_map_ready;
 assign warm_map_valid=warm_busy && pf_map_valid;assign warm_map_hit=pf_map_hit;assign warm_map_file=pf_map_file;
 assign map_req_ready=!warm_busy && pf_map_ready;
 assign map_rsp_valid=!warm_busy && pf_map_valid;assign map_rsp_hit=pf_map_hit;assign map_rsp_file_addr=pf_map_file;
 generate if(RESOURCE_PREPARE)begin : with_prewarm
  engine_b_vnext_prewarm_client #(.ADDR_WIDTH(ADDR_WIDTH)) resources(
   .clk,.reset,.preflight_pass(plan_finish),
   .fact_valid(fact_valid && !playback && (loop_planning ? !plan_resume_pending : pf_started && pf_ready)),.fact_ready(plan_fact_ready),.fact,
   .ready(prewarm_ready),.busy(warm_busy),.fault(resource_plan_fault),
   .map_req_valid(warm_map_req),.map_req_ready(warm_map_ready),.map_space_b(warm_map_space),.map_logical_addr(warm_map_logical),
   .map_rsp_valid(warm_map_valid),.map_rsp_hit(warm_map_hit),.map_rsp_file_addr(warm_map_file),.file_extent(file_size),
   .mem_req(prewarm_mem_req),.mem_addr(prewarm_mem_addr),.mem_ready(prewarm_mem_ready),.mem_valid(prewarm_mem_valid),
   .word_query_address(prewarm_query_address),.word_query_hit(prewarm_query_hit),.word_store_fault(prewarm_store_fault),.plan_count());
 end else begin : without_prewarm
  assign plan_fact_ready=1;assign prewarm_ready=1;assign resource_plan_fault=0;assign warm_busy=0;
  assign prewarm_mem_req=0;assign prewarm_mem_addr=0;assign prewarm_query_address=0;
  assign warm_map_req=0;assign warm_map_space=0;assign warm_map_logical=0;
 end endgenerate
 // Preparation may read the immutable header/first command during the retained
 // chip reset/init/settle fence; queue read-ahead is prepared at logical time
 // zero (sample_tick is held by the retained lifecycle). Actual playback_start
 // starts the timeline even if slow storage has not supplied the first fact.
 // No post-start fetch/busy condition can stop this timeline. No WRITE can pass
 // until playback_reset releases. Playback never gates tick on fetch/busy.
 assign prewarm_fault=resource_plan_fault || local_fault || (RESOURCE_PREPARE && !playback && resume_fault) ||
     (LOOP_PREFIX && RESOURCE_PREPARE && replay_prepare && decoder_loop_present && !prefix_ready);
 assign resume_valid=playback ? continuation_resume_valid : plan_resume_pending;
 assign resume_pc=playback ? continuation_resume_pc : loop_target;
 assign replay_prepare=plan_finish && !playback;
 assign decode_start=metadata_done_start || replay_prepare;
 assign req=metadata_active ? !metadata_pending : decoder_request;
 assign address=metadata_active ? 32'd76+{30'd0,metadata_index} : decoder_address;
 assign original_size=extent;
 assign pf_start=fact_valid && !playback && !pf_started;
 assign preflight_busy=header_running || pf_busy || loop_planning;
 assign chip_clock=raw_clock & 32'h3fffffff;
 assign variant_b=raw_clock[31];
 assign scan_req=external_memory_req && !playback && !range_fault;
 assign play_req=external_memory_req && playback && !range_fault && !transport_finish;
 assign scan_addr=memory_address[ADDR_WIDTH-1:0];assign play_addr=scan_addr;
 assign external_memory_req=memory_req && !local_selected;
 assign memory_ready=local_selected ? local_ready : playback ? play_ready : scan_ready;
 assign memory_rsp=local_rsp || (playback ? play_valid : scan_valid);
 assign memory_data=local_rsp ? local_byte : playback ? play_data : scan_data;
 assign range_fault=req && (address>=file_size || (address>>ADDR_WIDTH)!=0);
 assign fact_ready=playback ? scheduler_ready : loop_planning ? (!plan_resume_pending && plan_fact_ready) : (pf_ready && pf_started && plan_fact_ready);
 assign queue_level=levels[4];
 assign start_timeline=playback && !timeline_started &&
                       (playback_start || (fact_valid && scheduler_ready));
 // DATA metadata is already validated by PASS1; its playback barrier may
 // drain during the retained chip initialization fence. Transport boundaries
 // remain fenced until actual playback. No chip WRITE can pass this fence.
 assign barrier_ready=playback && !transport_finish && (!playback_reset || barrier.fact.kind==S_DATA);
 assign loop_entry=barrier_valid && barrier_ready && barrier.fact.kind==S_LOOP_ENTRY;
 assign loop_boundary=barrier_valid && barrier_ready && barrier.fact.kind==S_LOOP_BOUNDARY;
 assign running=playback && timeline_started && !finished && !error;
 assign finished=terminal || halted || (playback && transport_finish);
 assign error=scheduler_fault || invalid_target || resume_fault || range_fault;
 assign pc=source_pc(fact);assign opcode=ev.opcode;
 assign samples=playback_time[31:0];
 always_comb begin
  commit_ready='0;commit_ready[4]=adapter_ready;
 end
 generate if(PREFIX_BUFFER_WORDS>0 && LOOP_PREFIX && RESOURCE_PREPARE)begin : with_prefix_runway
  engine_b_vnext_prefix_word_prefetch #(.DEPTH(PREFIX_BUFFER_WORDS)) runway(
   .clk,.reset,.prepared(prewarm_ready),.prefix_ready,.prefix_replay,
   .epoch(read_epoch),.file_extent(file_size),.prefix_start,.prefix_end,.store_count(prepared_word_count),
   .fetch_valid(prefix_fetch_valid),.fetch_urgent(prefix_fetch_urgent),.fetch_slot(prefix_fetch_slot),.fetch_ready(prefix_fetch_ready),
   .fetch_rsp_valid(prefix_fetch_rsp_valid),.fetch_rsp_command(prefix_fetch_rsp_command),
   .fetch_rsp_address(prefix_fetch_rsp_address),.fetch_rsp_epoch(prefix_fetch_rsp_epoch),.fetch_rsp_data(prefix_fetch_rsp_data),
   .request(memory_req),.address(memory_address),.selected(local_selected),.ready(local_ready),
   .response_valid(local_rsp),.word_valid(local_word_valid),.response_byte(local_byte),.response_word(local_word),
   .response_address(local_address),.response_epoch(local_epoch),.fault(local_fault));
 end else begin : without_prefix_runway
  assign prefix_fetch_valid=0;assign prefix_fetch_urgent=0;assign prefix_fetch_slot=0;
  assign local_selected=0;assign local_ready=0;assign local_rsp=0;assign local_word_valid=0;assign local_fault=0;
  assign local_byte=0;assign local_word=0;assign local_address=0;assign local_epoch=0;
 end endgenerate
 generate if(COMMAND_WORD_FILL)begin : with_command_words
 engine_b_vnext_command_word_buffer command_words(
  .clk,.reset,.enable(COMMAND_WORD_FILL),.epoch(read_epoch),.file_extent(file_size),
  .byte_request(req && !range_fault),.byte_address(address),.byte_ready(ready),.byte_valid(rsp),.byte_data,
  .memory_request(memory_req),.memory_address,.memory_ready,.memory_valid(memory_rsp),.memory_data,
  .word_valid(word_valid || local_word_valid),.word_address(local_word_valid ? local_address : word_address),
  .word_epoch(local_word_valid ? local_epoch : word_epoch),.word_data(local_word_valid ? local_word : word_data));
 end else begin : without_command_words
  assign memory_req=req && !range_fault;assign memory_address=address;
  assign ready=memory_ready;assign rsp=memory_rsp;assign byte_data=memory_data;
 end endgenerate
 // PASS1 descriptors/totals are committed once. Replay only augments the
 // resource plan, using the already validated loop target and carried shadow.
 always_ff @(posedge clk)begin
  if(reset)begin loop_planning<=0;plan_resume_pending<=0;plan_finish<=0;end
  else begin
   plan_finish<=0;
   if(preflight_done && preflight_accepted && !playback)begin
    if(RESOURCE_PREPARE && decoder_loop_present)begin loop_planning<=1;plan_resume_pending<=1;end
    else plan_finish<=1;
   end
   if(plan_resume_pending && resume_ready)plan_resume_pending<=0;
   if(loop_planning && !plan_resume_pending && fact_valid && fact_ready && fact.kind==S_LOOP_BOUNDARY)begin
    loop_planning<=0;plan_finish<=1;
   end
  end
 end
 // Raw prefix planning uses accepted Common facts only. Positive WAIT is a
 // forward logical-horizon candidate; the corpus/audio gate validates that
 // this exact extent suffices (including the dense Stage6 initial burst).
 // The current prefix is immutable and reused only for owner CONTINUE resumes.
 always_ff @(posedge clk)begin
  if(reset)begin prefix_capture<=0;prefix_replay<=0;prefix_ready<=0;prefix_start<=0;prefix_end<=0;end
  else if(LOOP_PREFIX && RESOURCE_PREPARE)begin
   if(loop_planning && plan_resume_pending && resume_ready)begin
    prefix_capture<=1;prefix_start<=loop_target;prefix_end<=0;prefix_ready<=0;
   end
   if(prefix_capture && fact_valid && fact_ready)begin
    if(fact.kind==S_WAIT && fact.time_advance!=0)begin
     prefix_capture<=0;prefix_ready<=1;
     prefix_end<=prefix_event.source_pc+32'd1+{30'd0,prefix_event.operand_count};
    end else if(fact.kind==S_LOOP_BOUNDARY)begin
     prefix_capture<=0;prefix_ready<=1;prefix_end<=source_pc(fact)+32'd1;
    end
   end
   if(playback && continuation_resume_valid && resume_ready && prefix_ready)prefix_replay<=1;
   if(prefix_replay && req && ready && address>=prefix_end)prefix_replay<=0;
  end
 end
 // Track mode changes only after accepted preflight. No PASS1 audible path.
 always_ff @(posedge clk)begin
  if(reset)begin playback<=0;raw_clock<=0;version<=0;raw_data_offset<=0;owned_read<=0;owned_addr<=0;header_running<=0;pf_started<=0;metadata_active<=0;metadata_pending<=0;metadata_index<=0;metadata_done_start<=0;end
  else begin
   metadata_done_start<=0;
   if(preflight_start)begin
    header_running<=1;raw_clock<=0;
    if(file_size>=128)begin metadata_active<=1;metadata_index<=0;metadata_pending<=0;end
    else metadata_done_start<=1;
   end
   if(metadata_active && req && ready)metadata_pending<=1;
   if(metadata_active && rsp && metadata_pending)begin
    raw_clock[metadata_index*8+:8]<=byte_data;metadata_pending<=0;
    if(metadata_index==3)begin metadata_active<=0;metadata_done_start<=1;end
    else metadata_index<=metadata_index+1'b1;
   end
   if(pf_start)begin pf_started<=1;header_running<=0;end
   if(replay_prepare)playback<=1;
   if(req && ready && !range_fault)begin owned_read<=1;owned_addr<=address;end
   if(rsp && owned_read)begin
    owned_read<=0;
    if(!playback && !metadata_active)case(owned_addr)
     8,9,10,11:version[(owned_addr-8)*8+:8]<=byte_data;
     52,53,54,55:raw_data_offset[(owned_addr-52)*8+:8]<=byte_data;
     76,77,78,79:raw_clock[(owned_addr-76)*8+:8]<=byte_data;
     default:begin end
    endcase
   end
  end
 end
 always_ff @(posedge clk)begin
  trace_valid<=0;
  if(reset || replay_prepare)begin
   timeline_started<=0;writes<=0;p0<=0;p1<=0;loop_count<=0;command_count<=0;
   trace_pc<=0;trace_sample<=0;
  end else begin
   if(start_timeline)timeline_started<=1;
   if(playback && fact_valid && scheduler_ready)command_count<=command_count+1;
   if(adapter_accepted)begin
    writes<=writes+1;if(write_port)p1<=p1+1;else p0<=p0+1;
    trace_valid<=1;trace_pc<=source_pc(lane_event.fact);trace_sample<=lane_event.due_time[31:0];
   end
   if(playback && continuation_resume_valid && resume_ready)loop_count<=loop_count+1;
  end
 end
 vgm_parser_vnext_decoder #(.DATA_GRAMMAR(1),.DAC_GRAMMAR(1),.COMMON_WRITE_GRAMMAR(1),.RESUME_CONTROL(1)) decoder(
  .clk,.reset,.start(decode_start),.resume_valid,.resume_pc,.resume_ready,.resume_fault,.image_size(file_size),
  .reader_req_valid(decoder_request),.reader_req_ready(ready && !metadata_active && !range_fault),.reader_req_addr(decoder_address),
  .reader_rsp_valid(rsp && !metadata_active),.reader_rsp_byte(byte_data),.event_valid(ev_valid),.event_ready(ev_ready),
  .event_data(ev),.write_info(wi),.data_event_valid(df_valid),.data_event_data(df),
  .dac_fact_valid(dac_valid),.dac_fact_data(dac),.done(decoder_done),.file_extent(extent),.data_start,
  .loop_present(decoder_loop_present),.loop_target,.loop_terminal_valid(lt_valid),.loop_terminal_pc(loop_pc),.loop_entry_seen(entry_seen));
 vgm_scheduler_vnext_normalizer normalizer(
  .clk,.reset(reset || replay_prepare),.event_valid(ev_valid),.data_event_valid(df_valid),.dac_fact_valid(dac_valid),
  .loop_terminal_valid(lt_valid),.event_data(ev),.write_info(wi),.data_event_data(df),.dac_fact_data(dac),
  .loop_present(decoder_loop_present),.loop_target,.loop_terminal_pc(loop_pc),.event_ready(ev_ready),.fact_valid,.fact_ready,.fact);
 engine_b_vnext_preflight #(.ADDR_WIDTH(ADDR_WIDTH),.ENABLE_YM2610B(ENABLE_YM2610B)) preflight(
  .clk,.reset,.start(pf_start),.clock_field(raw_clock),.header_version(version),.raw_data_offset,
  .file_extent(extent),.data_start,.loop_target,.fact_valid(fact_valid && !playback && !loop_planning && pf_started && plan_fact_ready),.fact_ready(pf_ready),.fact,
  .busy(pf_busy),.done(preflight_done),.accepted(preflight_accepted),.classification,.reject_code,
  .total_samples,.total_writes,.port0_writes,.port1_writes,.b_only_writes,.unknown_writes,
  .command_count(pf_commands),.end_pc(pf_end),.loop_samples(pf_loop),.first_bad_pc,.first_bad_sample,
  .first_bad_port,.first_bad_address,.first_bad_data,.first_bad_semantic,.first_bad_target,
  .descriptor_a_count,.descriptor_b_count,.descriptor_a_count_full(),.descriptor_b_count_full(),
  .map_req_valid(selected_map_req),.map_req_ready(pf_map_ready),.map_space_b(selected_map_space),.map_logical_addr(selected_map_logical),.map_rsp_valid(pf_map_valid),.map_rsp_hit(pf_map_hit),.map_rsp_file_addr(pf_map_file));
 vgm_scheduler_vnext #(.TARGETS(5),.DEPTH(SCHEDULER_DEPTH)) scheduler(
  .clk,.reset(reset || replay_prepare),.play_start(start_timeline),.playback_tick(sample_tick),
  .fact_valid(fact_valid && playback),.fact_ready(scheduler_ready),.fact,.commit_valid,.commit_ready,.commits,
  .barrier_valid,.barrier_ready,.barrier,.loop_decision_valid(decision_valid),.loop_halt(decision_halt),
  .loop_waiting,.loop_release_pulse(release_pulse),.halted,.terminal,.fault_latched(scheduler_fault),.fault_reason(scheduler_reason),
  .due_time,.playback_time,.next_sequence(sequence_id),.levels);
 engine_b_vnext_playback_adapter adapter(
  .enabled(playback && !playback_reset && !transport_finish),.valid(commit_valid[4]),.event_data(commits[4]),
  .ready(adapter_ready),.write_valid,.write_port,.write_address,.write_data,.write_ready,.accepted(adapter_accepted),.invalid_target);
 engine_a_vnext_loop_continuation_client continuation(
  .clk,.reset(reset || playback_reset),.new_track(1'b0),.boundary_valid(loop_boundary),.boundary_ready(1'b1),
  .boundary_target(barrier.fact.payload[63:32]),.owner_halt(transport_halt_loop),.scheduler_waiting(loop_waiting),
  .scheduler_release(release_pulse),.decision_valid,.decision_halt,.resume_valid(continuation_resume_valid),.resume_ready(resume_ready && playback),.resume_pc(continuation_resume_pc),.busy());
endmodule
