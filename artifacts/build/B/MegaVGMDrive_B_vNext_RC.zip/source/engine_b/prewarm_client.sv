`timescale 1ns/1ps
// Candidate-only resource preparation. Consumes accepted PASS1 WRITE facts,
// never commands a sound core. Prepared bytes are immutable for this epoch.
module engine_b_vnext_prewarm_client #(
 parameter int ADDR_WIDTH=23, PLAN_DEPTH=256
)(
 input logic clk,reset,preflight_pass,
 input logic fact_valid,output logic fact_ready,
 input vgm_scheduler_vnext_pkg::normalized_fact_t fact,
 output logic ready,busy,fault,
 output logic map_req_valid,input logic map_req_ready,
 output logic map_space_b,output logic[23:0]map_logical_addr,
 input logic map_rsp_valid,map_rsp_hit,input logic[ADDR_WIDTH-1:0]map_rsp_file_addr,
 input logic[31:0] file_extent,
 output logic mem_req,output logic[ADDR_WIDTH-1:0]mem_addr,
 input logic mem_ready,mem_valid,
 output logic[ADDR_WIDTH-1:0]word_query_address,input logic word_query_hit,
 input logic word_store_fault,
 output logic[$clog2(PLAN_DEPTH):0]plan_count
);
 import vgm_parser_vnext_event_pkg::*;
 import vgm_scheduler_vnext_pkg::*;
 localparam int PTR=$clog2(PLAN_DEPTH);
 typedef enum logic[3:0]{COLLECT,PLAN_READ,PLAN_COMPARE,PLAN_APPEND,
  W_PLAN_READ,W_PLAN_USE,W_MAP,W_MAP_WAIT,W_READ,W_READ_WAIT,W_NEXT,READY,FAULT} state_t;
 state_t state;
 write_descriptor_t descriptor;assign descriptor=fact.payload[134:80];
 logic[15:0]start_a[6],start_b;
 (* ramstyle="M10K, no_rw_check" *)logic[16:0]plan[PLAN_DEPTH];
 logic[16:0]plan_q,key;
 logic[PTR-1:0]compare_index,warm_index;
 logic[5:0]remaining;
 logic[2:0]byte_offset;logic[16:0]warm_key;
 logic[ADDR_WIDTH-1:0]requested_file;
 wire warming=state>=W_PLAN_READ && state<=W_NEXT;
 function automatic logic[2:0]first_voice(input logic[5:0]mask);
  begin first_voice=0;for(integer v=5;v>=0;v=v-1)if(mask[v])first_voice=3'(v);end
 endfunction
 wire[2:0]selected_voice=first_voice(remaining);
 wire accepted=fact_valid && fact_ready;
 assign fact_ready=state==COLLECT && !reset && !preflight_pass;
 assign ready=state==READY;
 assign busy=warming;
 assign fault=state==FAULT || word_store_fault;
 assign map_req_valid=state==W_MAP && !reset;
 assign map_space_b=warm_key[16];
 assign map_logical_addr={warm_key[15:0],8'd0}+{21'd0,byte_offset};
 assign mem_req=state==W_READ && !word_query_hit && !reset && !fault;
 assign mem_addr=requested_file;assign word_query_address=requested_file;
 always_ff @(posedge clk)begin
  plan_q<=plan[warming ? warm_index : compare_index];
  if(reset)begin
   state<=COLLECT;plan_count<=0;compare_index<=0;warm_index<=0;
   key<=0;remaining<=0;warm_key<=0;byte_offset<=0;requested_file<=0;start_b<=0;
   for(integer v=0;v<6;v=v+1)start_a[v]<=0;
  end else if(word_store_fault)state<=FAULT;
  else case(state)
   COLLECT:begin
    if(preflight_pass)begin
     warm_index<=0;
     if(plan_count==0)state<=READY;else state<=W_PLAN_READ;
    end else if(accepted && fact.kind==S_WRITE && descriptor.chip==CHIP_YM2610_FAMILY &&
                !descriptor.instance_id && descriptor.access_kind==ACCESS_REGISTER)begin
     if(descriptor.port)begin
      if(descriptor.address>=16'h10 && descriptor.address<=16'h15)
       start_a[descriptor.address[2:0]][7:0]<=descriptor.data;
      if(descriptor.address>=16'h18 && descriptor.address<=16'h1d)
       start_a[descriptor.address[2:0]][15:8]<=descriptor.data;
      if(descriptor.address==0 && !descriptor.data[7] && |descriptor.data[5:0])begin
       key<={1'b0,start_a[first_voice(descriptor.data[5:0])]};
       remaining<=descriptor.data[5:0] & ~(6'b1<<first_voice(descriptor.data[5:0]));
       compare_index<=0;if(plan_count==0)state<=PLAN_APPEND;else state<=PLAN_READ;
      end
     end else begin
      if(descriptor.address==16'h12)start_b[7:0]<=descriptor.data;
      if(descriptor.address==16'h13)start_b[15:8]<=descriptor.data;
      if(descriptor.address==16'h10 && descriptor.data[7] && !descriptor.data[0])begin
       key<={1'b1,start_b};remaining<=0;compare_index<=0;
       if(plan_count==0)state<=PLAN_APPEND;else state<=PLAN_READ;
      end
     end
    end
   end
   PLAN_READ:state<=PLAN_COMPARE;
   PLAN_COMPARE:begin
    if(plan_q==key)begin
     if(remaining!=0)begin
      key<={1'b0,start_a[selected_voice]};remaining<=remaining & ~(6'b1<<selected_voice);
      compare_index<=0;state<=PLAN_READ;
     end else state<=COLLECT;
    end else if({1'b0,compare_index}+1'b1>=plan_count)state<=PLAN_APPEND;
    else begin compare_index<=compare_index+1'b1;state<=PLAN_READ;end
   end
   PLAN_APPEND:begin
    if(plan_count==($clog2(PLAN_DEPTH)+1)'(PLAN_DEPTH))state<=FAULT;
    else begin
     plan[plan_count[PTR-1:0]]<=key;plan_count<=plan_count+1'b1;
     if(remaining!=0)begin
      key<={1'b0,start_a[selected_voice]};remaining<=remaining & ~(6'b1<<selected_voice);
      compare_index<=0;state<=PLAN_READ;
     end else state<=COLLECT;
    end
   end
   W_PLAN_READ:state<=W_PLAN_USE;
   W_PLAN_USE:begin warm_key<=plan_q;byte_offset<=0;state<=W_MAP;end
   W_MAP:if(map_req_ready)state<=W_MAP_WAIT;
   W_MAP_WAIT:if(map_rsp_valid)begin
    if(!map_rsp_hit || {{(32-ADDR_WIDTH){1'b0}},map_rsp_file_addr}>=file_extent)state<=FAULT;
    else begin requested_file<=map_rsp_file_addr;state<=W_READ;end
   end
   W_READ:begin
    if(word_query_hit)state<=W_NEXT;
    else if(mem_ready)state<=W_READ_WAIT;
   end
   W_READ_WAIT:if(mem_valid)state<=W_NEXT;
   W_NEXT:begin
    if(byte_offset==(warm_key[16] ? 3'd7 : 3'd1))begin
     if({1'b0,warm_index}+1'b1>=plan_count)state<=READY;
     else begin warm_index<=warm_index+1'b1;state<=W_PLAN_READ;end
    end else begin byte_offset<=byte_offset+1'b1;state<=W_MAP;end
   end
   default:begin end
  endcase
 end
endmodule
