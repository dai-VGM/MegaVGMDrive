`timescale 1ns/1ps
// Candidate PASS1 only. No byte/opcode fetch and no chip-write/audio interface.
// RAM/map/overlap machinery reused verbatim from accepted production B scanner.
module engine_b_vnext_preflight #(
 parameter int ADDR_WIDTH=23, MAX_A_DESCRIPTORS=64, MAX_B_DESCRIPTORS=16,
 parameter bit ENABLE_YM2610B=1
)(
 input logic clk, reset, start,
 // Supplemental B admission metadata, not a second VGM command decoder.
 input logic [31:0] clock_field, header_version, raw_data_offset,
 input logic [31:0] file_extent, data_start, loop_target,
 input logic fact_valid, output logic fact_ready,
 input vgm_scheduler_vnext_pkg::normalized_fact_t fact,
 output logic busy, done, accepted,
 output logic [3:0] classification,
 output logic [7:0] reject_code,
 output logic [31:0] total_samples,total_writes,port0_writes,port1_writes,
 output logic [31:0] b_only_writes,unknown_writes,command_count,end_pc,loop_samples,
 output logic [31:0] first_bad_pc,first_bad_sample,
 output logic first_bad_port,
 output logic [7:0] first_bad_address,first_bad_data,
 output logic [3:0] first_bad_semantic,
 output logic [2:0] first_bad_target,
 output logic [3:0] descriptor_a_count,descriptor_b_count,
 output logic [6:0] descriptor_a_count_full,
 output logic [4:0] descriptor_b_count_full,
 input logic map_req_valid, output logic map_req_ready,
 input logic map_space_b, input logic [23:0] map_logical_addr,
 output logic map_rsp_valid,map_rsp_hit,
 output logic [ADDR_WIDTH-1:0] map_rsp_file_addr
);
 import vgm_parser_vnext_event_pkg::*;
 import vgm_scheduler_vnext_pkg::*;
 localparam logic [3:0] VARIANT_NONE=0,VARIANT_STANDARD=1,VARIANT_B_COMPAT=2,VARIANT_B_REQUIRED=3,VARIANT_DUAL=4;
 localparam logic [7:0] REJECT_NONE=0,REJECT_HEADER=1,REJECT_DUAL=2,REJECT_B_REQUIRED=3,REJECT_REGISTER=4,
   REJECT_OPCODE=5,REJECT_BLOCK=6,REJECT_RANGE=7,REJECT_DESCRIPTOR=8;
 localparam logic [6:0] MAX_A_DESCRIPTOR_COUNT=7'(MAX_A_DESCRIPTORS);
 localparam logic [4:0] MAX_B_DESCRIPTOR_COUNT=5'(MAX_B_DESCRIPTORS);
 typedef enum logic [2:0] {ST_IDLE,ST_FACT,ST_DESC_READ,ST_DESC_COMPARE,ST_DESC_STORE,ST_FINISH,ST_FATAL,ST_DONE} state_t;
 state_t state;
 decode_event_t body;
 write_descriptor_t write_info;
 data_event_t block_fact;
 logic variant_b,first_bad_valid,first_bad_b_only;
 logic compat_accepted,compat_b_only,compat_unknown;
 logic [3:0] compat_semantic;
 logic [2:0] compat_target;
 logic [31:0] rom_size,logical_start;
 assign body=fact.payload[79:0];
 assign write_info=fact.payload[134:80];
 assign block_fact=fact.payload;
 assign rom_size=block_fact.operands[79:48];
 assign logical_start=block_fact.operands[111:80];
 wire compat_effective_accepted=compat_accepted || (ENABLE_YM2610B && variant_b && compat_b_only);
 assign fact_ready=state==ST_FACT && !reset && !start;
 ym2610_player_compat u_compat(.port(write_info.port),.address(write_info.address[7:0]),.data(write_info.data),
 .accepted(compat_accepted),.b_only(compat_b_only),.unknown(compat_unknown),.semantic(compat_semantic),.target(compat_target));
    // Descriptor payloads are packed into synchronous memories.  No memory
    // clear is performed: the committed count is the validity boundary, which
    // keeps the arrays eligible for Cyclone V block-RAM inference.
    localparam int A_DESC_WIDTH = 24 + 25 + ADDR_WIDTH;
    localparam int B_DESC_WIDTH = 24 + 25 + ADDR_WIDTH;
    (* ramstyle = "M10K, no_rw_check" *)
    logic [A_DESC_WIDTH-1:0] desc_a_mem [0:MAX_A_DESCRIPTORS-1];
    (* ramstyle = "M10K, no_rw_check" *)
    logic [B_DESC_WIDTH-1:0] desc_b_mem [0:MAX_B_DESCRIPTORS-1];
    logic [A_DESC_WIDTH-1:0] desc_a_q;
    logic [B_DESC_WIDTH-1:0] desc_b_q;
    logic [5:0] descriptor_read_index;
    logic descriptor_a_we, descriptor_b_we;
    logic [5:0] descriptor_a_waddr;
    logic [3:0] descriptor_b_waddr;
    logic [A_DESC_WIDTH-1:0] descriptor_a_wdata;
    logic [B_DESC_WIDTH-1:0] descriptor_b_wdata;

    logic pending_desc_space_b;
    logic [23:0] pending_desc_logical;
    logic [24:0] pending_desc_length;
    logic [ADDR_WIDTH-1:0] pending_desc_file;
    logic [6:0] overlap_index;
    logic descriptors_committed;

    typedef enum logic [1:0] {MAP_IDLE, MAP_READ, MAP_COMPARE} map_state_t;
    map_state_t map_state;
    logic map_request_space_b;
    logic [23:0] map_request_logical;
    logic [6:0] map_index;

    wire [23:0] desc_a_start = desc_a_q[A_DESC_WIDTH-1 -: 24];
    wire [24:0] desc_a_length =
        desc_a_q[A_DESC_WIDTH-24-1 -: 25];
    wire [ADDR_WIDTH-1:0] desc_a_file = desc_a_q[ADDR_WIDTH-1:0];
    wire [23:0] desc_b_start = desc_b_q[B_DESC_WIDTH-1 -: 24];
    wire [24:0] desc_b_length =
        desc_b_q[B_DESC_WIDTH-24-1 -: 25];
    wire [ADDR_WIDTH-1:0] desc_b_file = desc_b_q[ADDR_WIDTH-1:0];

    assign descriptor_a_count = descriptor_a_count_full > 7'd15 ?
                                4'hf : descriptor_a_count_full[3:0];
    assign descriptor_b_count = descriptor_b_count_full > 5'd15 ?
                                4'hf : descriptor_b_count_full[3:0];
    assign map_req_ready = descriptors_committed && map_state == MAP_IDLE;

    always_comb begin
        descriptor_read_index = 6'd0;
        if (state == ST_DESC_READ)
            descriptor_read_index = overlap_index[5:0];
        else if (state == ST_DESC_COMPARE) begin
            if ((!pending_desc_space_b && overlap_index + 7'd1 <
                 descriptor_a_count_full) ||
                (pending_desc_space_b && overlap_index + 7'd1 <
                 {2'd0, descriptor_b_count_full}))
                descriptor_read_index = overlap_index[5:0] + 6'd1;
            else
                descriptor_read_index = overlap_index[5:0];
        end else if (map_state == MAP_READ)
            descriptor_read_index = map_index[5:0];
        else if (map_state == MAP_COMPARE) begin
            if ((!map_request_space_b && map_index + 7'd1 <
                 descriptor_a_count_full) ||
                (map_request_space_b && map_index + 7'd1 <
                 {2'd0, descriptor_b_count_full}))
                descriptor_read_index = map_index[5:0] + 6'd1;
            else
                descriptor_read_index = map_index[5:0];
        end

        descriptor_a_we = state == ST_DESC_STORE && !pending_desc_space_b;
        descriptor_b_we = state == ST_DESC_STORE && pending_desc_space_b;
        descriptor_a_waddr = descriptor_a_count_full[5:0];
        descriptor_b_waddr = descriptor_b_count_full[3:0];
        descriptor_a_wdata = {pending_desc_logical,
                              pending_desc_length,
                              pending_desc_file};
        descriptor_b_wdata = {pending_desc_logical,
                              pending_desc_length,
                              pending_desc_file};
    end

    always_ff @(posedge clk) begin
        if (descriptor_a_we)
            desc_a_mem[descriptor_a_waddr] <= descriptor_a_wdata;
        if (descriptor_b_we)
            desc_b_mem[descriptor_b_waddr] <= descriptor_b_wdata;
        desc_a_q <= desc_a_mem[descriptor_read_index];
        desc_b_q <= desc_b_mem[descriptor_read_index[3:0]];
    end

    // A single sequential engine serves runtime mapping after scan completion.
    // Scanner overlap checks use the same RAM read data while mapping is idle.
    always_ff @(posedge clk) begin
        map_rsp_valid <= 1'b0;
        if (reset || start) begin
            map_state <= MAP_IDLE;
            map_request_space_b <= 1'b0;
            map_request_logical <= 24'd0;
            map_index <= 7'd0;
            map_rsp_hit <= 1'b0;
            map_rsp_file_addr <= '0;
        end else begin
            case (map_state)
                MAP_IDLE: if (map_req_valid && map_req_ready) begin
                    map_request_space_b <= map_space_b;
                    map_request_logical <= map_logical_addr;
                    map_index <= 7'd0;
                    map_state <= MAP_READ;
                end
                MAP_READ: begin
                    if ((map_request_space_b && descriptor_b_count_full == 0) ||
                        (!map_request_space_b && descriptor_a_count_full == 0)) begin
                        map_rsp_valid <= 1'b1;
                        map_rsp_hit <= 1'b0;
                        map_rsp_file_addr <= '0;
                        map_state <= MAP_IDLE;
                    end else begin
                        map_state <= MAP_COMPARE;
                    end
                end
                MAP_COMPARE: begin
                    if (map_request_space_b) begin
                        if ({1'b0, map_request_logical} >=
                              {1'b0, desc_b_start} &&
                            {1'b0, map_request_logical} <
                              ({1'b0, desc_b_start} + desc_b_length)) begin
                            map_rsp_valid <= 1'b1;
                            map_rsp_hit <= 1'b1;
                            map_rsp_file_addr <= desc_b_file +
                                (map_request_logical - desc_b_start);
                            map_state <= MAP_IDLE;
                        end else if (map_index + 7'd1 >=
                                     {2'd0, descriptor_b_count_full}) begin
                            map_rsp_valid <= 1'b1;
                            map_rsp_hit <= 1'b0;
                            map_rsp_file_addr <= '0;
                            map_state <= MAP_IDLE;
                        end else begin
                            map_index <= map_index + 7'd1;
                            map_state <= MAP_COMPARE;
                        end
                    end else begin
                        if ({1'b0, map_request_logical} >=
                              {1'b0, desc_a_start} &&
                            {1'b0, map_request_logical} <
                              ({1'b0, desc_a_start} + desc_a_length)) begin
                            map_rsp_valid <= 1'b1;
                            map_rsp_hit <= 1'b1;
                            map_rsp_file_addr <= desc_a_file +
                                (map_request_logical - desc_a_start);
                            map_state <= MAP_IDLE;
                        end else if (map_index + 7'd1 >=
                                     descriptor_a_count_full) begin
                            map_rsp_valid <= 1'b1;
                            map_rsp_hit <= 1'b0;
                            map_rsp_file_addr <= '0;
                            map_state <= MAP_IDLE;
                        end else begin
                            map_index <= map_index + 7'd1;
                            map_state <= MAP_COMPARE;
                        end
                    end
                end
                default: map_state <= MAP_IDLE;
            endcase
        end
    end


 task automatic fail(input logic [7:0] code);
   reject_code<=code;state<=ST_FATAL;
 endtask
 always_ff @(posedge clk) begin
  done<=0;
  if(reset || start) begin
   if(start && !reset)state<=ST_FACT;else state<=ST_IDLE;
   busy<=start && !reset;accepted<=0;
   classification<=VARIANT_NONE;reject_code<=0;descriptors_committed<=0;
   descriptor_a_count_full<=0;descriptor_b_count_full<=0;
   total_samples<=0;total_writes<=0;port0_writes<=0;port1_writes<=0;
   b_only_writes<=0;unknown_writes<=0;command_count<=0;end_pc<=0;loop_samples<=0;
   variant_b<=clock_field[31];first_bad_valid<=0;first_bad_b_only<=0;
   first_bad_pc<=0;first_bad_port<=0;first_bad_address<=0;first_bad_data<=0;
   first_bad_sample<=0;first_bad_semantic<=0;first_bad_target<=0;
   pending_desc_space_b<=0;pending_desc_logical<=0;pending_desc_length<=0;pending_desc_file<=0;overlap_index<=0;
   if(start && !reset) begin
    if((clock_field & 32'h3fffffff)==0 || (header_version>=32'h150 && raw_data_offset==0)) fail(REJECT_HEADER);
    else if(clock_field[30]) begin classification<=VARIANT_DUAL;fail(REJECT_DUAL);end
   end
  end else case(state)
   ST_FACT: if(fact_valid && fact_ready) begin
    if(fact.kind!=S_LOOP_ENTRY)command_count<=command_count+1;
    case(fact.kind)
     S_WRITE: begin
      if(write_info.chip!=CHIP_YM2610_FAMILY || write_info.instance_id ||
         (body.opcode!=8'h58 && body.opcode!=8'h59)) fail(REJECT_OPCODE);
      else begin
       total_writes<=total_writes+1;
       if(write_info.port)port1_writes<=port1_writes+1;else port0_writes<=port0_writes+1;
       if(compat_b_only)b_only_writes<=b_only_writes+1;
       if(compat_unknown)unknown_writes<=unknown_writes+1;
       if(!compat_effective_accepted && !first_bad_valid)begin
        first_bad_valid<=1;first_bad_b_only<=compat_b_only;first_bad_pc<=body.source_pc;
        first_bad_port<=write_info.port;first_bad_address<=write_info.address[7:0];first_bad_data<=write_info.data;
        first_bad_sample<=total_samples;first_bad_semantic<=compat_semantic;first_bad_target<=compat_target;
       end
      end
     end
     S_WAIT: total_samples<=total_samples+{16'd0,fact.time_advance};
     S_DATA: begin
      if(block_fact.kind!=DATA_BLOCK || block_fact.instance_id ||
         (block_fact.block_type!=8'h82 && block_fact.block_type!=8'h83)) fail(REJECT_BLOCK);
      else if(rom_size==0 || rom_size>32'h01000000 || logical_start[31:24]!=0 ||
              ({1'b0,logical_start}+{1'b0,block_fact.payload_length})>{1'b0,rom_size} ||
              {1'b0,block_fact.payload_offset}+{1'b0,block_fact.payload_length}>{1'b0,file_extent}) fail(REJECT_RANGE);
      else if(block_fact.payload_length!=0)begin
       if((block_fact.block_type==8'h82 && descriptor_a_count_full>=MAX_A_DESCRIPTOR_COUNT) ||
          (block_fact.block_type==8'h83 && descriptor_b_count_full>=MAX_B_DESCRIPTOR_COUNT)) fail(REJECT_DESCRIPTOR);
       else begin
        pending_desc_space_b<=block_fact.block_type==8'h83;
        pending_desc_logical<=logical_start[23:0];pending_desc_length<=block_fact.payload_length[24:0];
        pending_desc_file<=block_fact.payload_offset[ADDR_WIDTH-1:0];overlap_index<=0;
        if((block_fact.block_type==8'h82 && descriptor_a_count_full==0) ||
           (block_fact.block_type==8'h83 && descriptor_b_count_full==0)) state<=ST_DESC_STORE;
        else state<=ST_DESC_READ;
       end
      end
     end
     S_LOOP_ENTRY: loop_samples<=total_samples;
     S_LOOP_BOUNDARY: begin end_pc<=fact.payload[31:0];state<=ST_FINISH;end
     S_END: begin end_pc<=body.source_pc;state<=ST_FINISH;end
     S_DIAGNOSTIC: begin
      case(body.reason)
       REASON_UNSUPPORTED_OPCODE: fail(REJECT_OPCODE);
       REASON_BAD_DATA_BLOCK: fail(REJECT_BLOCK);
       REASON_TRUNCATED: fail(REJECT_RANGE);
       default: fail(REJECT_HEADER);
      endcase
     end
     default: fail(REJECT_OPCODE);
    endcase
   end
                    ST_DESC_READ: state <= ST_DESC_COMPARE;
                    ST_DESC_COMPARE: begin
                        if (pending_desc_space_b) begin
                            if (({1'b0, pending_desc_logical} +
                                 pending_desc_length >
                                 {1'b0, desc_b_start}) &&
                                ({1'b0, pending_desc_logical} <
                                 ({1'b0, desc_b_start} + desc_b_length))) begin
                                reject_code <= REJECT_DESCRIPTOR;
                                state <= ST_FATAL;
                            end else if (overlap_index + 7'd1 >=
                                         {2'd0, descriptor_b_count_full}) begin
                                state <= ST_DESC_STORE;
                            end else begin
                                overlap_index <= overlap_index + 7'd1;
                                state <= ST_DESC_COMPARE;
                            end
                        end else begin
                            if (({1'b0, pending_desc_logical} +
                                 pending_desc_length >
                                 {1'b0, desc_a_start}) &&
                                ({1'b0, pending_desc_logical} <
                                 ({1'b0, desc_a_start} + desc_a_length))) begin
                                reject_code <= REJECT_DESCRIPTOR;
                                state <= ST_FATAL;
                            end else if (overlap_index + 7'd1 >=
                                         descriptor_a_count_full) begin
                                state <= ST_DESC_STORE;
                            end else begin
                                overlap_index <= overlap_index + 7'd1;
                                state <= ST_DESC_COMPARE;
                            end
                        end
                    end
                    ST_DESC_STORE: begin
                        if (pending_desc_space_b)
                            descriptor_b_count_full <=
                                descriptor_b_count_full + 5'd1;
                        else
                            descriptor_a_count_full <=
                                descriptor_a_count_full + 7'd1;
                        state <= ST_FACT;
                    end

   ST_FINISH: begin
    busy<=0;done<=1;
    if(first_bad_valid)begin
     accepted<=0;classification<=variant_b ? VARIANT_B_REQUIRED : VARIANT_STANDARD;
     reject_code<=first_bad_b_only ? REJECT_B_REQUIRED : REJECT_REGISTER;
    end else begin
     accepted<=1;classification<=variant_b ? VARIANT_B_COMPAT : VARIANT_STANDARD;
     reject_code<=REJECT_NONE;descriptors_committed<=1;
     if(loop_target!=0)loop_samples<=total_samples-loop_samples;
    end
    state<=ST_DONE;
   end
   ST_FATAL: begin busy<=0;accepted<=0;done<=1;state<=ST_DONE;end
   default:begin end
  endcase
 end
endmodule
