`timescale 1ns/1ps
// Candidate immutable epoch-local runway store outside the retained PCM cache.
// Resource and raw-command entries own distinct slots/classes, even when a
// physical file word is shared. Queries never count prefix words as resources.
// A hit is a registered local memory response, not a fabricated sample byte.
module engine_b_vnext_prepared_word_store #(
 parameter int WORDS=256,
 parameter bit LOOP_PREFIX=0, PREFETCH_PORT=0, SHARE_PREP_LOOKUP=0,
 parameter logic[28:0]DDRAM_BASE=29'd0
)(
 input logic clk,power_reset,new_track,prepared,
 input logic[31:0]epoch,file_extent,prefix_start,prefix_end,read_byte_address,
 input logic prefix_use,fill_prefix,
 input logic fill_valid,input logic[31:0]fill_address,input logic[63:0]fill_data,
 input logic[22:0]query_address,output logic query_hit,
 input logic bridge_read,input logic[28:0]bridge_address,input logic bridge_busy,
 output logic read_hit,local_valid,output logic[63:0]local_data,
 input logic fetch_valid,fetch_urgent,input logic[$clog2(WORDS)-1:0]fetch_slot,
 output logic fetch_ready,fetch_rsp_valid,fetch_rsp_command,
 output logic[31:0]fetch_rsp_address,fetch_rsp_epoch,
 output logic[63:0]fetch_rsp_data,output logic local_wait,
 output logic fault,output logic[$clog2(WORDS):0]word_count,resource_count,prefix_count
);
 localparam int PTR=$clog2(WORDS);
 logic[19:0]tags[WORDS];
 (* ramstyle = "M10K" *) logic[63:0]words[WORDS];
 logic command_words[WORDS];logic[31:0]store_epoch;
 // Address-keyed query/fill/read matches still use the original tag mirrors.
 // Only the already-indexed prefix metadata read uses this synchronous port.
 (* ramstyle = "M10K" *) logic[20:0]metadata[WORDS];
 logic[20:0]fetch_metadata;
 logic fetch_metadata_initialized,fetch_slot_valid;
 logic[31:0]fetch_prefix_start,fetch_prefix_end;
 wire[31:0]fetch_address={9'd0,fetch_metadata[19:0],3'd0};
 assign fetch_rsp_address=fetch_metadata_initialized ? fetch_address : 32'd0;
 assign fetch_rsp_command=fetch_metadata_initialized && fetch_slot_valid &&
     fetch_metadata[20] && fetch_address<fetch_prefix_end &&
     (fetch_address+32'd8)>fetch_prefix_start;
 wire prefix_fill=LOOP_PREFIX && fill_prefix;
 wire current_epoch=!LOOP_PREFIX || store_epoch==epoch;
 wire clear_store=power_reset || new_track || (LOOP_PREFIX && store_epoch!=epoch);
 // Opt-in for the B preparation protocol: query is consumed only in W_READ;
 // resource fill completes in W_READ_WAIT at that same requested word, and
 // prefix collection precedes resource warming. Never enable without proof.
 // Select from registered ownership, never response-valid: the latter would
 // couple the preparation query to combinational physical-response routing.
 wire[19:0]prep_tag=prefix_fill ? fill_address[22:3] : query_address[22:3];
 logic fill_hit;logic[PTR-1:0]selected_slot;
 logic prefix_yield;logic[63:0]port_data;logic port_initialized;
 wire resource_pending=bridge_read && read_hit && !clear_store;
 wire prefix_pending=PREFETCH_PORT && fetch_valid && current_epoch && prepared && !clear_store;
 wire prefix_grant=prefix_pending && (!resource_pending || (fetch_urgent && !prefix_yield));
 assign fetch_ready=PREFETCH_PORT && prefix_grant;
 assign local_wait=PREFETCH_PORT && read_hit && prefix_grant;
 assign local_data=port_initialized ? port_data : 64'd0;
 assign fetch_rsp_data=local_data;
 logic[28:0]relative_address;
 assign relative_address=bridge_address-DDRAM_BASE;
 always_comb begin
  query_hit=0;fill_hit=0;read_hit=0;selected_slot=0;
  for(integer n=0;n<WORDS;n=n+1)if(n<int'(word_count))begin
   if(SHARE_PREP_LOOKUP)begin
    if(tags[n]==prep_tag)begin
     if(current_epoch && !command_words[n])query_hit=1;
     if(command_words[n]==prefix_fill)fill_hit=1;
    end
   end else begin
    if(current_epoch && !command_words[n] && tags[n]==query_address[22:3])query_hit=1;
    if(command_words[n]==prefix_fill && tags[n]==fill_address[22:3])fill_hit=1;
   end
   if(current_epoch && prepared && bridge_address>=DDRAM_BASE && relative_address<29'h100000 &&
      (!command_words[n] || (LOOP_PREFIX && prefix_use && read_byte_address>=prefix_start &&
       read_byte_address<prefix_end && read_byte_address<file_extent)) &&
      tags[n]==relative_address[19:0])begin read_hit=1;selected_slot=PTR'(n);end
  end
 end
 // Select a single read address before the RAM. Keep its read/write process
 // free of reset and output muxing so Quartus can absorb the output register
 // into M10K. The separate valid bit preserves the cold-reset zero output.
 wire data_read_enable=!power_reset &&
     (prefix_grant || (bridge_read && read_hit && !bridge_busy));
 wire[PTR-1:0]data_read_address=prefix_grant ? fetch_slot : selected_slot;
 wire invalid_fill=LOOP_PREFIX && (fill_address>=file_extent || fill_address[31:23]!=0 ||
     (prefix_fill && fill_address<prefix_start));
 wire data_write_enable=!clear_store && fill_valid && !invalid_fill && !fill_hit &&
     word_count!=($clog2(WORDS)+1)'(WORDS);
 always_ff @(posedge clk)begin
  if(data_write_enable)words[word_count[PTR-1:0]]<=fill_data;
  if(data_read_enable)port_data<=words[data_read_address];
  if(data_write_enable)metadata[word_count[PTR-1:0]]<={prefix_fill,fill_address[22:3]};
  if(prefix_grant && !power_reset)fetch_metadata<=metadata[data_read_address];
 end
 always_ff @(posedge clk)begin
  if(power_reset)port_initialized<=0;
  else if(data_read_enable)port_initialized<=1;
 end
 always_ff @(posedge clk)begin
  // Completion of an accepted local read survives normal cancel/new epoch:
  // the frozen ledger drains it; only cold, quiescent power_reset clears debt.
  local_valid<=bridge_read && read_hit && !bridge_busy && !power_reset;
  // One shared registered data port. At most one grant per edge; contended
  // urgent prefix wins after idle; a grant yields the next contended edge.
  // The one-pending fetch client also supplies an unavoidable resource gap.
  fetch_rsp_valid<=prefix_grant && !power_reset;
  if(power_reset)begin
   prefix_yield<=0;fetch_metadata_initialized<=0;fetch_slot_valid<=0;
   fetch_prefix_start<=0;fetch_prefix_end<=0;fetch_rsp_epoch<=0;
  end
  else begin
   prefix_yield<=prefix_grant;
   if(prefix_grant)begin
    fetch_metadata_initialized<=1;fetch_rsp_epoch<=store_epoch;
    fetch_slot_valid<={1'b0,fetch_slot}<word_count;
    fetch_prefix_start<=prefix_start;fetch_prefix_end<=prefix_end;
   end
  end
  if(clear_store)begin word_count<=0;resource_count<=0;prefix_count<=0;fault<=0;store_epoch<=epoch;end
  else if(fill_valid && invalid_fill)fault<=1;
  else if(fill_valid && !fill_hit)begin
   if(word_count==($clog2(WORDS)+1)'(WORDS))fault<=1;
   else begin
    tags[word_count[PTR-1:0]]<=fill_address[22:3];
    command_words[word_count[PTR-1:0]]<=prefix_fill;
    word_count<=word_count+1'b1;
    if(prefix_fill)prefix_count<=prefix_count+1'b1;else resource_count<=resource_count+1'b1;
   end
  end
 end
endmodule
