// Namco System 2 source balance measured against the Dragon Saber software
// reference. Raw JT51 requires an exact 3x pre-mix gain (+9.542 dB) to match
// the reference YM2151:C140 ratio. This stage is profile-local; the shared
// family mixer and its final >>>2 normalization remain unchanged.
module c140_system2_source_balance (
    input  logic signed [15:0] ym2151_l,
    input  logic signed [15:0] ym2151_r,
    output logic signed [15:0] balanced_l,
    output logic signed [15:0] balanced_r
);
    logic signed [17:0] gain_l;
    logic signed [17:0] gain_r;

    function automatic logic signed [15:0] saturate16(
        input logic signed [17:0] value
    );
        if (value > 18'sd32767)
            saturate16 = 16'sh7fff;
        else if (value < -18'sd32768)
            saturate16 = 16'sh8000;
        else
            saturate16 = value[15:0];
    endfunction

    always_comb begin
        // Shift/add form makes the measured factor explicit and avoids a
        // multiplier in the already resource-constrained Stage-3 build.
        gain_l = $signed({{2{ym2151_l[15]}}, ym2151_l}) +
                 ($signed({{2{ym2151_l[15]}}, ym2151_l}) <<< 1);
        gain_r = $signed({{2{ym2151_r[15]}}, ym2151_r}) +
                 ($signed({{2{ym2151_r[15]}}, ym2151_r}) <<< 1);
        balanced_l = saturate16(gain_l);
        balanced_r = saturate16(gain_r);
    end
endmodule
