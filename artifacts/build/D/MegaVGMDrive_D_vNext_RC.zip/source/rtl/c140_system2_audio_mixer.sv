// System 2 mixer using the production arcade-family gain contract. Both cores
// keep their native signed 16-bit output through the shared saturation
// boundary; the saturated family sum then receives the established >>>2
// normalization before reaching the Golden Shell.
module c140_system2_audio_mixer (
    input  logic signed [15:0] ym2151_l,
    input  logic signed [15:0] ym2151_r,
    input  logic signed [15:0] c140_l,
    input  logic signed [15:0] c140_r,
    output logic signed [15:0] audio_l,
    output logic signed [15:0] audio_r
);
    logic signed [16:0] sum_l;
    logic signed [16:0] sum_r;
    logic signed [15:0] saturated_l;
    logic signed [15:0] saturated_r;

    function automatic logic signed [15:0] saturate16(
        input logic signed [16:0] value
    );
        if (value > 17'sd32767)
            saturate16 = 16'sh7fff;
        else if (value < -17'sd32768)
            saturate16 = 16'sh8000;
        else
            saturate16 = value[15:0];
    endfunction

    always_comb begin
        sum_l = {ym2151_l[15], ym2151_l} + {c140_l[15], c140_l};
        sum_r = {ym2151_r[15], ym2151_r} + {c140_r[15], c140_r};
        saturated_l = saturate16(sum_l);
        saturated_r = saturate16(sum_r);
        audio_l = saturated_l >>> 2;
        audio_r = saturated_r >>> 2;
    end
endmodule
