`timescale 1ns/1ps

// Simulation-first common C140 datapath. It implements all 24 voices,
// raw/byte-mu-law decoding, raw/compressed loops, two 8-byte lines per voice,
// a four-byte prefetch watermark, generation tags, and a fair round-robin
// one-request-at-a-time memory scheduler. Board-specific ROM banking is a
// runtime profile input; all voice, fetch, and arithmetic behavior is common.
module c140_stage3_24voice_core #(
    parameter int DESCRIPTORS = 16,
    parameter int ID_WIDTH = $clog2(DESCRIPTORS),
    parameter int unsigned PBASE_Q16 = 63406,
    parameter int MIX_SHIFT = 9
) (
    input  logic                    clk,
    input  logic                    reset,
    input  logic                    sample_tick,
    input  logic                    mapper_system21,

    input  logic                    descriptor_wr,
    input  logic [ID_WIDTH-1:0]     descriptor_wr_id,
    input  logic [21:0]             descriptor_logical_start,
    input  logic [21:0]             descriptor_logical_end_exclusive,
    input  logic [31:0]             descriptor_file_start,

    input  logic                    d4_wr,
    input  logic [15:0]             d4_addr,
    input  logic [7:0]              d4_data,

    output logic                    rom_req,
    output logic [31:0]             rom_file_address,
    output logic [4:0]              rom_voice,
    output logic [7:0]              rom_generation,
    input  logic                    rom_ready,
    input  logic                    rom_valid,
    input  logic [63:0]             rom_data,

    output logic signed [31:0]      mix_l_unshifted,
    output logic signed [31:0]      mix_r_unshifted,
    output logic signed [15:0]      audio_l,
    output logic signed [15:0]      audio_r,
    output logic                    audio_valid,
    output logic [23:0]             active_bitmap,
    output logic [63:0]             address_signature,

    output logic [31:0]             underflow_count,
    output logic [31:0]             descriptor_miss_count,
    output logic [31:0]             stale_response_count,
    output logic [31:0]             canceled_response_count,
    output logic [31:0]             request_count,
    output logic [31:0]             response_count,
    output logic [31:0]             raw_fetch_count,
    output logic [31:0]             compressed_fetch_count,
    output logic [31:0]             loop_count,
    output logic [31:0]             natural_end_count,
    output logic [31:0]             saturation_l_count,
    output logic [31:0]             saturation_r_count,
    output logic [31:0]             peak_abs_mix_l,
    output logic [31:0]             peak_abs_mix_r,
    output logic [4:0]              max_active_count,
    output logic [31:0]             max_request_wait_cycles,
    output logic [31:0]             max_round_robin_gap,
    output logic [31:0]             arithmetic_deadline_miss_count,
    output logic [7:0]              max_frame_processing_cycles,

    output logic                    debug_fetch_valid,
    output logic [4:0]              debug_fetch_voice,
    output logic [21:0]             debug_fetch_address,
    output logic signed [15:0]      debug_fetch_decoded,
    output logic                    debug_loop_valid,
    output logic [4:0]              debug_loop_voice,
    output logic [21:0]             debug_loop_address
);
    logic [21:0] descriptor_start [0:DESCRIPTORS-1];
    logic [21:0] descriptor_end   [0:DESCRIPTORS-1];
    logic [31:0] descriptor_file  [0:DESCRIPTORS-1];
    logic        descriptor_valid [0:DESCRIPTORS-1];

    logic [7:0] regs [0:23][0:11];
    typedef struct packed {
        logic [21:0] start_address;
        logic [21:0] end_address;
        logic [21:0] loop_address;
        logic [21:0] position;
        logic [15:0] phase;
        logic signed [15:0] previous_sample;
        logic signed [15:0] last_sample;
    } voice_state_t;

    typedef struct packed {
        logic        valid;
        logic [21:0] tag;
        logic [63:0] data;
    } cache_line_t;

    // These memories replace 7,440 flip-flop bits and, more importantly, the
    // parallel 24-way state/cache read fabric. Port A belongs to the frame
    // pipeline (and mode writes); port B belongs to the round-robin fetch
    // scheduler (and returning cache lines). No array reset is required:
    // active_bitmap and each cache valid bit are the architectural validity.
    (* ramstyle = "M10K, no_rw_check" *)
    voice_state_t voice_state_mem [0:31];
    (* ramstyle = "M10K, no_rw_check" *)
    cache_line_t cache0_mem [0:31];
    (* ramstyle = "M10K, no_rw_check" *)
    cache_line_t cache1_mem [0:31];

    voice_state_t voice_state_a_q;
    voice_state_t voice_state_b_q;
    voice_state_t voice_state_a_ram_q;
    voice_state_t voice_state_b_ram_q;
    cache_line_t cache0_a_q, cache0_b_q;
    cache_line_t cache1_a_q, cache1_b_q;
    logic [4:0] voice_state_a_addr;
    logic [4:0] voice_state_b_addr;
    logic [4:0] cache_a_addr;
    logic [4:0] cache_b_addr;
    logic voice_state_a_we;
    voice_state_t voice_state_a_wdata;
    logic cache0_a_we, cache1_a_we;
    logic cache0_b_we, cache1_b_we;
    cache_line_t cache0_a_wdata, cache1_a_wdata;
    cache_line_t cache0_b_wdata, cache1_b_wdata;
    logic voice_state_a_forward_valid;
    logic voice_state_b_forward_valid;
    voice_state_t voice_state_forward_data;

    logic [15:0] phase_increment [0:23];
    logic [7:0] generation [0:23];

    logic [4:0] rr_voice;
    logic pending;
    logic [4:0] pending_voice;
    logic [7:0] pending_generation;
    logic pending_canceled;
    logic pending_slot;
    logic [21:0] pending_line;
    logic request_slot_q;
    logic [21:0] request_line_q;
    logic [31:0] request_wait_cycles;
    logic [31:0] cycle_counter;
    logic [23:0] pitch_dirty;
    logic [4:0] pitch_rr_voice;
    logic pitch_mul_busy;
    logic [4:0] pitch_mul_voice;
    logic [15:0] pitch_mul_frequency;

    typedef enum logic [2:0] {
        MIX_IDLE,
        MIX_READ,
        MIX_UPDATE,
        MIX_INTERPOLATE,
        MIX_LEFT,
        MIX_RIGHT,
        MIX_COMMIT
    } mix_state_t;
    mix_state_t mix_state;
    logic [4:0] mix_voice;
    logic signed [31:0] frame_sum_l;
    logic signed [31:0] frame_sum_r;
    logic [63:0] frame_signature;
    logic signed [16:0] mix_interpolated;
    logic signed [15:0] mix_previous_sample;
    logic [21:0] mix_current_address;
    logic signed [17:0] mix_mul_a;
    logic signed [17:0] mix_mul_b;
    logic [7:0] frame_processing_cycles;
    logic [4:0] frame_active_count;
    logic frame_debug_fetch_valid;
    logic [4:0] frame_debug_fetch_voice;
    logic [21:0] frame_debug_fetch_address;
    logic signed [15:0] frame_debug_fetch_decoded;
    logic frame_debug_loop_valid;
    logic [4:0] frame_debug_loop_voice;
    logic [21:0] frame_debug_loop_address;

    logic [4:0] scheduler_issue_voice;
    logic [4:0] scheduler_eval_voice;
    logic scheduler_eval_valid;
    logic descriptor_lookup_busy;
    logic [ID_WIDTH-1:0] descriptor_lookup_index;
    logic descriptor_lookup_hit;
    logic descriptor_lookup_overlap;
    logic [31:0] descriptor_lookup_file;
    logic [4:0] candidate_voice;
    logic [7:0] candidate_generation;
    logic candidate_slot;
    logic [21:0] candidate_line;
    logic [4:0] candidate_distance;

    // Exactly two multiplier operators remain in Stage 3: one updates cached
    // pitch increments after frequency writes, and one is shared by every
    // voice's interpolation and left/right volume operations.
    (* multstyle = "dsp" *) wire [31:0] pitch_mul_product =
        pitch_mul_frequency * PBASE_Q16[15:0];
    (* multstyle = "dsp" *) wire signed [35:0] mix_mul_product =
        mix_mul_a * mix_mul_b;
    wire mode_write_now = d4_wr && d4_addr < 16'h0180 && d4_addr[3:0] == 4'd5;
    wire [4:0] mode_write_voice = d4_addr[8:4];

    function automatic logic [21:0] map_sample_address(
        input logic [7:0] bank, input logic [15:0] address);
        logic [23:0] raw;
        begin
            raw = {bank, address};
            if (mapper_system21)
                map_sample_address = ((raw & 24'h300000) >> 1) |
                                     (raw & 24'h07ffff);
            else
                map_sample_address = ((raw & 24'h200000) >> 2) |
                                     (raw & 24'h07ffff);
        end
    endfunction

    function automatic logic signed [15:0] decode_mulaw(input logic [7:0] code);
        logic signed [8:0] signed_code;
        logic [2:0] shift;
        logic [4:0] magnitude;
        logic [15:0] expanded;
        begin
            signed_code = code[7] ? $signed({1'b1, code}) : $signed({1'b0, code});
            shift = code[2:0];
            magnitude = signed_code[8] ?
                        -(signed_code >>> 3) & 5'h1f :
                        (signed_code >>> 3) & 5'h1f;
            expanded = ((16'h0080 << shift) & 16'hff00) +
                       (magnitude << (shift == 0 ? 4 : shift + 3));
            decode_mulaw = signed_code[8] ? -$signed(expanded) : $signed(expanded);
        end
    endfunction

    function automatic logic signed [15:0] saturate16(input logic signed [31:0] value);
        begin
            if (value > 32'sd32767) saturate16 = 16'sh7fff;
            else if (value < -32'sd32768) saturate16 = -16'sh8000;
            else saturate16 = value[15:0];
        end
    endfunction

    function automatic logic [31:0] abs32(input logic signed [31:0] value);
        abs32 = value[31] ? -value : value;
    endfunction

    // FNV_PRIME = 2^40 + 0x1b3.  Writing the constant product as shifts and
    // adds prevents the diagnostic signature from consuming another DSP.
    function automatic logic [63:0] fnv_multiply(input logic [63:0] value);
        fnv_multiply = (value << 40) + (value << 8) + (value << 7) +
                       (value << 5) + (value << 4) + (value << 1) + value;
    endfunction

    logic update_active;
    logic update_state_write;
    logic update_mix_valid;
    logic update_underflow;
    logic update_looped;
    logic update_natural_end;
    logic update_fetched;
    logic update_compressed;
    logic [16:0] update_phase_sum;
    logic [21:0] update_next_position;
    logic [21:0] update_fetch_address;
    logic [21:0] update_fetch_line;
    logic [7:0] update_source_byte;
    logic signed [15:0] update_previous;
    logic signed [15:0] update_last;
    voice_state_t update_state;

    always_comb begin : frame_update_decode
        update_active = active_bitmap[mix_voice];
        update_state_write = 1'b0;
        update_mix_valid = 1'b0;
        update_underflow = 1'b0;
        update_looped = 1'b0;
        update_natural_end = 1'b0;
        update_fetched = 1'b0;
        update_compressed = 1'b0;
        update_phase_sum = {1'b0, voice_state_a_q.phase} +
                           {1'b0, phase_increment[mix_voice]};
        update_next_position = voice_state_a_q.position +
                               update_phase_sum[16];
        update_fetch_address = voice_state_a_q.start_address +
                               update_next_position;
        update_fetch_line = {update_fetch_address[21:3], 3'b000};
        update_source_byte = 8'd0;
        update_previous = voice_state_a_q.previous_sample;
        update_last = voice_state_a_q.last_sample;
        update_state = voice_state_a_q;

        if (update_active) begin
            if (update_next_position >=
                voice_state_a_q.end_address - voice_state_a_q.start_address) begin
                if (regs[mix_voice][5][4]) begin
                    update_next_position = voice_state_a_q.loop_address -
                                           voice_state_a_q.start_address;
                    update_looped = 1'b1;
                end else begin
                    update_natural_end = 1'b1;
                end
            end

            update_fetch_address = voice_state_a_q.start_address +
                                   update_next_position;
            update_fetch_line = {update_fetch_address[21:3], 3'b000};
            if (!update_natural_end &&
                update_next_position <
                voice_state_a_q.end_address - voice_state_a_q.start_address) begin
                if (cache0_a_q.valid && cache0_a_q.tag == update_fetch_line)
                    update_source_byte =
                        cache0_a_q.data >> (update_fetch_address[2:0] * 8);
                else if (cache1_a_q.valid &&
                         cache1_a_q.tag == update_fetch_line)
                    update_source_byte =
                        cache1_a_q.data >> (update_fetch_address[2:0] * 8);
                else
                    update_underflow = 1'b1;

                if (!update_underflow) begin
                    if (update_phase_sum[16]) begin
                        update_previous = voice_state_a_q.last_sample;
                        update_compressed = regs[mix_voice][5][3];
                        update_last = update_compressed ?
                                      decode_mulaw(update_source_byte) :
                                      $signed(update_source_byte) <<< 8;
                        update_fetched = 1'b1;
                    end
                    update_state.position = update_next_position;
                    update_state.phase = update_phase_sum[15:0];
                    update_state.previous_sample = update_previous;
                    update_state.last_sample = update_last;
                    update_state_write = 1'b1;
                    update_mix_valid = 1'b1;
                end
            end
        end
    end

    wire response_store = pending && rom_valid && !pending_canceled &&
                          !(mode_write_now &&
                            mode_write_voice == pending_voice) &&
                          generation[pending_voice] == pending_generation;

    always_comb begin : memory_ports
        logic [21:0] mapped_start;
        logic [21:0] mapped_end;
        logic [21:0] mapped_loop;

        mapped_start = '0;
        mapped_end = '0;
        mapped_loop = '0;
        voice_state_a_addr = mode_write_now ? mode_write_voice : mix_voice;
        voice_state_b_addr = scheduler_issue_voice;
        cache_a_addr = mode_write_now ? mode_write_voice : mix_voice;
        cache_b_addr = response_store ? pending_voice : scheduler_issue_voice;

        voice_state_a_we = 1'b0;
        voice_state_a_wdata = update_state;
        cache0_a_we = mode_write_now;
        cache1_a_we = mode_write_now;
        cache0_a_wdata = '0;
        cache1_a_wdata = '0;
        cache0_b_we = response_store && !pending_slot;
        cache1_b_we = response_store && pending_slot;
        cache0_b_wdata = '0;
        cache0_b_wdata.valid = 1'b1;
        cache0_b_wdata.tag = pending_line;
        cache0_b_wdata.data = rom_data;
        cache1_b_wdata = '0;
        cache1_b_wdata.valid = 1'b1;
        cache1_b_wdata.tag = pending_line;
        cache1_b_wdata.data = rom_data;

        if (mode_write_now && d4_data[7]) begin
            mapped_start = map_sample_address(regs[mode_write_voice][4],
                                              {regs[mode_write_voice][6],
                                               regs[mode_write_voice][7]});
            mapped_end = map_sample_address(regs[mode_write_voice][4],
                                            {regs[mode_write_voice][8],
                                             regs[mode_write_voice][9]});
            mapped_loop = map_sample_address(regs[mode_write_voice][4],
                                             {regs[mode_write_voice][10],
                                              regs[mode_write_voice][11]});
            if (mapped_start < mapped_end) begin
                voice_state_a_we = 1'b1;
                voice_state_a_wdata = '0;
                voice_state_a_wdata.start_address = mapped_start;
                voice_state_a_wdata.end_address = mapped_end;
                voice_state_a_wdata.loop_address = mapped_loop;
            end
        end else if (mix_state == MIX_UPDATE && update_state_write) begin
            voice_state_a_we = 1'b1;
            voice_state_a_wdata = update_state;
        end
    end

    // Two independent read addresses and at most one writer per port match a
    // Cyclone-V true dual-port M10K. Voice-state mixed-port read-during-write
    // data is not defined by the device, so explicit one-cycle forwarding
    // makes both views deterministic when the scheduler reads the voice being
    // written. The RAM array itself retains registered reads.
    always_ff @(posedge clk) begin : voice_ram
        voice_state_a_ram_q <= voice_state_mem[voice_state_a_addr];
        voice_state_b_ram_q <= voice_state_mem[voice_state_b_addr];
        voice_state_a_forward_valid <= !reset && voice_state_a_we;
        voice_state_b_forward_valid <= !reset && voice_state_a_we &&
                                       voice_state_a_addr == voice_state_b_addr;
        voice_state_forward_data <= voice_state_a_wdata;
        if (voice_state_a_we)
            voice_state_mem[voice_state_a_addr] <= voice_state_a_wdata;
    end

    always_comb begin
        voice_state_a_q = voice_state_a_forward_valid ?
                          voice_state_forward_data : voice_state_a_ram_q;
        voice_state_b_q = voice_state_b_forward_valid ?
                          voice_state_forward_data : voice_state_b_ram_q;
    end

    always_ff @(posedge clk) begin : cache0_ram
        cache0_a_q <= cache0_mem[cache_a_addr];
        cache0_b_q <= cache0_mem[cache_b_addr];
        if (cache0_a_we) cache0_mem[cache_a_addr] <= cache0_a_wdata;
        if (cache0_b_we) cache0_mem[cache_b_addr] <= cache0_b_wdata;
    end

    always_ff @(posedge clk) begin : cache1_ram
        cache1_a_q <= cache1_mem[cache_a_addr];
        cache1_b_q <= cache1_mem[cache_b_addr];
        if (cache1_a_we) cache1_mem[cache_a_addr] <= cache1_a_wdata;
        if (cache1_b_we) cache1_mem[cache_b_addr] <= cache1_b_wdata;
    end

    integer i, j;
    always_ff @(posedge clk) begin : core_process
        logic [4:0] voice_index;
        logic [3:0] reg_offset;
        logic [21:0] current_address;
        logic [21:0] current_line;
        logic [21:0] wanted_line;
        logic wanted_slot;
        logic request_found;
        logic descriptor_hit_now;
        logic descriptor_overlap_now;
        logic [31:0] descriptor_file_now;
        logic signed [16:0] interpolated_now;
        logic signed [31:0] shifted_l;
        logic signed [31:0] shifted_r;
        integer rr_distance;

        audio_valid <= 1'b0;
        debug_fetch_valid <= 1'b0;
        debug_loop_valid <= 1'b0;
        cycle_counter <= cycle_counter + 1'b1;

        if (reset) begin
            for (i = 0; i < DESCRIPTORS; i = i + 1) begin
                descriptor_start[i] <= '0;
                descriptor_end[i] <= '0;
                descriptor_file[i] <= '0;
                descriptor_valid[i] <= 1'b0;
            end
            for (i = 0; i < 24; i = i + 1) begin
                for (j = 0; j < 12; j = j + 1) regs[i][j] <= '0;
                phase_increment[i] <= '0;
                generation[i] <= '0;
            end
            active_bitmap <= '0;
            rr_voice <= '0;
            pending <= 1'b0;
            pending_voice <= '0;
            pending_generation <= '0;
            pending_canceled <= 1'b0;
            pending_slot <= 1'b0;
            pending_line <= '0;
            request_slot_q <= 1'b0;
            request_line_q <= '0;
            rom_req <= 1'b0;
            rom_file_address <= '0;
            rom_voice <= '0;
            rom_generation <= '0;
            request_wait_cycles <= '0;
            cycle_counter <= '0;
            pitch_dirty <= '0;
            pitch_rr_voice <= '0;
            pitch_mul_busy <= 1'b0;
            pitch_mul_voice <= '0;
            pitch_mul_frequency <= '0;
            mix_state <= MIX_IDLE;
            mix_voice <= '0;
            frame_sum_l <= '0;
            frame_sum_r <= '0;
            frame_signature <= 64'hcbf29ce484222325;
            mix_interpolated <= '0;
            mix_previous_sample <= '0;
            mix_current_address <= '0;
            mix_mul_a <= '0;
            mix_mul_b <= '0;
            frame_processing_cycles <= '0;
            frame_active_count <= '0;
            frame_debug_fetch_valid <= 1'b0;
            frame_debug_fetch_voice <= '0;
            frame_debug_fetch_address <= '0;
            frame_debug_fetch_decoded <= '0;
            frame_debug_loop_valid <= 1'b0;
            frame_debug_loop_voice <= '0;
            frame_debug_loop_address <= '0;
            scheduler_issue_voice <= '0;
            scheduler_eval_voice <= '0;
            scheduler_eval_valid <= 1'b0;
            descriptor_lookup_busy <= 1'b0;
            descriptor_lookup_index <= '0;
            descriptor_lookup_hit <= 1'b0;
            descriptor_lookup_overlap <= 1'b0;
            descriptor_lookup_file <= '0;
            candidate_voice <= '0;
            candidate_generation <= '0;
            candidate_slot <= 1'b0;
            candidate_line <= '0;
            candidate_distance <= '0;
            mix_l_unshifted <= '0;
            mix_r_unshifted <= '0;
            audio_l <= '0;
            audio_r <= '0;
            address_signature <= 64'hcbf29ce484222325;
            underflow_count <= '0;
            descriptor_miss_count <= '0;
            stale_response_count <= '0;
            canceled_response_count <= '0;
            request_count <= '0;
            response_count <= '0;
            raw_fetch_count <= '0;
            compressed_fetch_count <= '0;
            loop_count <= '0;
            natural_end_count <= '0;
            saturation_l_count <= '0;
            saturation_r_count <= '0;
            peak_abs_mix_l <= '0;
            peak_abs_mix_r <= '0;
            max_active_count <= '0;
            max_request_wait_cycles <= '0;
            max_round_robin_gap <= '0;
            arithmetic_deadline_miss_count <= '0;
            max_frame_processing_cycles <= '0;
            debug_fetch_voice <= '0;
            debug_fetch_address <= '0;
            debug_fetch_decoded <= '0;
            debug_loop_voice <= '0;
            debug_loop_address <= '0;
        end else begin
            // A one-bit-per-clock round-robin walk replaces the former 24-way
            // priority mux. The 64 command-settle clocks leave ample time for
            // the shared pitch multiplier to drain all normal D4 bursts.
            if (pitch_mul_busy) begin
                phase_increment[pitch_mul_voice] <= pitch_mul_product[31:16];
                pitch_mul_busy <= 1'b0;
            end else if (pitch_dirty[pitch_rr_voice]) begin
                pitch_mul_frequency <=
                    {regs[pitch_rr_voice][2], regs[pitch_rr_voice][3]};
                pitch_mul_voice <= pitch_rr_voice;
                pitch_mul_busy <= 1'b1;
                pitch_dirty[pitch_rr_voice] <= 1'b0;
                pitch_rr_voice <= pitch_rr_voice == 23 ?
                                  0 : pitch_rr_voice + 1'b1;
            end else begin
                pitch_rr_voice <= pitch_rr_voice == 23 ?
                                  0 : pitch_rr_voice + 1'b1;
            end

            if (descriptor_wr) begin
                descriptor_start[descriptor_wr_id] <= descriptor_logical_start;
                descriptor_end[descriptor_wr_id] <= descriptor_logical_end_exclusive;
                descriptor_file[descriptor_wr_id] <= descriptor_file_start;
                descriptor_valid[descriptor_wr_id] <= 1'b1;
            end

            if (d4_wr && d4_addr < 16'h0180) begin
                voice_index = d4_addr[8:4];
                reg_offset = d4_addr[3:0];
                if (reg_offset < 12) regs[voice_index][reg_offset] <= d4_data;
                if (reg_offset == 2 || reg_offset == 3)
                    pitch_dirty[voice_index] <= 1'b1;
                if (reg_offset == 5) begin
                    generation[voice_index] <= generation[voice_index] + 1'b1;
                    if (!d4_data[7] || !voice_state_a_we)
                        active_bitmap[voice_index] <= 1'b0;
                    else
                        active_bitmap[voice_index] <= 1'b1;
                end
            end

            if (rom_req && rom_ready) begin
                rom_req <= 1'b0;
                pending <= 1'b1;
                pending_voice <= rom_voice;
                pending_generation <= rom_generation;
                pending_canceled <= mode_write_now &&
                                    mode_write_voice == rom_voice;
                pending_line <= request_line_q;
                pending_slot <= request_slot_q;
                request_count <= request_count + 1'b1;
`ifdef C140_STAGE3_TRACE_REQUEST
                if (rom_voice == 18)
                    $display("REQ cycle=%0d voice=%0d line=%h slot=%0d file=%h",
                             cycle_counter, rom_voice, request_line_q,
                             request_slot_q, rom_file_address);
`endif
                rr_voice <= rom_voice == 23 ? 0 : rom_voice + 1'b1;
                scheduler_issue_voice <= rom_voice == 23 ?
                                         0 : rom_voice + 1'b1;
                scheduler_eval_valid <= 1'b0;
                if (request_wait_cycles > max_request_wait_cycles)
                    max_request_wait_cycles <= request_wait_cycles;
                request_wait_cycles <= '0;
            end else if (rom_req) begin
                request_wait_cycles <= request_wait_cycles + 1'b1;
            end

            // A request held at ready=0 has not crossed the arbiter boundary.
            // Re-keying that same voice can therefore withdraw it locally;
            // otherwise it would later be accepted with the old generation
            // and turn an intentional cancellation into a stale response.
            if (mode_write_now && rom_req && !rom_ready &&
                mode_write_voice == rom_voice) begin
                rom_req <= 1'b0;
                request_wait_cycles <= '0;
                scheduler_eval_valid <= 1'b0;
                scheduler_issue_voice <= mode_write_voice == 23 ?
                                         0 : mode_write_voice + 1'b1;
            end

            if (mode_write_now && pending &&
                mode_write_voice == pending_voice)
                pending_canceled <= 1'b1;

            if (pending && rom_valid) begin
                pending <= 1'b0;
                response_count <= response_count + 1'b1;
                if (pending_canceled ||
                    (mode_write_now && mode_write_voice == pending_voice)) begin
                    canceled_response_count <= canceled_response_count + 1'b1;
                    pending_canceled <= 1'b0;
                end else if (generation[pending_voice] != pending_generation) begin
                    stale_response_count <= stale_response_count + 1'b1;
                end
            end

            // Descriptor translation checks four entries per clock. This cuts
            // the old sixteen-way comparator/adder fan-in by 4x while keeping
            // enough issue bandwidth for the four-byte prefetch watermark.
            if (descriptor_lookup_busy) begin
                if (mode_write_now && mode_write_voice == candidate_voice) begin
                    descriptor_lookup_busy <= 1'b0;
                    scheduler_eval_valid <= 1'b0;
                    scheduler_issue_voice <= candidate_voice == 23 ?
                                             0 : candidate_voice + 1'b1;
                end else begin
                    descriptor_hit_now = descriptor_lookup_hit;
                    descriptor_overlap_now = descriptor_lookup_overlap;
                    descriptor_file_now = descriptor_lookup_file;
                    for (j = 0; j < 4; j = j + 1) begin
                        if (descriptor_valid[descriptor_lookup_index + j] &&
                            candidate_line >=
                                descriptor_start[descriptor_lookup_index + j] &&
                            candidate_line <
                                descriptor_end[descriptor_lookup_index + j]) begin
                            if (descriptor_hit_now)
                                descriptor_overlap_now = 1'b1;
                            descriptor_hit_now = 1'b1;
                            descriptor_file_now =
                                descriptor_file[descriptor_lookup_index + j] +
                                candidate_line -
                                descriptor_start[descriptor_lookup_index + j];
                        end
                    end
                    if (descriptor_lookup_index >= DESCRIPTORS - 4) begin
                        descriptor_lookup_busy <= 1'b0;
                        scheduler_eval_valid <= 1'b0;
                        scheduler_issue_voice <= candidate_voice == 23 ?
                                                 0 : candidate_voice + 1'b1;
                        if (active_bitmap[candidate_voice] &&
                            generation[candidate_voice] ==
                                candidate_generation) begin
                            if (!descriptor_hit_now ||
                                descriptor_overlap_now) begin
                                descriptor_miss_count <=
                                    descriptor_miss_count + 1'b1;
                                active_bitmap[candidate_voice] <= 1'b0;
                            end else begin
                                rom_req <= 1'b1;
                                rom_file_address <= descriptor_file_now;
                                rom_voice <= candidate_voice;
                                rom_generation <= candidate_generation;
                                request_line_q <= candidate_line;
                                request_slot_q <= candidate_slot;
                                if (candidate_distance >
                                    max_round_robin_gap)
                                    max_round_robin_gap <=
                                        candidate_distance;
                            end
                        end
                    end else begin
                        descriptor_lookup_index <=
                            descriptor_lookup_index + 4;
                        descriptor_lookup_hit <= descriptor_hit_now;
                        descriptor_lookup_overlap <= descriptor_overlap_now;
                        descriptor_lookup_file <= descriptor_file_now;
                    end
                end
            end else if (!rom_req && !pending) begin
                request_found = 1'b0;
                wanted_line = '0;
                wanted_slot = 1'b0;
                if (scheduler_eval_valid &&
                    active_bitmap[scheduler_eval_voice] &&
                    !(mode_write_now &&
                      mode_write_voice == scheduler_eval_voice)) begin
                    current_address = voice_state_b_q.start_address +
                                      voice_state_b_q.position;
                    current_line = {current_address[21:3], 3'b000};
                    if ((!cache0_b_q.valid ||
                         cache0_b_q.tag != current_line) &&
                        (!cache1_b_q.valid ||
                         cache1_b_q.tag != current_line)) begin
                        request_found = 1'b1;
                        wanted_line = current_line;
                        wanted_slot = !cache0_b_q.valid ? 1'b0 : 1'b1;
                    end else if (current_address[2:0] >= 3'd4 &&
                                 current_line + 8 <
                                     voice_state_b_q.end_address &&
                                 (!cache0_b_q.valid ||
                                  cache0_b_q.tag != current_line + 8) &&
                                 (!cache1_b_q.valid ||
                                  cache1_b_q.tag != current_line + 8)) begin
                        request_found = 1'b1;
                        wanted_line = current_line + 8;
                        wanted_slot = cache0_b_q.tag == current_line;
                    end else if (regs[scheduler_eval_voice][5][4] &&
                                 current_line + 8 >=
                                     voice_state_b_q.end_address &&
                                 (!cache0_b_q.valid ||
                                  cache0_b_q.tag !=
                                    {voice_state_b_q.loop_address[21:3],
                                     3'b000}) &&
                                 (!cache1_b_q.valid ||
                                  cache1_b_q.tag !=
                                    {voice_state_b_q.loop_address[21:3],
                                     3'b000})) begin
                        request_found = 1'b1;
                        wanted_line =
                            {voice_state_b_q.loop_address[21:3], 3'b000};
                        wanted_slot = cache0_b_q.tag == current_line;
                    end
                end

                if (request_found) begin
                    rr_distance = scheduler_eval_voice >= rr_voice ?
                                  scheduler_eval_voice - rr_voice :
                                  scheduler_eval_voice + 24 - rr_voice;
                    candidate_voice <= scheduler_eval_voice;
                    candidate_generation <= generation[scheduler_eval_voice];
                    candidate_line <= wanted_line;
                    candidate_slot <= wanted_slot;
                    candidate_distance <= rr_distance[4:0];
                    descriptor_lookup_busy <= 1'b1;
                    descriptor_lookup_index <= '0;
                    descriptor_lookup_hit <= 1'b0;
                    descriptor_lookup_overlap <= 1'b0;
                    descriptor_lookup_file <= '0;
                    scheduler_eval_valid <= 1'b0;
                end else begin
                    scheduler_eval_voice <= scheduler_issue_voice;
                    scheduler_eval_valid <= 1'b1;
                    scheduler_issue_voice <= scheduler_issue_voice == 23 ?
                                             0 :
                                             scheduler_issue_voice + 1'b1;
                end
            end else begin
                scheduler_eval_valid <= 1'b0;
            end

            if (sample_tick && (mix_state != MIX_IDLE || pitch_mul_busy ||
                                pitch_dirty != 0)) begin
                arithmetic_deadline_miss_count <=
                    arithmetic_deadline_miss_count + 1'b1;
            end else if (sample_tick) begin
                frame_sum_l <= '0;
                frame_sum_r <= '0;
                frame_signature <= 64'hcbf29ce484222325;
                frame_active_count <= '0;
                frame_debug_fetch_valid <= 1'b0;
                frame_debug_loop_valid <= 1'b0;
                mix_voice <= '0;
                mix_state <= MIX_READ;
                frame_processing_cycles <= '0;
            end

            if (mix_state != MIX_IDLE)
                frame_processing_cycles <= frame_processing_cycles + 1'b1;

            // Every voice now passes through one registered M10K read and one
            // update cycle. Valid voices then use the unchanged three-cycle
            // shared interpolation/left/right multiplier sequence.
            case (mix_state)
                MIX_READ: begin
                    mix_state <= MIX_UPDATE;
                end

                MIX_UPDATE: begin
                    if (update_active)
                        frame_active_count <= frame_active_count + 1'b1;
                    if (update_looped) begin
                        loop_count <= loop_count + 1'b1;
                        frame_debug_loop_valid <= 1'b1;
                        frame_debug_loop_voice <= mix_voice;
                        frame_debug_loop_address <=
                            voice_state_a_q.loop_address;
                    end
                    if (update_natural_end) begin
                        active_bitmap[mix_voice] <= 1'b0;
                        natural_end_count <= natural_end_count + 1'b1;
                    end
                    if (update_underflow) begin
`ifdef C140_STAGE3_TRACE_UNDERFLOW
                        $display("UNDERFLOW cycle=%0d voice=%0d addr=%h pos=%h end=%h loop=%h c0=%b/%h c1=%b/%h",
                                 cycle_counter, mix_voice,
                                 update_fetch_address, update_next_position,
                                 voice_state_a_q.end_address,
                                 voice_state_a_q.loop_address,
                                 cache0_a_q.valid, cache0_a_q.tag,
                                 cache1_a_q.valid, cache1_a_q.tag);
`endif
                        underflow_count <= underflow_count + 1'b1;
                    end
                    if (update_fetched) begin
                        if (update_compressed)
                            compressed_fetch_count <=
                                compressed_fetch_count + 1'b1;
                        else
                            raw_fetch_count <= raw_fetch_count + 1'b1;
                        frame_debug_fetch_valid <= 1'b1;
                        frame_debug_fetch_voice <= mix_voice;
                        frame_debug_fetch_address <= update_fetch_address;
                        frame_debug_fetch_decoded <= update_last;
                    end

                    if (update_mix_valid) begin
                        mix_previous_sample <= update_previous;
                        mix_current_address <= update_fetch_address;
                        mix_mul_a <=
                            $signed({{2{update_last[15]}}, update_last}) -
                            $signed({{2{update_previous[15]}},
                                      update_previous});
                        mix_mul_b <=
                            $signed({2'b00, update_phase_sum[15:0]});
                        mix_state <= MIX_INTERPOLATE;
                    end else if (mix_voice == 23) begin
                        mix_state <= MIX_COMMIT;
                    end else begin
                        mix_voice <= mix_voice + 1'b1;
                        mix_state <= MIX_READ;
                    end
                end

                MIX_INTERPOLATE: begin
                    interpolated_now =
                        $signed({mix_previous_sample[15],
                                 mix_previous_sample}) +
                        $signed(mix_mul_product >>> 16);
                    mix_interpolated <= interpolated_now;
                    mix_mul_a <=
                        $signed({interpolated_now[16], interpolated_now});
                    mix_mul_b <= $signed({10'd0, regs[mix_voice][1]});
                    mix_state <= MIX_LEFT;
                end

                MIX_LEFT: begin
                    frame_sum_l <= frame_sum_l +
                                   $signed(mix_mul_product[25:0]);
                    mix_mul_a <=
                        $signed({mix_interpolated[16], mix_interpolated});
                    mix_mul_b <= $signed({10'd0, regs[mix_voice][0]});
                    mix_state <= MIX_RIGHT;
                end

                MIX_RIGHT: begin
                    frame_sum_r <= frame_sum_r +
                                   $signed(mix_mul_product[25:0]);
                    frame_signature <= fnv_multiply(
                        frame_signature ^
                        {37'd0, mix_voice, mix_current_address});
                    if (mix_voice == 23) begin
                        mix_state <= MIX_COMMIT;
                    end else begin
                        mix_voice <= mix_voice + 1'b1;
                        mix_state <= MIX_READ;
                    end
                end

                MIX_COMMIT: begin
                    mix_l_unshifted <= frame_sum_l;
                    mix_r_unshifted <= frame_sum_r;
                    shifted_l = frame_sum_l >>> MIX_SHIFT;
                    shifted_r = frame_sum_r >>> MIX_SHIFT;
                    audio_l <= saturate16(shifted_l);
                    audio_r <= saturate16(shifted_r);
                    audio_valid <= 1'b1;
                    address_signature <= frame_signature;
                    debug_fetch_valid <= frame_debug_fetch_valid;
                    debug_fetch_voice <= frame_debug_fetch_voice;
                    debug_fetch_address <= frame_debug_fetch_address;
                    debug_fetch_decoded <= frame_debug_fetch_decoded;
                    debug_loop_valid <= frame_debug_loop_valid;
                    debug_loop_voice <= frame_debug_loop_voice;
                    debug_loop_address <= frame_debug_loop_address;
                    if (frame_active_count > max_active_count)
                        max_active_count <= frame_active_count;
                    if (shifted_l > 32767 || shifted_l < -32768)
                        saturation_l_count <= saturation_l_count + 1'b1;
                    if (shifted_r > 32767 || shifted_r < -32768)
                        saturation_r_count <= saturation_r_count + 1'b1;
                    if (abs32(frame_sum_l) > peak_abs_mix_l)
                        peak_abs_mix_l <= abs32(frame_sum_l);
                    if (abs32(frame_sum_r) > peak_abs_mix_r)
                        peak_abs_mix_r <= abs32(frame_sum_r);
                    if (frame_processing_cycles + 1'b1 >
                        max_frame_processing_cycles)
                        max_frame_processing_cycles <=
                            frame_processing_cycles + 1'b1;
                    frame_processing_cycles <= '0;
                    mix_state <= MIX_IDLE;
                end

                default: begin end
            endcase
        end
    end
endmodule
