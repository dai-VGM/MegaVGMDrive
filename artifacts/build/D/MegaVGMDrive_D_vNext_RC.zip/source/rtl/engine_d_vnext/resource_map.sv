// C140 immutable resource spans. All VGM file mapping lives outside the Core.
// Synchronous descriptor RAM and a serialized overlap/lookup walk; no CAM.
module engine_d_vnext_resource_map #(
    parameter int CAPACITY=16,
    parameter int INDEX_WIDTH=$clog2(CAPACITY),
    parameter bit LOOKUP_CACHE=1,parameter bit PAGE_INDEX=1
) (
    input logic clk, reset, new_track,
    input logic [31:0] epoch, file_extent,
    input logic descriptor_valid,
    output logic descriptor_ready,
    input logic [31:0] descriptor_rom_size,descriptor_start,
    input logic [31:0] descriptor_length,descriptor_file_start,
    input logic publish,
    output logic published, fault,
    output logic [7:0] fault_code,
    output logic [INDEX_WIDTH:0] descriptor_count,
    input logic request_valid,
    output logic request_ready,
    input logic [31:0] request_logical_address,
    output logic response_valid,
    input logic response_ready,
    output logic [31:0] response_file_address,response_epoch,
    output logic [7:0] response_error
);
    // {logical_start22, logical_end_exclusive23, biased_file_start32}.
    (* ramstyle="M10K, no_rw_check" *) logic [76:0] descriptors [0:CAPACITY-1];
    logic [76:0] descriptor_q,pending_descriptor;
    // 64 x 64 KiB page index. Shared-page ambiguity falls back to the exact
    // serialized descriptor walk; it never changes gap/overlap semantics.
    (* ramstyle="M10K, no_rw_check" *) logic [76:0] pages[0:63];
    logic [76:0] page_q;
    logic [63:0] page_valid,page_ambiguous;
    logic [5:0] page_index,page_read_index;
    logic [32:0] page_file;
    logic [INDEX_WIDTH-1:0] read_index;
    logic [31:0] rom_size,owned_extent,owned_epoch,logical_address;
    logic [32:0] logical_end,file_end,mapped_file;
    assign page_file={1'b0,page_q[31:0]}+{1'b0,logical_address}-{11'd0,page_q[76:55]};

    logic [21:0] pending_start;
    logic [22:0] pending_end;
    logic [31:0] pending_file;
    logic [21:0] stored_start;
    logic [22:0] stored_end;
    logic [31:0] stored_file;
    logic mapping_cache_valid;
    logic [76:0] mapping_cache;
    logic [32:0] cached_file;
    typedef enum logic [3:0] {CONFIG_IDLE,CONFIG_READ,CONFIG_COMPARE,CONFIG_STORE,
        SEALED,MAP_READ,MAP_COMPARE,MAP_RESPONSE,CONFIG_PAGE,PAGE_READ,PAGE_COMPARE} state_t;
    state_t state;
    assign descriptor_ready=state==CONFIG_IDLE && !reset && !new_track && !fault;
    assign request_ready=state==SEALED && !reset && !new_track && !fault;
    assign response_valid=state==MAP_RESPONSE && !reset && !new_track;
    assign stored_start=descriptor_q[76:55];
    assign stored_end=descriptor_q[54:32];
    assign stored_file=descriptor_q[31:0];
    assign logical_end={1'b0,descriptor_start}+{1'b0,descriptor_length};
    assign file_end={1'b0,descriptor_file_start}+{1'b0,descriptor_length};
    assign pending_start=pending_descriptor[76:55];
    assign pending_end=pending_descriptor[54:32];
    assign pending_file=pending_descriptor[31:0];
    assign mapped_file={1'b0,stored_file}+{1'b0,logical_address}-{11'd0,stored_start};
    assign cached_file={1'b0,mapping_cache[31:0]}+{1'b0,request_logical_address}-
                       {11'd0,mapping_cache[76:55]};
    initial begin
        if(CAPACITY<2 || CAPACITY!=(1<<INDEX_WIDTH)) $fatal(1,"invalid descriptor capacity");
    end
    // Only validity/count is reset. A configuration write never overlaps lookup.
    always_ff @(posedge clk) begin
        descriptor_q<=descriptors[read_index];
        page_q<=pages[page_read_index];
        if(PAGE_INDEX && state==CONFIG_PAGE && !reset && !new_track && !fault)
            pages[page_index]<=pending_descriptor;
        if(state==CONFIG_STORE && !reset && !new_track && !fault)
            descriptors[descriptor_count[INDEX_WIDTH-1:0]]<=pending_descriptor;
    end
    task automatic reject_config(input logic [7:0] code);
        fault<=1;fault_code<=code;published<=0;
    endtask
    task automatic complete_map(input logic [7:0] error, input logic [31:0] address);
        response_epoch<=owned_epoch;response_error<=error;
        response_file_address<=error==0 ? address : 0;
        state<=MAP_RESPONSE;
    endtask
    always_ff @(posedge clk) begin
        if(reset || new_track) begin
            state<=CONFIG_IDLE;descriptor_count<=0;read_index<=0;
            pending_descriptor<=0;rom_size<=0;owned_extent<=0;owned_epoch<=epoch;
            mapping_cache_valid<=0;mapping_cache<=0;
            page_valid<=0;page_ambiguous<=0;page_index<=0;page_read_index<=0;
            logical_address<=0;published<=0;fault<=0;fault_code<=0;
            response_file_address<=0;response_epoch<=0;response_error<=0;
        end else if(!fault) begin
            case(state)
                CONFIG_IDLE: begin
                    if(descriptor_valid && descriptor_ready) begin
                        if(descriptor_count==(INDEX_WIDTH+1)'(CAPACITY)) reject_config(8'h02);
                        else if(descriptor_rom_size==0 || descriptor_rom_size>32'h00400000 ||
                            descriptor_start>=descriptor_rom_size || descriptor_length==0 ||
                            logical_end>{1'b0,descriptor_rom_size} || file_end>{1'b0,file_extent} ||
                            descriptor_file_start<{29'd0,descriptor_start[2:0]} ||
                            (descriptor_count!=0 && descriptor_rom_size!=rom_size)) reject_config(8'h01);
                        else begin
                            pending_descriptor<={descriptor_start[21:3],3'b000,
                                logical_end[22:0],descriptor_file_start-{29'd0,descriptor_start[2:0]}};
                            rom_size<=descriptor_rom_size;owned_extent<=file_extent;owned_epoch<=epoch;
                            read_index<=0;
                            if(descriptor_count==0) state<=CONFIG_STORE;
                            else state<=CONFIG_READ;
                        end
                    end else if(publish) begin published<=1;state<=SEALED;end
                end
                CONFIG_READ: state<=CONFIG_COMPARE;
                CONFIG_COMPARE: begin
                    // Preserve legacy D's nonoverlapping resource admission.
                    // A later-overlap policy is not silently invented here.
                    if({1'b0,pending_start}<stored_end && {1'b0,stored_start}<pending_end)
                        reject_config(8'h03);
                    else if({1'b0,read_index}+1'b1==descriptor_count) state<=CONFIG_STORE;
                    else begin read_index<=read_index+1'b1;state<=CONFIG_READ;end
                end
                CONFIG_STORE: begin
                    descriptor_count<=descriptor_count+1'b1;
                    page_index<=pending_start[21:16];
                    state<=PAGE_INDEX ? CONFIG_PAGE : CONFIG_IDLE;
                end
                CONFIG_PAGE: begin
                    if(page_valid[page_index]) page_ambiguous[page_index]<=1;
                    page_valid[page_index]<=1;
                    if({1'b0,page_index}==((pending_end-23'd1)>>16)) state<=CONFIG_IDLE;
                    else page_index<=page_index+1'b1;
                end
                SEALED: if(request_valid && request_ready) begin
                    logical_address<=request_logical_address;read_index<=0;page_read_index<=request_logical_address[21:16];
                    if(epoch!=owned_epoch) complete_map(8'h08,0);
                    else if(descriptor_count==0) complete_map(8'h04,0);
                    else if(request_logical_address>=rom_size) complete_map(8'h05,0);
                    else if(request_logical_address[2:0]!=0) complete_map(8'h07,0);
                    else if(LOOKUP_CACHE && mapping_cache_valid && request_logical_address>={10'd0,mapping_cache[76:55]} &&
                            {1'b0,request_logical_address}<{10'd0,mapping_cache[54:32]}) begin
                        if(cached_file+33'd8>{1'b0,owned_extent}) complete_map(8'h06,0);
                        else complete_map(0,cached_file[31:0]);
                    end
                    else state<=PAGE_INDEX ? PAGE_READ : MAP_READ;
                end
                PAGE_READ: state<=PAGE_COMPARE;
                PAGE_COMPARE: begin
                    if(epoch!=owned_epoch) complete_map(8'h08,0);
                    else if(page_valid[page_read_index] && !page_ambiguous[page_read_index] &&
                            logical_address>={10'd0,page_q[76:55]} &&
                            {1'b0,logical_address}<{10'd0,page_q[54:32]}) begin
                        if(page_file+33'd8>{1'b0,owned_extent}) complete_map(8'h06,0);
                        else begin mapping_cache<=page_q;mapping_cache_valid<=1;complete_map(0,page_file[31:0]);end
                    end else state<=MAP_READ;
                end
                MAP_READ: state<=MAP_COMPARE;
                MAP_COMPARE: begin
                    if(epoch!=owned_epoch) complete_map(8'h08,0);
                    else if(logical_address>={10'd0,stored_start} &&
                            {1'b0,logical_address}<{10'd0,stored_end}) begin
                        // Validate the full eight-byte fetch before any backend projection.
                        if(mapped_file+33'd8>{1'b0,owned_extent}) complete_map(8'h06,0);
                        else begin
                            mapping_cache<=descriptor_q;mapping_cache_valid<=1;
                            complete_map(0,mapped_file[31:0]);
                        end
                    end else if({1'b0,read_index}+1'b1==descriptor_count) complete_map(8'h04,0);
                    else begin read_index<=read_index+1'b1;state<=MAP_READ;end
                end
                MAP_RESPONSE: if(response_ready) state<=SEALED;
                default: reject_config(8'hff);
            endcase
        end
    end
endmodule
