// Two passes through the same pinned Parser. The caller owns chip reset/init,
// physical Strict Reader debt, native snapshot phase, output/UI and Transport.
// Post-start ticks are never qualified by storage, queue state or chip busy.
module engine_d_vnext_command_client #(
    parameter int SCHEDULER_DEPTH=32,parameter int YM_FIFO_DEPTH=256
) (
    input logic clk,reset,preflight_start,prepare_playback,play_start,playback_tick,
    input logic chip_enabled,ym_enabled,resources_ready,resource_fault,
    input logic [31:0] image_size,
    input logic [7:0] c140_type,
    output logic memory_request,
    input logic memory_ready,memory_valid,
    output logic [31:0] memory_address,
    input logic [7:0] memory_data,
    output logic preflight_done,preflight_accepted,playback_prepared,initial_commands_ready,initialization_ready,timeline_started,
    output logic descriptor_valid,
    input logic descriptor_ready,
    output logic [31:0] descriptor_rom_size,descriptor_start,descriptor_length,descriptor_file_start,
    output logic publish_resources,
    output logic [31:0] descriptor_count,
    output logic ym_write,
    output logic [7:0] ym_address,ym_data,
    input logic ym_ready,
    output logic c140_write,
    output logic [15:0] c140_address,
    output logic [7:0] c140_data,
    input logic c140_ready,native_drained,transport_halt_loop,transport_finish,
    output logic loop_entry,loop_boundary,finished,fault,
    output logic [7:0] fault_code,
    output logic [31:0] first_bad_pc,
    output logic [63:0] due_time,playback_time,
    input logic [63:0] native_time,
    output logic native_horizon_known,native_control_debt,
    output logic [31:0] command_pc,
    output logic [7:0] command_opcode,
    output logic [5:0] command_state,
    output logic [$clog2(YM_FIFO_DEPTH):0] ym_level,ym_max_level
);
    import vgm_parser_vnext_event_pkg::*;
    import vgm_scheduler_vnext_pkg::*;
    typedef enum logic [2:0] {IDLE,SCAN_ARM,SCAN,VALIDATED,REPLAY_ARM,PLAY} phase_t;
    phase_t phase;
    logic event_valid,event_ready,data_event_valid,dac_fact_valid,decoder_done;
    logic loop_present,loop_terminal_valid,loop_entry_seen,resume_ready,resume_fault;
    logic [31:0] file_extent,data_start,loop_target,loop_terminal_pc,resume_pc;
    logic resume_valid;
    decode_event_t event_data;
    write_descriptor_t write_info,ym_descriptor,c140_descriptor;
    data_event_t data_event_data;
    dac_stream_fact_t dac_fact_data;
    normalized_fact_t fact;
    logic fact_valid,fact_ready,pf_ready,scheduler_ready;
    logic [7:0] pf_reject;
    logic [31:0] pf_bad_pc;
    logic [6:0] commit_valid,commit_ready;
    scheduled_fact_t commits[7],barrier;
    scheduled_fact_t ym_commit,c140_commit;
    logic barrier_valid,barrier_ready,loop_waiting,release_pulse,halted,terminal,scheduler_fault;
    logic [2:0] scheduler_reason;
    logic [63:0] next_sequence;
    logic [$clog2(SCHEDULER_DEPTH):0] levels[7];
    logic decision_valid,decision_halt;
    logic ym_input_ready,ym_enqueue,ym_adapter_ready,ym_rejected;
    logic ym_valid,ym_empty,c140_rejected,c140_adapter_ready;
    logic [7:0] ym_queue_address,ym_queue_data;
    logic [15:0] ym_head;
    // A direct capability guard constrains the unchanged Scheduler's input
    // to D's two admitted WRITE targets. It preserves every fact bit/ABI and
    // also makes unused target queue enables statically unreachable; no
    // temporal Preflight assumption or chip-specific Parser is required.
    wire schedule_capability=fact.kind!=S_DAC &&
        (fact.kind!=S_WRITE || fact.target==3'd2 || fact.target==3'd6);
    wire prepare_fire=prepare_playback && (phase==SCAN || phase==VALIDATED) &&
                      preflight_done && preflight_accepted && resources_ready && !resource_fault;
    wire decode_reset=reset || preflight_start || prepare_fire;
    wire playing=phase==PLAY && !preflight_start;
    wire executable=playing && chip_enabled && !fault && !transport_finish;
    assign playback_prepared=playing;
    // Native due-zero initialization drains before the caller starts the
    // continuous clock. Subsequent busy/resource conditions never stop it.
    assign initial_commands_ready=playing && native_horizon_known && native_drained &&
        (levels[2]==0 || ym_commit.due_time!=0) && (levels[6]==0 || c140_commit.due_time!=0);
    assign initialization_ready=initial_commands_ready && ym_empty && ym_ready;
    assign fact_ready=playing ? (scheduler_ready && schedule_capability) : phase==SCAN ? pf_ready : 1'b0;
    assign publish_resources=preflight_done && preflight_accepted;
    assign ym_commit=commits[2];assign c140_commit=commits[6];
    assign ym_descriptor=ym_commit.fact.payload[134:80];
    assign c140_descriptor=c140_commit.fact.payload[134:80];
    assign native_control_debt=levels[6]!=0 && c140_commit.due_time<=native_time;
    assign native_horizon_known=due_time>native_time || terminal || halted ||
        (barrier_valid && (barrier.fact.kind==S_END || barrier.fact.kind==S_LOOP_BOUNDARY));
    assign command_state={3'd0,phase};
    assign ym_write=ym_valid && executable && ym_enabled && ym_ready;
    assign ym_address=ym_head[15:8];assign ym_data=ym_head[7:0];
    assign barrier_ready=executable &&
        ((barrier.fact.kind==S_DATA || barrier.fact.kind==S_LOOP_ENTRY) ||
         (ym_empty && ym_ready && native_drained));
    assign loop_entry=barrier_valid && barrier_ready && barrier.fact.kind==S_LOOP_ENTRY;
    assign loop_boundary=barrier_valid && barrier_ready && barrier.fact.kind==S_LOOP_BOUNDARY;
    assign finished=terminal || halted || (playing && transport_finish);
    always @* begin
        commit_ready='0;commit_ready[2]=ym_adapter_ready;commit_ready[6]=c140_adapter_ready;
    end
    always_ff @(posedge clk) begin
        if(reset || preflight_start) begin
            if(preflight_start) phase<=SCAN_ARM;else phase<=IDLE;
            timeline_started<=0;
            fault<=0;fault_code<=0;first_bad_pc<=0;
            command_pc<=0;command_opcode<=0;
        end else begin
            case(phase)
                SCAN_ARM:phase<=SCAN;
                SCAN:if(prepare_fire) phase<=REPLAY_ARM;else if(preflight_done) phase<=VALIDATED;
                VALIDATED:if(prepare_fire) phase<=REPLAY_ARM;
                REPLAY_ARM:phase<=PLAY;
                default:begin end
            endcase
            if(playing && play_start) timeline_started<=1;
            if(fact_valid && fact_ready && fact.kind!=S_LOOP_ENTRY) begin
                command_pc<=source_pc(fact);
                command_opcode<=data_event_valid ? data_event_data.opcode : loop_terminal_valid ? 8'h66 : event_data.opcode;
            end
            if(!fault) begin
                if(resource_fault) begin fault<=1;fault_code<=8'h20;end
                else if(preflight_done && !preflight_accepted) begin fault<=1;fault_code<=pf_reject;first_bad_pc<=pf_bad_pc;end
                else if(resume_fault || scheduler_fault || ym_rejected || c140_rejected ||
                    (playing && fact_valid && !schedule_capability) ||
                    (playing && |(commit_valid & 7'b0111011))) begin
                    fault<=1;fault_code<=8'h21;first_bad_pc<=source_pc(fact);
                end
            end
        end
    end
    vgm_parser_vnext_decoder #(.DATA_GRAMMAR(1),.COMMON_WRITE_GRAMMAR(1),.RESUME_CONTROL(1)) parser(
        .clk,.reset(decode_reset),.start(phase==SCAN_ARM || phase==REPLAY_ARM),
        .resume_valid,.resume_pc,.resume_ready,.resume_fault,.image_size,
        .reader_req_valid(memory_request),.reader_req_ready(memory_ready),.reader_req_addr(memory_address),
        .reader_rsp_valid(memory_valid),.reader_rsp_byte(memory_data),
        .event_valid,.event_ready,.event_data,.write_info,.data_event_valid,.data_event_data,
        .dac_fact_valid,.dac_fact_data,.done(decoder_done),.file_extent,.data_start,.loop_present,.loop_target,
        .loop_terminal_valid,.loop_terminal_pc,.loop_entry_seen);
    vgm_scheduler_vnext_normalizer normalizer(.clk,.reset(decode_reset),.*);
    engine_d_vnext_preflight #(.YM_INITIAL_CAPACITY(YM_FIFO_DEPTH)) admission(.clk,.reset(reset || preflight_start),.start(phase==SCAN_ARM),
        .file_extent,.c140_type,.fact_valid(fact_valid && phase==SCAN),.fact_ready(pf_ready),.fact,
        .descriptor_valid,.descriptor_ready,.descriptor_rom_size,.descriptor_start,.descriptor_length,.descriptor_file_start,
        .done(preflight_done),.accepted(preflight_accepted),.reject_code(pf_reject),.first_bad_pc(pf_bad_pc),.descriptor_count);
    vgm_scheduler_vnext #(.TARGETS(7),.DEPTH(SCHEDULER_DEPTH)) scheduler(
        .clk,.reset(reset || !playing),.play_start(playing),.playback_tick(playback_tick && timeline_started),
        .fact_valid(fact_valid && playing && schedule_capability && !fault && !transport_finish),.fact_ready(scheduler_ready),.fact,
        .commit_valid,.commit_ready,.commits,.barrier_valid,.barrier_ready,.barrier,
        .loop_decision_valid(decision_valid),.loop_halt(decision_halt),.loop_waiting,
        .loop_release_pulse(release_pulse),.halted,.terminal,.fault_latched(scheduler_fault),
        .fault_reason(scheduler_reason),.due_time,.playback_time,.next_sequence,.levels);
    engine_a_vnext_loop_continuation_client continuation(.clk,.reset(reset || !playing),.new_track(preflight_start),
        .boundary_valid(loop_boundary),.boundary_ready(1'b1),.boundary_target(barrier.fact.payload[63:32]),
        .owner_halt(transport_halt_loop),.scheduler_waiting(loop_waiting),.scheduler_release(release_pulse),
        .decision_valid,.decision_halt,.resume_valid,.resume_ready,.resume_pc,.busy());
    engine_a_vnext_chip_write_adapter #(.TARGET(2)) ym_adapter(.enabled(executable),.valid(commit_valid[2]),
        .core_ready(ym_input_ready),.descriptor(ym_descriptor),.ready(ym_adapter_ready),.write_pulse(ym_enqueue),
        .port(),.rejected(ym_rejected),.control_noop(),.address(ym_queue_address),.data(ym_queue_data));
    engine_d_vnext_ym_command_fifo #(.DEPTH(YM_FIFO_DEPTH)) ym_queue(.clk,.reset(reset || !playing),
        .input_valid(ym_enqueue),.input_ready(ym_input_ready),.input_data({ym_queue_address,ym_queue_data}),
        .output_valid(ym_valid),.output_ready(ym_ready && executable && ym_enabled),.output_data(ym_head),
        .empty(ym_empty),.level(ym_level),.max_level(ym_max_level));
    engine_d_vnext_c140_write_adapter c140_adapter(.enabled(executable),.valid(commit_valid[6]),
        .core_ready(c140_ready),.descriptor(c140_descriptor),.ready(c140_adapter_ready),.write_pulse(c140_write),
        .rejected(c140_rejected),.address(c140_address),.data(c140_data));
endmodule
