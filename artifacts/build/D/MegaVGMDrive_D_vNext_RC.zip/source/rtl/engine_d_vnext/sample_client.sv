// C140 logical line -> immutable resource map -> Strict shared byte/word reader.
// Core owns two cache lines per voice. This client owns one fetch and retains
// two authenticated boundary words. The two-entry cache also shares an
// unaligned line across simultaneous voice starts; no resource prewarm store.
module engine_d_vnext_sample_client #(
    parameter bit BOUNDARY_CACHE=1,
    parameter int BOUNDARY_WORDS=2
) (
    input logic clk,reset,new_track,prepared,
    input logic [31:0] epoch,file_extent,
    input logic core_request,
    output logic core_ready,core_valid,
    input logic [31:0] core_logical_address,
    input logic [4:0] core_voice,
    input logic [7:0] core_generation,
    output logic [63:0] core_data,
    output logic [4:0] response_voice,
    output logic [7:0] response_generation,
    output logic map_request,
    input logic map_ready,
    output logic [31:0] map_logical_address,
    input logic map_valid,
    output logic map_response_ready,
    input logic [31:0] map_file_address,map_epoch,
    input logic [7:0] map_error,
    output logic memory_request,
    input logic memory_ready,memory_valid,memory_fault,
    output logic [31:0] memory_address,
    input logic [7:0] memory_data,
    input logic word_valid,
    input logic [31:0] word_address,word_epoch,
    input logic [63:0] word_data,
    output logic fault,
    output logic [7:0] fault_code
);
    typedef enum logic [2:0] {IDLE,MAP_OFFER,MAP_WAIT,READ_OFFER,READ_WAIT,REPLY,FAILED} state_t;
    state_t state;
    logic [31:0] owned_epoch,owned_extent,logical_address,file_address,second_address;
    logic [4:0] voice;
    logic [7:0] generation;
    logic second,have_word,have_byte;
    logic [63:0] first_word,observed_word;
    logic [7:0] observed_byte;
    logic [127:0] joined;
    logic cache_valid,cache1_valid,replace_second;
    logic [28:0] cache_tag,cache1_tag;
    logic [31:0] cache_epoch,cache_extent;
    logic [63:0] cache_word,cache1_word,hit_word;
    wire hit0=cache_valid && cache_tag==memory_address[31:3];
    wire hit1=BOUNDARY_WORDS==2 && cache1_valid && cache1_tag==memory_address[31:3];
    wire cache_hit=BOUNDARY_CACHE && cache_epoch==owned_epoch && cache_extent==owned_extent && (hit0 || hit1);
    assign hit_word=hit0 ? cache_word : cache1_word;
    initial begin
        if(BOUNDARY_WORDS<1 || BOUNDARY_WORDS>2) $fatal(1,"invalid boundary cache size");
    end
    wire active=!reset && !new_track && owned_epoch==epoch && owned_extent==file_extent;
    assign core_ready=state==IDLE && prepared && !reset && !new_track && !fault;
    assign map_request=state==MAP_OFFER && active;
    assign map_logical_address=logical_address;
    assign map_response_ready=state==MAP_WAIT && active;
    assign memory_request=state==READ_OFFER && active && !cache_hit;
    assign memory_address=second ? second_address : file_address;
    assign core_valid=state==REPLY && active && !fault;
    assign response_voice=voice;assign response_generation=generation;
    assign joined={observed_word,first_word};
    task automatic fail(input logic [7:0] code);
        fault<=1;fault_code<=code;state<=FAILED;
    endtask
    always_ff @(posedge clk) begin
        if(reset || new_track) begin
            state<=IDLE;owned_epoch<=epoch;owned_extent<=file_extent;logical_address<=0;
            file_address<=0;second_address<=0;voice<=0;generation<=0;
            second<=0;have_word<=0;have_byte<=0;first_word<=0;observed_word<=0;
            observed_byte<=0;core_data<=0;fault<=0;fault_code<=0;
            cache_valid<=0;cache_tag<=0;cache_epoch<=0;cache_extent<=0;cache_word<=0;
            cache1_valid<=0;cache1_tag<=0;cache1_word<=0;replace_second<=0;
        end else if(state!=IDLE && state!=FAILED && !active) fail(8'h08);
        else begin
            case(state)
                IDLE: if(core_request && core_ready) begin
                    owned_epoch<=epoch;owned_extent<=file_extent;logical_address<=core_logical_address;
                    voice<=core_voice;generation<=core_generation;state<=MAP_OFFER;
                    if(cache_epoch!=epoch || cache_extent!=file_extent) begin
                        cache_valid<=0;cache1_valid<=0;replace_second<=0;
                        cache_epoch<=epoch;cache_extent<=file_extent;
                    end
                end
                MAP_OFFER: if(map_request && map_ready) state<=MAP_WAIT;
                MAP_WAIT: if(map_valid && map_response_ready) begin
                    if(map_error!=0) fail(map_error);
                    else if(map_epoch!=owned_epoch) fail(8'h08);
                    else if({1'b0,map_file_address}+33'd8>{1'b0,owned_extent}) fail(8'h06);
                    else begin
                        file_address<=map_file_address;
                        second_address<={map_file_address[31:3],3'd0}+32'd8;
                        second<=0;have_word<=0;have_byte<=0;state<=READ_OFFER;
                    end
                end
                READ_OFFER: begin
                    if(memory_fault) fail(8'h10);
                    else if(cache_hit) begin
                        observed_word<=hit_word;observed_byte<=hit_word[memory_address[2:0]*8+:8];
                        have_word<=1;have_byte<=1;state<=READ_WAIT;
                    end
                    else if(memory_request && memory_ready) state<=READ_WAIT;
                end
                READ_WAIT: begin
                    if(memory_fault) fail(8'h10);
                    else if(word_valid && (word_address!=memory_address || word_epoch!=owned_epoch)) fail(8'h11);
                    else begin
                        if(word_valid) begin
                            observed_word<=word_data;have_word<=1;
                        end
                        if(memory_valid) begin observed_byte<=memory_data;have_byte<=1;end
                        if(have_word && have_byte) begin
                            // Authenticate the physical word against its demanded READ_OK lane.
                            if(observed_word[memory_address[2:0]*8+:8]!=observed_byte) fail(8'h12);
                            else begin
                                if(!cache_hit) begin
                                    if(BOUNDARY_WORDS==2 && replace_second) begin
                                        cache1_valid<=1;cache1_tag<=memory_address[31:3];cache1_word<=observed_word;
                                    end else begin
                                        cache_valid<=1;cache_tag<=memory_address[31:3];cache_word<=observed_word;
                                    end
                                    replace_second<=!replace_second;
                                end
                                if(!second && file_address[2:0]!=0) begin
                                    first_word<=observed_word;second<=1;have_word<=0;have_byte<=0;state<=READ_OFFER;
                                end else begin
                                    core_data<=second ? 64'(joined>>(file_address[2:0]*8)) : observed_word;
                                    state<=REPLY;
                                end
                            end
                        end
                    end
                end
                REPLY:state<=IDLE;
                default:begin end
            endcase
        end
    end
endmodule
