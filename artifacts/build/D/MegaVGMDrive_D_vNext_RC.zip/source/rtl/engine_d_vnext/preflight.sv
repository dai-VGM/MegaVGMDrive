// PASS1 fact admission only. The same Common Parser is replayed for playback.
// No byte reader, grammar decoder, chip write, sample clock or loop policy.
module engine_d_vnext_preflight #(
    parameter int MAX_DESCRIPTORS = 16,parameter int YM_INITIAL_CAPACITY=256
) (
    input logic clk, reset, start,
    input logic [31:0] file_extent,
    input logic [7:0] c140_type,
    input logic fact_valid,
    output logic fact_ready,
    input vgm_scheduler_vnext_pkg::normalized_fact_t fact,
    output logic descriptor_valid,
    input logic descriptor_ready,
    output logic [31:0] descriptor_rom_size, descriptor_start,
    output logic [31:0] descriptor_length, descriptor_file_start,
    output logic done, accepted,
    output logic [7:0] reject_code,
    output logic [31:0] first_bad_pc,
    output logic [31:0] descriptor_count
);
    import vgm_parser_vnext_event_pkg::*;
    import vgm_scheduler_vnext_pkg::*;
    logic scanning, write_supported, block_supported, resources_closed,positive_wait_seen;
    logic [$clog2(YM_INITIAL_CAPACITY+1)-1:0] initial_ym_count;
    write_descriptor_t write_info;
    data_event_t resource;
    logic [32:0] logical_end, file_end;
    assign write_info = fact.payload[134:80];
    assign resource = fact.payload;
    assign descriptor_rom_size = resource.operands[79:48];
    assign descriptor_start = resource.operands[111:80];
    assign descriptor_length = resource.payload_length;
    assign descriptor_file_start = resource.payload_offset;
    assign logical_end = {1'b0,descriptor_start}+{1'b0,descriptor_length};
    assign file_end = {1'b0,descriptor_file_start}+{1'b0,descriptor_length};
    assign block_supported = resource.kind==DATA_BLOCK &&
        resource.block_type==8'h8d && !resource.instance_id &&
        resource.metadata_bytes==8 && descriptor_rom_size!=0 &&
        descriptor_rom_size<=32'h00400000 && descriptor_start<descriptor_rom_size &&
        descriptor_length!=0 && logical_end<={1'b0,descriptor_rom_size} &&
        file_end<={1'b0,file_extent} && descriptor_count<MAX_DESCRIPTORS && !resources_closed;
    assign write_supported = !write_info.instance_id && !write_info.port &&
        write_info.access_kind==ACCESS_REGISTER &&
        ((write_info.chip==CHIP_YM2151 && write_info.address[15:8]==0) ||
          write_info.chip==CHIP_C140);
    assign descriptor_valid = scanning && !reset && !start && fact_valid &&
                              fact.kind==S_DATA && block_supported;
    assign fact_ready = scanning && !reset && !start &&
                        (fact.kind!=S_DATA || !block_supported || descriptor_ready);
    task automatic reject(input logic [7:0] code);
        reject_code<=code;first_bad_pc<=source_pc(fact);
        scanning<=0;done<=1;accepted<=0;
    endtask
    always_ff @(posedge clk) begin
        if(reset || start) begin
            scanning<=start && (c140_type==0 || c140_type==1);
            done<=start && (c140_type!=0 && c140_type!=1);
            accepted<=0;reject_code<=start && c140_type>1 ? 8'h01 : 0;
            first_bad_pc<=0;descriptor_count<=0;resources_closed<=0;
            positive_wait_seen<=0;initial_ym_count<=0;
        end else if(fact_valid && fact_ready) begin
            case(fact.kind)
                S_WRITE: begin
                    resources_closed<=1;
                    if(!write_supported) reject(8'h02);
                    else if(!positive_wait_seen && write_info.chip==CHIP_YM2151) begin
                        // Startup must fit before phase-closed Core release.
                        // Reject before audio, rather than deadlock a full FIFO.
                        if(initial_ym_count==$clog2(YM_INITIAL_CAPACITY+1)'(YM_INITIAL_CAPACITY)) reject(8'h06);
                        else initial_ym_count<=initial_ym_count+1'b1;
                    end
                end
                S_DATA: begin
                    if(resources_closed) reject(8'h05);
                    else if(!block_supported) reject(8'h03);
                    else descriptor_count<=descriptor_count+1'b1;
                end
                S_END,S_LOOP_BOUNDARY: begin scanning<=0;done<=1;accepted<=1;end
                S_WAIT: if(fact.time_advance!=0) begin resources_closed<=1;positive_wait_seen<=1;end
                S_LOOP_ENTRY: begin end
                default: reject(8'h04);
            endcase
        end
    end
endmodule
