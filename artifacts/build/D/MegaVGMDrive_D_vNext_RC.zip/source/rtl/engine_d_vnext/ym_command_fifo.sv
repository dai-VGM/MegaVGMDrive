// Narrow native-bus queue. Due/sequence remain Scheduler facts; simulation
// scoreboards observe commits externally. No production trace/CAM/MUX array.
module engine_d_vnext_ym_command_fifo #(
    parameter int DEPTH=256,parameter int ADDRESS_WIDTH=$clog2(DEPTH)
) (
    input logic clk,reset,
    input logic input_valid,
    output logic input_ready,
    input logic [15:0] input_data,
    output logic output_valid,
    input logic output_ready,
    output logic [15:0] output_data,
    output logic empty,
    output logic [ADDRESS_WIDTH:0] level,max_level
);
    (* ramstyle="M10K, no_rw_check" *) logic [15:0] memory [0:DEPTH-1];
    logic [ADDRESS_WIDTH-1:0] read_pointer,write_pointer;
    logic [15:0] read_q,head;
    logic head_valid,read_pending;
    wire push=input_valid && input_ready;
    wire pop=output_valid && output_ready;
    assign input_ready=!reset && level<(ADDRESS_WIDTH+1)'(DEPTH);
    assign output_valid=!reset && head_valid;
    assign output_data=head;
    assign empty=level==0;
    initial begin
        if(DEPTH<2 || DEPTH!=(1<<ADDRESS_WIDTH)) $fatal(1,"invalid YM FIFO capacity");
    end
    always_ff @(posedge clk) begin
        read_q<=memory[read_pointer];
        if(push) memory[write_pointer]<=input_data;
    end
    always_ff @(posedge clk) begin
        if(reset) begin
            read_pointer<=0;write_pointer<=0;head_valid<=0;read_pending<=0;head<=0;
            level<=0;max_level<=0;
        end else begin
            case({push,pop})
                2'b10:begin level<=level+1'b1;if(level+1'b1>max_level) max_level<=level+1'b1;end
                2'b01:level<=level-1'b1;
                default:begin end
            endcase
            if(push) write_pointer<=write_pointer+1'b1;
            if(pop) begin read_pointer<=read_pointer+1'b1;head_valid<=0;end
            if(!head_valid && !read_pending && level!=0) read_pending<=1;
            if(read_pending) begin head<=read_q;head_valid<=1;read_pending<=0;end
        end
    end
endmodule
