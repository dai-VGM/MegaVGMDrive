// Generic WRITE descriptor -> unchanged C140 register interface.
// Capability validation is outside Parser; no timing/resource/loop policy here.
module engine_d_vnext_c140_write_adapter (
    input logic enabled, valid, core_ready,
    input vgm_parser_vnext_event_pkg::write_descriptor_t descriptor,
    output logic ready, write_pulse, rejected,
    output logic [15:0] address,
    output logic [7:0] data
);
    import vgm_parser_vnext_event_pkg::*;
    logic supported;
    // Preserve the full encoded register address. The unchanged Core owns
    // ignored register locations as well as the 24 voice register records.
    assign supported = descriptor.chip == CHIP_C140 &&
                       !descriptor.instance_id && !descriptor.port &&
                       descriptor.access_kind == ACCESS_REGISTER;
    assign ready = enabled && (supported ? core_ready : 1'b1);
    assign rejected = enabled && valid && !supported;
    assign write_pulse = valid && ready && supported;
    assign address = descriptor.address;
    assign data = descriptor.data;
endmodule
