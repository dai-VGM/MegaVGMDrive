// D vNext attachment to unchanged Golden upload, shell, audio and UI interfaces.
module c140_stage3_profile #(
    parameter int RUN_MODE = 2,
    parameter int COMMAND_SETTLE_CYCLES = 288,
    parameter bit TRANSPORT_LOOP_CONTROL = 1'b0
) (
    input  logic         clk,
    input  logic         reset,
    input  logic         audio_isolate_step,
    input  logic         audio_gain_boost,
    input  logic         transport_loop_policy_active,
    input  logic         transport_halt_loop,
    input  logic         transport_finish,
    output logic         playback_loop_entry_pulse,
    output logic         playback_loop_boundary_pulse,
    input  logic         ioctl_download,
    input  logic         ioctl_wr,
    input  logic [26:0]  ioctl_addr,
    input  logic [7:0]   ioctl_dout,
    input  logic [15:0]  ioctl_index,
    output logic         ioctl_wait,

    input  logic         ddram_busy,
    output logic [7:0]   ddram_burstcnt,
    output logic [28:0]  ddram_addr,
    input  logic [63:0]  ddram_dout,
    input  logic         ddram_dout_ready,
    output logic         ddram_rd,
    output logic [63:0]  ddram_din,
    output logic [7:0]   ddram_be,
    output logic         ddram_we,

    output logic signed [15:0] audio_l,
    output logic signed [15:0] audio_r,
    output logic         audio_sample_valid,
    output logic         audio_enable,
    output logic         playback_active,
    output logic         playback_done,
    output logic         profile_fatal,
    output logic [7:0]   error_code,
    output logic [2:0]   profile_state,
    output logic         load_busy,
    output logic         load_done,
    output logic         load_error,
    output logic         load_overflow,
    output logic [23:0]  uploaded_file_size,
    output logic [23:0]  accepted_byte_count,
    output logic [3:0]   wait_reason,
    output logic [7:0]   outstanding_fifo,
    output logic         scan_started,
    output logic [31:0]  vgm_sample_time,
    output logic [31:0]  natural_end_count,
    output logic [31:0]  command_deadline_miss_count,
    output logic [22:0]  debug_command_pc,
    output logic [7:0]   debug_last_command,
    output logic [5:0]   debug_parser_state,
    output logic [4:0]   debug_active_count,
    output logic [31:0]  debug_underflow_count,
    output logic [31:0]  debug_descriptor_miss_count,
    output logic [31:0]  debug_stale_response_count,
    output logic [31:0]  debug_raw_fetch_count,
    output logic [31:0]  debug_compressed_fetch_count,
    output logic         debug_first_deadline_valid,
    output logic [22:0]  debug_first_deadline_pc,
    output logic [7:0]   debug_first_deadline_command,
    output logic [5:0]   debug_first_deadline_state,
    output logic [7:0]   debug_first_deadline_flags,
    output logic [31:0]  debug_first_deadline_producer_time,
    output logic [31:0]  debug_first_deadline_playback_time,
    output logic [15:0]  debug_first_deadline_frame_clock,
    output logic [15:0]  debug_first_deadline_retired,
    output logic [7:0]   debug_first_deadline_reason,
    output logic [7:0]   ym2151_activity_event,
    output logic [23:0]  c140_activity_state,
    output logic         profile_system21
);
    localparam int FILE_ADDR_WIDTH=23,DDRAM_ADDR_WIDTH=29,WRITE_FIFO_DEPTH=256;
    localparam logic [7:0] FILE_INDEX=8'd1;
    localparam logic [28:0] DDRAM_BASE_ADDR={4'b0011,25'd0};
    localparam logic [28:0] UNUSED_PCM_BASE=DDRAM_BASE_ADDR+29'h00100000;
    // Configuration initialization only. Live reset/cancel never clears the
    // physical ledger, even when the unchanged Golden backend is reset.
    logic power_reset=1'b1;
    always_ff @(posedge clk) power_reset<=1'b0;
    // The unchanged YM wrapper's CEN accumulator/half-rate phase free-run
    // through reset. gcd(20_000_000,3_579_545)=5: accumulator repeats after
    // 4_000_000 clocks; its odd 715_909 enables invert P1 phase, so the full
    // phase repeats after 8_000_000. This power-initialized shadow advances
    // even through user reset, exactly as that wrapper does. Release only on
    // one repeated phase after enabled reset flush. No VGM tick exists yet.
    logic [22:0] ym_clock_phase=23'd0;
    always_ff @(posedge clk) begin
        if(ym_clock_phase==23'd7999999) ym_clock_phase<=0;
        else ym_clock_phase<=ym_clock_phase+1'b1;
    end
    logic download_q,stopped;
    logic [31:0] epoch=0;
    logic [31:0] uploaded_vgm_version;
    logic [7:0] uploaded_c140_type;
    wire load_begin=ioctl_download && !download_q;
    wire accepted_upload=ioctl_download && ioctl_wr && !ioctl_wait && ioctl_index[7:0]==FILE_INDEX;
    logic backend_load_busy,backend_load_done,backend_load_error,backend_overflow_error;
    logic [31:0] backend_file_size;
    logic [15:0] backend_fifo_debug,backend_ready_debug;
    logic [7:0] backend_ddram_burstcnt,backend_ddram_be;
    logic [28:0] backend_ddram_addr;
    logic backend_ddram_rd,backend_ddram_we,golden_busy;
    logic [63:0] backend_ddram_din;
    logic load_done_pulse,golden_request,golden_ready,golden_valid;
    logic [22:0] golden_byte_address;
    logic [7:0] golden_data;
    logic command_request,command_ready,command_valid,command_word_valid,command_read_priority;
    logic sample_request,sample_ready,sample_valid,sample_word_valid;
    logic [31:0] command_address,sample_address,word_address,word_epoch;
    logic [7:0] command_data,sample_data;
    logic [63:0] word_data;
    logic source_request,source_ready,source_valid,source_fault,source_captured,source_word_valid;
    logic [31:0] source_address,source_word_address,source_word_epoch;
    logic [63:0] source_word_data;
    logic [7:0] source_data;
    vgm_reader_vnext_pkg::read_response_t fault_response;
    logic logical_active,drain_blocked,boundary_fault,reader_owned;
    logic core_chip_reset,core_ym_reset,core_running,core_parser_done,core_fatal,native_started;
    logic [7:0] core_fatal_code;
    logic ym_write,ym_ready;
    logic [7:0] ym_address,ym_data;
    logic signed [15:0] ym_raw_l,ym_raw_r,ym_audio_l,ym_audio_r,c140_l,c140_r;
    logic signed [15:0] balanced_l,balanced_r,mixed_l,mixed_r,selected_l,selected_r;
    logic ym_audio_valid,c140_audio_valid,ym_muted;
    logic [23:0] activity;
    logic [63:0] playback_time,decoded_due;
    logic [15:0] native_age;
    logic [31:0] command_pc,underflows,descriptor_misses,stale_responses,raw_fetches,compressed_fetches;
    logic [7:0] command_opcode;
    logic [5:0] command_state;
    logic [4:0] descriptor_count;
    logic [8:0] ym_max_level;
    wire mapper_system21=uploaded_vgm_version>=32'h161 && uploaded_c140_type==1;
    wire lifecycle=reset || ioctl_download || transport_finish || stopped;
    wire current_read_fault=boundary_fault ||
        (source_fault && fault_response.epoch==epoch && !lifecycle);
    wire file_overflow=|backend_file_size[31:23];
    initial begin
        if(RUN_MODE!=2) $fatal(1,"D vNext production requires complete chip mix");
    end
    always_ff @(posedge clk) begin
        if(power_reset) epoch<=0;
        else if(load_begin) epoch<=epoch+1'b1;
        if(reset) begin
            download_q<=0;stopped<=0;uploaded_vgm_version<=0;uploaded_c140_type<=0;
            accepted_byte_count<=0;scan_started<=0;
        end else begin
            download_q<=ioctl_download;
            if(load_begin) begin
                stopped<=0;uploaded_vgm_version<=0;uploaded_c140_type<=0;
                accepted_byte_count<=accepted_upload ? 24'd1 : 24'd0;scan_started<=0;
            end else if(accepted_upload) accepted_byte_count<=accepted_byte_count+1'b1;
            if(transport_finish) stopped<=1;
            if(command_request && command_ready) scan_started<=1;
            if(accepted_upload) case(ioctl_addr)
                27'h8:uploaded_vgm_version[7:0]<=ioctl_dout;
                27'h9:uploaded_vgm_version[15:8]<=ioctl_dout;
                27'ha:uploaded_vgm_version[23:16]<=ioctl_dout;
                27'hb:uploaded_vgm_version[31:24]<=ioctl_dout;
                27'h96:uploaded_c140_type<=ioctl_dout;
                default:begin end
            endcase
        end
    end
    engine_d_vnext_playback_core #(.SETTLE_CLOCKS(COMMAND_SETTLE_CYCLES)) plugin(
        .clk,.reset(reset || ioctl_download),.start(load_done_pulse),.transport_finish,
        .transport_halt_loop(TRANSPORT_LOOP_CONTROL && transport_loop_policy_active && transport_halt_loop),
        .strict_fault(current_read_fault),.file_size(backend_file_size),.epoch,
        .c140_type(uploaded_c140_type),.mapper_system21,.ym_reset_phase_ready(ym_clock_phase==0),
        .command_request,.command_ready,.command_valid,.command_address,.command_data,.command_word_valid,
        .command_word_address(word_address),.command_word_epoch(word_epoch),.command_word_data(word_data),
        .sample_request,.sample_ready,.sample_valid,.sample_address,.sample_data,.sample_word_valid,
        .sample_word_address(word_address),.sample_word_epoch(word_epoch),.sample_word_data(word_data),
        .chip_reset(core_chip_reset),.ym_chip_reset(core_ym_reset),.command_read_priority,.ym_write,.ym_address,.ym_data,.ym_ready,
        .c140_audio_l(c140_l),.c140_audio_r(c140_r),.c140_audio_valid,.activity,
        .running(core_running),.parser_done(core_parser_done),.fatal(core_fatal),.fatal_code(core_fatal_code),.native_started,
        .loop_entry(playback_loop_entry_pulse),.loop_boundary(playback_loop_boundary_pulse),
        .playback_time,.decoded_due,.native_age,.command_pc,.command_opcode,.command_state,.descriptor_count,
        .underflows,.descriptor_misses,.stale_responses,.raw_fetches,.compressed_fetches,
        .natural_ends(natural_end_count),.deadline_misses(command_deadline_miss_count),.ym_max_level);
    engine_d_vnext_reader_mux owners(.clk,.power_reset,.lifecycle,.epoch,
        .command_request,.sample_request,.command_priority(command_read_priority),.command_address,.sample_address,.command_ready,.sample_ready,
        .command_valid,.sample_valid,.command_data,.sample_data,.command_word_valid,.sample_word_valid,
        .word_address,.word_epoch,.word_data,.source_request,.source_address,.source_captured,
        .source_ready,.source_valid,.source_fault,.source_data,.source_word_valid,
        .source_word_address,.source_word_epoch,.source_word_data,.owned(reader_owned));
    engine_b_vnext_shared_reader_binding reader(.clk,.power_reset,.backend_reset(reset),
        .download_active(ioctl_download),.session_reload(transport_finish),.current_epoch(epoch),
        .file_extent(backend_file_size),.backend_loaded(backend_load_done),
        .backend_load_error(backend_load_error || backend_overflow_error || file_overflow),
        .request_valid(source_request),.request_ready(source_ready),.request_address(source_address),
        .response_valid(source_valid),.response_byte(source_data),.fault_valid(source_fault),.fault_response,
        .golden_request,.golden_byte_address,.golden_ready,.golden_valid,
        .golden_read(backend_ddram_rd),.golden_write(backend_ddram_we),.golden_address(backend_ddram_addr),
        .golden_be(backend_ddram_be),.golden_burst(backend_ddram_burstcnt),.golden_busy,
        .avalon_read(ddram_rd),.avalon_address(ddram_addr),.avalon_be(ddram_be),.avalon_burst(ddram_burstcnt),
        .avalon_busy(ddram_busy),.avalon_valid(ddram_dout_ready),.avalon_data(ddram_dout),
        .word_valid(source_word_valid),.word_address(source_word_address),.word_epoch(source_word_epoch),.word_data(source_word_data),
        .request_captured(source_captured),.logical_active,.drain_blocked,.boundary_fault);
    assign ddram_din=backend_ddram_din;assign ddram_we=backend_ddram_we;
    ym2151_sound_module #(.CLK_SYS_HZ(32'd20000000),.YM2151_CLK_HZ(32'd3579545)) ym2151_sound(
        .clk,.reset(core_ym_reset),.ym2151_cmd_valid(ym_write),.ym2151_cmd_reg(ym_address),.ym2151_cmd_data(ym_data),
        .ym2151_cmd_ready(ym_ready),.audio_l(ym_raw_l),.audio_r(ym_raw_r),.audio_sample_valid(ym_audio_valid));
    ym2151_prewait_audio_gate ym2151_gate(.clk,.reset_or_rearm(core_ym_reset),.positive_wait_active(native_started),
        .raw_audio_l(ym_raw_l),.raw_audio_r(ym_raw_r),.audible_audio_l(ym_audio_l),.audible_audio_r(ym_audio_r),.mute_active(ym_muted));
    c140_system2_source_balance source_balance(.ym2151_l(ym_audio_l),.ym2151_r(ym_audio_r),.balanced_l,.balanced_r);
    c140_system2_audio_mixer mixer(.ym2151_l(balanced_l),.ym2151_r(balanced_r),.c140_l,.c140_r,.audio_l(mixed_l),.audio_r(mixed_r));
    megavgm_engine_d_output_gain output_gain(.boost(audio_gain_boost),.audio_l(mixed_l),.audio_r(mixed_r),.selected_l,.selected_r);
    megavgm_engine_d_activity_source activity_source(.ym2151_cmd_valid(ym_write),.ym2151_cmd_ready(ym_ready),
        .ym2151_cmd_reg(ym_address),.ym2151_cmd_data(ym_data),.c140_active_bitmap(activity),
        .ym2151_activity_event,.c140_activity_state);
    assign uploaded_file_size=backend_file_size[23:0];
    // LOADING covers admission/reset/resource preparation, not only upload.
    assign load_busy=ioctl_download || backend_load_busy ||
        (backend_load_done && !core_running && !stopped && !profile_fatal);
    assign load_done=backend_load_done;
    assign load_error=backend_load_error || backend_overflow_error;assign load_overflow=file_overflow;
    assign profile_fatal=core_fatal || current_read_fault || load_error || file_overflow;
    assign error_code=core_fatal ? core_fatal_code : current_read_fault ? 8'h40 : load_error ? 8'h31 : file_overflow ? 8'h32 : 8'h00;
    assign playback_active=core_running && !profile_fatal && !stopped;
    assign playback_done=(core_parser_done && core_running) || stopped;
    assign audio_enable=playback_active;
    assign audio_l=audio_enable ? selected_l : 16'sd0;assign audio_r=audio_enable ? selected_r : 16'sd0;
    assign audio_sample_valid=audio_enable && (c140_audio_valid || ym_audio_valid);
    assign vgm_sample_time=playback_time[31:0];assign profile_system21=mapper_system21;
    assign profile_state=ioctl_download ? 3'd1 : profile_fatal ? 3'd5 : stopped ? 3'd4 :
                         core_running ? 3'd3 : backend_load_done ? 3'd2 : 3'd0;
    assign wait_reason={backend_ready_debug[10],backend_ready_debug[7],backend_ready_debug[6],backend_ready_debug[4]};
    assign outstanding_fifo={backend_ready_debug[6],backend_fifo_debug[6:0]};
    assign debug_command_pc=command_pc[22:0];assign debug_last_command=command_opcode;assign debug_parser_state=command_state;
    always @* begin
        debug_active_count=0;
        for(integer voice=0;voice<24;voice=voice+1) debug_active_count=debug_active_count+{4'd0,activity[voice]};
    end
    assign debug_underflow_count=underflows;assign debug_descriptor_miss_count=descriptor_misses;
    assign debug_stale_response_count=stale_responses;assign debug_raw_fetch_count=raw_fetches;
    assign debug_compressed_fetch_count=compressed_fetches;
    always_ff @(posedge clk) begin
        if(reset || ioctl_download) begin
            debug_first_deadline_valid<=0;debug_first_deadline_pc<=0;debug_first_deadline_command<=0;
            debug_first_deadline_state<=0;debug_first_deadline_flags<=0;debug_first_deadline_producer_time<=0;
            debug_first_deadline_playback_time<=0;debug_first_deadline_frame_clock<=0;
            debug_first_deadline_retired<=0;debug_first_deadline_reason<=0;
        end else if(command_deadline_miss_count!=0 && !debug_first_deadline_valid) begin
            debug_first_deadline_valid<=1;debug_first_deadline_pc<=command_pc[22:0];debug_first_deadline_command<=command_opcode;
            debug_first_deadline_state<=command_state;debug_first_deadline_flags<=8'h01;
            debug_first_deadline_producer_time<=decoded_due[31:0];debug_first_deadline_playback_time<=playback_time[31:0];
            debug_first_deadline_frame_clock<=native_age;debug_first_deadline_reason<=8'h01;
        end
    end
    vgm_ddram_backend #(
        .ADDR_WIDTH(FILE_ADDR_WIDTH),
        .ACCEPT_ANY_INDEX(1'b0),
        .FILE_INDEX(FILE_INDEX),
        .DDRAM_ADDR_WIDTH(DDRAM_ADDR_WIDTH),
        .WRITE_FIFO_DEPTH(WRITE_FIFO_DEPTH),
        .DDRAM_BASE_ADDR(DDRAM_BASE_ADDR),
        .SEGAPCM_ROM_BASE_ADDR(UNUSED_PCM_BASE)
    ) production_backend (
        .clk(clk),
        .reset(reset),
        .ioctl_download(ioctl_download),
        .ioctl_wr(ioctl_wr),
        .ioctl_addr({5'd0, ioctl_addr}),
        .ioctl_dout(ioctl_dout),
        .ioctl_index(ioctl_index[7:0]),
        .ioctl_wait(ioctl_wait),

        .mem_rd_req(golden_request),
        .mem_rd_addr(golden_byte_address),
        .mem_rd_ready(golden_ready),
        .mem_rd_valid(golden_valid),
        .mem_rd_data(golden_data),

        .segapcm_copy_wr_req(1'b0),
        .segapcm_copy_wr_ready(),
        .segapcm_copy_wr_addr(19'd0),
        .segapcm_copy_wr_data(8'd0),
        .segapcm_copy_flush_req(1'b0),
        .segapcm_copy_flush_done(),
        .segapcm_copy_accept_count_debug(),
        .segapcm_copy_write_count_debug(),
        .segapcm_copy_fifo_debug(backend_fifo_debug),
        .segapcm_copy_ready_debug(backend_ready_debug),
        .segapcm_copy_write_req_debug(),
        .segapcm_copy_word_debug(),
        .segapcm_copy_flush_debug(),
        .segapcm_copy_full_detect_count_debug(),
        .segapcm_copy_push_req_count_debug(),
        .segapcm_copy_push_fire_count_debug(),
        .segapcm_copy_fifo_push_count_debug(),
        .segapcm_copy_pack_ready_debug(),
        .segapcm_copy_post_push_debug(),
        .segapcm_read_gate_debug(),
        .segapcm_read_after_copy_count_debug(),

        .load_busy(backend_load_busy),
        .load_done(backend_load_done),
        .load_done_pulse(load_done_pulse),
        .play_ready_pulse(),
        .load_error(backend_load_error),
        .overflow_error(backend_overflow_error),
        .file_size(backend_file_size),
        .magic_debug(),

        .ddram_busy(golden_busy),
        .ddram_burstcnt(backend_ddram_burstcnt),
        .ddram_addr(backend_ddram_addr),
        .ddram_dout(ddram_dout),
        .ddram_dout_ready(ddram_dout_ready),
        .ddram_rd(backend_ddram_rd),
        .ddram_din(backend_ddram_din),
        .ddram_be(backend_ddram_be),
        .ddram_we(backend_ddram_we)
    );
endmodule
