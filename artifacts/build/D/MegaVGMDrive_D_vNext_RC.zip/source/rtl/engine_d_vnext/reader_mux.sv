// Ownership around the pinned shared Strict binding. Capture precedes physical
// ACCEPT. Keep the owner until explicit READ_OK/fault closure, including cancel.
module engine_d_vnext_reader_mux (
    input logic clk,power_reset,lifecycle,
    input logic [31:0] epoch,
    input logic command_request,sample_request,command_priority,
    input logic [31:0] command_address,sample_address,
    output logic command_ready,sample_ready,command_valid,sample_valid,
    output logic [7:0] command_data,sample_data,
    output logic command_word_valid,sample_word_valid,
    output logic [31:0] word_address,word_epoch,
    output logic [63:0] word_data,
    output logic source_request,
    output logic [31:0] source_address,
    input logic source_captured,source_ready,source_valid,source_fault,
    input logic [7:0] source_data,
    input logic source_word_valid,
    input logic [31:0] source_word_address,source_word_epoch,
    input logic [63:0] source_word_data,
    output logic owned
);
    // Controls needed for the imminent native snapshot outrank samples;
    // otherwise sample preparation outranks speculative command lookahead.
    // An already captured physical transaction is never preempted.
    logic owner_sample;
    logic [31:0] owned_address,owned_epoch;
    wire choose_sample=owned ? owner_sample : sample_request && (!command_request || !command_priority);
    wire deliver=owned && owned_epoch==epoch && !lifecycle;
    assign source_request=!lifecycle && (owned || command_request || sample_request);
    assign source_address=owned ? owned_address : choose_sample ? sample_address : command_address;
    assign command_ready=deliver && !owner_sample && source_ready;
    assign sample_ready=deliver && owner_sample && source_ready;
    assign command_valid=deliver && !owner_sample && source_valid;
    assign sample_valid=deliver && owner_sample && source_valid;
    assign command_data=source_data;assign sample_data=source_data;
    assign command_word_valid=deliver && !owner_sample && source_word_valid && source_word_epoch==owned_epoch;
    assign sample_word_valid=deliver && owner_sample && source_word_valid && source_word_epoch==owned_epoch;
    assign word_address=source_word_address;assign word_epoch=source_word_epoch;assign word_data=source_word_data;
    always_ff @(posedge clk) begin
        if(power_reset) begin owned<=0;owner_sample<=0;owned_address<=0;owned_epoch<=0;end
        else begin
            if(source_captured && !lifecycle && !owned) begin
                owned<=1;owner_sample<=choose_sample;owned_address<=source_address;owned_epoch<=epoch;
            end
            if(source_valid || source_fault) owned<=0;
        end
    end
endmodule
