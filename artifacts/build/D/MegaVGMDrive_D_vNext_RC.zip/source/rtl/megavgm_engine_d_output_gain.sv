// SPDX-License-Identifier: GPL-2.0-or-later
//
// Engine D production Audio Gain control. Boost is applied to the complete
// post-mixer sample, preserving the YM2151:C140 source-balance contract.

module megavgm_engine_d_output_gain (
    input  logic               boost,
    input  logic signed [15:0] audio_l,
    input  logic signed [15:0] audio_r,
    output logic signed [15:0] selected_l,
    output logic signed [15:0] selected_r
);
    function automatic logic signed [15:0] saturating_double(
        input logic signed [15:0] sample
    );
        logic signed [16:0] doubled;
        begin
            doubled = $signed({sample[15], sample}) <<< 1;
            if (doubled > 17'sd32767)
                saturating_double = 16'sh7fff;
            else if (doubled < -17'sd32768)
                saturating_double = 16'sh8000;
            else
                saturating_double = doubled[15:0];
        end
    endfunction

    always_comb begin
        selected_l = boost ? saturating_double(audio_l) : audio_l;
        selected_r = boost ? saturating_double(audio_r) : audio_r;
    end
endmodule
