// SPDX-License-Identifier: GPL-2.0-or-later
//
// Observation-only Engine D activity. YM2151 pulses are derived from writes
// accepted by the existing JT51 wrapper. C140 state is the core's actual
// active/keyed bitmap. No output feeds back into either sound engine.

module megavgm_engine_d_activity_source (
    input  logic        ym2151_cmd_valid,
    input  logic        ym2151_cmd_ready,
    input  logic [7:0]  ym2151_cmd_reg,
    input  logic [7:0]  ym2151_cmd_data,
    input  logic [23:0] c140_active_bitmap,
    output logic [7:0]  ym2151_activity_event,
    output logic [23:0] c140_activity_state
);
    always_comb begin
        ym2151_activity_event = 8'd0;

        if (ym2151_cmd_valid && ym2151_cmd_ready) begin
            // Register 08 selects the channel in data[2:0]. Key-off-only
            // writes do not light the activity display.
            if ((ym2151_cmd_reg == 8'h08) &&
                (ym2151_cmd_data[6:3] != 4'd0)) begin
                ym2151_activity_event[ym2151_cmd_data[2:0]] = 1'b1;
            end else if (ym2151_cmd_reg >= 8'h20) begin
                // Channel/operator registers encode the channel in reg[2:0].
                ym2151_activity_event[ym2151_cmd_reg[2:0]] = 1'b1;
            end
        end

        c140_activity_state = c140_active_bitmap;
    end
endmodule
