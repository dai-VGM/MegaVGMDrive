// Candidate engine attachment. Golden upload/Shell/Transport/chip wrappers stay outside.
module engine_a_vnext_functional_engine #(parameter int COMMAND_PREFETCH_BYTES=8,
 SCHEDULER_DEPTH=8,RESOURCE_REGIONS=32) (
 input logic clk,power_reset,session_reset,new_track,enable,play_start,
 input logic playback_tick,native_tick,execution_arm,owner_halt,transport_finish,
 input logic [31:0] epoch,file_size,
 input logic [3:0] bank_shift,input logic [7:0] bank_mask,
 input logic backend_reset,download_active,backend_loaded,backend_load_error,
 output logic golden_request,output logic [22:0] golden_byte_address,
 input logic golden_ready,golden_valid,golden_read,golden_write,
 input logic [28:0] golden_address,input logic [7:0] golden_be,golden_burst,
 output logic golden_busy,avalon_read,output logic [28:0] avalon_address,
 output logic [7:0] avalon_be,avalon_burst,
 input logic avalon_busy,avalon_valid,input logic [63:0] avalon_data,
 input logic psg_ready,ym2612_ready,ym2151_ready,ym2203_ready,
 output logic psg_valid,output logic [7:0] psg_data,
 output logic ym2612_valid,ym2612_port,output logic [7:0] ym2612_reg,ym2612_data,
 output logic ym2151_valid,output logic [7:0] ym2151_reg,ym2151_data,
 output logic ym2203_valid,output logic [7:0] ym2203_reg,ym2203_data,
 output logic signed [15:0] segapcm_left,segapcm_right,
 output logic audio_valid,busy,done,fatal,loop_entry_pulse,loop_boundary_pulse,resume_pulse,
 output logic loop_present,output logic [31:0] loop_target,data_start,
 output logic [63:0] playback_time,decoded_due,
 input logic [7:0] register_read_address,output logic [7:0] register_read_data,
 output logic first_wait,channel_quiet,control_primed,
 output logic [31:0] diagnostic_pc,output logic [7:0] diagnostic_opcode,diagnostic_code,
 output logic c0_accepted,output logic [31:0] c0_pc,output logic [15:0] c0_address,
 output logic [7:0] c0_data,output logic [63:0] c0_due,c0_sequence,
 output logic sample_request_pulse,output segapcm_vnext_pkg::sample_request_t sample_request,
 output logic voice_trace_valid,output segapcm_vnext_pkg::voice_trace_t voice_trace,
 output logic raw_valid,output logic signed [18:0] raw_left,raw_right,
 output logic [31:0] dac_cursor,gap_count,
 output logic [31:0] max_acceptance_stall,max_response_latency,
 output logic [9:0] min_deadline_margin,max_frame_cycles,
 output logic [31:0] sample_deadline_faults,control_deadline_faults
);
 import vgm_parser_vnext_event_pkg::*;import vgm_scheduler_vnext_pkg::*;
 import vgm_reader_vnext_pkg::*;import segapcm_vnext_pkg::*;import segapcm_vnext_adapter_pkg::*;
 // Named struct prefixes must be declared before use for Quartus.
 vgm_scheduler_vnext_pkg::normalized_fact_t fact;
 vgm_parser_vnext_event_pkg::data_event_t block_fact;
 logic fact_valid,fact_ready;
 logic track_reset,started,transport_stopped,issue_enabled;
 assign track_reset=session_reset || new_track;
 assign issue_enabled=enable && !fatal && !transport_finish && !transport_stopped;
 assign done=terminal || halted || transport_stopped;
 assign busy=started && !done && !fatal;
 always_ff @(posedge clk)begin
  if(track_reset)begin started<=0;transport_stopped<=0;first_wait<=0;end
  else begin
   if(play_start)started<=1;
   if(transport_finish)transport_stopped<=1;
   if(fact_valid && fact_ready && fact.kind==S_WAIT)first_wait<=1;
  end
 end
 read_request_t strict_request,p_request,d_request,s_request,control_request;
 read_response_t strict_response,p_response,d_response,s_response,control_response;
 logic strict_valid,strict_ready,strict_rsp_valid,strict_rsp_ready,reader_active,drain_blocked,reader_boundary;
 logic p_valid,p_ready,p_rsp_valid,d_valid,d_ready,d_rsp_valid,d_rsp_ready;
 logic s_valid,s_ready,s_rsp_valid,s_rsp_ready,control_valid,control_ready,control_rsp_valid,control_rsp_ready;
 logic control_active,reader_arbiter_active,capture,physical_accept,physical_response,cancelled,timed_out;
 logic [31:0] ledger_id,ledger_epoch,acceptance_stalls,response_age;logic [2:0] bridge_state;
 engine_a_vnext_strict_golden_read_binding reader(.clk,.power_reset,.backend_reset,.download_active,
  .session_reload(new_track || transport_finish),.current_epoch(epoch),
  .request_valid(strict_valid),.request_ready(strict_ready),.request_data(strict_request),
  .response_valid(strict_rsp_valid),.response_ready(strict_rsp_ready),.response_data(strict_response),
  .backend_loaded,.backend_load_error,.backend_file_size(file_size),.golden_request,.golden_byte_address,
  .golden_ready,.golden_valid,.golden_read,.golden_write,.golden_address,.golden_be,.golden_burst,.golden_busy,
  .avalon_read,.avalon_address,.avalon_be,.avalon_burst,.avalon_busy,.avalon_valid,.avalon_data,
  .logical_active(reader_active),.drain_blocked,.boundary_fault(reader_boundary),.capture,.physical_accept,.physical_response,
  .cancelled,.timed_out,.ledger_transaction_id(ledger_id),.ledger_epoch,.acceptance_stalls,.response_age,.state_debug(bridge_state));
 // Nest the already-proven single-owner arbiter: DAC/parser, then sample/control.
 // Both arbiters retain ownership through cancellation until the tagged reply.
 segapcm_vnext_reader_arbiter control_reads(.clk,.power_reset,
  .parser_valid(p_valid),.parser_ready(p_ready),.parser_request(p_request),.parser_response_valid(p_rsp_valid),
  .parser_response_ready(1'b1),.parser_response(p_response),.sample_valid(d_valid),.sample_pending(dac_active),
  .sample_ready(d_ready),.sample_request(d_request),.sample_response_valid(d_rsp_valid),
  .sample_response_ready(d_rsp_ready),.sample_response(d_response),.reader_valid(control_valid),.reader_ready(control_ready),
  .reader_request(control_request),.reader_response_valid(control_rsp_valid),.reader_response_ready(control_rsp_ready),
  .reader_response(control_response),.active(control_active));
 segapcm_vnext_reader_arbiter sample_reads(.clk,.power_reset,
  .parser_valid(control_valid),.parser_ready(control_ready),.parser_request(control_request),.parser_response_valid(control_rsp_valid),
  .parser_response_ready(control_rsp_ready),.parser_response(control_response),.sample_valid(s_valid),.sample_pending(sample_active || chip_req_valid),
  .sample_ready(s_ready),.sample_request(s_request),.sample_response_valid(s_rsp_valid),
  .sample_response_ready(s_rsp_ready),.sample_response(s_response),.reader_valid(strict_valid),.reader_ready(strict_ready),
  .reader_request(strict_request),.reader_response_valid(strict_rsp_valid),.reader_response_ready(strict_rsp_ready),
  .reader_response(strict_response),.active(reader_arbiter_active));
 assign channel_quiet=strict_ready && !reader_arbiter_active && !control_active;
 logic byte_req_valid,byte_req_ready,byte_rsp_valid,parser_reader_fault;
 logic [31:0] byte_address,parser_extent,terminal_pc;logic [7:0] byte_data;
 logic parser_done,event_valid,event_ready,data_valid,dac_fact_valid,terminal_fact_valid,entry_seen;
 logic resume_valid,resume_ready,resume_fault,continuation_busy;logic [31:0] resume_pc;
 decode_event_t event_data;write_descriptor_t write_info;data_event_t data_fact;
 dac_stream_fact_t dac_fact;
 generate if(COMMAND_PREFETCH_BYTES==0)begin: no_prefetch
 segapcm_vnext_byte_bridge bytes(.clk,.session_reset(track_reset),.enable(issue_enabled),.epoch,.file_extent(file_size),
  .byte_request_valid(byte_req_valid),.byte_request_ready(byte_req_ready),.byte_address,.byte_response_valid(byte_rsp_valid),.byte_data,
  .reader_valid(p_valid),.reader_ready(p_ready),.reader_request(p_request),.reader_response_valid(p_rsp_valid),.reader_response(p_response),.fatal_latched(parser_reader_fault));
 end else begin: command_prefetch
 engine_a_vnext_command_byte_fifo #(.CAPACITY_BYTES(COMMAND_PREFETCH_BYTES)) bytes(
  .clk,.session_reset(track_reset),
  .enable(issue_enabled && backend_loaded && !backend_reset && !download_active && !backend_load_error),
  .flush(resume_pulse || transport_finish || backend_reset || download_active),.epoch,
  .file_extent(data_start!=0 ? parser_extent : file_size),
  .byte_request_valid(byte_req_valid),.byte_request_ready(byte_req_ready),.byte_address,
  .byte_response_valid(byte_rsp_valid),.byte_data,
  .reader_valid(p_valid),.reader_ready(p_ready),.reader_request(p_request),
  .reader_response_valid(p_rsp_valid),.reader_response(p_response),
  .physical_accept,.physical_response,.physical_address(avalon_address),.physical_data(avalon_data),
  .physical_transaction_id(ledger_id),.physical_epoch(ledger_epoch),.fatal_latched(parser_reader_fault),
  .fault_result(),.hit_pulse(),.miss_pulse(),.fill_pulse());
 end endgenerate
 vgm_parser_vnext_decoder #(.DATA_GRAMMAR(1),.DAC_GRAMMAR(1),.COMMON_WRITE_GRAMMAR(1),.RESUME_CONTROL(1)) parser(
  .clk,.reset(track_reset),.start(play_start && enable),.image_size(file_size),.resume_valid,.resume_ready,.resume_pc,.resume_fault,
  .reader_req_valid(byte_req_valid),.reader_req_ready(byte_req_ready),.reader_req_addr(byte_address),.reader_rsp_valid(byte_rsp_valid),.reader_rsp_byte(byte_data),
  .event_valid,.event_ready,.event_data,.write_info,.data_event_valid(data_valid),.data_event_data(data_fact),.dac_fact_valid,.dac_fact_data(dac_fact),
  .done(parser_done),.file_extent(parser_extent),.data_start,.loop_present,.loop_target,.loop_terminal_valid(terminal_fact_valid),.loop_terminal_pc(terminal_pc),.loop_entry_seen(entry_seen));
 vgm_scheduler_vnext_normalizer normalizer(.clk,.reset(track_reset),.event_valid,.data_event_valid(data_valid),.dac_fact_valid,
  .loop_terminal_valid(terminal_fact_valid),.event_data,.write_info,.data_event_data(data_fact),.dac_fact_data(dac_fact),
  .loop_present,.loop_target,.loop_terminal_pc(terminal_pc),.event_ready,.fact_valid,.fact_ready,.fact);
 scheduled_fact_t commits[7],barrier,c0_head;
 logic [6:0] commit_valid,commit_ready;logic [$clog2(SCHEDULER_DEPTH):0] levels[7];
 logic barrier_valid,barrier_ready,loop_waiting,loop_release,decision_valid,decision_halt,halted,terminal,scheduler_fault;
 logic [63:0] next_sequence;
 // Golden startup ownership: timestamp-zero setup has been accepted on all
 // chip lanes before musical/native clocks start. Future heads are permitted;
 // waiting for an entirely empty read-ahead queue would deadlock at time zero.
 logic initial_setup_debt;
 always_comb begin
  initial_setup_debt=queue_valid && c0_head.due_time==0;
  for(int lane=0;lane<7;lane++)
   if(levels[lane]!=0 && commits[lane].due_time==0)initial_setup_debt=1;
 end
 assign control_primed=(decoded_due>0 || terminal || halted || (parser_done && !loop_present)) && !initial_setup_debt && !core_busy;
 vgm_scheduler_vnext #(.DEPTH(SCHEDULER_DEPTH)) scheduler(.clk,.reset(track_reset),.play_start(play_start && enable),
  .playback_tick(playback_tick && execution_arm && !transport_finish && !transport_stopped),
  .fact_valid(fact_valid && issue_enabled),.fact_ready,.fact,.commit_valid,.commit_ready,.commits,.barrier_valid,.barrier_ready,.barrier,
  .loop_decision_valid(decision_valid),.loop_halt(decision_halt),.loop_waiting,.loop_release_pulse(loop_release),.halted,.terminal,
  .fault_latched(scheduler_fault),.fault_reason(),.due_time(decoded_due),.playback_time,.next_sequence,.levels);
 engine_a_vnext_loop_continuation_client continuation(.clk,.reset(track_reset),.new_track,
  .boundary_valid(barrier_valid && barrier.fact.kind==S_LOOP_BOUNDARY),.boundary_ready(barrier_ready),.boundary_target(barrier.fact.payload[63:32]),
  .owner_halt,.scheduler_waiting(loop_waiting),.scheduler_release(loop_release),.decision_valid,.decision_halt,.resume_valid,.resume_ready,.resume_pc,.busy(continuation_busy));
 assign loop_entry_pulse=barrier_valid && barrier_ready && barrier.fact.kind==S_LOOP_ENTRY;
 assign loop_boundary_pulse=barrier_valid && barrier_ready && barrier.fact.kind==S_LOOP_BOUNDARY;
 assign resume_pulse=resume_valid && resume_ready;
 logic [3:0] chip_rejected;logic [3:0] lane_ready;
 write_descriptor_t lane_info[4],dac_write;scheduled_fact_t dac_source,dac_fault_source;
 logic dac_write_valid,dac_write_ready,dac_ready,dac_data_ready,dac_fault_valid,dac_fatal,dac_active;
 logic [31:0] dac_fault_epoch,bank_size,dac_file_address;resource_result_t dac_fault_result;
 genvar lane;
 generate
 for(lane=0;lane<4;lane++)begin: descriptor_lanes
  if(lane==1)assign lane_info[lane]=commits[lane].fact.kind==S_DAC ? dac_write : commits[lane].fact.payload[134:80];
  else assign lane_info[lane]=commits[lane].fact.payload[134:80];
 end
 endgenerate
 engine_a_vnext_chip_write_adapter #(.TARGET(0)) psg(.enabled(issue_enabled),.valid(commit_valid[0]),.core_ready(psg_ready),.descriptor(lane_info[0]),
  .ready(lane_ready[0]),.write_pulse(psg_valid),.port(),.rejected(chip_rejected[0]),.control_noop(),.address(),.data(psg_data));
 engine_a_vnext_chip_write_adapter #(.TARGET(1)) ym2612(.enabled(issue_enabled),
  .valid(commit_valid[1] && (commits[1].fact.kind!=S_DAC || dac_write_valid)),.core_ready(ym2612_ready),.descriptor(lane_info[1]),
  .ready(lane_ready[1]),.write_pulse(ym2612_valid),.port(ym2612_port),.rejected(chip_rejected[1]),.control_noop(),.address(ym2612_reg),.data(ym2612_data));
 engine_a_vnext_chip_write_adapter #(.TARGET(2)) ym2151(.enabled(issue_enabled),.valid(commit_valid[2]),.core_ready(ym2151_ready),.descriptor(lane_info[2]),
  .ready(lane_ready[2]),.write_pulse(ym2151_valid),.port(),.rejected(chip_rejected[2]),.control_noop(),.address(ym2151_reg),.data(ym2151_data));
 engine_a_vnext_chip_write_adapter #(.TARGET(3)) ym2203(.enabled(issue_enabled),.valid(commit_valid[3]),.core_ready(ym2203_ready),.descriptor(lane_info[3]),
  .ready(lane_ready[3]),.write_pulse(ym2203_valid),.port(),.rejected(chip_rejected[3]),.control_noop(),.address(ym2203_reg),.data(ym2203_data));
 assign dac_write_ready=lane_ready[1] && commit_valid[1] && commits[1].fact.kind==S_DAC;
 engine_a_vnext_ym2612_dac_client dac(.clk,.power_reset,.new_track,.cancel(session_reset || transport_finish),.channel_quiescent(channel_quiet),.epoch,.file_extent(file_size),
  .data_valid(barrier_valid && barrier.fact.kind==S_DATA && (block_fact.kind==DATA_SEEK || block_fact.block_type==0) && resource_window),.data_ready(dac_data_ready),.data_fact(block_fact),
  .dac_valid(issue_enabled && commit_valid[1] && commits[1].fact.kind==S_DAC),.dac_ready,.dac_event(commits[1]),
  .reader_valid(d_valid),.reader_ready(d_ready),.reader_request(d_request),.reader_response_valid(d_rsp_valid),.reader_response_ready(d_rsp_ready),.reader_response(d_response),
  .reader_boundary_fault(reader_boundary),.write_valid(dac_write_valid),.write_ready(dac_write_ready),.write_descriptor(dac_write),.write_source(dac_source),
  .fault_valid(dac_fault_valid),.fault_ready(1'b1),.fault_result(dac_fault_result),.fault_epoch(dac_fault_epoch),.fault_source(dac_fault_source),
  .fatal_latched(dac_fatal),.active(dac_active),.cursor(dac_cursor),.bank_size,.owned_file_address(dac_file_address));
 assign commit_ready[0]=lane_ready[0];assign commit_ready[1]=commits[1].fact.kind==S_DAC ? dac_ready : lane_ready[1];
 assign commit_ready[2]=lane_ready[2];assign commit_ready[3]=lane_ready[3];assign commit_ready[4]=0;assign commit_ready[6]=0;
 logic queue_valid,queue_ready,adapter_ready,register_valid,register_ready,c0_rejected;
 logic [4:0] queue_level;logic [7:0] reg_address,reg_data;decode_event_t c0_event;write_descriptor_t c0_write;
 engine_a_vnext_c0_control_queue c0_queue(.clk,.reset(track_reset),.input_valid(issue_enabled && commit_valid[5]),.input_ready(queue_ready),.input_fact(commits[5]),
  .output_valid(queue_valid),.output_ready(adapter_ready),.output_fact(c0_head),.level(queue_level));
 assign commit_ready[5]=queue_ready;
 assign c0_event=c0_head.fact.payload[79:0];assign c0_write=c0_head.fact.payload[134:80];
 logic frame_tick,frame_pending,control_deadline_fault,regular_window,boundary_window,write_window,core_busy,core_fault;
 logic [9:0] frame_age;logic [63:0] boundary_time;logic [64:0] horizon_sum;logic [63:0] horizon;
 core_fault_t core_reason;
 assign horizon_sum={1'b0,decoded_due}+{49'd0,((fact_valid && fact_ready && issue_enabled && (fact.kind==S_WAIT || fact.kind==S_DAC)) ? fact.time_advance : 16'd0)};
 assign horizon=horizon_sum[64] ? decoded_due : horizon_sum[63:0];
 // END closes the VGM stream; native sample updates continue until the
 // unchanged Transport owner finishes/mutes the session.
 engine_a_vnext_c0_frame_boundary frame(.clk,.reset(track_reset),.enabled(enable),.execution_arm(execution_arm && issue_enabled),
  .native_tick(native_tick && issue_enabled),.core_busy,.mix_valid(raw_valid),.playback_time(playback_time+64'(playback_tick && execution_arm && !done)),
  .decoded_due(horizon),.stream_complete(terminal || halted || (parser_done && !loop_present)),.scheduler_valid(levels[5]!=0),.queue_valid,
  .scheduler_due(commits[5].due_time),.queue_due(c0_head.due_time),.control_window(boundary_window),.frame_tick,.pending(frame_pending),
  .deadline_fault(control_deadline_fault),.boundary_time,.age(frame_age));
 segapcm_vnext_register_gate aperture(.clk,.reset(track_reset),.native_tick,.execution_arm,.window_open(regular_window));
 assign write_window=!control_deadline_fault && ((!frame_pending && regular_window) || boundary_window);
 segapcm_vnext_c0_adapter c0(.valid(issue_enabled && queue_valid),.ready(adapter_ready),.event_data(c0_event),.write_info(c0_write),
  .register_valid,.register_ready(register_ready && write_window),.register_address(reg_address),.register_data(reg_data),.rejected(c0_rejected));
 assign c0_accepted=register_valid && register_ready && write_window;
`ifdef MEGAVGM_VNEXT_PRODUCTION_MINIMAL
 assign voice_trace_valid=0;assign voice_trace='0;
`endif
 assign c0_pc=c0_event.source_pc;assign c0_address=c0_write.address;assign c0_data=c0_write.data;
 assign c0_due=c0_head.due_time;assign c0_sequence=c0_head.sequence_id;
 sample_request_t chip_request;sample_response_t chip_response;
 logic chip_req_valid,chip_req_ready,chip_rsp_valid,chip_rsp_ready,sample_active,map_ready,map_fault,sample_fatal,gap_hit;
 logic map_valid,resource_window;logic [31:0] mapped_file_address,rom_extent,generation;
 resource_result_t map_result,registration_reason,sample_reason;
 assign block_fact=barrier.fact.payload;
 assign resource_window=!queue_valid && !core_busy && !sample_active && !dac_active && psg_ready && ym2612_ready && ym2151_ready && ym2203_ready;
 assign map_valid=issue_enabled && barrier_valid && barrier.fact.kind==S_DATA && block_fact.kind==DATA_BLOCK && block_fact.block_type==8'h80 && resource_window;
 assign barrier_ready=issue_enabled && resource_window &&
  (barrier.fact.kind!=S_DATA || (block_fact.kind==DATA_SEEK || block_fact.block_type==0 ? dac_data_ready : map_ready));
 segapcm_vnext_resource_map #(.REGIONS(RESOURCE_REGIONS)) mapping(.clk,.power_reset,.new_track,.current_epoch(epoch),.file_extent(file_size),.register_valid(map_valid),.register_ready(map_ready),.block_fact,
  .query_epoch(chip_request.epoch),.query_address(chip_request.address),.file_address(mapped_file_address),.query_result(map_result),
  .registration_fault(map_fault),.registration_reason,.generation,.rom_extent);
 segapcm_vnext_core core(.clk,.reset(track_reset),.native_tick(frame_tick),.epoch,.bank_shift,.bank_mask,
  .register_valid(register_valid && write_window),.register_ready,.register_address(reg_address),.register_data(reg_data),.read_address(register_read_address),.read_data(register_read_data),
  .request_valid(chip_req_valid),.request_ready(chip_req_ready),.request(chip_request),.response_valid(chip_rsp_valid),.response_ready(chip_rsp_ready),.response(chip_response),
  .mix_valid(raw_valid),.mix_left(raw_left),.mix_right(raw_right),
`ifdef MEGAVGM_VNEXT_PRODUCTION_MINIMAL
  .trace_valid(),.trace(),
`else
  .trace_valid(voice_trace_valid),.trace(voice_trace),
`endif
  .busy(core_busy),.fault_latched(core_fault),.fault_reason(core_reason),.stale_responses());
 segapcm_vnext_sample_adapter samples(.clk,.power_reset,.new_track,.channel_quiescent(channel_quiet),.current_epoch(epoch),.file_extent(file_size),
  .mapped_file_address,.mapping_result(map_result),.request_valid(chip_req_valid),.request_ready(chip_req_ready),.request(chip_request),
  .response_valid(chip_rsp_valid),.response_ready(chip_rsp_ready),.response(chip_response),.reader_request_valid(s_valid),.reader_request_ready(s_ready),.reader_request(s_request),
  .reader_response_valid(s_rsp_valid),.reader_response_ready(s_rsp_ready),.reader_response(s_response),.reader_boundary_fault(reader_boundary),
  .gap_hit,.gap_count,.fatal_latched(sample_fatal),.fatal_reason(sample_reason),.active(sample_active));
 assign sample_request_pulse=chip_req_valid && chip_req_ready;assign sample_request=chip_request;
 segapcm_vnext_output_adapter output_conversion(.clk,.reset(track_reset),.invalidate(fatal || transport_stopped),.native_tick,
  .raw_valid(raw_valid && !control_deadline_fault),.raw_left,.raw_right,.audio_valid,.audio_left(segapcm_left),.audio_right(segapcm_right),
  .clipped_left(),.clipped_right(),.pending(),.overflow_latched(output_fault));
 logic output_fault;
`ifdef MEGAVGM_VNEXT_PRODUCTION_MINIMAL
 // Observation-only ports: no counters or comparators are instantiated.
 assign max_acceptance_stall=0;assign max_response_latency=0;
 assign min_deadline_margin=0;assign max_frame_cycles=0;
 assign sample_deadline_faults=0;assign control_deadline_faults=0;
`else
 engine_a_vnext_measurement_telemetry telemetry(.clk,.reset(track_reset),.physical_accept,.physical_response,.acceptance_stalls,.response_age,
  .native_tick,.mix_valid(raw_valid),.frame_fault(control_deadline_fault),.core_fault(core_fault && core_reason==FAULT_DEADLINE),
  .resource_fault(sample_fatal && sample_reason==RESOURCE_TIMEOUT),.frame_age,
  .max_acceptance_stall,.max_response_latency,.min_deadline_margin,.max_frame_cycles,.sample_deadline_faults,.control_deadline_faults);
`endif
 always_ff @(posedge clk)begin
  if(track_reset)begin fatal<=0;diagnostic_pc<=0;diagnostic_opcode<=0;diagnostic_code<=0;end
  else if(parser_reader_fault || reader_boundary || scheduler_fault || resume_fault || |chip_rejected || c0_rejected ||
    map_fault || sample_fatal || dac_fatal || core_fault || output_fault || control_deadline_fault ||
    (event_valid && event_ready && event_data.kind==EVENT_DIAGNOSTIC) || commit_valid[4] || commit_valid[6] ||
    (barrier_valid && barrier.fact.kind==S_DATA && block_fact.kind==DATA_BLOCK && block_fact.block_type!=0 && block_fact.block_type!=8'h80))begin
   fatal<=1;
   if(!fatal)begin
    diagnostic_pc<=event_data.source_pc;diagnostic_opcode<=event_data.opcode;
    diagnostic_code<=event_valid && event_data.kind==EVENT_DIAGNOSTIC ? {4'hd,event_data.reason} : 8'he0;
   end
  end
 end
endmodule
