// Passive Engine A chip-clock metadata capture at accepted Golden upload edges.
// Parser remains the sole file/header grammar validator. No ready/reset feedback.
module engine_a_vnext_uploaded_header_observer(
 input logic clk,reset,new_track,download,write_accepted,
 input logic [31:0] address,input logic [7:0] data,
 input logic parser_header_valid,input logic [31:0] data_start,
 output logic [31:0] segapcm_clock,segapcm_interface,ym2203_clock,
 output logic clock_commit,output logic [3:0] bank_shift,output logic [7:0] bank_mask
);
 logic [31:0] pcm_clock,pcm_interface,opn_clock;
 logic committed;
 logic [31:0] selected_interface;
 assign segapcm_clock=parser_header_valid ? pcm_clock : 32'd0;
 assign segapcm_interface=parser_header_valid ? pcm_interface : 32'd0;
 // A long command stream does not imply that the extended header field exists.
 assign ym2203_clock=parser_header_valid && data_start>32'h47 ? opn_clock : 32'd0;
 assign clock_commit=parser_header_valid && !committed;
 assign selected_interface=segapcm_interface==0 ? 32'hc : segapcm_interface;
 assign bank_shift=selected_interface[3:0];
 assign bank_mask=8'h70 | (selected_interface[23:16] & 8'hfc);
 always_ff @(posedge clk)begin
  if(reset || new_track)begin pcm_clock<=0;pcm_interface<=0;opn_clock<=0;committed<=0;end
  else begin
   if(clock_commit)committed<=1;
   if(download && write_accepted)begin
    if(address>=32'h38 && address<=32'h3b)pcm_clock[address[1:0]*8+:8]<=data;
    if(address>=32'h3c && address<=32'h3f)pcm_interface[address[1:0]*8+:8]<=data;
    if(address>=32'h44 && address<=32'h47)opn_clock[address[1:0]*8+:8]<=data;
   end
  end
 end
endmodule
