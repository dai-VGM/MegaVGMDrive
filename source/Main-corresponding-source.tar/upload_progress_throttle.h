#ifndef UPLOAD_PROGRESS_THROTTLE_H
#define UPLOAD_PROGRESS_THROTTLE_H

#include <inttypes.h>
#include <string>

class UploadProgressThrottle
{
public:
	explicit UploadProgressThrottle(uint64_t interval_ns = 100000000ULL);

	void reset();
	bool should_publish(uint64_t now_ns, const char *title, const char *text,
		int current, int maximum, bool force = false);

	uint64_t interval_ns() const { return interval_ns_; }

private:
	uint64_t interval_ns_;
	uint64_t last_publish_ns_;
	int last_current_;
	int last_maximum_;
	bool published_;
	std::string last_title_;
	std::string last_text_;
};

#endif
