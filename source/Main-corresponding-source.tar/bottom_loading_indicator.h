#ifndef BOTTOM_LOADING_INDICATOR_H
#define BOTTOM_LOADING_INDICATOR_H

#include <stdint.h>

struct BottomLoadingIndicator
{
	char filename[28];
	int progress_pixels;
	int width_cells;
	int height_cells;
};

int BottomLoadingIndicatorProgress(int current, int max);
void BottomLoadingIndicatorBuild(BottomLoadingIndicator *indicator,
		const char *target, int progress);
int BottomLoadingIndicatorY(uint32_t video_height, int height_cells);

#endif
