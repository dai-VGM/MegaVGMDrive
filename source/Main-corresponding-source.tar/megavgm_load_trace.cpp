#include "megavgm_load_trace.h"

#include <atomic>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

namespace
{
constexpr const char *kTracePath = "/tmp/megavgm_load_file.log";
std::atomic<uint64_t> pending_sequence(0);
std::atomic<uint64_t> pending_generation(0);
std::atomic<bool> pending_generation_valid(false);
std::atomic<uint32_t> pending_index(0);
std::atomic<bool> pending_backend_ready(false);
std::atomic<uint32_t> last_session(0xffffffffU);
std::atomic<uint32_t> last_state(0xffffffffU);
uint64_t diagnostic_timing_calls = 0;

uint64_t monotonic_ms()
{
	struct timespec value = {};
	if (clock_gettime(CLOCK_MONOTONIC, &value)) return 0;
	return static_cast<uint64_t>(value.tv_sec) * 1000U +
		static_cast<uint64_t>(value.tv_nsec / 1000000L);
}

uint64_t monotonic_us()
{
	struct timespec value = {};
	if (clock_gettime(CLOCK_MONOTONIC, &value)) return 0;
	return static_cast<uint64_t>(value.tv_sec) * 1000000U +
		static_cast<uint64_t>(value.tv_nsec / 1000L);
}

uint64_t monotonic_raw_ns()
{
	struct timespec value = {};
	if (clock_gettime(CLOCK_MONOTONIC_RAW, &value)) return 0;
	return static_cast<uint64_t>(value.tv_sec) * 1000000000ULL +
		static_cast<uint64_t>(value.tv_nsec);
}

void append_line(const char *line, size_t size)
{
	int fd = open(kTracePath, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0644);
	if (fd < 0) return;
	const char *cursor = line;
	while (size)
	{
		ssize_t written = write(fd, cursor, size);
		if (written > 0)
		{
			cursor += written;
			size -= static_cast<size_t>(written);
			continue;
		}
		if (written < 0 && errno == EINTR) continue;
		break;
	}
	close(fd);
}
}

void megavgm_load_trace_event(const char *event, uint64_t command_sequence,
		bool generation_valid, uint64_t generation, unsigned int index,
		const char *path, const char *reason)
{
	char line[1400];
	int length = snprintf(line, sizeof(line),
		"t_ms=%llu event=%s command_seq=%llu generation=%s%llu index=%u path=%s%s%s\n",
		static_cast<unsigned long long>(monotonic_ms()),
		event ? event : "UNKNOWN",
		static_cast<unsigned long long>(command_sequence),
		generation_valid ? "" : "legacy:",
		static_cast<unsigned long long>(generation), index,
		path ? path : "", reason ? " reason=" : "", reason ? reason : "");
	if (length <= 0 || static_cast<size_t>(length) >= sizeof(line)) return;
	append_line(line, static_cast<size_t>(length));
	printf("%s", line);
}

void megavgm_load_trace_set_pending(uint64_t command_sequence,
		bool generation_valid, uint64_t generation, unsigned int index)
{
	pending_sequence.store(command_sequence, std::memory_order_relaxed);
	pending_generation.store(generation, std::memory_order_relaxed);
	pending_generation_valid.store(generation_valid, std::memory_order_relaxed);
	pending_index.store(index, std::memory_order_relaxed);
	pending_backend_ready.store(false, std::memory_order_relaxed);
}

uint64_t megavgm_load_trace_monotonic_us()
{
	return monotonic_us();
}

uint64_t megavgm_load_trace_monotonic_ns()
{
	++diagnostic_timing_calls;
	return monotonic_raw_ns();
}

void megavgm_load_trace_timing_reset()
{
	diagnostic_timing_calls = 0;
}

uint64_t megavgm_load_trace_timing_call_count()
{
	return diagnostic_timing_calls;
}

uint64_t megavgm_load_trace_measure_clock_call_ns(unsigned int iterations)
{
	if (!iterations) return 0;
	struct timespec value = {};
	const uint64_t begin = monotonic_raw_ns();
	for (unsigned int i = 0; i < iterations; i++)
		clock_gettime(CLOCK_MONOTONIC_RAW, &value);
	const uint64_t end = monotonic_raw_ns();
	return (end - begin) / iterations;
}

void megavgm_load_trace_transfer_event(const char *event, uint64_t bytes,
		uint64_t total_bytes, uint64_t source_read_us,
		uint64_t payload_submit_us)
{
	const uint32_t index = pending_index.load(std::memory_order_relaxed);
	if (index != 1) return;
	const uint64_t sequence = pending_sequence.load(std::memory_order_relaxed);
	const uint64_t generation = pending_generation.load(std::memory_order_relaxed);
	const bool generation_valid =
		pending_generation_valid.load(std::memory_order_relaxed);
	char line[1536];
	const int length = snprintf(line, sizeof(line),
		"INDEX1_LATENCY event=%s t_us=%llu command_seq=%llu generation=%s%llu "
		"index=%u bytes=%llu total_bytes=%llu source_read_us=%llu "
		"payload_submit_us=%llu\n",
		event ? event : "UNKNOWN",
		static_cast<unsigned long long>(monotonic_us()),
		static_cast<unsigned long long>(sequence),
		generation_valid ? "" : "legacy:",
		static_cast<unsigned long long>(generation), index,
		static_cast<unsigned long long>(bytes),
		static_cast<unsigned long long>(total_bytes),
		static_cast<unsigned long long>(source_read_us),
		static_cast<unsigned long long>(payload_submit_us));
	if (length <= 0 || static_cast<size_t>(length) >= sizeof(line)) return;
	append_line(line, static_cast<size_t>(length));
}

void megavgm_load_trace_upload_summary(const megavgm_upload_summary &s)
{
	const uint32_t index = pending_index.load(std::memory_order_relaxed);
	if (index != 1) return;
	const uint64_t sequence = pending_sequence.load(std::memory_order_relaxed);
	const uint64_t generation = pending_generation.load(std::memory_order_relaxed);
	const bool generation_valid =
		pending_generation_valid.load(std::memory_order_relaxed);
	char line[3072];
	const int length = snprintf(line, sizeof(line),
		"INDEX1_UPLOAD_SUMMARY command_seq=%llu generation=%s%llu index=%u "
		"total_bytes=%llu chunk_count=%llu loop_wall_ns=%llu "
		"source_read_ns=%llu source_read_max_ns=%llu "
		"bookkeeping_ns=%llu bookkeeping_max_ns=%llu "
		"crc_ns=%llu crc_max_ns=%llu progress_calls=%llu "
		"progress_render_calls=%llu progress_prep_ns=%llu "
		"progress_prep_max_ns=%llu progress_output_ns=%llu "
		"progress_output_max_ns=%llu submit_ns=%llu submit_max_ns=%llu "
		"spi_sample_count=%llu spi_sample_total_ns=%llu "
		"spi_sample_active_ns=%llu spi_sample_wait_ns=%llu "
		"spi_wait_poll_count=%llu misc_ns=%llu finalize_ns=%llu "
		"timing_call_count=%llu clock_call_cost_ns=%llu\n",
		static_cast<unsigned long long>(sequence),
		generation_valid ? "" : "legacy:",
		static_cast<unsigned long long>(generation), index,
		static_cast<unsigned long long>(s.total_bytes),
		static_cast<unsigned long long>(s.chunk_count),
		static_cast<unsigned long long>(s.loop_wall_ns),
		static_cast<unsigned long long>(s.source_read_ns),
		static_cast<unsigned long long>(s.source_read_max_ns),
		static_cast<unsigned long long>(s.bookkeeping_ns),
		static_cast<unsigned long long>(s.bookkeeping_max_ns),
		static_cast<unsigned long long>(s.crc_ns),
		static_cast<unsigned long long>(s.crc_max_ns),
		static_cast<unsigned long long>(s.progress_calls),
		static_cast<unsigned long long>(s.progress_render_calls),
		static_cast<unsigned long long>(s.progress_prep_ns),
		static_cast<unsigned long long>(s.progress_prep_max_ns),
		static_cast<unsigned long long>(s.progress_output_ns),
		static_cast<unsigned long long>(s.progress_output_max_ns),
		static_cast<unsigned long long>(s.submit_ns),
		static_cast<unsigned long long>(s.submit_max_ns),
		static_cast<unsigned long long>(s.spi_sample_count),
		static_cast<unsigned long long>(s.spi_sample_total_ns),
		static_cast<unsigned long long>(s.spi_sample_active_ns),
		static_cast<unsigned long long>(s.spi_sample_wait_ns),
		static_cast<unsigned long long>(s.spi_wait_poll_count),
		static_cast<unsigned long long>(s.misc_ns),
		static_cast<unsigned long long>(s.finalize_ns),
		static_cast<unsigned long long>(s.timing_call_count),
		static_cast<unsigned long long>(s.clock_call_cost_ns));
	if (length <= 0 || static_cast<size_t>(length) >= sizeof(line)) return;
	append_line(line, static_cast<size_t>(length));
}

void megavgm_load_trace_session_observed(uint32_t session, const char *state)
{
	const uint64_t sequence =
		pending_sequence.load(std::memory_order_relaxed);
	if (!sequence) return;
	uint32_t state_code = 0;
	if (state)
		for (const unsigned char *p = reinterpret_cast<const unsigned char *>(state);
				*p; p++)
			state_code = (state_code * 33U) ^ *p;
	uint32_t previous_session =
		last_session.exchange(session, std::memory_order_relaxed);
	uint32_t previous_state =
		last_state.exchange(state_code, std::memory_order_relaxed);
	if (previous_session == session && previous_state == state_code) return;
	if (session && state && !strcmp(state, "PLAYING") &&
		!pending_backend_ready.exchange(true, std::memory_order_relaxed))
		megavgm_load_trace_transfer_event("i12_backend_player_ready", 0, 0);

	char line[512];
	const bool generation_valid =
		pending_generation_valid.load(std::memory_order_relaxed);
	const uint64_t generation =
		pending_generation.load(std::memory_order_relaxed);
	int length = snprintf(line, sizeof(line),
		"t_ms=%llu event=SESSION_OBSERVED command_seq=%llu generation=%s%llu session=%u state=%s\n",
		static_cast<unsigned long long>(monotonic_ms()),
		static_cast<unsigned long long>(sequence),
		generation_valid ? "" : "legacy:",
		static_cast<unsigned long long>(generation), session,
		state ? state : "UNKNOWN");
	if (length <= 0 || static_cast<size_t>(length) >= sizeof(line)) return;
	append_line(line, static_cast<size_t>(length));
	printf("%s", line);
}
