#include "upload_progress_throttle.h"

UploadProgressThrottle::UploadProgressThrottle(uint64_t interval_ns)
	: interval_ns_(interval_ns)
{
	reset();
}

void UploadProgressThrottle::reset()
{
	last_publish_ns_ = 0;
	last_current_ = 0;
	last_maximum_ = 0;
	published_ = false;
	last_title_.clear();
	last_text_.clear();
}

bool UploadProgressThrottle::should_publish(uint64_t now_ns,
		const char *title, const char *text, int current, int maximum,
		bool force)
{
	const char *safe_title = title ? title : "";
	const char *safe_text = text ? text : "";
	const bool message_changed = published_ &&
		(last_title_ != safe_title || last_text_ != safe_text);
	const bool zero_boundary = maximum > 0 && current <= 0 &&
		(!published_ || last_current_ != 0 || last_maximum_ != maximum);
	const bool completion_boundary = maximum > 0 && current >= maximum;
	const bool clock_discontinuity = published_ && now_ns < last_publish_ns_;
	const bool interval_elapsed = published_ && !clock_discontinuity &&
		now_ns - last_publish_ns_ >= interval_ns_;

	if (!(force || !published_ || message_changed || zero_boundary ||
		completion_boundary || clock_discontinuity || interval_elapsed))
		return false;

	published_ = true;
	last_publish_ns_ = now_ns;
	last_current_ = current;
	last_maximum_ = maximum;
	last_title_ = safe_title;
	last_text_ = safe_text;
	return true;
}
