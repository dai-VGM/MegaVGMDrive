#include "mister_cmd_stream.h"

#include <string.h>

void mister_cmd_stream_init(MisterCmdStream *stream)
{
	if (!stream) return;
	memset(stream, 0, sizeof(*stream));
}

void mister_cmd_stream_feed(MisterCmdStream *stream, const char *data,
		size_t size, MisterCmdStreamLineHandler handler, void *opaque)
{
	if (!stream || (!data && size)) return;

	for (size_t i = 0; i < size; i++)
	{
		const char byte = data[i];
		if (byte == '\n')
		{
			if (stream->discarding_overlong)
			{
				stream->discarding_overlong = false;
				stream->length = 0;
				stream->completed_overlong++;
				continue;
			}
			stream->line[stream->length] = 0;
			if (handler) handler(stream->line, opaque);
			stream->length = 0;
			continue;
		}

		if (stream->discarding_overlong) continue;
		if (stream->length >= MISTER_CMD_STREAM_LINE_MAX)
		{
			stream->discarding_overlong = true;
			stream->length = 0;
			continue;
		}
		stream->line[stream->length++] = byte;
	}
}
