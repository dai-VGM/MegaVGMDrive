#ifndef MEGAVGM_LOAD_TRACE_H
#define MEGAVGM_LOAD_TRACE_H

#include <stdint.h>

struct megavgm_upload_summary
{
	uint64_t total_bytes;
	uint64_t chunk_count;
	uint64_t loop_wall_ns;
	uint64_t source_read_ns;
	uint64_t source_read_max_ns;
	uint64_t bookkeeping_ns;
	uint64_t bookkeeping_max_ns;
	uint64_t crc_ns;
	uint64_t crc_max_ns;
	uint64_t progress_calls;
	uint64_t progress_render_calls;
	uint64_t progress_prep_ns;
	uint64_t progress_prep_max_ns;
	uint64_t progress_output_ns;
	uint64_t progress_output_max_ns;
	uint64_t submit_ns;
	uint64_t submit_max_ns;
	uint64_t spi_sample_count;
	uint64_t spi_sample_total_ns;
	uint64_t spi_sample_active_ns;
	uint64_t spi_sample_wait_ns;
	uint64_t spi_wait_poll_count;
	uint64_t misc_ns;
	uint64_t finalize_ns;
	uint64_t timing_call_count;
	uint64_t clock_call_cost_ns;
};

void megavgm_load_trace_event(const char *event, uint64_t command_sequence,
		bool generation_valid, uint64_t generation, unsigned int index,
		const char *path, const char *reason = nullptr);
void megavgm_load_trace_set_pending(uint64_t command_sequence,
		bool generation_valid, uint64_t generation, unsigned int index);
uint64_t megavgm_load_trace_monotonic_us();
uint64_t megavgm_load_trace_monotonic_ns();
void megavgm_load_trace_timing_reset();
uint64_t megavgm_load_trace_timing_call_count();
uint64_t megavgm_load_trace_measure_clock_call_ns(unsigned int iterations);
void megavgm_load_trace_transfer_event(const char *event, uint64_t bytes,
		uint64_t total_bytes, uint64_t source_read_us = 0,
		uint64_t payload_submit_us = 0);
void megavgm_load_trace_upload_summary(const megavgm_upload_summary &summary);
void megavgm_load_trace_session_observed(uint32_t session,
		const char *state);

#endif
