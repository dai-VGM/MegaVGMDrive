#ifndef MENU_H
#define MENU_H

#include <inttypes.h>

void SelectFile(const char* path, const char* pFileExt, int Options, unsigned char MenuSelect, unsigned char MenuCancel);

void HandleUI(void);
void menu_key_set(unsigned int c);
void menu_process_save();
void PrintDirectory(int expand = 0);
void ScrollLongName(void);

void ProgressMessage(const char* title = 0, const char* text = 0, int current = 0, int max = 0);
void ProgressMessageUploadBegin();
void ProgressMessageUpload(const char *title, const char *text, int current,
	int max, bool force = false);
void ProgressMessageUploadAbort();
void ProgressMessageUploadEnd();

struct progress_message_diagnostic_stats
{
	uint64_t call_count;
	uint64_t render_count;
	uint64_t preparation_ns;
	uint64_t preparation_max_ns;
	uint64_t output_ns;
	uint64_t output_max_ns;
};

void ProgressMessageDiagnosticReset();
progress_message_diagnostic_stats ProgressMessageDiagnosticSnapshot();
void InfoMessage(const char *message, int timeout = 2000, const char *title = "Message");
void Info(const char *message, int timeout = 2000, int width = 0, int height = 0, int frame = 0);
void MenuHide();
void SelectINI();

void open_joystick_setup();
int menu_lightgun_cb(int idx, uint16_t type, uint16_t code, int value);

int menu_allow_cfg_switch();
void StoreIdx_F(int idx, const char *path);
void StoreIdx_S(int idx, const char *path);

int menu_present();

#endif
