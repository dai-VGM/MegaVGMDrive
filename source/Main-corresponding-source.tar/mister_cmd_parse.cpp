#include "mister_cmd_parse.h"

#include <string.h>

static bool is_horizontal_space(char c)
{
	return c == ' ' || c == '\t';
}

MisterCmdLoadFileParseResult mister_cmd_parse_load_file(const char *command,
		MisterCmdLoadFile *load_file)
{
	static const char token[] = "load_file";
	static const char generated_token[] = "load_file_gen";
	if (!command)
		return MisterCmdLoadFileParseResult::NotLoadFile;
	bool generated = !strncmp(command, generated_token,
		sizeof(generated_token) - 1) &&
		(!command[sizeof(generated_token) - 1] ||
		 is_horizontal_space(command[sizeof(generated_token) - 1]));
	bool legacy = !strncmp(command, token, sizeof(token) - 1) &&
		(!command[sizeof(token) - 1] ||
		 is_horizontal_space(command[sizeof(token) - 1]));
	if (!generated && !legacy)
		return MisterCmdLoadFileParseResult::NotLoadFile;

	const char *p = command + (generated ?
		sizeof(generated_token) - 1 : sizeof(token) - 1);
	uint64_t generation = 0;
	if (generated)
	{
		while (is_horizontal_space(*p)) p++;
		if (!*p || *p == '\r')
			return MisterCmdLoadFileParseResult::MissingGeneration;
		if (*p < '0' || *p > '9')
			return MisterCmdLoadFileParseResult::InvalidGeneration;
		while (*p >= '0' && *p <= '9')
		{
			const uint64_t digit = static_cast<uint64_t>(*p - '0');
			if (generation > (UINT64_MAX - digit) / 10)
				return MisterCmdLoadFileParseResult::InvalidGeneration;
			generation = generation * 10 + digit;
			p++;
		}
		if (!*p || *p == '\r')
			return MisterCmdLoadFileParseResult::MissingIndex;
		if (!is_horizontal_space(*p))
			return MisterCmdLoadFileParseResult::InvalidGeneration;
	}

	while (is_horizontal_space(*p)) p++;
	if (!*p || *p == '\r') return MisterCmdLoadFileParseResult::MissingIndex;
	if (*p < '0' || *p > '9') return MisterCmdLoadFileParseResult::InvalidIndex;

	unsigned int index = 0;
	while (*p >= '0' && *p <= '9')
	{
		index = (index * 10) + static_cast<unsigned int>(*p - '0');
		if (index > 255) return MisterCmdLoadFileParseResult::InvalidIndex;
		p++;
	}

	if (*p && !is_horizontal_space(*p) && *p != '\r')
		return MisterCmdLoadFileParseResult::InvalidIndex;
	if (!*p || *p == '\r') return MisterCmdLoadFileParseResult::MissingPath;

	while (is_horizontal_space(*p)) p++;
	if (!*p || *p == '\r') return MisterCmdLoadFileParseResult::MissingPath;

	size_t path_length = strlen(p);
	// The FIFO command is normally newline terminated. input.cpp removes LF;
	// accept the CR left by CRLF framing without making it part of the path.
	if (path_length && p[path_length - 1] == '\r') path_length--;
	if (!path_length) return MisterCmdLoadFileParseResult::MissingPath;
	if (path_length > MISTER_CMD_LOAD_FILE_PATH_MAX)
		return MisterCmdLoadFileParseResult::PathTooLong;

	for (size_t i = 0; i < path_length; i++)
	{
		unsigned char c = static_cast<unsigned char>(p[i]);
		if (c < 0x20 || c == 0x7f)
			return MisterCmdLoadFileParseResult::InvalidPath;
	}

	if (load_file)
	{
		load_file->index = static_cast<unsigned char>(index);
		load_file->generation_valid = generated;
		load_file->generation = generation;
		memcpy(load_file->path, p, path_length);
		load_file->path[path_length] = 0;
	}
	return MisterCmdLoadFileParseResult::Ok;
}

const char *mister_cmd_load_file_parse_error(MisterCmdLoadFileParseResult result)
{
	switch (result)
	{
	case MisterCmdLoadFileParseResult::MissingIndex: return "missing index";
	case MisterCmdLoadFileParseResult::InvalidIndex: return "invalid index (expected 0..255)";
	case MisterCmdLoadFileParseResult::MissingGeneration: return "missing generation";
	case MisterCmdLoadFileParseResult::InvalidGeneration: return "invalid generation";
	case MisterCmdLoadFileParseResult::MissingPath: return "missing path";
	case MisterCmdLoadFileParseResult::InvalidPath: return "invalid control byte in path";
	case MisterCmdLoadFileParseResult::PathTooLong: return "path too long";
	default: return "unknown parse error";
	}
}

bool mister_cmd_is_reset_core(const char *command)
{
	if (!command) return false;
	return !strcmp(command, "reset_core") || !strcmp(command, "reset_core\r");
}
