#ifndef MEGAVGM_STATUS_H
#define MEGAVGM_STATUS_H

#include <stddef.h>
#include <stdint.h>

enum class MegaVGMPlaybackState : uint8_t
{
	Idle = 0,
	Loading = 1,
	Playing = 2,
	Ended = 3,
	Fatal = 4
};

struct MegaVGMStatusSnapshot
{
	uint8_t version;
	uint32_t session;
	MegaVGMPlaybackState state;
	uint8_t error_code;
	bool loop_valid;
	uint16_t loop_count;
};

const char *megavgm_status_path();
const char *megavgm_status_state_name(MegaVGMPlaybackState state);

bool megavgm_status_decode(const char *core_name,
		const uint8_t *status, size_t status_size,
		MegaVGMStatusSnapshot *snapshot);

bool megavgm_status_update(const char *core_name,
		const uint8_t *status, size_t status_size,
		const char *path = nullptr);

void megavgm_status_clear(const char *path = nullptr);

#endif
