#ifndef MISTER_CMD_STREAM_H
#define MISTER_CMD_STREAM_H

#include <stddef.h>

static const size_t MISTER_CMD_STREAM_LINE_MAX = 1023;

struct MisterCmdStream
{
	char line[MISTER_CMD_STREAM_LINE_MAX + 1];
	size_t length;
	bool discarding_overlong;
	unsigned int completed_overlong;
};

typedef void (*MisterCmdStreamLineHandler)(const char *line, void *opaque);

void mister_cmd_stream_init(MisterCmdStream *stream);
void mister_cmd_stream_feed(MisterCmdStream *stream, const char *data,
		size_t size, MisterCmdStreamLineHandler handler, void *opaque);

#endif
