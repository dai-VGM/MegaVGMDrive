#include "megavgm_status.h"
#include "megavgm_load_trace.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <unistd.h>

namespace
{
constexpr const char *kStatusPath = "/tmp/MegaVGMPlayer.status";
constexpr uint8_t kV1InterfaceMagic = 0x4d;
constexpr uint8_t kV1InterfaceVersion = 1;
constexpr uint8_t kV2InterfaceVersion = 2;

bool is_megavgm_core(const char *core_name)
{
	return core_name &&
		(!strcasecmp(core_name, "MegaVGMDrive") ||
		 !strcasecmp(core_name, "MegaVGMPlayer"));
}

uint64_t read_high_record(const uint8_t *status)
{
	uint64_t record = 0;
	for (unsigned int i = 0; i < 8; i++)
		record |= static_cast<uint64_t>(status[8 + i]) << (i * 8);
	return record;
}

bool write_all(int fd, const char *data, size_t size)
{
	while (size)
	{
		ssize_t written = write(fd, data, size);
		if (written < 0)
		{
			if (errno == EINTR) continue;
			return false;
		}
		if (!written) return false;
		data += written;
		size -= static_cast<size_t>(written);
	}
	return true;
}
}

const char *megavgm_status_path()
{
	return kStatusPath;
}

const char *megavgm_status_state_name(MegaVGMPlaybackState state)
{
	switch (state)
	{
	case MegaVGMPlaybackState::Idle: return "IDLE";
	case MegaVGMPlaybackState::Loading: return "LOADING";
	case MegaVGMPlaybackState::Playing: return "PLAYING";
	case MegaVGMPlaybackState::Ended: return "ENDED";
	case MegaVGMPlaybackState::Fatal: return "FATAL";
	default: return nullptr;
	}
}

bool megavgm_status_decode(const char *core_name,
		const uint8_t *status, size_t status_size,
		MegaVGMStatusSnapshot *snapshot)
{
	if (!is_megavgm_core(core_name) || !status || status_size < 16 || !snapshot)
		return false;

	uint64_t record = read_high_record(status);
	if (static_cast<uint8_t>(record >> 56) != kV1InterfaceMagic)
		return false;

	if (static_cast<uint8_t>(record >> 48) == kV1InterfaceVersion)
	{
		uint8_t state_value = static_cast<uint8_t>((record >> 13) & 0x07);
		uint8_t reserved = static_cast<uint8_t>(record & 0x1f);
		if (state_value > static_cast<uint8_t>(MegaVGMPlaybackState::Fatal) ||
			reserved)
			return false;

		snapshot->version = kV1InterfaceVersion;
		snapshot->session = static_cast<uint32_t>(record >> 16);
		snapshot->state = static_cast<MegaVGMPlaybackState>(state_value);
		snapshot->error_code = static_cast<uint8_t>((record >> 5) & 0xff);
		snapshot->loop_valid = false;
		snapshot->loop_count = 0;
		return true;
	}

	uint8_t version = static_cast<uint8_t>((record >> 52) & 0x0f);
	uint8_t state_value = static_cast<uint8_t>((record >> 17) & 0x07);
	uint32_t payload = static_cast<uint32_t>(record & 0x1ffff);
	if (version != kV2InterfaceVersion ||
		state_value > static_cast<uint8_t>(MegaVGMPlaybackState::Fatal))
		return false;

	snapshot->version = version;
	snapshot->session = static_cast<uint32_t>((record >> 20) & 0xffffffff);
	snapshot->state = static_cast<MegaVGMPlaybackState>(state_value);
	if (snapshot->state == MegaVGMPlaybackState::Fatal)
	{
		if (payload & 0x01ff) return false;
		snapshot->error_code = static_cast<uint8_t>((payload >> 9) & 0xff);
		snapshot->loop_valid = false;
		snapshot->loop_count = 0;
	}
	else
	{
		snapshot->error_code = 0;
		snapshot->loop_valid = (payload >> 16) & 1;
		snapshot->loop_count = static_cast<uint16_t>(payload & 0xffff);
	}
	return true;
}

void megavgm_status_clear(const char *path)
{
	const char *target = path ? path : kStatusPath;
	if (target[0]) unlink(target);
}

bool megavgm_status_update(const char *core_name,
		const uint8_t *status, size_t status_size,
		const char *path)
{
	const char *target = path ? path : kStatusPath;
	MegaVGMStatusSnapshot snapshot = {};
	if (!target[0] ||
		!megavgm_status_decode(core_name, status, status_size, &snapshot))
	{
		megavgm_status_clear(target);
		return false;
	}

	const char *state_name = megavgm_status_state_name(snapshot.state);
	if (!state_name)
	{
		megavgm_status_clear(target);
		return false;
	}
	megavgm_load_trace_session_observed(snapshot.session, state_name);

	char content[200];
	int content_size;
	if (snapshot.version == kV2InterfaceVersion)
	{
		content_size = snprintf(content, sizeof(content),
			"version=%u\nsession=%u\nstate=%s\nerror=%02X\n"
			"loop_valid=%u\nloop_count=%u\n",
			snapshot.version, snapshot.session, state_name,
			snapshot.error_code, snapshot.loop_valid ? 1 : 0,
			snapshot.loop_count);
	}
	else
	{
		content_size = snprintf(content, sizeof(content),
			"version=%u\nsession=%u\nstate=%s\nerror=%02X\n",
			snapshot.version, snapshot.session, state_name,
			snapshot.error_code);
	}
	if (content_size < 0 || static_cast<size_t>(content_size) >= sizeof(content))
		return false;

	char temporary[1200];
	int temporary_size = snprintf(temporary, sizeof(temporary), "%s.tmp.%ld",
		target, static_cast<long>(getpid()));
	if (temporary_size < 0 ||
		static_cast<size_t>(temporary_size) >= sizeof(temporary))
		return false;

	int fd = open(temporary, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
	if (fd < 0) return false;

	bool success = write_all(fd, content, static_cast<size_t>(content_size));
	if (success && fsync(fd)) success = false;
	if (close(fd)) success = false;

	if (success && !rename(temporary, target)) return true;

	unlink(temporary);
	return false;
}
