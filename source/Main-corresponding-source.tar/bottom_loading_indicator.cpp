#include "bottom_loading_indicator.h"

#include <stdio.h>
#include <string.h>

namespace
{
constexpr int kProgressCount = 28;
constexpr int kProgressStepsPerCell = 6;
constexpr int kProgressMaximum = (kProgressStepsPerCell * kProgressCount) - 1;
constexpr int kProgressWidthPixels = kProgressCount * 8;
constexpr int kSafeMargin = 2;
}

int BottomLoadingIndicatorProgress(int current, int max)
{
	return (static_cast<uint64_t>(current) * kProgressMaximum) / max;
}

void BottomLoadingIndicatorBuild(BottomLoadingIndicator *indicator,
		const char *target, int progress)
{
	memset(indicator, 0, sizeof(*indicator));
	if (progress > kProgressMaximum) progress = kProgressMaximum;

	if (progress < 0) progress = 0;
	if (target && *target)
		snprintf(indicator->filename, sizeof(indicator->filename), "%.27s", target);

	indicator->progress_pixels =
		(static_cast<uint64_t>(progress) * kProgressWidthPixels) /
		kProgressMaximum;
	indicator->width_cells = kProgressCount;
	indicator->height_cells = 1;
}

int BottomLoadingIndicatorY(uint32_t video_height, int height_cells)
{
	unsigned scale = 1;
	if (video_height >= 1280) scale = 5;
	else if (video_height >= 960) scale = 4;
	else if (video_height >= 640) scale = 3;
	else if (video_height >= 320) scale = 2;

	int logical_height = video_height ? video_height / scale : 240;
	int y = logical_height - (height_cells * 8) - kSafeMargin;
	return y > kSafeMargin ? y : kSafeMargin;
}
