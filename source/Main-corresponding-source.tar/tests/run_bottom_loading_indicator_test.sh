#!/bin/sh
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
test_bin=${TMPDIR:-/tmp}/bottom_loading_indicator_test.$$
trap 'rm -f "$test_bin"' EXIT HUP INT TERM

${CXX:-c++} -std=c++14 -Wall -Wextra -Wpedantic -Werror \
	-I"$repo_dir" \
	"$repo_dir/tests/test_bottom_loading_indicator.cpp" \
	"$repo_dir/bottom_loading_indicator.cpp" \
	-o "$test_bin"
"$test_bin"
