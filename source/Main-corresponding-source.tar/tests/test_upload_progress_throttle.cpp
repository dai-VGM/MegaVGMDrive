#include "upload_progress_throttle.h"

#include <assert.h>
#include <stdio.h>

namespace
{
constexpr uint64_t ms(uint64_t value)
{
	return value * 1000000ULL;
}
}

int main()
{
	UploadProgressThrottle throttle;
	assert(throttle.interval_ns() == ms(100));

	// A short upload publishes both boundaries even within 100 ms.
	assert(throttle.should_publish(ms(10), "Loading", "short.vgm", 0, 4096));
	assert(throttle.should_publish(ms(11), "Loading", "short.vgm", 4096, 4096));

	// Normal intermediate updates are bounded to 10 Hz.
	throttle.reset();
	assert(throttle.should_publish(ms(0), "Loading", "long.vgm", 0, 1000));
	assert(!throttle.should_publish(ms(50), "Loading", "long.vgm", 100, 1000));
	assert(!throttle.should_publish(ms(99), "Loading", "long.vgm", 200, 1000));
	assert(throttle.should_publish(ms(100), "Loading", "long.vgm", 300, 1000));
	assert(!throttle.should_publish(ms(199), "Loading", "long.vgm", 400, 1000));
	assert(throttle.should_publish(ms(200), "Loading", "long.vgm", 500, 1000));

	throttle.reset();
	unsigned int publications = 0;
	for (uint64_t elapsed = 0; elapsed < 1000; elapsed += 10)
		if (throttle.should_publish(ms(elapsed), "Loading", "rate.vgm",
			static_cast<int>(elapsed), 2000)) publications++;
	assert(publications == 10);

	// Completion, error/cancel force, and phase/message changes are immediate.
	throttle.reset();
	assert(throttle.should_publish(ms(0), "Loading", "long.vgm", 0, 1000));
	assert(throttle.should_publish(ms(201), "Loading", "long.vgm", 1000, 1000));
	assert(throttle.should_publish(ms(202), "Error", "long.vgm", 500, 1000, true));
	assert(throttle.should_publish(ms(203), "Loading", "other.vgm", 500, 1000));
	assert(throttle.should_publish(ms(204), "Cancelled", "other.vgm", 500, 1000, true));

	// Every new upload/session starts from a clean throttle epoch.
	throttle.reset();
	assert(throttle.should_publish(ms(205), "Loading", "next.vgm", 0, 1000));
	assert(!throttle.should_publish(ms(206), "Loading", "next.vgm", 100, 1000));

	// A monotonic discontinuity fails open rather than hiding progress forever.
	assert(throttle.should_publish(ms(100), "Loading", "next.vgm", 200, 1000));

	puts("upload progress throttle tests: PASS");
	return 0;
}
