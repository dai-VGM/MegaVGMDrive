#include "bottom_loading_indicator.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>

static void expect_bottom_margin(uint32_t video_height, int scale)
{
	const int height_cells = 1;
	const int y = BottomLoadingIndicatorY(video_height, height_cells);
	assert(y * scale + height_cells * 8 * scale + 2 * scale <=
		static_cast<int>(video_height));
}

int main()
{
	assert(BottomLoadingIndicatorProgress(0, 100) == 0);
	assert(BottomLoadingIndicatorProgress(50, 100) == 83);
	assert(BottomLoadingIndicatorProgress(100, 100) == 167);

	BottomLoadingIndicator indicator = {};
	BottomLoadingIndicatorBuild(&indicator, "Dragon Saber / Ending", 167);
	assert(!strcmp(indicator.filename, "Dragon Saber / Ending"));
	assert(strstr(indicator.filename, "MegaVGMPlayer") == nullptr);
	assert(strstr(indicator.filename, "Loading") == nullptr);
	assert(strchr(indicator.filename, '%') == nullptr);
	assert(indicator.progress_pixels == 224);
	assert(indicator.width_cells == 28);
	assert(indicator.height_cells == 1);

	BottomLoadingIndicatorBuild(&indicator, nullptr, 0);
	assert(!indicator.filename[0]);
	assert(indicator.progress_pixels == 0);

	BottomLoadingIndicatorBuild(&indicator, "filename.vgm", 83);
	assert(indicator.progress_pixels == 111);

	expect_bottom_margin(240, 1);
	expect_bottom_margin(288, 1);
	expect_bottom_margin(480, 2);
	expect_bottom_margin(576, 2);
	expect_bottom_margin(720, 3);
	expect_bottom_margin(1080, 4);
	assert(BottomLoadingIndicatorY(240, 1) == 230);
	assert(BottomLoadingIndicatorY(288, 1) == 278);
	assert(BottomLoadingIndicatorY(480, 1) == 230);
	assert(BottomLoadingIndicatorY(576, 1) == 278);
	assert(BottomLoadingIndicatorY(720, 1) == 230);
	assert(BottomLoadingIndicatorY(1080, 1) == 260);
	assert(BottomLoadingIndicatorY(0, 1) == 230);

	puts("bottom loading indicator tests: PASS");
	return 0;
}
