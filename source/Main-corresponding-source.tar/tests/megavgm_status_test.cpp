#include "../megavgm_status.h"

#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static void encode_record(uint8_t *status, uint8_t version, uint32_t session,
		MegaVGMPlaybackState state, uint8_t error)
{
	memset(status, 0, 16);
	uint64_t record =
		(static_cast<uint64_t>(0x4d) << 56) |
		(static_cast<uint64_t>(version) << 48) |
		(static_cast<uint64_t>(session) << 16) |
		(static_cast<uint64_t>(state) << 13) |
		(static_cast<uint64_t>(error) << 5);
	for (unsigned int i = 0; i < 8; i++)
		status[8 + i] = static_cast<uint8_t>(record >> (i * 8));
}

static void encode_v2_record(uint8_t *status, uint32_t session,
		MegaVGMPlaybackState state, uint8_t error, bool loop_valid,
		uint16_t loop_count)
{
	memset(status, 0, 16);
	uint32_t payload = state == MegaVGMPlaybackState::Fatal ?
		(static_cast<uint32_t>(error) << 9) :
		((static_cast<uint32_t>(loop_valid) << 16) |
		 static_cast<uint32_t>(loop_count));
	uint64_t record =
		(static_cast<uint64_t>(0x4d) << 56) |
		(static_cast<uint64_t>(2) << 52) |
		(static_cast<uint64_t>(session) << 20) |
		(static_cast<uint64_t>(state) << 17) |
		payload;
	for (unsigned int i = 0; i < 8; i++)
		status[8 + i] = static_cast<uint8_t>(record >> (i * 8));
}

static void expect_decode(uint32_t session, MegaVGMPlaybackState state,
		uint8_t error)
{
	uint8_t status[16];
	encode_record(status, 1, session, state, error);
	MegaVGMStatusSnapshot snapshot = {};
	assert(megavgm_status_decode("MegaVGMDrive", status, sizeof(status),
		&snapshot));
	assert(snapshot.version == 1);
	assert(snapshot.session == session);
	assert(snapshot.state == state);
	assert(snapshot.error_code == error);
	assert(!snapshot.loop_valid);
	assert(snapshot.loop_count == 0);
}

static char *read_text(const char *path)
{
	FILE *file = fopen(path, "rb");
	assert(file);
	assert(!fseek(file, 0, SEEK_END));
	long size = ftell(file);
	assert(size >= 0);
	assert(!fseek(file, 0, SEEK_SET));
	char *text = static_cast<char *>(malloc(static_cast<size_t>(size) + 1));
	assert(text);
	assert(fread(text, 1, static_cast<size_t>(size), file) ==
		static_cast<size_t>(size));
	text[size] = 0;
	fclose(file);
	return text;
}

int main()
{
	expect_decode(1, MegaVGMPlaybackState::Idle, 0x00);
	expect_decode(2, MegaVGMPlaybackState::Loading, 0x00);
	expect_decode(3, MegaVGMPlaybackState::Playing, 0x00);
	expect_decode(4, MegaVGMPlaybackState::Ended, 0x00);
	expect_decode(5, MegaVGMPlaybackState::Fatal, 0x0d);

	uint8_t status[16];
	MegaVGMStatusSnapshot snapshot = {};
	encode_record(status, 2, 7, MegaVGMPlaybackState::Ended, 0);
	assert(!megavgm_status_decode("MegaVGMDrive", status, sizeof(status),
		&snapshot));
	encode_record(status, 1, 7, MegaVGMPlaybackState::Ended, 0);
	assert(!megavgm_status_decode("OtherCore", status, sizeof(status),
		&snapshot));
	assert(megavgm_status_decode("MegaVGMPlayer", status, sizeof(status),
		&snapshot));

	encode_v2_record(status, 0xfedcba98, MegaVGMPlaybackState::Playing,
		0, true, 2);
	assert(megavgm_status_decode("MegaVGMDrive", status, sizeof(status),
		&snapshot));
	assert(snapshot.version == 2);
	assert(snapshot.session == 0xfedcba98);
	assert(snapshot.state == MegaVGMPlaybackState::Playing);
	assert(snapshot.error_code == 0);
	assert(snapshot.loop_valid);
	assert(snapshot.loop_count == 2);

	encode_v2_record(status, 99, MegaVGMPlaybackState::Fatal, 0xa7,
		true, 0xffff);
	assert(megavgm_status_decode("MegaVGMDrive", status, sizeof(status),
		&snapshot));
	assert(snapshot.version == 2);
	assert(snapshot.session == 99);
	assert(snapshot.state == MegaVGMPlaybackState::Fatal);
	assert(snapshot.error_code == 0xa7);
	assert(!snapshot.loop_valid);
	assert(snapshot.loop_count == 0);

	char directory_template[] = "/tmp/megavgm-status-test.XXXXXX";
	char *directory = mkdtemp(directory_template);
	assert(directory);
	char path[1024];
	char temp_path[1100];
	snprintf(path, sizeof(path), "%s/status", directory);
	snprintf(temp_path, sizeof(temp_path), "%s.tmp.%ld", path,
		static_cast<long>(getpid()));

	int old = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
	assert(old >= 0);
	assert(write(old, "stale\n", 6) == 6);
	assert(!close(old));

	encode_record(status, 1, 41, MegaVGMPlaybackState::Playing, 0);
	assert(megavgm_status_update("MegaVGMDrive", status, sizeof(status), path));
	char *text = read_text(path);
	assert(!strcmp(text,
		"version=1\nsession=41\nstate=PLAYING\nerror=00\n"));
	free(text);
	assert(access(temp_path, F_OK) != 0);

	encode_v2_record(status, 43, MegaVGMPlaybackState::Playing, 0,
		true, 2);
	assert(megavgm_status_update("MegaVGMDrive", status, sizeof(status), path));
	text = read_text(path);
	assert(!strcmp(text,
		"version=2\nsession=43\nstate=PLAYING\nerror=00\n"
		"loop_valid=1\nloop_count=2\n"));
	free(text);

	encode_v2_record(status, 44, MegaVGMPlaybackState::Playing, 0,
		false, 0);
	assert(megavgm_status_update("MegaVGMDrive", status, sizeof(status), path));
	text = read_text(path);
	assert(!strcmp(text,
		"version=2\nsession=44\nstate=PLAYING\nerror=00\n"
		"loop_valid=0\nloop_count=0\n"));
	free(text);

	encode_record(status, 1, 42, MegaVGMPlaybackState::Fatal, 0xa7);
	assert(megavgm_status_update("MegaVGMDrive", status, sizeof(status), path));
	text = read_text(path);
	assert(!strcmp(text,
		"version=1\nsession=42\nstate=FATAL\nerror=A7\n"));
	free(text);

	// An unrelated core cannot leave a false MegaVGMPlayer ENDED snapshot.
	encode_record(status, 1, 42, MegaVGMPlaybackState::Ended, 0);
	assert(!megavgm_status_update("OtherCore", status, sizeof(status), path));
	assert(access(path, F_OK) != 0);

	megavgm_status_clear(path);
	assert(!rmdir(directory));
	puts("megavgm_status_test: PASS");
	return 0;
}
