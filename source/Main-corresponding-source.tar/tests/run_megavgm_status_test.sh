#!/bin/sh
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
test_bin=${TMPDIR:-/tmp}/megavgm_status_test.$$
trap 'rm -f "$test_bin"' EXIT HUP INT TERM

${CXX:-c++} -std=c++14 -Wall -Wextra -Werror \
	-I"$repo_dir" \
	-o "$test_bin" \
	"$repo_dir/megavgm_load_trace.cpp" \
	"$repo_dir/megavgm_status.cpp" \
	"$repo_dir/tests/megavgm_status_test.cpp"
"$test_bin"
