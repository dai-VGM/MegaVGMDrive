#!/bin/sh
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
test_bin=${TMPDIR:-/tmp}/upload_progress_throttle_test.$$
trap 'rm -f "$test_bin"' EXIT HUP INT TERM

${CXX:-c++} -std=c++14 -Wall -Wextra -Wpedantic -Werror \
	-I"$repo_dir" \
	"$repo_dir/tests/test_upload_progress_throttle.cpp" \
	"$repo_dir/upload_progress_throttle.cpp" \
	-o "$test_bin"
"$test_bin"
