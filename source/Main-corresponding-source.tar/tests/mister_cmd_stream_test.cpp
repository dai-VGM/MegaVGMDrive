#include "../mister_cmd_parse.h"
#include "../mister_cmd_stream.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <unistd.h>

struct Capture
{
	std::vector<std::string> lines;
	std::vector<MisterCmdLoadFile> loads;
};

static void capture_line(const char *line, void *opaque)
{
	Capture *capture = static_cast<Capture *>(opaque);
	capture->lines.emplace_back(line);
	MisterCmdLoadFile load = {};
	if (mister_cmd_parse_load_file(line, &load) ==
		MisterCmdLoadFileParseResult::Ok)
		capture->loads.push_back(load);
}

static std::string generated(unsigned int generation)
{
	return "load_file_gen " + std::to_string(generation) +
		" 1 /album/" + std::to_string(generation) + ".vgm\n";
}

int main()
{
	const std::string policy = "load_file 2 /tmp/megavgm_transition_control.bin\n";
	const std::string track4 =
		"load_file_gen 4 1 /album/04 Stage 1-1.vgm\n";

	// A FIFO is a byte stream: two successful writes can be returned by one
	// read. The pre-fix Main passed this whole buffer to one parser invocation,
	// which rejects the embedded LF and silently loses the second command too.
	int fds[2];
	assert(pipe(fds) == 0);
	assert(write(fds[1], policy.data(), policy.size()) ==
		static_cast<ssize_t>(policy.size()));
	assert(write(fds[1], track4.data(), track4.size()) ==
		static_cast<ssize_t>(track4.size()));
	char combined[1024];
	ssize_t combined_size = read(fds[0], combined, sizeof(combined) - 1);
	assert(combined_size == static_cast<ssize_t>(policy.size() + track4.size()));
	combined[combined_size] = 0;
	close(fds[0]);
	close(fds[1]);
	MisterCmdLoadFile rejected = {};
	assert(mister_cmd_parse_load_file(combined, &rejected) ==
		MisterCmdLoadFileParseResult::InvalidPath);

	MisterCmdStream stream = {};
	Capture capture;
	mister_cmd_stream_feed(&stream, combined,
		static_cast<size_t>(combined_size), capture_line, &capture);
	assert(capture.lines.size() == 2);
	assert(capture.loads.size() == 2);
	assert(capture.loads[1].generation_valid);
	assert(capture.loads[1].generation == 4);
	assert(capture.loads[1].index == 1);
	assert(!strcmp(capture.loads[1].path, "/album/04 Stage 1-1.vgm"));

	// 100 automatic transitions. Deliberately combine records and split them
	// at unrelated byte offsets. Every VGM load must be recovered exactly once.
	std::string burst;
	for (unsigned int generation = 1; generation <= 100; generation++)
		burst += policy + generated(generation);
	MisterCmdStream stress_stream = {};
	Capture stress;
	static const size_t chunks[] = {1, 7, 1023, 3, 61, 2, 509};
	size_t offset = 0;
	size_t chunk_index = 0;
	while (offset < burst.size())
	{
		size_t size = chunks[chunk_index++ %
			(sizeof(chunks) / sizeof(chunks[0]))];
		if (size > burst.size() - offset) size = burst.size() - offset;
		mister_cmd_stream_feed(&stress_stream, burst.data() + offset, size,
			capture_line, &stress);
		offset += size;
	}
	assert(stress.lines.size() == 200);
	assert(stress.loads.size() == 200);
	unsigned int transfers = 0;
	uint64_t session = 0;
	for (const MisterCmdLoadFile &load : stress.loads)
	{
		if (load.index != 1) continue;
		transfers++;
		assert(load.generation_valid);
		assert(load.generation == transfers);
		session++;
	}
	assert(transfers == 100);
	assert(session == 100);

	// Overlong records are discarded only through their LF; the next valid
	// record remains independently dispatchable.
	std::string overlong(MISTER_CMD_STREAM_LINE_MAX + 10, 'x');
	overlong += "\n" + generated(101);
	MisterCmdStream overflow_stream = {};
	Capture overflow;
	mister_cmd_stream_feed(&overflow_stream, overlong.data(), overlong.size(),
		capture_line, &overflow);
	assert(overflow_stream.completed_overlong == 1);
	assert(overflow.loads.size() == 1);
	assert(overflow.loads[0].generation == 101);

	puts("mister_cmd_stream_test: PASS (100 transfers, 100 sessions)");
	return 0;
}
