#!/bin/sh
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
test_bin=${TMPDIR:-/tmp}/mister_cmd_parse_test.$$
trap 'rm -f "$test_bin"' EXIT HUP INT TERM

${CXX:-c++} -std=c++14 -Wall -Wextra -Werror \
	-I"$repo_dir" \
	"$repo_dir/mister_cmd_parse.cpp" \
	"$repo_dir/tests/mister_cmd_parse_test.cpp" \
	-o "$test_bin"
"$test_bin"
