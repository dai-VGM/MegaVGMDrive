#include "../mister_cmd_parse.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>

static void expect_ok(const char *input, unsigned int index, const char *path)
{
	MisterCmdLoadFile command = {};
	auto result = mister_cmd_parse_load_file(input, &command);
	assert(result == MisterCmdLoadFileParseResult::Ok);
	assert(command.index == index);
	assert(!command.generation_valid);
	assert(!strcmp(command.path, path));
}

static void expect_generated_ok(const char *input, uint64_t generation,
		unsigned int index, const char *path)
{
	MisterCmdLoadFile command = {};
	auto result = mister_cmd_parse_load_file(input, &command);
	assert(result == MisterCmdLoadFileParseResult::Ok);
	assert(command.index == index);
	assert(command.generation_valid);
	assert(command.generation == generation);
	assert(!strcmp(command.path, path));
}

static void expect_result(const char *input, MisterCmdLoadFileParseResult expected)
{
	MisterCmdLoadFile command = {};
	assert(mister_cmd_parse_load_file(input, &command) == expected);
}

int main()
{
	assert(mister_cmd_is_reset_core("reset_core"));
	assert(mister_cmd_is_reset_core("reset_core\r"));
	assert(!mister_cmd_is_reset_core("reset_core 1"));
	assert(!mister_cmd_is_reset_core("reset"));
	assert(!mister_cmd_is_reset_core(nullptr));

	expect_ok("load_file 1 /media/fat/MegaVGMDrive/vgm_cache/test.vgm", 1,
		"/media/fat/MegaVGMDrive/vgm_cache/test.vgm");
	expect_ok("load_file 1 /media/fat/MegaVGMDrive/vgm_cache/01 Track Name.vgm", 1,
		"/media/fat/MegaVGMDrive/vgm_cache/01 Track Name.vgm");
	expect_ok("load_file 1 /media/fat/MegaVGMDrive/vgm_cache/[Test] Track.vgm", 1,
		"/media/fat/MegaVGMDrive/vgm_cache/[Test] Track.vgm");
	expect_ok("load_file 1 /media/fat/MegaVGMDrive/vgm_cache/Fantasy Zone (Arcade).vgm", 1,
		"/media/fat/MegaVGMDrive/vgm_cache/Fantasy Zone (Arcade).vgm");
	expect_ok("load_file 1 /media/fat/MegaVGMDrive/vgm_cache/\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e.vgm", 1,
		"/media/fat/MegaVGMDrive/vgm_cache/\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e.vgm");
	expect_ok("load_file 1 /tmp/*.vgm", 1, "/tmp/*.vgm");
	expect_ok("load_file 1 /tmp/trailing-space.vgm ", 1, "/tmp/trailing-space.vgm ");
	expect_ok("load_file\t255\t/tmp/test.vgm\r", 255, "/tmp/test.vgm");
	expect_generated_ok("load_file_gen 4 1 /tmp/04 Stage 1-1.vgm", 4, 1,
		"/tmp/04 Stage 1-1.vgm");
	expect_generated_ok("load_file_gen 18446744073709551615 2 /tmp/policy", UINT64_MAX,
		2, "/tmp/policy");

	expect_result("load_file", MisterCmdLoadFileParseResult::MissingIndex);
	expect_result("load_file X foo.vgm", MisterCmdLoadFileParseResult::InvalidIndex);
	expect_result("load_file 1", MisterCmdLoadFileParseResult::MissingPath);
	expect_result("load_file -1 foo.vgm", MisterCmdLoadFileParseResult::InvalidIndex);
	expect_result("load_file 256 foo.vgm", MisterCmdLoadFileParseResult::InvalidIndex);
	expect_result("load_file 1x foo.vgm", MisterCmdLoadFileParseResult::InvalidIndex);
	expect_result("load_file 1    ", MisterCmdLoadFileParseResult::MissingPath);
	expect_result("load_file 1 foo\nbar.vgm", MisterCmdLoadFileParseResult::InvalidPath);
	expect_result("load_file_extra 1 foo.vgm", MisterCmdLoadFileParseResult::NotLoadFile);
	expect_result("load_file_gen 1", MisterCmdLoadFileParseResult::MissingIndex);
	expect_result("load_file_gen X 1 foo.vgm", MisterCmdLoadFileParseResult::InvalidGeneration);
	expect_result("load_file_gen 18446744073709551616 1 foo.vgm",
		MisterCmdLoadFileParseResult::InvalidGeneration);
	expect_result("volume 5", MisterCmdLoadFileParseResult::NotLoadFile);

	char too_long[MISTER_CMD_LOAD_FILE_PATH_MAX + 32];
	memset(too_long, 'a', sizeof(too_long));
	memcpy(too_long, "load_file 1 ", 12);
	too_long[sizeof(too_long) - 1] = 0;
	expect_result(too_long, MisterCmdLoadFileParseResult::PathTooLong);

	puts("mister_cmd_parse_test: PASS");
	return 0;
}
