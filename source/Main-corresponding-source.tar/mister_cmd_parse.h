#ifndef MISTER_CMD_PARSE_H
#define MISTER_CMD_PARSE_H

#include <stddef.h>
#include <stdint.h>

// Keep the complete command below the existing 1024-byte MiSTer_cmd buffer.
// This also makes an overlong atomic FIFO write fail parsing instead of loading
// a truncated path from the first read.
static const size_t MISTER_CMD_LOAD_FILE_PATH_MAX = 960;

enum class MisterCmdLoadFileParseResult
{
	NotLoadFile,
	Ok,
	MissingIndex,
	InvalidIndex,
	MissingGeneration,
	InvalidGeneration,
	MissingPath,
	InvalidPath,
	PathTooLong
};

struct MisterCmdLoadFile
{
	unsigned char index;
	bool generation_valid;
	uint64_t generation;
	char path[MISTER_CMD_LOAD_FILE_PATH_MAX + 1];
};

MisterCmdLoadFileParseResult mister_cmd_parse_load_file(const char *command,
		MisterCmdLoadFile *load_file);
const char *mister_cmd_load_file_parse_error(MisterCmdLoadFileParseResult result);
bool mister_cmd_is_reset_core(const char *command);

#endif
