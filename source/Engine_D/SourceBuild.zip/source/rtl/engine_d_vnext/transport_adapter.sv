`timescale 1ns/1ps

// D vNext attachment: the unchanged shared owner handles EOF, finite loops
// and resident exit. Profile audio remains live until owner end_pulse.
module megavgm_engine_d_transport_adapter #(
    parameter logic [15:0] VGM_LOAD_FILE_INDEX = 16'd1,
    parameter logic [15:0] TRANSITION_FILE_INDEX = 16'd2,
    parameter logic [31:0] TRACK_FADE_CYCLES = 32'd2_000_000,
    parameter logic [31:0] LOOP_FADE_SAMPLES = 32'd88200
)(
    input  logic        clk,
    input  logic        reset,
    input  logic        ioctl_download,
    input  logic        ioctl_wr,
    input  logic [15:0] ioctl_index,
    input  logic [26:0] ioctl_addr,
    input  logic  [7:0] ioctl_dout,
    input  logic        profile_playback_active,
    input  logic        profile_done,
    input  logic        profile_fatal,
    input  logic        profile_load_busy,
    input  logic        profile_load_error,
    input  logic        profile_load_overflow,
    input  logic        profile_audio_enable,
    input  logic [31:0] playback_session_id,
    input  logic [31:0] profile_sample_time,
    input  logic        profile_loop_entry_pulse,
    input  logic        profile_loop_boundary_pulse,
    output wire         transport_loop_policy_active,
    output wire         transport_halt_loop,

    output logic  [8:0] transport_gain,
    output logic        transport_fade_active,
    output logic        transport_released,
    output logic        transport_end_pulse,
    output logic        transport_done,
    output logic        transport_busy,
    output logic        transport_audio_open,
    output wire         preparation_cancel_request,
    output logic [31:0] transport_debug
);
    wire selected_vgm_download =
        ioctl_download && (ioctl_index == VGM_LOAD_FILE_INDEX);

    // Index-2 policy precedes index-1 upload. The shared owner must stay
    // alive so its pending policy can become active on the new load edge.
    wire owner_fade_active;
    wire owner_released;
    wire owner_end_pulse;
    wire [8:0] owner_gain;
    wire unused_owner_download;
    wire unused_owner_write;
    wire unused_owner_wait;
    wire unused_owner_load_begin;
    wire unused_owner_loop_limit;
    wire owner_fade_only_request;
    wire owner_fade_only_accept;
    wire owner_fade_eligible;
    wire owner_control_valid;
    wire [3:0] owner_control_seen;
    logic fade_only_owned;
    logic fade_ended;
    (* preserve = "true" *) logic debug_request_seen;
    (* preserve = "true" *) logic debug_accept_seen;
    (* preserve = "true" *) logic debug_fade_seen;
    (* preserve = "true" *) logic debug_end_seen;
    (* preserve = "true" *) logic debug_done_seen;
    (* preserve = "true" *) logic debug_active_at_request;
    (* preserve = "true" *) logic debug_load_busy_at_request;
    (* preserve = "true" *) logic debug_done_at_request;
    (* preserve = "true" *) logic debug_error_at_request;
    (* preserve = "true" *) logic debug_audio_open_at_request;

    megavgm_transport_owner #(
        .VGM_LOAD_FILE_INDEX(VGM_LOAD_FILE_INDEX),
        .MODE5_TRANSITION_FILE_INDEX(TRANSITION_FILE_INDEX),
        .MODE5_TRACK_FADE_CYCLES(TRACK_FADE_CYCLES),
        .MODE5_LOOP_LIMIT_FADE_SAMPLES(LOOP_FADE_SAMPLES),
        .DIRECT_LOAD_REARM(1'b1)
    ) transport_owner (
        .clk(clk), .reset(reset),
        .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr),
        .ioctl_index(ioctl_index), .ioctl_addr(ioctl_addr),
        .ioctl_dout(ioctl_dout), .mode5_backend_ioctl_wait(1'b0),
        .playback_started(profile_playback_active),
        .player_busy(profile_playback_active),
        .loaded_player_done(profile_done), .session_id(playback_session_id),
        .vgm_load_busy(profile_load_busy),
        .vgm_load_error(profile_load_error),
        .vgm_load_overflow(profile_load_overflow),
        .vgm_player_error(profile_fatal),
        .audio_runtime_open(profile_audio_enable),
        .vgm_wait_ticks_consumed_debug(profile_sample_time),
        .mode5_player_loop_entry_pulse(profile_loop_entry_pulse),
        .mode5_player_loop_boundary_pulse(profile_loop_boundary_pulse),
        .mode5_ioctl_download(unused_owner_download),
        .mode5_ioctl_wr(unused_owner_write), .ioctl_wait(unused_owner_wait),
        .mode5_load_begin_pulse(unused_owner_load_begin),
        .halt_loop(transport_halt_loop), .gain(owner_gain),
        .fade_active(owner_fade_active), .released(owner_released),
        .end_pulse(owner_end_pulse),
        .loop_limit_active(unused_owner_loop_limit),
        .loop_policy_active(transport_loop_policy_active),
        .fade_only_request_debug(owner_fade_only_request),
        .fade_only_accept_debug(owner_fade_only_accept),
        .fade_eligible_debug(owner_fade_eligible),
        .control_valid_debug(owner_control_valid),
        .control_seen_debug(owner_control_seen)
    );

    // Shared owner's complete MV02/FADE_ONLY decode; preparation owner
    // decides whether an unstarted owned session can be cancelled.
    assign preparation_cancel_request = owner_fade_only_request;

    // Ownership is latched independently of the profile. If native EOF lands
    // during the 100 ms tail, PLAYING remains owned until gain reaches zero.
    // FATAL still wins through its separate status path and never fabricates
    // ENDED because Transport v1.3 emits no end pulse on an interrupted fade.
    always_ff @(posedge clk) begin
        if (reset || selected_vgm_download) begin
            fade_only_owned <= 1'b0;
            fade_ended <= 1'b0;
            debug_request_seen <= 1'b0;
            debug_accept_seen <= 1'b0;
            debug_fade_seen <= 1'b0;
            debug_end_seen <= 1'b0;
            debug_done_seen <= 1'b0;
            debug_active_at_request <= 1'b0;
            debug_load_busy_at_request <= 1'b0;
            debug_done_at_request <= 1'b0;
            debug_error_at_request <= 1'b0;
            debug_audio_open_at_request <= 1'b0;
        end else begin
            if (owner_fade_active)
                fade_only_owned <= 1'b1;
            if (owner_end_pulse)
                fade_ended <= 1'b1;
            if (owner_fade_only_request) begin
                debug_request_seen <= 1'b1;
                debug_active_at_request <= profile_playback_active;
                debug_load_busy_at_request <= profile_load_busy;
                debug_done_at_request <= profile_done;
                debug_error_at_request <= profile_fatal ||
                    profile_load_error || profile_load_overflow;
                debug_audio_open_at_request <= profile_audio_enable;
            end
            if (owner_fade_only_accept)
                debug_accept_seen <= 1'b1;
            if (owner_fade_active)
                debug_fade_seen <= 1'b1;
            if (owner_end_pulse)
                debug_end_seen <= 1'b1;
            if (transport_done)
                debug_done_seen <= 1'b1;
        end
    end

    always_comb begin
        transport_gain = owner_gain;
        transport_fade_active = owner_fade_active;
        transport_released = owner_released;
        transport_end_pulse = owner_end_pulse;
        transport_done = fade_ended;
        transport_busy = profile_playback_active && !fade_ended;
        transport_audio_open = profile_audio_enable && !fade_ended &&
            !profile_fatal;
        // SignalTap contract for the production hierarchy. Bits [9:0] are
        // sticky first-fault evidence; upper bits retain live decode/ramp
        // boundaries. This bus is observation-only.
        transport_debug = {
            ioctl_download && (ioctl_index == TRANSITION_FILE_INDEX),
            owner_control_valid,
            owner_control_seen,
            owner_fade_only_request,
            owner_fade_only_accept,
            owner_fade_eligible,
            owner_fade_active,
            owner_end_pulse,
            transport_done,
            owner_released,
            owner_gain,
            debug_request_seen,
            debug_accept_seen,
            debug_fade_seen,
            debug_end_seen,
            debug_done_seen,
            debug_active_at_request,
            debug_load_busy_at_request,
            debug_done_at_request,
            debug_error_at_request,
            debug_audio_open_at_request
        };
    end
endmodule
