// PASS1 fact admission only. The same Common Parser is replayed for playback.
// No byte reader, grammar decoder, chip write, sample clock or loop policy.
module engine_d_vnext_preflight #(
    parameter int MAX_DESCRIPTORS = 16,parameter int YM_INITIAL_CAPACITY=256
) (
    input logic clk, reset, start,
    input logic [31:0] file_extent,
    input logic [7:0] c140_type,
    input logic [31:0] msm_header_clock,ym_header_clock,vgm_version,vgm_data_start,
    output logic msm_used,msm_descriptor_valid,
    output logic [255:0] msm_sample_mask,
    output logic [1:0] msm_banks,
    input logic fact_valid,
    output logic fact_ready,
    input vgm_scheduler_vnext_pkg::normalized_fact_t fact,
    output logic descriptor_valid,
    input logic descriptor_ready,
    output logic [31:0] descriptor_rom_size, descriptor_start,
    output logic [31:0] descriptor_length, descriptor_file_start,
    output logic done, accepted,
    // Observation only: publish usage only after complete PASS1 acceptance.
    output logic [2:0] accepted_source_mask,
    output logic [7:0] reject_code,
    output logic [31:0] first_bad_pc,
    output logic [31:0] descriptor_count
);
    import vgm_parser_vnext_event_pkg::*;
    import vgm_scheduler_vnext_pkg::*;
    write_descriptor_t write_info;
    logic scanning, write_supported, block_supported, resources_closed,positive_wait_seen;
    logic c140_block,msm_block,msm_prefix,scan_bank,loop_bank,loop_seen;
    logic [2:0] scanned_source_mask;
    assign accepted_source_mask = (done && accepted) ? scanned_source_mask : 3'b000;
    logic [6:0] scan_phrase;
    logic [31:0] scan_clock;
    logic [23:0] clock_buffer;
    logic [4:0] msm_count;
    wire msm_header_valid=vgm_version>=32'h161 && vgm_data_start>=32'h9c &&
        !msm_header_clock[30] && msm_header_clock[29:0]!=0 && msm_header_clock[29:0]<=4000000;
    wire ym_header_valid=ym_header_clock[31:30]==0 && ym_header_clock[29:0]!=0;
    wire msm_register=write_info.address==0 || (write_info.address>=8 && write_info.address<=12) || write_info.address==15;
    logic [$clog2(YM_INITIAL_CAPACITY+1)-1:0] initial_ym_count;

    data_event_t resource;
    logic [32:0] logical_end, file_end;
    assign write_info = fact.payload[134:80];
    assign resource = fact.payload;
    assign descriptor_rom_size = resource.operands[79:48];
    assign descriptor_start = resource.operands[111:80];
    assign descriptor_length = resource.payload_length;
    assign descriptor_file_start = resource.payload_offset;
    assign logical_end = {1'b0,descriptor_start}+{1'b0,descriptor_length};
    assign file_end = {1'b0,descriptor_file_start}+{1'b0,descriptor_length};
    assign c140_block = resource.kind==DATA_BLOCK &&
        resource.block_type==8'h8d && !resource.instance_id &&
        resource.metadata_bytes==8 && descriptor_rom_size!=0 &&
        descriptor_rom_size<=32'h00400000 && descriptor_start<descriptor_rom_size &&
        descriptor_length!=0 && logical_end<={1'b0,descriptor_rom_size} &&
        file_end<={1'b0,file_extent} && descriptor_count<MAX_DESCRIPTORS && !resources_closed;
    assign msm_block=resource.kind==DATA_BLOCK && resource.block_type==8'h8b && !resource.instance_id &&
        resource.metadata_bytes==8 && descriptor_rom_size!=0 && descriptor_rom_size<=32'h100000 &&
        descriptor_start<=descriptor_rom_size && logical_end<={1'b0,descriptor_rom_size} &&
        file_end<={1'b0,file_extent} && msm_count<5'(MAX_DESCRIPTORS) && !resources_closed;
    assign block_supported=c140_block || msm_block;
    assign msm_descriptor_valid=scanning && !reset && !start && fact_valid && fact.kind==S_DATA && msm_block && descriptor_length!=0;
    assign write_supported = !write_info.instance_id && !write_info.port &&
        write_info.access_kind==ACCESS_REGISTER &&
        ((write_info.chip==CHIP_YM2151 && write_info.address[15:8]==0) ||
          write_info.chip==CHIP_C140 || (write_info.chip==CHIP_MSM6295 && msm_register));
    assign descriptor_valid = scanning && !reset && !start && fact_valid &&
                              fact.kind==S_DATA && c140_block;
    assign fact_ready = scanning && !reset && !start &&
                        (fact.kind!=S_DATA || !block_supported || descriptor_ready);
    task automatic reject(input logic [7:0] code);
        reject_code<=code;first_bad_pc<=source_pc(fact);
        scanning<=0;done<=1;accepted<=0;
    endtask
    always_ff @(posedge clk) begin
        if(reset || start) begin
            scanning<=start && (c140_type==0 || c140_type==1);
            done<=start && (c140_type!=0 && c140_type!=1);
            accepted<=0;reject_code<=start && c140_type>1 ? 8'h01 : 0;
            first_bad_pc<=0;descriptor_count<=0;resources_closed<=0;
            positive_wait_seen<=0;initial_ym_count<=0;scanned_source_mask<=0;
            msm_used<=0;msm_prefix<=0;scan_phrase<=0;scan_bank<=0;loop_bank<=0;loop_seen<=0;
            msm_sample_mask<=0;msm_banks<=1;msm_count<=0;scan_clock<={2'd0,msm_header_clock[29:0]};clock_buffer<=msm_header_clock[23:0];
        end else if(fact_valid && fact_ready) begin
            case(fact.kind)
                S_WRITE: begin
                    resources_closed<=1;
                    if(write_supported) case(write_info.chip)
                        CHIP_YM2151: scanned_source_mask[0]<=1;
                        CHIP_C140: scanned_source_mask[1]<=1;
                        CHIP_MSM6295: scanned_source_mask[2]<=1;
                        default: ;
                    endcase
                    if(!write_supported) reject(8'h02);
                    // Header clock zero means unused. Validate the YM clock
                    // on every actual YM WRITE, independently of PCM usage.
                    else if(write_info.chip==CHIP_YM2151 && !ym_header_valid) reject(8'h07);
                    else if(write_info.chip==CHIP_MSM6295)begin
                        msm_used<=1;
                        if(!msm_header_valid || (write_info.address==0 && !msm_prefix && write_info.data[7] && msm_count==0))reject(8'h07);
                        else case(write_info.address)
                            0:if(msm_prefix)begin
                                msm_prefix<=0;
                                if(write_info.data[7:4]!=0)msm_sample_mask[{scan_bank,scan_phrase}]<=1;
                            end else if(write_info.data[7])begin msm_prefix<=1;scan_phrase<=write_info.data[6:0];end
                            8:clock_buffer[7:0]<=write_info.data;
                            9:clock_buffer[15:8]<=write_info.data;
                            10:clock_buffer[23:16]<=write_info.data;
                            11:if({write_info.data,clock_buffer}==0 || {write_info.data,clock_buffer}>4000000)reject(8'h08);
                                else scan_clock<={write_info.data,clock_buffer};
                            12:if(write_info.data>1)reject(8'h09);
                            15:if(write_info.data>1)reject(8'h0a);
                                else begin scan_bank<=write_info.data[0];if(write_info.data[0])msm_banks<=2;end
                            default:reject(8'h02);
                        endcase
                    end else if(!positive_wait_seen && write_info.chip==CHIP_YM2151) begin
                        // Startup must fit before phase-closed Core release.
                        // Reject before audio, rather than deadlock a full FIFO.
                        if(initial_ym_count==$clog2(YM_INITIAL_CAPACITY+1)'(YM_INITIAL_CAPACITY)) reject(8'h06);
                        else initial_ym_count<=initial_ym_count+1'b1;
                    end
                end
                S_DATA: begin
                    if(resources_closed) reject(8'h05);
                    else if(!block_supported) reject(8'h03);
                    else if(msm_block)begin if(descriptor_length!=0)msm_count<=msm_count+1'b1;end else descriptor_count<=descriptor_count+1'b1;
                end
                S_END,S_LOOP_BOUNDARY: begin
                    if(msm_prefix || (loop_seen && scan_bank!=loop_bank))reject(8'h0b);
                    else begin scanning<=0;done<=1;accepted<=1;end
                end
                S_WAIT: if(fact.time_advance!=0) begin resources_closed<=1;positive_wait_seen<=1;end
                S_LOOP_ENTRY: begin loop_seen<=1;loop_bank<=scan_bank;end
                default: reject(8'h04);
            endcase
        end
    end
endmodule
