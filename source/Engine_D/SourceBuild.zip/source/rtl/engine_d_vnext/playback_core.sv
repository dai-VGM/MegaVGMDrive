// D plugin composition. Sound Cores and common infrastructure remain pinned.
// This block owns D readiness/resource/sample/native-snapshot integration only.
module engine_d_vnext_playback_core #(
    parameter int SCHEDULER_DEPTH=32,parameter int YM_FIFO_DEPTH=256,
    parameter int SETTLE_CLOCKS=288
) (
    input logic clk,reset,start,transport_finish,transport_halt_loop,strict_fault,
    input logic [31:0] file_size,epoch,
    input logic [7:0] c140_type,
    input logic [31:0] msm_header_clock,ym_header_clock,vgm_version,
    output logic [2:0] accepted_source_mask,
    output logic accepted_source_valid,
    output logic msm_enabled,msm_audio_valid,output logic signed [18:0] msm_audio_q5,
    output logic [3:0] msm_activity,
    input logic mapper_system21,ym_reset_phase_ready,
    output logic command_request,
    input logic command_ready,command_valid,
    output logic [31:0] command_address,
    input logic [7:0] command_data,
    input logic command_word_valid,
    input logic [31:0] command_word_address,command_word_epoch,
    input logic [63:0] command_word_data,
    output logic sample_request,
    input logic sample_ready,sample_valid,
    output logic [31:0] sample_address,
    input logic [7:0] sample_data,
    input logic sample_word_valid,
    input logic [31:0] sample_word_address,sample_word_epoch,
    input logic [63:0] sample_word_data,
    output logic chip_reset,ym_chip_reset,ym_write,command_read_priority,
    output logic [7:0] ym_address,ym_data,
    input logic ym_ready,
    output logic signed [15:0] c140_audio_l,c140_audio_r,
    output logic c140_audio_valid,
    output logic [23:0] activity,
    output logic running,parser_done,fatal,native_started,
    output logic [7:0] fatal_code,
    output logic loop_entry,loop_boundary,
    output logic [63:0] playback_time,
    output logic [63:0] decoded_due,
    output logic [15:0] native_age,
    output logic [31:0] command_pc,
    output logic [7:0] command_opcode,
    output logic [5:0] command_state,
    output logic [4:0] descriptor_count,
    output logic [31:0] underflows,descriptor_misses,stale_responses,
    output logic [31:0] raw_fetches,compressed_fetches,natural_ends,deadline_misses,
    output logic [$clog2(YM_FIFO_DEPTH):0] ym_max_level
);
    typedef enum logic [3:0] {IDLE,SCAN_ARM,SCAN,CHIP_FLUSH,IDENTITY,REPLAY,INITIALIZE,YM_RELEASE,YM_INITIALIZE,START_CLOCK,PLAY,STOPPED,FAILED,MSM_PREP} phase_t;
    phase_t phase;
    logic [10:0] flush_count;
    logic preflight_done,preflight_accepted,playback_prepared,initial_commands_ready,initialization_ready,timeline_started;
    logic descriptor_valid,descriptor_ready,publish_resources,published,map_fault,sample_fault,command_fault;
    logic [7:0] map_fault_code,sample_fault_code,command_fault_code;
    logic [31:0] descriptor_rom_size,descriptor_start,descriptor_length,descriptor_file_start,pf_count,first_bad_pc;
    logic [4:0] map_count;
    logic [63:0] due_time,native_index,native_time;
    logic native_horizon_known,native_control_debt;
    logic msm_control_check,msm_control_check_debt;
    logic [63:0] msm_control_check_time;
    logic playback_tick,native_tick,native_pending,native_inflight;
    logic [31:0] tick_phase;
    logic [$clog2(SETTLE_CLOCKS+1)-1:0] settle_count;
    logic memory_request,memory_ready,memory_valid;
    logic [31:0] memory_address;
    logic [7:0] memory_data;
    logic c140_write;
    logic [15:0] c140_address;
    logic [7:0] c140_data;
    logic [$clog2(YM_FIFO_DEPTH):0] ym_level;
    logic rom_request,rom_ready,rom_valid;
    logic [31:0] rom_logical_address;
    logic [4:0] rom_voice;
    logic [7:0] rom_generation;
    logic [63:0] rom_data;
    logic map_request,map_ready,map_valid,map_response_ready;
    logic [31:0] map_logical_address,map_file_address,map_epoch;
    logic [7:0] map_error;
    logic [31:0] arithmetic_deadlines;
    logic msm_used,msm_prepared,msm_fault,msm_map_fault,msm_map_published,msm_descriptor_valid,msm_descriptor_ready;
    logic [7:0] msm_fault_code,msm_map_fault_code,msm_address,msm_data;
    logic [255:0] msm_sample_mask;logic [1:0] msm_banks;
    logic msm_write,msm_ready,msm_native_tick;
    logic msm_rom_request,msm_rom_ready,msm_rom_response;
    logic [17:0] msm_rom_address;logic [7:0] msm_rom_bank,msm_rom_data;
    logic [31:0] msm_rom_transaction,msm_rom_epoch,msm_response_transaction,msm_response_epoch;
    logic [1:0] msm_response_result;
    logic range_request,range_ready,range_response,range_ok;
    logic [18:0] range_start;logic [19:0] range_end_exclusive;
    logic c_sample_request,c_sample_ready,c_sample_valid,c_sample_word_valid;
    logic [31:0] c_sample_address;logic [7:0] c_sample_data;
    logic msm_memory_request,msm_memory_ready,msm_memory_valid;logic [31:0] msm_memory_address;logic [7:0] msm_memory_data;
    logic [24:0] msm_clock_phase,msm_clock_sum;
    logic [31:0] msm_clock;logic [23:0] msm_clock_buffer;logic msm_pin7;
    wire msm_cen=running && msm_used && msm_clock_sum>=25'd20000000;
    assign msm_clock_sum=msm_clock_phase+{1'b0,msm_clock[23:0]};
    assign msm_enabled=msm_used;
    assign accepted_source_valid=preflight_done && preflight_accepted;
    always_ff @(posedge clk)begin
        if(reset || start)begin
            msm_clock_phase<=0;msm_clock<={2'd0,msm_header_clock[29:0]};msm_clock_buffer<=msm_header_clock[23:0];msm_pin7<=msm_header_clock[31];
        end else begin
            if(!running)msm_clock_phase<=0;
            else msm_clock_phase<=msm_cen ? msm_clock_sum-25'd20000000:msm_clock_sum;
            if(msm_write)case(msm_address)
                8:msm_clock_buffer[7:0]<=msm_data;
                9:msm_clock_buffer[15:8]<=msm_data;
                10:msm_clock_buffer[23:16]<=msm_data;
                11:msm_clock<={msm_data,msm_clock_buffer};
                12:msm_pin7<=msm_data[0];
                default:begin end
            endcase
        end
    end
    wire chip_enabled=phase==INITIALIZE || phase==YM_RELEASE || phase==YM_INITIALIZE || phase==START_CLOCK || phase==PLAY;
    wire ym_enabled=accepted_source_mask[0] && (phase==YM_INITIALIZE || phase==START_CLOCK || phase==PLAY);
    wire native_drained=!native_inflight && !rom_request && rom_ready;
    wire start_clock=phase==START_CLOCK;
    wire native_begin=start_clock || playback_tick;
    wire native_settled=settle_count==$clog2(SETTLE_CLOCKS+1)'(SETTLE_CLOCKS-1);
    assign chip_reset=reset || start || phase==IDLE || phase==SCAN_ARM || phase==SCAN || phase==CHIP_FLUSH;
    assign ym_chip_reset=chip_reset || !ym_enabled;
    // All due-zero commands are prepared before the phase-closed YM reset
    // release. DDR latency cannot change initial YM register timing.
    // Current native controls/horizon must be prepared first. Once known,
    // command lookahead is speculative and sample service owns priority.
    assign command_read_priority=!native_horizon_known || native_control_debt;
    assign descriptor_count=map_count;
    assign decoded_due=due_time;
    assign running=timeline_started && (phase==PLAY || phase==START_CLOCK) && !fatal;
    assign native_tick=native_pending && native_settled && native_horizon_known && !native_control_debt &&
                       !native_inflight && !fatal && !transport_finish;
    initial begin
        if(SETTLE_CLOCKS<2 || SETTLE_CLOCKS>400) $fatal(1,"invalid D native settle envelope");
    end
    always_ff @(posedge clk) begin
        if(reset || start) begin
            if(start) phase<=SCAN_ARM;else phase<=IDLE;
            flush_count<=0;fatal<=0;fatal_code<=0;deadline_misses<=0;
            native_index<=0;native_time<=0;native_pending<=0;native_inflight<=0;settle_count<=0;
            native_started<=0;native_age<=0;msm_control_check<=0;msm_control_check_time<=0;
        end else begin
            // Core applies CPU control before snapshot on the same edge.
            // Horizon is checked immediately. FIFO debt is checked exactly
            // one cycle later, before any sample publication, against the
            // captured boundary time; no clock/deadline/WRITE is delayed.
            msm_control_check<=msm_native_tick;
            if(msm_native_tick) msm_control_check_time<=native_time;
            case(phase)
                SCAN_ARM:phase<=SCAN;
                SCAN:if(preflight_done && preflight_accepted && published && msm_map_published)
                    phase<=msm_used ? MSM_PREP:CHIP_FLUSH;
                MSM_PREP:if(msm_prepared)phase<=CHIP_FLUSH;
                CHIP_FLUSH:if(flush_count==1023) phase<=IDENTITY;
                else flush_count<=flush_count+1'b1;
                IDENTITY:phase<=REPLAY;
                REPLAY:phase<=INITIALIZE;
                INITIALIZE:if(initial_commands_ready && native_settled)
                    // The accepted PASS1 mask, not an Activity level, owns
                    // chip presence. PCM-only streams keep YM reset asserted.
                    phase<=accepted_source_mask[0] ? YM_RELEASE : START_CLOCK;
                YM_RELEASE:if(ym_reset_phase_ready) phase<=YM_INITIALIZE;
                YM_INITIALIZE:if(initialization_ready && native_settled) phase<=START_CLOCK;
                START_CLOCK:phase<=PLAY;
                default:begin end
            endcase
            if(chip_enabled && !native_settled) settle_count<=settle_count+1'b1;
            if(running && native_age!=16'hffff) native_age<=native_age+1'b1;
            if(c140_write) settle_count<=0;
            if(native_begin && !transport_finish && !fatal) begin
                native_time<=start_clock ? 64'd0 : native_index+1'b1;
                native_index<=start_clock ? 64'd0 : native_index+1'b1;
                native_pending<=1;settle_count<=0;
                native_age<=0;
                if(native_pending) begin fatal<=1;fatal_code<=8'h45;deadline_misses<=deadline_misses+1'b1;phase<=FAILED;end
            end
            if(native_tick) begin native_pending<=0;native_inflight<=1;native_started<=1;end
            if(c140_audio_valid) native_inflight<=0;
            if(transport_finish) begin phase<=STOPPED;native_pending<=0;end
            if(!fatal && (strict_fault || map_fault || sample_fault || command_fault ||
                          underflows!=0 || descriptor_misses!=0 || arithmetic_deadlines!=0 || msm_fault || msm_map_fault ||
                          ((msm_native_tick && !native_horizon_known) || (msm_control_check && msm_control_check_debt)))) begin
                fatal<=1;phase<=FAILED;
                fatal_code<=strict_fault ? 8'h40 : map_fault ? 8'h41 : sample_fault ? 8'h42 :
                    command_fault ? command_fault_code : msm_fault ? msm_fault_code : msm_map_fault ? msm_map_fault_code :
                    ((msm_native_tick && !native_horizon_known) || (msm_control_check && msm_control_check_debt)) ? 8'h48:underflows!=0 ? 8'h43 :
                    descriptor_misses!=0 ? 8'h44 : 8'h46;
            end
        end
    end
    vgm_scheduler_vnext_tick_enable timebase(.clk,.reset(reset || start),
        .enable(running),.tick(playback_tick),.phase_debug(tick_phase));
    engine_d_vnext_command_client #(.SCHEDULER_DEPTH(SCHEDULER_DEPTH),.YM_FIFO_DEPTH(YM_FIFO_DEPTH)) commands(
        .clk,.reset(reset || start),.preflight_start(phase==SCAN_ARM),.prepare_playback(phase==REPLAY),
        .play_start(start_clock),.playback_tick,.chip_enabled(chip_enabled && !fatal && !transport_finish),
        .ym_enabled(ym_enabled && !fatal && !transport_finish),.resources_ready(published && (!msm_used || msm_prepared)),.resource_fault(map_fault || sample_fault || strict_fault || msm_fault || msm_map_fault),.image_size(file_size),.c140_type,.msm_header_clock,.ym_header_clock,.vgm_version,
        .msm_used,.msm_descriptor_valid,.msm_descriptor_ready,.msm_sample_mask,.msm_banks,.msm_write,.msm_address,.msm_data,.msm_ready,
        .memory_request,.memory_ready,.memory_valid,.memory_address,.memory_data,
        .accepted_source_mask,.preflight_done,.preflight_accepted,.playback_prepared,.initial_commands_ready,.initialization_ready,.timeline_started,
        .descriptor_valid,.descriptor_ready,.descriptor_rom_size,.descriptor_start,.descriptor_length,.descriptor_file_start,
        .publish_resources,.descriptor_count(pf_count),.ym_write,.ym_address,.ym_data,.ym_ready,
        .c140_write,.c140_address,.c140_data,.c140_ready(1'b1),.native_drained,.transport_halt_loop,.transport_finish,
        .loop_entry,.loop_boundary,.finished(parser_done),.fault(command_fault),.fault_code(command_fault_code),
        .first_bad_pc,.due_time,.playback_time,.native_time,.msm_control_check_time,.msm_control_check_debt,.native_horizon_known,.native_control_debt,
        .command_pc,.command_opcode,.command_state,.ym_level,.ym_max_level);
    engine_b_vnext_command_word_buffer command_buffer(.clk,.reset(reset || start || phase==REPLAY),
        .enable(1'b1),.epoch,.file_extent(file_size),.byte_request(memory_request),.byte_address(memory_address),
        .byte_ready(memory_ready),.byte_valid(memory_valid),.byte_data(memory_data),
        .memory_request(command_request),.memory_address(command_address),.memory_ready(command_ready),
        .memory_valid(command_valid),.memory_data(command_data),.word_valid(command_word_valid),
        .word_address(command_word_address),.word_epoch(command_word_epoch),.word_data(command_word_data));
    engine_d_vnext_resource_map resources(.clk,.reset,.new_track(start),.epoch,.file_extent(file_size),
        .descriptor_valid,.descriptor_ready,.descriptor_rom_size,.descriptor_start,.descriptor_length,.descriptor_file_start,
        .publish(publish_resources),.published,.fault(map_fault),.fault_code(map_fault_code),.descriptor_count(map_count),
        .request_valid(map_request),.request_ready(map_ready),.request_logical_address(map_logical_address),
        .response_valid(map_valid),.response_ready(map_response_ready),.response_file_address(map_file_address),
        .response_epoch(map_epoch),.response_error(map_error));
    engine_d_vnext_sample_client samples(.clk,.reset,.new_track(start),.prepared(published && !chip_reset && !fatal),
        .epoch,.file_extent(file_size),.core_request(rom_request),.core_ready(rom_ready),.core_valid(rom_valid),
        .core_logical_address(rom_logical_address),.core_voice(rom_voice),.core_generation(rom_generation),.core_data(rom_data),
        .response_voice(),.response_generation(),.map_request,.map_ready,.map_logical_address,.map_valid,.map_response_ready,
        .map_file_address,.map_epoch,.map_error,.memory_request(c_sample_request),.memory_ready(c_sample_ready),
        .memory_valid(c_sample_valid),.memory_fault(strict_fault),.memory_address(c_sample_address),.memory_data(c_sample_data),
        .word_valid(c_sample_word_valid),.word_address(sample_word_address),.word_epoch(sample_word_epoch),.word_data(sample_word_data),
        .fault(sample_fault),.fault_code(sample_fault_code));
    engine_d_msm6295_chip_plugin msm_chip(.clk,.reset,.new_track(start),
        .prepare_start(phase==SCAN && preflight_done && preflight_accepted && published && msm_map_published && msm_used),
        .armed(chip_enabled && msm_used && !fatal && !transport_finish),.chip_cen(msm_cen),.pin7(msm_pin7),
        .banks(msm_banks),.sample_mask(msm_sample_mask),.epoch,
        .command_valid(msm_write && msm_address==0),.command_data(msm_data),.command_ready(msm_ready),.busy(msm_activity),
        .bank_valid(msm_write && msm_address==15),.bank_data(msm_data),
        .range_request,.range_ready,.range_response,.range_ok,.range_start,.range_end_exclusive,
        .prepared(msm_prepared),.fault(msm_fault),.fault_code(msm_fault_code),
        .rom_request(msm_rom_request),.rom_ready(msm_rom_ready),.rom_address(msm_rom_address),.rom_bank(msm_rom_bank),
        .rom_transaction(msm_rom_transaction),.rom_epoch(msm_rom_epoch),.rom_response(msm_rom_response),.rom_data(msm_rom_data),
        .response_transaction(msm_response_transaction),.response_epoch(msm_response_epoch),.response_result(msm_response_result),
        .native_tick(msm_native_tick),.audio_valid(msm_audio_valid),.audio_q5(msm_audio_q5));
    engine_d_msm6295_rom_client msm_resources(.clk,.reset,.new_track(start),.epoch,.file_extent(file_size),
        .descriptor_valid(msm_descriptor_valid),.descriptor_ready(msm_descriptor_ready),
        .descriptor_rom_size,.descriptor_start,.descriptor_length,.descriptor_file_start,
        .publish(publish_resources),.published(msm_map_published),.fault(msm_map_fault),.fault_code(msm_map_fault_code),
        .range_request,.range_ready,.range_start,.range_end_exclusive,.range_response,.range_ok,
        .request(msm_rom_request),.ready(msm_rom_ready),.address(msm_rom_address),.bank(msm_rom_bank),
        .transaction(msm_rom_transaction),.request_epoch(msm_rom_epoch),.response(msm_rom_response),.data(msm_rom_data),
        .response_transaction(msm_response_transaction),.response_epoch(msm_response_epoch),.response_result(msm_response_result),
        .memory_request(msm_memory_request),.memory_ready(msm_memory_ready),.memory_valid(msm_memory_valid),
        .memory_address(msm_memory_address),.memory_data(msm_memory_data),.memory_fault(strict_fault));
    engine_d_msm6295_sample_arbiter sample_owners(.clk,.reset(reset || start),.lifecycle(fatal || transport_finish),
        .c_request(c_sample_request),.c_address(c_sample_address),.c_ready(c_sample_ready),.c_valid(c_sample_valid),.c_data(c_sample_data),
        .m_request(msm_memory_request),.m_address(msm_memory_address),.m_ready(msm_memory_ready),.m_valid(msm_memory_valid),.m_data(msm_memory_data),
        .c_word_valid(c_sample_word_valid),.word_valid(sample_word_valid),.request(sample_request),.address(sample_address),
        .ready(sample_ready),.valid(sample_valid),.data(sample_data),.fault(strict_fault));
    c140_stage3_24voice_core #(.DESCRIPTORS(4)) c140_core(.clk,.reset(chip_reset),.sample_tick(native_tick),.mapper_system21,
        .descriptor_wr(phase==IDENTITY),.descriptor_wr_id(2'd0),.descriptor_logical_start(22'd0),
        .descriptor_logical_end_exclusive(22'h3fffff),.descriptor_file_start(32'd0),
        .d4_wr(c140_write),.d4_addr(c140_address),.d4_data(c140_data),
        .rom_req(rom_request),.rom_file_address(rom_logical_address),.rom_voice,.rom_generation,.rom_ready,.rom_valid,.rom_data,
        .mix_l_unshifted(),.mix_r_unshifted(),.audio_l(c140_audio_l),.audio_r(c140_audio_r),.audio_valid(c140_audio_valid),
        .active_bitmap(activity),.address_signature(),.underflow_count(underflows),.descriptor_miss_count(descriptor_misses),
        .stale_response_count(stale_responses),.canceled_response_count(),.request_count(),.response_count(),
        .raw_fetch_count(raw_fetches),.compressed_fetch_count(compressed_fetches),.loop_count(),.natural_end_count(natural_ends),
        .saturation_l_count(),.saturation_r_count(),.peak_abs_mix_l(),.peak_abs_mix_r(),.max_active_count(),
        .max_request_wait_cycles(),.max_round_robin_gap(),.arithmetic_deadline_miss_count(arithmetic_deadlines),
        .max_frame_processing_cycles(),.debug_fetch_valid(),.debug_fetch_voice(),.debug_fetch_address(),
        .debug_fetch_decoded(),.debug_loop_valid(),.debug_loop_voice(),.debug_loop_address());
endmodule
