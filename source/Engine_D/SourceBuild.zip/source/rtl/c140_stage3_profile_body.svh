// C140 Stage-3 Golden Shell compatibility-body implementation.
    function automatic logic signed [15:0] c140_profile_scale_audio_256(
        input logic signed [15:0] value,
        input logic        [8:0]  gain
    );
        logic signed [25:0] product;
        begin
            product = $signed(value) * $signed({1'b0, gain});
            c140_profile_scale_audio_256 = product >>> 8;
        end
    endfunction

    wire profile_reset = !reset_n;
    wire signed [15:0] profile_audio_l;
    wire signed [15:0] profile_audio_r;
    wire profile_audio_valid;
    wire profile_audio_enable;
    wire profile_playback_active;
    wire profile_done;
    wire profile_fatal;
    wire [7:0] profile_error_code;
    wire [2:0] profile_state;
    wire profile_load_busy;
    wire profile_load_done;
    wire profile_load_error;
    wire profile_load_overflow;
    wire [23:0] profile_file_size;
    wire [23:0] profile_accepted_bytes;
    wire [3:0] profile_wait_reason;
    wire [7:0] profile_outstanding_fifo;
    wire profile_scan_started;
    wire [31:0] profile_sample_time;
    wire profile_playback_loop_entry_pulse;
    wire profile_playback_loop_boundary_pulse;
    wire profile_transport_loop_policy_active;
    wire profile_transport_halt_loop;
    wire [31:0] profile_natural_end_count;
    wire [31:0] profile_deadline_misses;
    wire [22:0] profile_debug_command_pc;
    wire [7:0] profile_debug_last_command;
    wire [5:0] profile_debug_parser_state;
    wire [4:0] profile_debug_active_count;
    wire [31:0] profile_debug_underflows;
    wire [31:0] profile_debug_misses;
    wire [31:0] profile_debug_stale;
    wire [31:0] profile_debug_raw_fetches;
    wire [31:0] profile_debug_compressed_fetches;
    wire profile_debug_first_deadline_valid;
    wire [22:0] profile_debug_first_deadline_pc;
    wire [7:0] profile_debug_first_deadline_command;
    wire [5:0] profile_debug_first_deadline_state;
    wire [7:0] profile_debug_first_deadline_flags;
    wire [31:0] profile_debug_first_deadline_producer_time;
    wire [31:0] profile_debug_first_deadline_playback_time;
    wire [15:0] profile_debug_first_deadline_frame_clock;
    wire [15:0] profile_debug_first_deadline_retired;
    wire [7:0] profile_debug_first_deadline_reason;
    wire [7:0] profile_ym_activity_event;
    wire [23:0] profile_c140_activity_state;
    wire [3:0] profile_msm6295_activity_state;
`ifndef MEGAVGM_ENGINE_D_VNEXT
    assign profile_msm6295_activity_state = 4'd0;
`endif
    wire profile_system21;
`ifdef MEGAVGMDRIVE_ENGINE_D_VNEXT
    wire [2:0] profile_source_mask;
    wire profile_source_valid;
`endif
    wire [22:0] profile_panel_pc = profile_debug_first_deadline_valid ?
        profile_debug_first_deadline_pc : profile_debug_command_pc;
    wire [7:0] profile_panel_command = profile_debug_first_deadline_valid ?
        profile_debug_first_deadline_command : profile_debug_last_command;
    wire [5:0] profile_panel_parser_state =
        profile_debug_first_deadline_valid ?
        profile_debug_first_deadline_state : profile_debug_parser_state;
    wire profile_ioctl_wait;
    wire [7:0] profile_ddram_burstcnt;
    wire [28:0] profile_ddram_addr;
    wire profile_ddram_rd;
    wire [63:0] profile_ddram_din;
    wire [7:0] profile_ddram_be;
    wire profile_ddram_we;

`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    // The production ioctl bus is broadcast to profile-local consumers.
    // C140 owns only index 1 VGM uploads; index 2 remains exclusively under
    // Transport v1.3 semantic ownership and must not reset active playback.
    wire profile_vgm_download =
        ioctl_download && (ioctl_index[7:0] == VGM_LOAD_FILE_INDEX);
    wire profile_vgm_wr = ioctl_wr && profile_vgm_download;
    wire profile_runtime_status_ready;
    wire [31:0] profile_status_session_id;
    wire [31:0] profile_status_done_session_id;
    wire [31:0] profile_status_error_session_id;
    wire profile_status_loop_valid;
    wire profile_status_loop_boundary_pulse;
    wire [8:0] profile_transport_gain;
    wire profile_transport_fade_active;
    wire profile_transport_released;
    wire profile_transport_end_pulse;
    wire profile_transport_done;
    wire profile_preparation_cancel_request;
    wire profile_preparation_cancelled;
    wire profile_transport_busy;
    wire profile_transport_audio_open;
    (* keep = "true" *) wire [31:0] profile_transport_debug;
`endif

`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    localparam bit PROFILE_TRANSPORT_LOOP_CONTROL = 1'b1;
`else
    localparam bit PROFILE_TRANSPORT_LOOP_CONTROL = 1'b0;
    assign profile_transport_loop_policy_active = 1'b0;
    assign profile_transport_halt_loop = 1'b0;
`endif

    // Full-track mode is the hardware profile. RUN_MODE=0 is the historical
    // first-key-on diagnostic and must not be used for a production attach.
    c140_stage3_profile #(
        .RUN_MODE(2), .COMMAND_SETTLE_CYCLES(288),
        .TRANSPORT_LOOP_CONTROL(PROFILE_TRANSPORT_LOOP_CONTROL)
    ) c140_profile (
        .clk(clk), .reset(profile_reset),
        .transport_loop_policy_active(profile_transport_loop_policy_active),
        .transport_halt_loop(profile_transport_halt_loop),
`ifdef MEGAVGM_ENGINE_D_VNEXT
        .transport_finish(profile_transport_end_pulse),
        .preparation_cancel(profile_preparation_cancel_request),
        .preparation_cancelled(profile_preparation_cancelled),
`endif
        .playback_loop_entry_pulse(profile_playback_loop_entry_pulse),
        .playback_loop_boundary_pulse(profile_playback_loop_boundary_pulse),
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
        .audio_isolate_step(1'b0),
        .audio_gain_boost(audio_gain_boost),
`else
        .audio_isolate_step(audio_gain_boost),
        .audio_gain_boost(1'b0),
`endif
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
        .ioctl_download(profile_vgm_download), .ioctl_wr(profile_vgm_wr),
`else
        .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr),
`endif
        .ioctl_addr(ioctl_addr), .ioctl_dout(ioctl_dout),
        .ioctl_index(ioctl_index), .ioctl_wait(profile_ioctl_wait),
        .ddram_busy(ddram_busy),
        .ddram_burstcnt(profile_ddram_burstcnt),
        .ddram_addr(profile_ddram_addr), .ddram_dout(ddram_dout),
        .ddram_dout_ready(ddram_dout_ready), .ddram_rd(profile_ddram_rd),
        .ddram_din(profile_ddram_din), .ddram_be(profile_ddram_be),
        .ddram_we(profile_ddram_we), .audio_l(profile_audio_l),
        .audio_r(profile_audio_r), .audio_sample_valid(profile_audio_valid),
        .audio_enable(profile_audio_enable),
        .playback_active(profile_playback_active),
        .playback_done(profile_done), .profile_fatal(profile_fatal),
        .error_code(profile_error_code), .profile_state(profile_state),
        .load_busy(profile_load_busy), .load_done(profile_load_done),
        .load_error(profile_load_error), .load_overflow(profile_load_overflow),
        .uploaded_file_size(profile_file_size),
        .accepted_byte_count(profile_accepted_bytes),
        .wait_reason(profile_wait_reason),
        .outstanding_fifo(profile_outstanding_fifo),
        .scan_started(profile_scan_started),
        .vgm_sample_time(profile_sample_time),
        .natural_end_count(profile_natural_end_count),
        .command_deadline_miss_count(profile_deadline_misses),
        .debug_command_pc(profile_debug_command_pc),
        .debug_last_command(profile_debug_last_command),
        .debug_parser_state(profile_debug_parser_state),
        .debug_active_count(profile_debug_active_count),
        .debug_underflow_count(profile_debug_underflows),
        .debug_descriptor_miss_count(profile_debug_misses),
        .debug_stale_response_count(profile_debug_stale),
        .debug_raw_fetch_count(profile_debug_raw_fetches),
        .debug_compressed_fetch_count(profile_debug_compressed_fetches),
        .debug_first_deadline_valid(profile_debug_first_deadline_valid),
        .debug_first_deadline_pc(profile_debug_first_deadline_pc),
        .debug_first_deadline_command(profile_debug_first_deadline_command),
        .debug_first_deadline_state(profile_debug_first_deadline_state),
        .debug_first_deadline_flags(profile_debug_first_deadline_flags),
        .debug_first_deadline_producer_time(
            profile_debug_first_deadline_producer_time),
        .debug_first_deadline_playback_time(
            profile_debug_first_deadline_playback_time),
        .debug_first_deadline_frame_clock(
            profile_debug_first_deadline_frame_clock),
        .debug_first_deadline_retired(profile_debug_first_deadline_retired),
        .debug_first_deadline_reason(profile_debug_first_deadline_reason),
        .ym2151_activity_event(profile_ym_activity_event),
        .c140_activity_state(profile_c140_activity_state),
`ifdef MEGAVGM_ENGINE_D_VNEXT
        .msm6295_activity_state(profile_msm6295_activity_state),
`endif
        `ifdef MEGAVGMDRIVE_ENGINE_D_VNEXT
        .accepted_source_mask(profile_source_mask),.accepted_source_valid(profile_source_valid),
`endif
        .profile_system21(profile_system21)
    );

`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    megavgm_engine_d_transport_adapter #(
        .VGM_LOAD_FILE_INDEX(VGM_LOAD_FILE_INDEX),
        .TRANSITION_FILE_INDEX(MODE5_TRANSITION_FILE_INDEX),
        .TRACK_FADE_CYCLES(MODE5_TRACK_FADE_CYCLES)
    ) engine_d_transport (
        .clk(clk), .reset(profile_reset),
        .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr),
        .ioctl_index(ioctl_index), .ioctl_addr(ioctl_addr),
        .ioctl_dout(ioctl_dout),
        .profile_playback_active(profile_playback_active),
        .profile_done(profile_done), .profile_fatal(profile_fatal),
        .profile_load_busy(profile_load_busy),
        .profile_load_error(profile_load_error),
        .profile_load_overflow(profile_load_overflow),
        .profile_audio_enable(profile_audio_enable),
        .playback_session_id(profile_status_session_id),
        .profile_sample_time(profile_sample_time),
        .profile_loop_entry_pulse(profile_playback_loop_entry_pulse),
        .profile_loop_boundary_pulse(profile_playback_loop_boundary_pulse),
        .transport_loop_policy_active(profile_transport_loop_policy_active),
        .transport_halt_loop(profile_transport_halt_loop),
        .transport_gain(profile_transport_gain),
        .transport_fade_active(profile_transport_fade_active),
        .transport_released(profile_transport_released),
        .transport_end_pulse(profile_transport_end_pulse),
        .transport_done(profile_transport_done),
        .preparation_cancel_request(profile_preparation_cancel_request),
        .transport_busy(profile_transport_busy),
        .transport_audio_open(profile_transport_audio_open),
        .transport_debug(profile_transport_debug)
    );

    megavgm_engine_d_runtime_status_bridge engine_d_runtime_status_bridge (
        .clk(clk), .reset(profile_reset),
        .ioctl_download(ioctl_download), .ioctl_index(ioctl_index),
        .ioctl_wr(ioctl_wr), .ioctl_addr(ioctl_addr),
        .ioctl_dout(ioctl_dout), .ioctl_wait(profile_ioctl_wait),
        .load_done(profile_load_done && !profile_preparation_cancelled),
        .player_done(profile_transport_done || profile_preparation_cancelled),
        .player_fatal(profile_fatal),
        .playback_loop_boundary_pulse(profile_playback_loop_boundary_pulse),
        .loop_policy_active(profile_transport_loop_policy_active),
        .parser_state(profile_debug_parser_state),
        .parser_command(profile_debug_last_command),
        .runtime_ready(profile_runtime_status_ready),
        .playback_session_id(profile_status_session_id),
        .done_session_id(profile_status_done_session_id),
        .error_session_id(profile_status_error_session_id),
        .player_loop_valid(profile_status_loop_valid),
        .player_loop_boundary_pulse(profile_status_loop_boundary_pulse)
    );
`endif

`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign audio_l = !profile_transport_audio_open ? 16'sd0 :
        (profile_transport_gain == 9'd256) ? profile_audio_l :
        c140_profile_scale_audio_256(profile_audio_l, profile_transport_gain);
    assign audio_r = !profile_transport_audio_open ? 16'sd0 :
        (profile_transport_gain == 9'd256) ? profile_audio_r :
        c140_profile_scale_audio_256(profile_audio_r, profile_transport_gain);
`else
    assign audio_l = profile_audio_l;
    assign audio_r = profile_audio_r;
`endif
    assign audio_sample_valid = profile_audio_valid;
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign player_busy = profile_transport_busy;
    assign player_done = profile_transport_done || profile_preparation_cancelled;
`else
    assign player_busy = profile_playback_active;
    assign player_done = profile_done;
`endif
    assign player_pc_debug = profile_panel_pc[9:0];
    assign player_last_cmd_debug = profile_panel_command;
    assign startup_reset_active = '0;
    assign startup_waiting = '0;
    assign startup_done = 1'b1;
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign audio_gate_open = profile_transport_audio_open;
    assign audio_muted = !profile_transport_audio_open;
`else
    assign audio_gate_open = profile_audio_enable;
    assign audio_muted = !profile_audio_enable;
`endif
    assign ioctl_wait = profile_ioctl_wait;
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign mode5_load_ready = profile_runtime_status_ready;
`else
    assign mode5_load_ready = profile_load_done && !profile_fatal;
`endif
    assign vgm_load_busy = profile_load_busy;
    assign vgm_load_done = profile_load_done;
    assign vgm_load_error = profile_load_error;
    assign vgm_load_overflow = profile_load_overflow;
    assign vgm_header_valid = profile_load_done;
    assign vgm_player_error = profile_fatal;
    assign vgm_unsupported_opcode = '0;
    assign vgm_unsupported_pc = '0;
    assign vgm_player_error_code = profile_error_code;
    assign vgm_error_pc_debug = profile_debug_command_pc[17:0];
    assign vgm_error_cmd_debug = profile_debug_last_command;
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign vgm_error_session_id = profile_status_error_session_id;
`else
    assign vgm_error_session_id = '0;
`endif
    assign vgm_player_state_debug = {4'd0, profile_state};
    assign vgm_mem_rd_req_debug = '0;
    assign vgm_mem_rd_ready_debug = '0;
    assign vgm_mem_rd_valid_debug = '0;
    assign vgm_mem_rd_addr_debug = '0;
    assign vgm_player_core_debug = {10'd0, profile_panel_parser_state};
    assign vgm_player_lifecycle_debug = '0;
    assign vgm_player_last_read_byte_debug = '0;
    assign vgm_header_magic_read_debug = '0;
    assign vgm_header_magic_fail_index_debug = '0;
    assign vgm_read_request_addr_debug = '0;
    assign vgm_read_response_addr_debug = '0;
    assign vgm_read_pending_debug = profile_debug_first_deadline_valid;
    assign vgm_read_valid_consumed_debug = '0;
    assign vgm_final_state_debug = '0;
    assign vgm_final_pc_debug = '0;
    assign vgm_final_cmd_debug = '0;
    assign vgm_final_error_code_debug = '0;
    assign vgm_final_flags_debug = '0;
    assign vgm_final_reason_debug = '0;
    assign vgm_final_progress_debug = '0;
    assign vgm_first_playback_cmd_after_scan_debug = '0;
    assign vgm_first_playback_cmds_after_scan_debug = '0;
    assign vgm_scan_state_debug = '0;
    assign vgm_scan_pc_debug = '0;
    assign vgm_scan_last_cmd_debug = '0;
    assign vgm_scan_block_type_debug = '0;
    assign vgm_scan_block_size_low_debug = '0;
    assign vgm_scan_remaining_low_debug = '0;
    assign vgm_scan_wait_debug = '0;
    assign vgm_scan_abort_reason_debug = '0;
    assign vgm_scan_copy_last_index_low_debug = '0;
    assign vgm_scan_copy_req_count_debug = '0;
    assign vgm_scan_copy_ready_count_debug = '0;
    assign vgm_scan_copy_tail_debug = '0;
    assign vgm_scan_player_accept_count_debug = '0;
    assign vgm_scan_player_remaining_debug = '0;
    assign vgm_scan_payload_len_low_debug = '0;
    assign vgm_scan_remaining_zero_before_expected_accept_debug = '0;
    assign vgm_scan_zero_state_debug = '0;
    assign vgm_scan_zero_pc_debug = '0;
    assign vgm_scan_zero_cmd_debug = '0;
    assign vgm_scan_copy_accept_fire_count_debug = '0;
    assign vgm_scan_noncopy_advance_count_debug = '0;
    assign vgm_scan_used_noncopy_advance_debug = '0;
    assign vgm_scan_raw_copy_byte_count_debug = '0;
    assign vgm_scan_raw_event_debug = '0;
    assign vgm_scan_copy_exit_debug = '0;
    assign vgm_scan_copy_exit_pc_debug = '0;
    assign vgm_scan_copy_exit_count_debug = '0;
    assign vgm_scan_copy_phase_debug = '0;
    assign vgm_scan_copy_read_req_count_debug = '0;
    assign vgm_scan_copy_read_accept_count_debug = '0;
    assign vgm_scan_copy_read_accept_internal_debug = '0;
    assign vgm_scan_copy_read_valid_count_debug = '0;
    assign vgm_scan_copy_mem_req_cycle_count_debug = '0;
    assign vgm_scan_copy_mem_req_ready_cycle_count_debug = '0;
    assign vgm_scan_copy_request_state_debug = '0;
    assign vgm_scan_copy_state_lifetime_debug = '0;
    assign vgm_scan_copy_clear_reason_debug = '0;
    assign vgm_scan_copy_payload_pc_debug = '0;
    assign vgm_scan_copy_first01_debug = '0;
    assign vgm_scan_copy_first23_debug = '0;
    assign vgm_scan_copy_first45_debug = '0;
    assign vgm_scan_copy_first67_debug = '0;
    assign vgm_scan_copy_first8_phase_debug = '0;
    assign vgm_scan_copy_read_raw_valid_count_debug = '0;
    assign vgm_scan_copy_read_ignored_valid_count_debug = '0;
    assign vgm_scan_copy_read_handshake_debug = '0;
    assign vgm_scan_payload_o0_debug = '0;
    assign vgm_scan_payload_oh_debug = '0;
    assign vgm_scan_payload_bd_debug = '0;
    assign vgm_scan_payload_af_debug = '0;
    assign vgm_scan_payload_ah_debug = '0;
    assign vgm_scan_payload_oh2_debug = '0;
    assign vgm_scan_payload_as_debug = '0;
    assign vgm_scan_payload_vd_debug = '0;
    assign vgm_scan_payload_vh_debug = '0;
    assign vgm_scan_payload_vs_debug = '0;
    assign vgm_scan_payload_cp_debug = '0;
    assign vgm_scan_payload_ch_debug = '0;
    assign vgm_scan_payload_cs_debug = '0;
    assign vgm_scan_raw_player_accept_count_debug = '0;
    assign vgm_scan_raw_copy_accept_count_debug = '0;
    assign vgm_scan_raw_read_accept_count_debug = '0;
    assign vgm_scan_raw_read_valid_count_debug = '0;
    assign vgm_scan_max_player_accept_count_debug = '0;
    assign vgm_scan_max_copy_accept_count_debug = '0;
    assign vgm_scan_max_read_accept_count_debug = '0;
    assign vgm_scan_max_read_valid_count_debug = '0;
    assign vgm_scan_counter_latch_accept_debug = '0;
    assign vgm_scan_counter_latch_read_debug = '0;
    assign vgm_scan_counter_anomaly_debug = '0;
    assign vgm_scan_counter_reset_source_debug = '0;
    assign vgm_scan_stop_source_debug = '0;
    assign vgm_scan_term_pl_debug = '0;
    assign vgm_scan_term_rm_debug = '0;
    assign vgm_scan_term_cc_debug = '0;
    assign vgm_scan_term_nx_debug = '0;
    assign vgm_scan_term_be_debug = '0;
    assign vgm_scan_guard_debug = '0;
    assign vgm_scan_sticky_guard_debug = '0;
    assign vgm_scan_payload_qg_debug = '0;
    assign vgm_scan_payload_sf_debug = '0;
    assign mode5_backend_copy_accept_count_debug = '0;
    assign mode5_backend_copy_write_count_debug = '0;
    assign mode5_backend_copy_fifo_debug = '0;
    assign mode5_backend_copy_ready_debug = '0;
    assign mode5_backend_copy_write_req_debug = '0;
    assign mode5_backend_copy_word_debug = '0;
    assign mode5_backend_copy_flush_debug = '0;
    assign mode5_backend_copy_full_detect_count_debug = '0;
    assign mode5_backend_copy_push_req_count_debug = '0;
    assign mode5_backend_copy_push_fire_count_debug = '0;
    assign mode5_backend_copy_fifo_push_count_debug = '0;
    assign mode5_backend_copy_pack_ready_debug = '0;
    assign mode5_backend_copy_post_push_debug = '0;
    assign mode5_backend_read_gate_debug = '0;
    assign mode5_backend_read_after_copy_count_debug = '0;
    assign mode5_read_mux_debug = '0;
    assign mode5_read_ready_compare_debug = '0;
    assign mode5_read_ready_blocker_debug = '0;
    assign mode5_copy_mismatch_debug = '0;
    assign mode5_copy_max_ready_count_debug = '0;
    assign mode5_copy_min_remaining_debug = '0;
    assign mode5_restart_after_load_count_debug = '0;
    assign mode5_scan_start_count_debug = {15'd0, profile_scan_started};
    assign mode5_direct_start_debug = '0;
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign mode5_top_stop_snapshot_debug = profile_transport_debug[15:0];
`else
    assign mode5_top_stop_snapshot_debug = '0;
`endif
    assign vgm_load_size = profile_file_size;
    assign vgm_load_magic = '0;
    assign vgm_data_start_debug = '0;
    assign vgm_current_pc_debug = profile_debug_command_pc[17:0];
    assign vgm_loop_pc_debug = '0;
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign vgm_loop_valid_debug = profile_status_loop_valid;
`else
    assign vgm_loop_valid_debug = '0;
`endif
    assign vgm_loop_taken_debug = '0;
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign vgm_loop_boundary_pulse_debug =
        profile_status_loop_boundary_pulse;
`else
    assign vgm_loop_boundary_pulse_debug = '0;
`endif
    assign vgm_loop_jump_pulse_debug = '0;
    assign vgm_end_command_seen = '0;
    assign vgm_restarted_from_data_start = '0;
    assign vgm_pcm_oob = '0;
    assign vgm_pcm_oob_count = '0;
    assign vgm_wait_ticks_consumed_debug = '0;
    assign dac_stream_cmd_count = '0;
    assign dac_stream_wait_samples_total = '0;
    assign dac_stream_clk_cycles_total = '0;
    assign dac_stream_overhead_cycles_total = '0;
    assign max_dac_stream_cmd_cycles = '0;
    assign count_wait0_dac_stream_cmd = '0;
    assign count_wait0_overhead_nonzero = '0;
    assign segapcm_write_count = '0;
    assign segapcm_last_addr = '0;
    assign segapcm_last_data = '0;
    assign segapcm_core_rom_addr_low = '0;
    assign segapcm_core_rom_addr_raw_high = '0;
    assign segapcm_core_rom_addr_raw_low = '0;
    assign segapcm_core_rom_addr_mapped_high = '0;
    assign segapcm_core_rom_addr_mapped_low = '0;
    assign segapcm_core_rom_addr_min_high = '0;
    assign segapcm_core_rom_addr_min_low = '0;
    assign segapcm_core_rom_addr_max_high = '0;
    assign segapcm_core_rom_addr_max_low = '0;
    assign segapcm_core_rom_audio_active_high = '0;
    assign segapcm_core_rom_audio_active_low = '0;
    assign segapcm_core_rom_first_after_ctrl_high = '0;
    assign segapcm_core_rom_first_after_ctrl_low = '0;
    assign segapcm_core_rom_range_group = '0;
    assign segapcm_core_rom_range_group2 = '0;
    assign segapcm_core_rom_early_after_ctrl_high = '0;
    assign segapcm_core_rom_early_after_ctrl_low = '0;
    assign segapcm_core_rom_active_after_ctrl_high = '0;
    assign segapcm_core_rom_active_after_ctrl_low = '0;
    assign segapcm_core_rom_hit_miss_compact = '0;
    assign segapcm_core_rom_range_hit_count = '0;
    assign segapcm_core_rom_range_miss_count = '0;
    assign segapcm_core_rom_activity_count = '0;
    assign segapcm_core_rom_return_mapped_high = '0;
    assign segapcm_core_rom_return_mapped_low = '0;
    assign segapcm_core_rom_return_data = '0;
    assign segapcm_core_rom_return_last01 = '0;
    assign segapcm_core_rom_return_last23 = '0;
    assign segapcm_core_rom_return_nonzero_count = '0;
    assign segapcm_core_rom_return_change_count = '0;
    assign segapcm_core_rom_return_neutral_count = '0;
    assign segapcm_core_rom_preload_data = '0;
    assign segapcm_core_rom_core_ok_count = '0;
    assign segapcm_core_rom_fallback_count = '0;
    assign segapcm_core_rom_read_valid_count = '0;
    assign segapcm_core_rom_latency_debug = '0;
    assign segapcm_core_rom_payload_len_low = '0;
    assign segapcm_core_rom_payload_len_high = '0;
    assign segapcm_core_pcm_debug_bk = '0;
    assign segapcm_core_pcm_debug_cuh = '0;
    assign segapcm_core_pcm_debug_cul = '0;
    assign segapcm_core_known38686_flags = '0;
    assign segapcm_core_known38686_bank = '0;
    assign segapcm_core_known38686_channel = '0;
    assign segapcm_core_known38686_state = '0;
    assign segapcm_core_known38686_cur_high = '0;
    assign segapcm_core_known38686_cur_low = '0;
    assign segapcm_core_known38686_en_addr = '0;
    assign segapcm_core_known38686_en_value = '0;
    assign segapcm_core_known38686_d0_addr = '0;
    assign segapcm_core_known38686_d0_value = '0;
    assign segapcm_core_known38686_d1_addr = '0;
    assign segapcm_core_known38686_d1_value = '0;
    assign segapcm_core_known38686_d2_addr = '0;
    assign segapcm_core_known38686_d2_value = '0;
    assign segapcm_core_known38686_cfg_en = '0;
    assign segapcm_core_known38686_cur_23 = '0;
    assign segapcm_core_known38686_cur_15 = '0;
    assign segapcm_core_known38686_cur_07 = '0;
    assign segapcm_core_c0_capture_write_count = '0;
    assign segapcm_core_c0_capture_last_addr = '0;
    assign segapcm_core_c0_capture_last_data = '0;
    assign segapcm_core_c0_capture_channel_activity = '0;
    assign segapcm_core_c0_capture_selected_channel = '0;
    assign segapcm_core_c0_capture_ch3_ctrl = '0;
    assign segapcm_core_c0_capture_ch3_cur_low = '0;
    assign segapcm_core_c0_capture_ch3_cur_mid = '0;
    assign segapcm_core_c0_capture_ch3_cur_high = '0;
    assign segapcm_core_c0_capture_ch3_delta = '0;
    assign segapcm_core_c0_capture_ch3_vol_l = '0;
    assign segapcm_core_c0_capture_ch3_vol_r = '0;
    assign segapcm_core_c0_capture_ch3_loop = '0;
    assign segapcm_core_c0_capture_ch3_end = '0;
    assign segapcm_core_jt_smoke_vol_l = '0;
    assign segapcm_core_jt_smoke_vol_r = '0;
    assign segapcm_core_jt_smoke_sample_byte = '0;
    assign segapcm_core_jt_smoke_out_l = '0;
    assign segapcm_core_jt_smoke_out_r = '0;
    assign segapcm_core_ch3_evolution_flags = '0;
    assign segapcm_core_ch3_delta = '0;
    assign segapcm_core_ch1_first_high = '0;
    assign segapcm_core_ch1_first_low = '0;
    assign segapcm_core_ch1_first_raw_high = '0;
    assign segapcm_core_ch1_first_raw_low = '0;
    assign segapcm_core_ch3_first_high = '0;
    assign segapcm_core_ch3_first_low = '0;
    assign segapcm_core_ch3_first_raw_high = '0;
    assign segapcm_core_ch3_first_raw_low = '0;
    assign segapcm_core_ch3_r0_high = '0;
    assign segapcm_core_ch3_r0_low = '0;
    assign segapcm_core_ch3_r1_high = '0;
    assign segapcm_core_ch3_r1_low = '0;
    assign segapcm_core_ch3_r2_high = '0;
    assign segapcm_core_ch3_r2_low = '0;
    assign segapcm_core_ch3_load_after_23 = '0;
    assign segapcm_core_ch3_load_after_15 = '0;
    assign segapcm_core_ch3_load_after_07 = '0;
    assign segapcm_core_update_state_channel = '0;
    assign segapcm_core_update_before_23 = '0;
    assign segapcm_core_update_before_15 = '0;
    assign segapcm_core_update_before_07 = '0;
    assign segapcm_core_update_addend = '0;
    assign segapcm_core_update_after_23 = '0;
    assign segapcm_core_update_after_15 = '0;
    assign segapcm_core_update_after_07 = '0;
    assign segapcm_core_update_reason = '0;
    assign segapcm_jt_rv60_debug_bus = '0;
    assign segapcm_rv61_signature_bus = '0;
    assign segapcm_core_cpu_write_count = '0;
    assign segapcm_core_cpu_cen_write_count = '0;
    assign segapcm_core_cpu_addr_debug = '0;
    assign segapcm_core_shadow_decode_debug = '0;
    assign segapcm_core_shadow_ch0_vol_debug = '0;
    assign segapcm_core_shadow_ch0_end_delta_debug = '0;
    assign segapcm_core_shadow_ch0_start_debug = '0;
    assign segapcm_core_shadow_ch0_ctrl_debug = '0;
    assign segapcm_core_shadow_ch1_vol_debug = '0;
    assign segapcm_core_shadow_ch1_loop_debug = '0;
    assign segapcm_core_shadow_ch1_end_delta_debug = '0;
    assign segapcm_core_shadow_ch1_start_debug = '0;
    assign segapcm_core_shadow_ch1_ctrl_debug = '0;
    assign segapcm_core_shadow_ch3_loop_debug = '0;
    assign segapcm_core_shadow_ch3_end_delta_debug = '0;
    assign segapcm_core_shadow_ch3_start_debug = '0;
    assign segapcm_core_shadow_ch3_ctrl_debug = '0;
    assign segapcm_core_shadow_ch3_l0_debug = '0;
    assign segapcm_core_shadow_ch3_l2_debug = '0;
    assign segapcm_core_shadow_ch3_l4_debug = '0;
    assign segapcm_core_shadow_ch3_l6_debug = '0;
    assign segapcm_core_shadow_ch3_h0_debug = '0;
    assign segapcm_core_shadow_ch3_h2_debug = '0;
    assign segapcm_core_shadow_ch3_h4_debug = '0;
    assign segapcm_core_shadow_ch3_h6_debug = '0;
    assign segapcm_core_audio_nonzero_count = '0;
    assign segapcm_core_audio_abs_peak = '0;
    assign segapcm_core_last_audio_l = '0;
    assign segapcm_core_last_audio_r = '0;
    assign segapcm_core_status_debug = '0;
    assign segapcm_block6_probe_b6_debug = '0;
    assign segapcm_block6_probe_r6_debug = '0;
    assign segapcm_block6_probe_h6_debug = '0;
    assign segapcm_block6_probe_c6_debug = '0;
    assign segapcm_block6_probe_m6_debug = '0;
    assign data_block_count = {profile_debug_first_deadline_frame_clock,
        profile_debug_first_deadline_retired};
    assign last_data_block_type = profile_debug_first_deadline_reason;
    assign last_data_block_size_low = '0;
    // The Golden Shell's existing 32-bit diagnostic lane carries the full
    // 23-bit C140 command PC; its legacy 18-bit PC lane is intentionally too
    // narrow for the 1.2 MiB Dragon Saber fixture.
    assign parser_command_count_debug = {9'd0, profile_panel_pc};
    assign parser_data_block_count_debug =
        profile_debug_first_deadline_producer_time;
    assign parser_last_block_type_debug = profile_debug_first_deadline_flags;
    assign parser_type00_block_count_debug =
        profile_debug_first_deadline_playback_time;
    assign parser_type80_block_count_debug = '0;
    assign segapcm_rom_block_count = '0;
    assign segapcm_last_rom_size = '0;
    assign segapcm_last_rom_start = '0;
    assign pcm_ram_write_skip_count = '0;
    assign segapcm_rom_scan_busy = '0;
    assign segapcm_rom_scan_done = '0;
    assign segapcm_rom_scan_overflow = '0;
    assign segapcm_rom_scan_block_count = '0;
    assign segapcm_rom_scan_byte_count = '0;
    assign segapcm_rom_scan_checksum32 = '0;
    assign segapcm_rom_scan_total_size = '0;
    assign segapcm_rom_scan_last_start = '0;
    assign segapcm_rom_copy_byte_count = '0;
    assign segapcm_rom_copy_overflow = '0;
    assign segapcm_rom_copy_flush_done = '0;
    assign segapcm_copy_flush_req_debug = '0;
    assign mode5_sound_reset_active = '0;
    assign mode5_player_start_pulse_debug = '0;
    assign mode5_start_hold_debug = '0;
    assign mode5_load_begin_count = profile_debug_underflows;
    assign mode5_load_done_edge_count = profile_debug_misses;
    assign mode5_sound_reset_start_count = profile_debug_stale;
    assign mode5_player_start_count = {27'd0, profile_debug_active_count};
    assign mode5_player_reset_count = profile_debug_raw_fetches;
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign mode5_playback_session_id = profile_status_session_id;
`else
    assign mode5_playback_session_id = '0;
`endif
    assign mode5_duplicate_start_blocked_count =
        profile_debug_compressed_fetches;
    assign mode5_player_end_count = profile_natural_end_count;
    assign mode5_repeat_restart_count = '0;
    assign mode5_done_armed_debug = '0;
    assign mode5_repeat_session_id = '0;
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign mode5_done_session_id = profile_status_done_session_id;
`else
    assign mode5_done_session_id = '0;
`endif
    assign mode5_cycles_since_start = profile_deadline_misses;
    assign mode5_done_pc_debug = profile_debug_command_pc[17:0];
    assign mode5_done_cmd_debug = profile_debug_last_command;
    assign fm_adjust_clip_count_l = '0;
    assign fm_adjust_clip_count_r = '0;
    assign genmix_wrap_count_l = '0;
    assign genmix_wrap_count_r = '0;
    assign ym_write_requested_count = '0;
    assign ym_write_accepted_count = '0;
    assign ym_write_dropped_or_busy_count = '0;
    assign ym_port0_count = '0;
    assign ym_port1_count = '0;
    assign last_ym_port = '0;
    assign last_ym_addr = '0;
    assign last_ym_data = '0;
    assign jt12_cen_interval_1_count = '0;
    assign jt12_cen_interval_2_count = '0;
    assign jt12_cen_interval_3_count = '0;
    assign jt12_cen_interval_4_count = '0;
    assign jt12_cen_interval_ge5_count = '0;
    assign jt12_cen_interval_min = '0;
    assign jt12_cen_interval_max = '0;
    assign jt12_cen_interval_last = '0;
    assign fm_raw_abs_peak = '0;
    assign fm_adjust_abs_peak = '0;
    assign fm_lpf_abs_peak = '0;
    assign genmix_abs_peak = '0;
    assign md_final_audio_abs_peak = '0;
    assign c0_top_dbg_tp = '0;
    assign c0_top_dbg_sl = '0;
    assign c0_top_dbg_sr = '0;
    assign c0_top_dbg_ml = '0;
    assign c0_top_dbg_mr = '0;
    assign c0_top_dbg_fl = '0;
    assign c0_top_dbg_fr = '0;
    assign c0_top_dbg_ol = '0;
    assign c0_top_dbg_or = '0;
    assign c0_top_dbg_tm = '0;
    assign ddram_burstcnt = profile_ddram_burstcnt;
    assign ddram_addr = profile_ddram_addr;
    assign ddram_rd = profile_ddram_rd;
    assign ddram_din = profile_ddram_din;
    assign ddram_be = profile_ddram_be;
    assign ddram_we = profile_ddram_we;
`ifdef MEGAVGMDRIVE_ENGINE_D_C140
    assign engine_d_ym_activity_event = profile_ym_activity_event;
    assign engine_d_c140_activity_state = profile_c140_activity_state;
    assign engine_d_msm6295_activity_state = profile_msm6295_activity_state;
    assign engine_d_system21 = profile_system21;
`ifdef MEGAVGMDRIVE_ENGINE_D_VNEXT
    assign engine_d_source_mask = profile_source_mask;
    assign engine_d_source_valid = profile_source_valid;
`else
    assign engine_d_source_mask = 3'b111;
    assign engine_d_source_valid = 1'b1;
`endif
`endif

    wire unused_c140_profile_debug = ^{profile_accepted_bytes,
        profile_wait_reason, profile_outstanding_fifo};
