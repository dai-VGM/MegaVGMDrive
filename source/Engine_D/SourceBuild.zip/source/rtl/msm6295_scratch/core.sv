// SPDX-License-Identifier: BSD-3-Clause
// Independently authored chip-local MSM6295 behavioral candidate.
// No JT6295 implementation is compiled or copied into this module.
// Preparation supplies authenticated table descriptors and their first bytes.
// ROM addresses are chip addresses; board bank projection belongs to Storage.
module megavgm_msm6295_scratch (
 input logic clk, reset, new_track, armed, chip_cen, pin7,
 input logic [31:0] epoch,
 input logic command_valid, input logic [7:0] command_data,
 output logic command_ready, output logic [3:0] busy,
 input logic bank_valid, input logic [7:0] bank_data,
 input logic table_valid, input logic [7:0] table_index,
 input logic [17:0] table_start,table_end, input logic [7:0] table_head,
 output logic rom_request, input logic rom_ready,
 output logic [17:0] rom_address, output logic [7:0] rom_bank,
 output logic [31:0] rom_transaction,rom_epoch,
 input logic rom_response, input logic [7:0] rom_data,
 input logic [31:0] response_transaction,response_epoch,
 input logic [1:0] response_result,
 output logic native_tick, audio_valid,
 output logic signed [18:0] audio_q5,
 output logic fault, output logic [7:0] fault_code
);
 // Two explicitly prepared banks, not a universal board bank map.
 (* ramstyle="M10K, no_rw_check" *) logic [43:0] table_memory0[0:127];
 (* ramstyle="M10K, no_rw_check" *) logic [43:0] table_memory1[0:127];
 logic [255:0] table_present;
 logic [7:0] bank;
 logic [43:0] descriptor_q0,descriptor_q1;
 wire [43:0] descriptor_q=bank[0] ? descriptor_q1:descriptor_q0;
 logic [1:0] descriptor_present_q;
 wire descriptor_present=bank<2 && descriptor_present_q[bank[0]];
 logic prefix;
 logic [7:0] divider;
 logic [3:0] active, active_n;
 logic signed [11:0] predictor[4],predictor_n[4];
 logic [5:0] index[4],index_n[4],gain[4],gain_n[4];
 logic [17:0] address[4],address_n[4],ending[4],ending_n[4];
 logic [31:0] generation[4],generation_n[4];
 logic [7:0] cache[4],cache_n[4];
 logic [3:0] low,low_n,cache_valid,cache_valid_n,next_valid,next_valid_n;
 logic [7:0] next_cache[4],next_cache_n[4];
 logic [3:0] frame_active;
 logic signed [11:0] frame_predictor[4];
 logic [5:0] frame_index[4],frame_gain[4];
 logic [3:0] frame_nibble[4];
 logic [31:0] frame_generation[4];
 logic [1:0] voice;
 typedef enum logic [2:0] {IDLE,DECODE,PRODUCT,ACCUMULATE,PUBLISH} mix_state_t;
 mix_state_t mix_state;
 logic signed [11:0] decoded;
 logic [5:0] decoded_index;
 logic signed [18:0] product,accumulator;
 typedef enum logic [1:0] {ROM_IDLE,ROM_OFFER,ROM_WAIT} rom_state_t;
 rom_state_t rom_state;
 logic [1:0] fetch_voice,round_robin;
 logic [31:0] fetch_generation;
 logic [31:0] transaction;
 logic response_matches, fetch_current;
 logic [3:0] missing,snapshot_active,snapshot_low;
 logic [7:0] snapshot_cache[4];
 integer step_value,delta_value,signal_value,index_value;
 logic [3:0] nibble;
 logic signed [11:0] decoded_comb;
 logic [5:0] index_comb;
 function automatic integer step(input logic [5:0] i);
 case(i)
 0:step=16;
 1:step=17;
 2:step=19;
 3:step=21;
 4:step=23;
 5:step=25;
 6:step=28;
 7:step=31;
 8:step=34;
 9:step=37;
 10:step=41;
 11:step=45;
 12:step=50;
 13:step=55;
 14:step=60;
 15:step=66;
 16:step=73;
 17:step=80;
 18:step=88;
 19:step=97;
 20:step=107;
 21:step=118;
 22:step=130;
 23:step=143;
 24:step=157;
 25:step=173;
 26:step=190;
 27:step=209;
 28:step=230;
 29:step=253;
 30:step=279;
 31:step=307;
 32:step=337;
 33:step=371;
 34:step=408;
 35:step=449;
 36:step=494;
 37:step=544;
 38:step=598;
 39:step=658;
 40:step=724;
 41:step=796;
 42:step=876;
 43:step=963;
 44:step=1060;
 45:step=1166;
 46:step=1282;
 47:step=1411;
 48:step=1552;
 default: step=16;
 endcase
 endfunction
 function automatic logic [5:0] volume(input logic [3:0] v);
 case(v)
 0:volume=32;1:volume=22;2:volume=16;3:volume=11;4:volume=8;
 5:volume=6;6:volume=4;7:volume=3;8:volume=2;default:volume=0;
 endcase
 endfunction
 assign busy=active;
 assign command_ready=armed && !reset && !new_track && !fault;
 assign native_tick=armed && chip_cen && divider >= (pin7 ? 8'd131 : 8'd164)
                    && !reset && !new_track;
 assign rom_request=rom_state==ROM_OFFER && !reset && !new_track && !fault;
 assign response_matches=rom_state==ROM_WAIT && rom_response &&
   response_transaction==rom_transaction && response_epoch==rom_epoch;
 assign fetch_current=generation[fetch_voice]==fetch_generation &&
   (address[fetch_voice]==rom_address || (address[fetch_voice]!=ending[fetch_voice] && address[fetch_voice]+18'd1==rom_address)) && bank==rom_bank && active[fetch_voice];
 always @* begin
  nibble=frame_nibble[voice]; step_value=step(frame_index[voice]);
  delta_value=(step_value>>3)+(nibble[0] ? (step_value>>2):0)+
    (nibble[1] ? (step_value>>1):0)+(nibble[2] ? step_value:0);
  signal_value=int'($signed(frame_predictor[voice]))+(nibble[3] ? -delta_value:delta_value);
  if(signal_value>2047) signal_value=2047;
  if(signal_value< -2048) signal_value=-2048;
  case(nibble[2:0])
   0,1,2,3:index_value=int'(frame_index[voice])-1;
   4:index_value=int'(frame_index[voice])+2;
   5:index_value=int'(frame_index[voice])+4;
   6:index_value=int'(frame_index[voice])+6;
   7:index_value=int'(frame_index[voice])+8;
  endcase
  if(index_value<0) index_value=0;
  if(index_value>48) index_value=48;
  decoded_comb=12'(signal_value);index_comb=6'(index_value);
 end
 // Ordering on one edge: previous frame writeback, CPU control, response,
 // then native snapshot. Deadline-edge READ_OK participates in that snapshot.
 always @* begin
  active_n=active;low_n=low;cache_valid_n=cache_valid;next_valid_n=next_valid;
  for(integer v=0;v<4;v=v+1) begin
   predictor_n[v]=predictor[v];index_n[v]=index[v];gain_n[v]=gain[v];
   address_n[v]=address[v];ending_n[v]=ending[v];generation_n[v]=generation[v];cache_n[v]=cache[v];next_cache_n[v]=next_cache[v];
  end
  if(mix_state==PRODUCT && frame_active[voice] && generation[voice]==frame_generation[voice]) begin
   predictor_n[voice]=decoded;index_n[voice]=decoded_index;
  end
  if(command_valid && command_ready) begin
   if(prefix) begin
    for(integer v=0;v<4;v=v+1)
     if(command_data[v+4] && !active_n[v] && descriptor_present && descriptor_q[43:26]<descriptor_q[25:8]) begin
      active_n[v]=1;low_n[v]=0;cache_valid_n[v]=1;next_valid_n[v]=0;cache_n[v]=descriptor_q[7:0];
      address_n[v]=descriptor_q[43:26];ending_n[v]=descriptor_q[25:8];
      predictor_n[v]=0;index_n[v]=0;gain_n[v]=volume(command_data[3:0]);generation_n[v]=generation[v]+32'd1;
     end
   end else if(!command_data[7]) begin
    for(integer v=0;v<4;v=v+1) if(command_data[v+3]) begin
      active_n[v]=0;cache_valid_n[v]=0;next_valid_n[v]=0;generation_n[v]=generation[v]+32'd1;
    end
   end
  end
  if(bank_valid && bank_data!=bank) begin cache_valid_n=0;next_valid_n=0;end
  if(response_matches && fetch_current && response_result==0 && !bank_valid &&
      generation_n[fetch_voice]==fetch_generation) begin
   if(address_n[fetch_voice]==rom_address) begin cache_n[fetch_voice]=rom_data;cache_valid_n[fetch_voice]=1;end
   else if(address_n[fetch_voice]+18'd1==rom_address) begin next_cache_n[fetch_voice]=rom_data;next_valid_n[fetch_voice]=1;end
  end
  missing=active_n & ~cache_valid_n; snapshot_active=active_n;snapshot_low=low_n;
  for(integer v=0;v<4;v=v+1) snapshot_cache[v]=cache_n[v];
  if(native_tick && missing==0 && mix_state==IDLE && !fault) begin
   for(integer v=0;v<4;v=v+1) if(active_n[v]) begin
    if(low_n[v]) begin
     if(address_n[v]==ending_n[v]) active_n[v]=0;
     else begin address_n[v]=address_n[v]+18'd1;cache_n[v]=next_cache_n[v];cache_valid_n[v]=next_valid_n[v];next_valid_n[v]=0;end
    end
    low_n[v]=!low_n[v];
   end
  end
 end
 // RAM is not reset; validity belongs to the session. Synchronous descriptor
 // read on the prefix permits the second command on the immediately next edge.
 always_ff @(posedge clk) begin
  if(table_valid && !armed && !reset && !new_track)
   begin
   if(table_index[7])table_memory1[table_index[6:0]]<={table_start,table_end,table_head};
   else table_memory0[table_index[6:0]]<={table_start,table_end,table_head};
  end
  if(command_valid && command_ready && !prefix && command_data[7]) begin
   descriptor_q0<=table_memory0[command_data[6:0]];
   descriptor_q1<=table_memory1[command_data[6:0]];
   descriptor_present_q<={table_present[{1'b1,command_data[6:0]}],table_present[{1'b0,command_data[6:0]}]};
  end
 end
 always_ff @(posedge clk) begin
  if(reset || new_track) begin
   active<=0;low<=0;cache_valid<=0;next_valid<=0;prefix<=0;bank<=0;divider<=0;table_present<=0;
   mix_state<=IDLE;voice<=0;decoded<=0;decoded_index<=0;product<=0;accumulator<=0;
   audio_valid<=0;audio_q5<=0;fault<=0;fault_code<=0;
   rom_state<=ROM_IDLE;fetch_voice<=0;fetch_generation<=0;round_robin<=0;
   rom_address<=0;rom_bank<=0;rom_transaction<=0;rom_epoch<=0;transaction<=0;
   frame_active<=0;
   for(integer v=0;v<4;v=v+1) begin
    predictor[v]<=0;index[v]<=0;gain[v]<=0;address[v]<=0;ending[v]<=0;generation[v]<=0;cache[v]<=0;next_cache[v]<=0;
    frame_predictor[v]<=0;frame_index[v]<=0;frame_gain[v]<=0;frame_nibble[v]<=0;frame_generation[v]<=0;
   end
  end else begin
   active<=active_n;low<=low_n;cache_valid<=cache_valid_n;next_valid<=next_valid_n;
   for(integer v=0;v<4;v=v+1) begin
    predictor[v]<=predictor_n[v];index[v]<=index_n[v];gain[v]<=gain_n[v];
    address[v]<=address_n[v];ending[v]<=ending_n[v];generation[v]<=generation_n[v];cache[v]<=cache_n[v];next_cache[v]<=next_cache_n[v];
   end
   if(table_valid && !armed) table_present[table_index]<=1;
   if(bank_valid) begin bank<=bank_data;
    if(bank_data>=2)begin fault<=1;fault_code<=8'h25;end
   end
   if(command_valid && command_ready) begin
    if(prefix) begin
     prefix<=0;
     if(!descriptor_present) begin fault<=1;fault_code<=8'h21;end
    end else prefix<=command_data[7];
   end
   if(!armed) divider<=0;
   else if(chip_cen) divider<=native_tick ? 8'd0 : divider+8'd1;
   audio_valid<=0;
   case(mix_state)
    DECODE:begin decoded<=decoded_comb;decoded_index<=index_comb;mix_state<=PRODUCT;end
    PRODUCT:begin
     product<=frame_active[voice] ? $signed(decoded)*$signed({1'b0,frame_gain[voice]}) : 19'sd0;
     mix_state<=ACCUMULATE;
    end
    ACCUMULATE:begin
     accumulator<=accumulator+product;
     if(voice==3) mix_state<=PUBLISH;
     else begin voice<=voice+2'd1;mix_state<=DECODE;end
    end
    PUBLISH:begin audio_q5<=accumulator;audio_valid<=!fault;mix_state<=IDLE;end
    default:begin end
   endcase
   if(native_tick) begin
    if(missing!=0 || mix_state!=IDLE) begin fault<=1;fault_code<=missing!=0 ? 8'h22:8'h23;end
    else if(!fault) begin
     frame_active<=snapshot_active;
     for(integer v=0;v<4;v=v+1) begin
      frame_predictor[v]<=predictor_n[v];frame_index[v]<=index_n[v];frame_gain[v]<=gain_n[v];
      frame_generation[v]<=generation_n[v];
      // low/address already advanced in next-state: nibble uses pre-advance phase.
      frame_nibble[v]<=snapshot_low[v] ? snapshot_cache[v][3:0] : snapshot_cache[v][7:4];
     end
     voice<=0;accumulator<=0;mix_state<=DECODE;
    end
   end
   case(rom_state)
    ROM_IDLE:begin
     for(integer k=3;k>=0;k=k-1) begin
      if(active[(int'(round_robin)+k)%4] && (!cache_valid[(int'(round_robin)+k)%4] || (!next_valid[(int'(round_robin)+k)%4] && address[(int'(round_robin)+k)%4]!=ending[(int'(round_robin)+k)%4]))) begin
       fetch_voice<=2'((int'(round_robin)+k)%4);fetch_generation<=generation[(int'(round_robin)+k)%4];
       rom_address<=address[(int'(round_robin)+k)%4]+(cache_valid[(int'(round_robin)+k)%4] ? 18'd1 : 18'd0);rom_bank<=bank;rom_epoch<=epoch;
       rom_transaction<=transaction;transaction<=transaction+32'd1;rom_state<=ROM_OFFER;
      end
     end
    end
    ROM_OFFER:if(rom_request && rom_ready) rom_state<=ROM_WAIT;
    ROM_WAIT:if(response_matches) begin
     rom_state<=ROM_IDLE;round_robin<=fetch_voice+2'd1;
     if(response_result!=0 && fetch_current) begin fault<=1;fault_code<=8'h24;end
    end
    default:rom_state<=ROM_IDLE;
   endcase
  end
 end
endmodule
