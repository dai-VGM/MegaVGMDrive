// Legacy gain policy: preserve legacy D bit-exact when MSM is disabled.
// MSM native Q5 /4 -> signed16 domain (one predictor unit *8 at gain32).
// Sum at legacy family saturation BEFORE >>>2 normalization. Real-song balance
// calibration remains PENDING; this arithmetic is fixed, not waveform fitted.
module engine_d_msm6295_output_adapter(
 input logic enabled,cps_profile,input logic signed [18:0] msm_q5,
 input logic signed [15:0] ym_raw_l,ym_raw_r,
 input logic signed [15:0] ym_l,ym_r,c140_l,c140_r,
 output logic signed [15:0] audio_l,audio_r
);
 // CPS mono: (21*(raw YM L+R)+9*OKI Q5)/128. Relative OKI/FM
 // is 18/7 times the former stereo-mean ratio. One common scale retains
 // 1.01dB at the conservative independent full-scale four-voice bound.
 // 24-bit intermediates; arithmetic floor <1 output LSB; saturate only last.
 logic signed [23:0] cps_fm,cps_oki,cps_sum,cps_normalized;
 logic signed [18:0] sum_l,sum_r,msm;
 function automatic logic signed [15:0] sat(input logic signed [18:0] v);
  if(v>32767)sat=16'sh7fff;else if(v< -32768)sat=16'sh8000;else sat=v[15:0];
 endfunction
 always_comb begin
  msm=enabled ? msm_q5>>>2:19'sd0;
  sum_l={{3{ym_l[15]}},ym_l}+{{3{c140_l[15]}},c140_l}+msm;
  sum_r={{3{ym_r[15]}},ym_r}+{{3{c140_r[15]}},c140_r}+msm;
  cps_fm={{8{ym_raw_l[15]}},ym_raw_l}+{{8{ym_raw_r[15]}},ym_raw_r};
  cps_oki={{5{msm_q5[18]}},msm_q5};
  cps_sum=cps_fm*24'sd21+cps_oki*24'sd9;
  cps_normalized=cps_sum>>>7;
  if(cps_profile && enabled) begin
   if(cps_normalized>32767) audio_l=16'sh7fff;
   else if(cps_normalized< -32768) audio_l=16'sh8000;
   else audio_l=cps_normalized[15:0];
   audio_r=audio_l;
  end else begin
   audio_l=sat(sum_l)>>>2;audio_r=sat(sum_r)>>>2;
  end
 end
endmodule
