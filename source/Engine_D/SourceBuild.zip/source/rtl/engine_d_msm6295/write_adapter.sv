// Candidate-only target translation. No grammar, WAIT or playback policy.
module engine_d_msm6295_write_adapter(
 input logic enabled,valid,command_ready,
 input vgm_parser_vnext_event_pkg::write_descriptor_t descriptor,
 output logic ready,write_pulse,rejected,
 output logic [7:0] address,data
);
 import vgm_parser_vnext_event_pkg::*;
 wire supported=descriptor.chip==CHIP_MSM6295 && !descriptor.instance_id &&
  !descriptor.port && descriptor.access_kind==ACCESS_REGISTER && descriptor.address[15:7]==0 &&
  (descriptor.address==0 || (descriptor.address>=8 && descriptor.address<=12) || descriptor.address==15);
 assign ready=enabled && (supported ? (descriptor.address!=0 || command_ready):1'b1);
 assign write_pulse=valid && ready && supported;
 assign rejected=valid && enabled && !supported;
 assign address=descriptor.address[7:0];assign data=descriptor.data;
endmodule
