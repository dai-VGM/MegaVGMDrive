// Two chip-local sample owners share the established D sample Reader port.
// Ownership spans captured request through READ_OK; cancellation debt remains
// with the unchanged outer D mux/Strict binding.
module engine_d_msm6295_sample_arbiter(
 input logic clk,reset,lifecycle,
 input logic c_request,m_request,input logic [31:0] c_address,m_address,
 output logic c_ready,m_ready,c_valid,m_valid,output logic [7:0] c_data,m_data,
 output logic c_word_valid,input logic word_valid,
 output logic request,output logic [31:0] address,
 input logic ready,valid,fault,input logic [7:0] data
);
 logic owned,owner_m,next_m;
 wire choose_m=owned ? owner_m : m_request && (!c_request || next_m);
 assign request=!lifecycle && (owned || c_request || m_request);
 assign address=choose_m ? m_address:c_address;
 assign c_ready=!lifecycle && !choose_m && ready;
 assign m_ready=!lifecycle && choose_m && ready;
 assign c_valid=!lifecycle && owned && !owner_m && valid;
 assign m_valid=!lifecycle && owned && owner_m && valid;
 assign c_word_valid=!lifecycle && owned && !owner_m && word_valid;
 assign c_data=data;assign m_data=data;
 always_ff @(posedge clk)begin
  if(reset)begin owned<=0;owner_m<=0;next_m<=0;end
  else begin
   // Outer ready is only high after Strict capture, so hold the selected
   // owner from first offer, even before its ready/physical ACCEPT.
   if(!owned && !lifecycle && (c_request || m_request))begin owned<=1;owner_m<=choose_m;end
   if(owned && (valid || fault || lifecycle))begin owned<=0;next_m<=!owner_m;end
  end
 end
endmodule
