// SPDX-License-Identifier: BSD-3-Clause
// Chip-local preparation/core attachment with one logical resource boundary.
// Golden physical Reader, lifecycle, Scheduler and Status are not implemented here.
module engine_d_msm6295_chip_plugin (
 input logic clk,reset,new_track,prepare_start,armed,chip_cen,pin7,
 input logic [1:0] banks,input logic [255:0] sample_mask,input logic [31:0] epoch,
 input logic command_valid,input logic [7:0] command_data,
 output logic command_ready,output logic [3:0] busy,
 input logic bank_valid,input logic [7:0] bank_data,
 output logic range_request,input logic range_ready,range_response,range_ok,
 output logic [18:0] range_start,output logic [19:0] range_end_exclusive,
 output logic prepared,fault,output logic [7:0] fault_code,
 output logic rom_request,input logic rom_ready,
 output logic [17:0] rom_address,output logic [7:0] rom_bank,
 output logic [31:0] rom_transaction,rom_epoch,
 input logic rom_response,input logic [7:0] rom_data,
 input logic [31:0] response_transaction,response_epoch,input logic [1:0] response_result,
 output logic native_tick,audio_valid,output logic signed [18:0] audio_q5
);
 wire prep_fault,core_fault;wire [7:0] core_fault_code;
 wire p_req,c_req;wire [17:0] p_addr,c_addr;wire [7:0] p_bank,c_bank;
 wire [31:0] p_transaction,c_transaction,p_epoch,c_epoch;
 wire table_valid;wire [7:0] table_index,table_head;wire [17:0] table_start,table_end;
 logic range_pending,range_verified,range_fault,range_other;
// For a two-bank profile, every used interval must be mapped in both banks.
 // A bank write may change active voices; do not discover a missing span after PLAY.
 wire table_ready=(table_start>=table_end) || range_verified;
 assign range_request=table_valid && table_start<table_end && !range_pending && !range_verified && !range_fault;
 assign range_start={table_index[7]^range_other,table_start};
 assign range_end_exclusive={1'b0,table_index[7]^range_other,table_end}+20'd1;
 always_ff @(posedge clk)begin
  if(reset || new_track)begin range_pending<=0;range_verified<=0;range_fault<=0;range_other<=0;end
  else begin
   if(range_request && range_ready)range_pending<=1;
   if(range_response && range_pending)begin range_pending<=0;if(!range_ok)range_fault<=1;else if(banks==2 && !range_other)range_other<=1;else range_verified<=1;end
   if(table_valid && table_ready)begin range_verified<=0;range_other<=0;end
  end
 end
 assign rom_request=prepared ? c_req:p_req;
 assign rom_address=prepared ? c_addr:p_addr;assign rom_bank=prepared ? c_bank:p_bank;
 assign rom_transaction=prepared ? c_transaction:p_transaction;assign rom_epoch=prepared ? c_epoch:p_epoch;
 assign fault=range_fault || prep_fault || core_fault;assign fault_code=range_fault ? 8'h27:prep_fault ? 8'h26:core_fault_code;
 engine_d_msm6295_table_prepare prepare(
  .clk,.reset,.new_track,.start(prepare_start),.banks,.sample_mask,.epoch,.done(prepared),.fault(prep_fault),
  .request(p_req),.ready(rom_ready && !prepared),.address(p_addr),.bank(p_bank),.transaction(p_transaction),.request_epoch(p_epoch),
  .response(rom_response && !prepared),.response_transaction,.response_epoch,.response_result,.data(rom_data),
  .table_ready,.table_valid,.table_index,.table_start,.table_end,.table_head);
 megavgm_msm6295_scratch core(
  .clk,.reset,.new_track,.armed(armed && prepared && !prep_fault),.chip_cen,.pin7,.epoch,
  .command_valid,.command_data,.command_ready,.busy,.bank_valid,.bank_data,
  .table_valid(table_valid && table_ready),.table_index,.table_start,.table_end,.table_head,
  .rom_request(c_req),.rom_ready(rom_ready && prepared),.rom_address(c_addr),.rom_bank(c_bank),.rom_transaction(c_transaction),.rom_epoch(c_epoch),
  .rom_response(rom_response && prepared),.rom_data,.response_transaction,.response_epoch,.response_result,
  .native_tick,.audio_valid,.audio_q5,.fault(core_fault),.fault_code(core_fault_code));
endmodule
