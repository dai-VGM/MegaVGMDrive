// SPDX-License-Identifier: BSD-3-Clause
// Chip-local table/head preparation. No physical memory or VGM grammar owner.
module engine_d_msm6295_table_prepare (
 input logic clk,reset,new_track,start,
 input logic [1:0] banks,
 input logic [255:0] sample_mask, // Sealed Preflight facts, stable through preparation.
 input logic [31:0] epoch,
 output logic done,fault,
 output logic request,input logic ready,
 output logic [17:0] address,output logic [7:0] bank,
 output logic [31:0] transaction,request_epoch,
 input logic response,input logic [31:0] response_transaction,response_epoch,
 input logic [1:0] response_result,input logic [7:0] data,
 input logic table_ready,output logic table_valid,output logic [7:0] table_index,
 output logic [17:0] table_start,table_end,output logic [7:0] table_head
);
 typedef enum logic [2:0] {IDLE,OFFER,WAIT_RESPONSE,HEAD_OFFER,HEAD_WAIT,EMIT,FINISHED,FAILED} state_t;
 state_t state;
 logic [2:0] byte_index;
 logic [6:0] phrase;
 logic selected_bank;
 logic [1:0] bank_count;
 logic [31:0] next_transaction;
 assign request=((state==OFFER && sample_mask[{selected_bank,phrase}]) || (state==HEAD_OFFER && table_start<table_end)) && !reset && !new_track;
 assign address=state==HEAD_OFFER || state==HEAD_WAIT ? table_start : {8'd0,phrase,3'd0}+{15'd0,byte_index};
 assign bank={7'd0,selected_bank};
 assign table_index={selected_bank,phrase};
 assign table_valid=state==EMIT && !reset && !new_track;
 wire matched=response && response_transaction==transaction && response_epoch==request_epoch;
 always_ff @(posedge clk) begin
  if(reset || new_track) begin
   state<=IDLE;done<=0;fault<=0;byte_index<=0;phrase<=0;selected_bank<=0;bank_count<=0;
   transaction<=0;next_transaction<=1;request_epoch<=epoch;table_start<=0;table_end<=0;table_head<=0;
  end else begin
   if(state!=IDLE && state!=FINISHED && state!=FAILED && epoch!=request_epoch)begin fault<=1;state<=FAILED;end
   else case(state)
    IDLE:if(start)begin
     if(banks==0 || banks>2)begin fault<=1;state<=FAILED;end
     else begin bank_count<=banks;state<=OFFER;request_epoch<=epoch;end
    end
    OFFER:if(!sample_mask[{selected_bank,phrase}])begin
  byte_index<=0;table_start<=0;table_end<=0;table_head<=0;
  if(phrase==127 && {1'b0,selected_bank}+2'd1==bank_count)begin done<=1;state<=FINISHED;end
  else begin phrase<=phrase+7'd1;if(phrase==127)selected_bank<=1;state<=OFFER;end
end
          else if(request && ready)state<=WAIT_RESPONSE;
    WAIT_RESPONSE:if(matched)begin
     if(response_result!=0)begin fault<=1;state<=FAILED;end
     else begin
      case(byte_index)
       0:table_start[17:16]<=data[1:0];1:table_start[15:8]<=data;2:table_start[7:0]<=data;
       3:table_end[17:16]<=data[1:0];4:table_end[15:8]<=data;5:table_end[7:0]<=data;
      endcase
      transaction<=next_transaction;next_transaction<=next_transaction+32'd1;
      if(byte_index==5)begin table_head<=0;state<=HEAD_OFFER;end
      else begin byte_index<=byte_index+3'd1;state<=OFFER;end
     end
    end
    HEAD_OFFER:begin
     if(table_start>=table_end)state<=EMIT;
     else if(request && ready)state<=HEAD_WAIT;
    end
    HEAD_WAIT:if(matched)begin
     if(response_result!=0)begin fault<=1;state<=FAILED;end
     else begin table_head<=data;transaction<=next_transaction;next_transaction<=next_transaction+32'd1;state<=EMIT;end
    end
    EMIT:if(table_ready)begin
  byte_index<=0;table_start<=0;table_end<=0;table_head<=0;
  if(phrase==127 && {1'b0,selected_bank}+2'd1==bank_count)begin done<=1;state<=FINISHED;end
  else begin phrase<=phrase+7'd1;if(phrase==127)selected_bank<=1;state<=OFFER;end
end
    default:begin end
   endcase
  end
 end
endmodule
