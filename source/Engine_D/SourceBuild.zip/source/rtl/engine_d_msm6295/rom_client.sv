// MSM byte spans; candidate-local logical client of the existing Strict Reader.
// Exact byte validation before any file projection; no sparse fallback byte.
module engine_d_msm6295_rom_client #(parameter int CAPACITY=16)(
 input logic clk,reset,new_track,publish,
 input logic [31:0] epoch,file_extent,
 input logic descriptor_valid,
 output logic descriptor_ready,
 input logic [31:0] descriptor_rom_size,descriptor_start,descriptor_length,descriptor_file_start,
 input logic range_request,output logic range_ready,
 input logic [18:0] range_start,input logic [19:0] range_end_exclusive,
 output logic range_response,range_ok,
 output logic published,fault,output logic [7:0] fault_code,
 input logic request,output logic ready,input logic [17:0] address,input logic [7:0] bank,
 input logic [31:0] transaction,request_epoch,
 output logic response,output logic [7:0] data,
 output logic [31:0] response_transaction,response_epoch,output logic [1:0] response_result,
 output logic memory_request,input logic memory_ready,memory_valid,memory_fault,
 output logic [31:0] memory_address,input logic [7:0] memory_data
);
 localparam int IW=$clog2(CAPACITY);
 (* ramstyle="M10K, no_rw_check" *) logic [95:0] spans[0:CAPACITY-1];
 logic [95:0] span_q,pending;
 logic [IW-1:0] index;logic [IW:0] count;
 logic [31:0] rom_size,logical_address,owned_extent,owned_epoch;
 logic [32:0] config_end,config_file_end,mapped;
 typedef enum logic [3:0] {CONFIG,CONFIG_READ,CONFIG_CHECK,STORE,SEALED,LOOK_READ,LOOK_CHECK,READ_OFFER,READ_WAIT,REPLY,FAILED,RANGE_READ,RANGE_CHECK,RANGE_REPLY} state_t;
 state_t state;
 logic [31:0] range_cursor,range_end;
 assign config_end={1'b0,descriptor_start}+{1'b0,descriptor_length};
 assign config_file_end={1'b0,descriptor_file_start}+{1'b0,descriptor_length};
 assign mapped={1'b0,span_q[31:0]}+{1'b0,logical_address}-{1'b0,span_q[95:64]};
 assign descriptor_ready=state==CONFIG && !reset && !new_track && !fault;
 assign range_ready=state==SEALED && !reset && !new_track && !fault;
 assign range_response=state==RANGE_REPLY && !reset && !new_track;
 assign ready=!range_request && state==SEALED && !reset && !new_track && !fault;
 assign response=state==REPLY && !reset && !new_track && owned_epoch==epoch;
 assign memory_request=state==READ_OFFER && !reset && !new_track && owned_epoch==epoch;
 // Synchronous one-port query, serialized admission overlap check.
 always_ff @(posedge clk)begin
  span_q<=spans[index];
  if(state==STORE && !reset && !new_track)spans[count[IW-1:0]]<=pending;
 end
 always_ff @(posedge clk)begin
  if(reset || new_track)begin
   state<=CONFIG;count<=0;index<=0;pending<=0;rom_size<=0;
   published<=0;fault<=0;fault_code<=0;logical_address<=0;owned_epoch<=epoch;owned_extent<=file_extent;
   range_cursor<=0;range_end<=0;range_ok<=0;
   response_transaction<=0;response_epoch<=epoch;response_result<=0;data<=0;memory_address<=0;
  end else if(state!=CONFIG && state!=FAILED && owned_epoch!=epoch)begin fault<=1;fault_code<=8'h38;state<=FAILED;end
  else case(state)
   CONFIG:if(descriptor_valid && descriptor_ready)begin
    if(count==(IW+1)'(CAPACITY) || descriptor_rom_size==0 || descriptor_rom_size>32'h100000 || descriptor_length==0 ||
       descriptor_start>=descriptor_rom_size || config_end>{1'b0,descriptor_rom_size} || config_file_end>{1'b0,file_extent} ||
       (count!=0 && descriptor_rom_size!=rom_size))begin fault<=1;fault_code<=8'h31;state<=FAILED;end
    else begin
     pending<={descriptor_start,config_end[31:0],descriptor_file_start};index<=0;
     rom_size<=descriptor_rom_size;owned_epoch<=epoch;owned_extent<=file_extent;
     state<=count==0 ? STORE:CONFIG_READ;
    end
   end else if(publish)begin state<=SEALED;published<=1;end
   CONFIG_READ:state<=CONFIG_CHECK;
   CONFIG_CHECK:if(pending[95:64]<span_q[63:32] && span_q[95:64]<pending[63:32])begin fault<=1;fault_code<=8'h32;state<=FAILED;end
    else if({1'b0,index}+1'b1==count)state<=STORE;
    else begin index<=index+1'b1;state<=CONFIG_READ;end
   STORE:begin count<=count+1'b1;state<=CONFIG;end
   SEALED:if(range_request && range_ready)begin
    range_cursor<={13'd0,range_start};range_end<={12'd0,range_end_exclusive};index<=0;range_ok<=0;
    if(count==0 || {12'd0,range_end_exclusive}>rom_size || {1'b0,range_start}>=range_end_exclusive)state<=RANGE_REPLY;
    else state<=RANGE_READ;
   end else if(request && ready)begin
    logical_address<={13'd0,bank[0],address};index<=0;
    response_transaction<=transaction;response_epoch<=request_epoch;response_result<=0;
    if(request_epoch!=epoch || file_extent!=owned_extent || bank>1 || count==0 ||
       {13'd0,bank[0],address}>=rom_size)begin response_result<=1;data<=0;state<=REPLY;end else state<=LOOK_READ;
   end
   RANGE_READ:state<=RANGE_CHECK;
   RANGE_CHECK:if(range_cursor>=span_q[95:64] && range_cursor<span_q[63:32])begin
    if(span_q[63:32]>=range_end)begin range_ok<=1;state<=RANGE_REPLY;end
    else begin range_cursor<=span_q[63:32];index<=0;state<=RANGE_READ;end
   end else if({1'b0,index}+1'b1==count)state<=RANGE_REPLY;
   else begin index<=index+1'b1;state<=RANGE_READ;end
   RANGE_REPLY:state<=SEALED;
   LOOK_READ:state<=LOOK_CHECK;
   LOOK_CHECK:if(logical_address>=span_q[95:64] && logical_address<span_q[63:32])begin
    if(mapped>={1'b0,owned_extent})begin response_result<=1;data<=0;state<=REPLY;end
    else begin memory_address<=mapped[31:0];state<=READ_OFFER;end
   end else if({1'b0,index}+1'b1==count)begin response_result<=1;data<=0;state<=REPLY;end
   else begin index<=index+1'b1;state<=LOOK_READ;end
   READ_OFFER:if(memory_fault)begin response_result<=2;data<=0;state<=REPLY;end
    else if(memory_request && memory_ready)begin
     if(memory_valid)begin data<=memory_data;state<=REPLY;end else state<=READ_WAIT;
    end
   READ_WAIT:if(memory_fault)begin response_result<=2;data<=0;state<=REPLY;end
    else if(memory_valid)begin data<=memory_data;state<=REPLY;end
   REPLY:state<=SEALED;
   default:begin end
  endcase
 end
endmodule
