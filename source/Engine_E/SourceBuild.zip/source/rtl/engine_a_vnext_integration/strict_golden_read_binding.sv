// Frozen Strict Reader plus candidate acceptance facade; not a production graph.
module engine_a_vnext_strict_golden_read_binding (
    input logic clk,power_reset,backend_reset,download_active,session_reload,
    input logic [31:0] current_epoch,
    input logic request_valid,
    output logic request_ready,
    input vgm_reader_vnext_pkg::read_request_t request_data,
    output logic response_valid,
    input logic response_ready,
    output vgm_reader_vnext_pkg::read_response_t response_data,
    input logic backend_loaded,backend_load_error,
    input logic [31:0] backend_file_size,
    output logic golden_request,
    output logic [22:0] golden_byte_address,
    input logic golden_ready,golden_valid,golden_read,golden_write,
    input logic [28:0] golden_address,
    input logic [7:0] golden_be,golden_burst,
    output logic golden_busy,avalon_read,
    output logic [28:0] avalon_address,
    output logic [7:0] avalon_be,avalon_burst,
    input logic avalon_busy,avalon_valid,
    input logic [63:0] avalon_data,
    output logic logical_active,drain_blocked,boundary_fault,
    output logic capture,physical_accept,physical_response,cancelled,timed_out,
    output logic [31:0] ledger_transaction_id,ledger_epoch,acceptance_stalls,response_age,
    output logic [2:0] state_debug
);
    import vgm_reader_vnext_pkg::*;
    read_request_t owned;
    logic [31:0] owned_backend_size;
    logic request,ready,valid,observer_read,observer_valid,blocked,protocol_fault,reader_fault;
    logic [7:0] data;
    wire cancel_event=backend_reset || download_active || session_reload ||
                      (blocked && owned.epoch!=current_epoch) || !backend_loaded || backend_load_error ||
                      (blocked && owned_backend_size!=backend_file_size);
    // Capture the public request identity; never inspect Frozen Reader internals.
    always_ff @(posedge clk) begin
        if(power_reset)begin owned<='0;owned_backend_size<=0;end
        else if(request_valid && request_ready)begin owned<=request_data;owned_backend_size<=backend_file_size;end
    end
    assign boundary_fault=reader_fault || protocol_fault;
    vgm_reader_vnext_strict_adapter reader(
        .clk,.power_reset,.backend_reset,.download_active,.session_reload,.current_epoch,
        .request_valid,.request_ready,.request_data,.response_valid,.response_ready,.response_data,
        .backend_request(request),.backend_address(golden_byte_address),.backend_ready(ready),
        .backend_valid(valid),.backend_data(data),.backend_loaded,.backend_load_error,.backend_file_size,
        .physical_read(observer_read),.physical_busy(1'b0),.physical_valid(observer_valid),
        .logical_active,.drain_blocked,.boundary_fault(reader_fault));
    engine_a_vnext_golden_read_accept_bridge bridge(
        .clk,.power_reset,.cancel_event,.request,.byte_address(golden_byte_address),
        .transaction_id(owned.transaction_id),.epoch(owned.epoch),.ready,.valid,.data,.observer_read,.observer_valid,
        .golden_request,.golden_ready,.golden_read,.golden_write,.golden_valid,.golden_address,.golden_be,.golden_burst,
        .golden_busy,.avalon_read,.avalon_address,.avalon_be,.avalon_burst,
        .avalon_busy,.avalon_valid,.avalon_data,.capture,.physical_accept,.physical_response,.blocked,
        .cancelled,.timed_out,.protocol_fault,.ledger_transaction_id,.ledger_epoch,.acceptance_stalls,.response_age,.state_debug);
endmodule
