// Candidate-only single-beat acceptance facade. Live cancellation never resets debt.
module engine_a_vnext_golden_read_accept_bridge #(
    parameter int RESPONSE_TIMEOUT_CYCLES=1024
)(
    input logic clk,power_reset,cancel_event,
    input logic request, input logic [22:0] byte_address,
    input logic [31:0] transaction_id,epoch,
    output logic ready,valid, output logic [7:0] data,
    output logic observer_read,observer_valid,
    output logic golden_request,
    input logic golden_ready,golden_read,golden_write,golden_valid,
    input logic [28:0] golden_address,
    input logic [7:0] golden_be,golden_burst,
    output logic golden_busy,
    output logic avalon_read,
    output logic [28:0] avalon_address,
    output logic [7:0] avalon_be,avalon_burst,
    input logic avalon_busy,avalon_valid,
    input logic [63:0] avalon_data,
    output logic capture,physical_accept,physical_response,blocked,
    output logic cancelled,timed_out,protocol_fault,
    output logic [31:0] ledger_transaction_id,ledger_epoch,
    output logic [31:0] acceptance_stalls,response_age,
    output logic [2:0] state_debug
);
    typedef enum logic [2:0] {IDLE,WAIT_PULSE,WAIT_ACCEPT,WAIT_RESPONSE,QUIET} state_t;
    state_t state;
    logic [28:0] held_address;
    logic [7:0] held_be,held_burst;
    logic [2:0] lane;
    logic observer_owned,early_response,result_sent;
    logic [1:0] quiet_count;
    localparam logic [31:0] LAST=32'(RESPONSE_TIMEOUT_CYCLES-1);
    assign state_debug=state;
    assign blocked=state!=IDLE;
    // Golden retains upload/packing and read pulse generation; its early timer
    // is diagnostic only here. The facade's return boundary begins at ACCEPT.
    assign golden_busy=avalon_busy || blocked;
    assign golden_request=state==IDLE && request && golden_ready && !cancel_event && !golden_write;
    assign capture=state==WAIT_PULSE && golden_read;
    assign avalon_read=state==WAIT_ACCEPT;
    assign avalon_address=avalon_read ? held_address : golden_address;
    assign avalon_be=avalon_read ? held_be : golden_be;
    assign avalon_burst=avalon_read ? held_burst : golden_burst;
    assign physical_accept=avalon_read && !avalon_busy;
    assign physical_response=avalon_valid && (state==WAIT_RESPONSE || physical_accept);
    // Ready during IDLE is quiescence only, not a request handshake. Request
    // handshake occurs exactly at ACCEPT; observer_read is its next-cycle
    // notification. Real bus debt is independently retained by this bridge.
    assign ready=(state==IDLE && golden_ready && !request) ||
                 (physical_accept && request && !cancel_event && !cancelled);
    assign observer_valid=observer_owned && state==WAIT_RESPONSE &&
                          (early_response || avalon_valid);
    always_ff @(posedge clk) begin
        if(power_reset) begin
            state<=IDLE;held_address<=0;held_be<=0;held_burst<=0;lane<=0;
            observer_owned<=0;early_response<=0;result_sent<=0;quiet_count<=0;
            valid<=0;data<=0;observer_read<=0;cancelled<=0;timed_out<=0;
            protocol_fault<=0;ledger_transaction_id<=0;ledger_epoch<=0;
            acceptance_stalls<=0;response_age<=0;
        end else begin
            valid<=0;observer_read<=0;
            if(cancel_event && blocked)cancelled<=1;
            if(avalon_valid && !physical_response)protocol_fault<=1;
            if(golden_read && state!=WAIT_PULSE)protocol_fault<=1;
            case(state)
                IDLE: if(golden_request) begin
                    lane<=byte_address[2:0];ledger_transaction_id<=transaction_id;
                    ledger_epoch<=epoch;cancelled<=0;timed_out<=0;
                    observer_owned<=0;early_response<=0;result_sent<=0;
                    acceptance_stalls<=0;response_age<=0;state<=WAIT_PULSE;
                end
                WAIT_PULSE: if(golden_read) begin
                    held_address<=golden_address;held_be<=golden_be;
                    held_burst<=golden_burst;
                    if(golden_burst!=1 || golden_write)protocol_fault<=1;
                    state<=WAIT_ACCEPT;
                end
                WAIT_ACCEPT: begin
                    // Presented Avalon commands cannot be withdrawn under waitrequest,
                    // including after cancel. Complete acceptance, then drain.
                    if(!request)cancelled<=1;
                    if(physical_accept) begin
                        observer_owned<=ready && request;
                        observer_read<=ready && request;
                        response_age<=0;state<=WAIT_RESPONSE;
                        if(avalon_valid) begin
                            data<=avalon_data[lane*8+:8];early_response<=1;
                        end
                    end else if(acceptance_stalls!=32'hffffffff)
                        acceptance_stalls<=acceptance_stalls+1'b1;
                end
                WAIT_RESPONSE: begin
                    if(early_response || avalon_valid) begin
                        if(!early_response)data<=avalon_data[lane*8+:8];
                        if(observer_owned && !result_sent)valid<=1;
                        early_response<=0;result_sent<=1;quiet_count<=0;state<=QUIET;
                    end else if(!result_sent && response_age==LAST) begin
                        // No synthetic EOF byte. Frozen Reader's observer classifies
                        // the completion as TIMEOUT; the physical debt remains.
                        if(observer_owned)valid<=1;
                        data<=0;timed_out<=1;result_sent<=1;
                    end
                    if(response_age!=32'hffffffff)response_age<=response_age+1'b1;
                end
                QUIET: begin
                    if(!golden_read && !golden_valid && !avalon_valid && !golden_write) begin
                        if(quiet_count==1) begin state<=IDLE;observer_owned<=0;end
                        else quiet_count<=quiet_count+1'b1;
                    end else quiet_count<=0;
                end
                default: protocol_fault<=1;
            endcase
        end
    end
endmodule
