// SPDX-License-Identifier: GPL-2.0-or-later
//
// Frame-rate hold for production activity pulses/state. The observed source
// and video timing share clk_sys, so no clock-domain crossing storage is
// required. Activity is accumulated until VBlank, then remains visible for
// the next two complete video frames.

module megavgm_source_activity_hold #(
	parameter int WIDTH = 5
) (
	input  logic             clk,
	input  logic             reset,
	input  logic             vblank_start,
	input  logic [WIDTH-1:0] source_event,
	output logic [WIDTH-1:0] source_activity
);

	logic [WIDTH-1:0] frame_accumulator;
	logic [WIDTH-1:0] current_frame;
	logic [WIDTH-1:0] previous_frame;

	always_ff @(posedge clk) begin
		if(reset) begin
			frame_accumulator <= '0;
			current_frame <= '0;
			previous_frame <= '0;
		end
		else if(vblank_start) begin
			// Include an event coincident with the VBlank boundary instead of
			// dropping it while the accumulator is cleared.
			previous_frame <= current_frame;
			current_frame <= frame_accumulator | source_event;
			frame_accumulator <= '0;
		end
		else begin
			frame_accumulator <= frame_accumulator | source_event;
		end
	end

	always_comb source_activity = current_frame | previous_frame;

endmodule
