// Engine E Golden socket; reused physical backend/reader, external real T65.
module e_platform_profile #(
    parameter int RUN_MODE = 2, parameter int INIT_LIMIT=1789773, parameter int LOAD_LIMIT=400000000,
    parameter int COMMAND_SETTLE_CYCLES = 288,
    parameter bit TRANSPORT_LOOP_CONTROL = 1'b0
) (
    input wire [15:0] cpu_address, input wire [7:0] cpu_out,
    input wire cpu_read,cpu_sync, input wire [7:0] track,
    output wire [7:0] cpu_in, output wire cpu_reset,cpu_enable,cpu_rdy,irq_n,
    output wire session_restart,
    output wire native_ce, output wire [35:0] digital, output wire [63:0] cycle,
    output wire [31:0] plays, output wire resident_ready,
    output wire sound_write,dmc_get, output wire [15:0] dmc_address,
    output wire [7:0] dmc_byte,selected_bank,
    input  logic         clk,
    input  logic         reset,
    input  logic         audio_isolate_step,
    input  logic         audio_gain_boost,
    input  logic         transport_loop_policy_active,
    input  logic         transport_halt_loop,
    input  logic         transport_finish,
    output logic         playback_loop_entry_pulse,
    output logic         playback_loop_boundary_pulse,
    input  logic         ioctl_download,
    input  logic         ioctl_wr,
    input  logic [26:0]  ioctl_addr,
    input  logic [7:0]   ioctl_dout,
    input  logic [15:0]  ioctl_index,
    output logic         ioctl_wait,

    input  logic         ddram_busy,
    output logic [7:0]   ddram_burstcnt,
    output logic [28:0]  ddram_addr,
    input  logic [63:0]  ddram_dout,
    input  logic         ddram_dout_ready,
    output logic         ddram_rd,
    output logic [63:0]  ddram_din,
    output logic [7:0]   ddram_be,
    output logic         ddram_we,

    output logic signed [15:0] audio_l,
    output logic signed [15:0] audio_r,
    output logic         audio_sample_valid,
    output logic         audio_enable,
    output logic         playback_active,
    output logic         playback_done,
    output logic         profile_fatal,
    output logic [7:0]   error_code,
    output logic [2:0]   profile_state,
    output logic         load_busy,
    output logic         load_done,
    output logic         load_error,
    output logic         load_overflow,
    output logic [23:0]  uploaded_file_size,
    output logic [23:0]  accepted_byte_count,
    output logic [3:0]   wait_reason,
    output logic [7:0]   outstanding_fifo,
    output logic         scan_started,
    output logic [31:0]  vgm_sample_time,
    output logic [31:0]  natural_end_count,
    output logic [31:0]  command_deadline_miss_count,
    output logic [22:0]  debug_command_pc,
    output logic [7:0]   debug_last_command,
    output logic [5:0]   debug_parser_state,
    output logic [4:0]   debug_active_count,
    output logic [31:0]  debug_underflow_count,
    output logic [31:0]  debug_descriptor_miss_count,
    output logic [31:0]  debug_stale_response_count,
    output logic [31:0]  debug_raw_fetch_count,
    output logic [31:0]  debug_compressed_fetch_count,
    output logic         debug_first_deadline_valid,
    output logic [22:0]  debug_first_deadline_pc,
    output logic [7:0]   debug_first_deadline_command,
    output logic [5:0]   debug_first_deadline_state,
    output logic [7:0]   debug_first_deadline_flags,
    output logic [31:0]  debug_first_deadline_producer_time,
    output logic [31:0]  debug_first_deadline_playback_time,
    output logic [15:0]  debug_first_deadline_frame_clock,
    output logic [15:0]  debug_first_deadline_retired,
    output logic [7:0]   debug_first_deadline_reason,
    output logic [7:0]   ym2151_activity_event,
    output logic [23:0]  c140_activity_state,
    output logic         profile_system21
);

    // One master clock: Golden 20MHz. No generated/gated clock nets.
    logic power_reset=1'b1;
    always_ff @(posedge clk) power_reset<=1'b0;
    logic backend_load_busy,backend_load_done,backend_load_error,backend_overflow_error;
    wire initialized;
    logic download_q,stopped;
    logic [31:0] epoch=0,accepted_count;
    logic upload_invalid;
    logic [7:0] track_q; logic preload_start; logic [31:0] load_age; logic prep_timeout;
    wire selected_download=ioctl_download && ioctl_index==16'd1;
    wire track_begin=track!=track_q && backend_load_done && !selected_download;
    assign session_restart=track_begin;
    wire load_begin=selected_download && !download_q;
    wire accepted_upload=selected_download && ioctl_wr && !ioctl_wait;
    wire restart_event=(download_q && !selected_download && !stopped) || track_begin;
    wire [31:0] expected_address=load_begin ? 32'd0 : accepted_count;
    always_ff @(posedge clk) begin
        download_q<=selected_download;track_q<=track;preload_start<=restart_event;
        if(power_reset) epoch<=0;
        else if(load_begin || track_begin) epoch<=epoch+32'd1;
        if(reset) begin download_q<=0;stopped<=0;accepted_count<=0;upload_invalid<=0;track_q<=0;preload_start<=0;load_age<=0;prep_timeout<=0;end
        else begin
            if(load_begin || track_begin) begin stopped<=0;load_age<=0;prep_timeout<=0;end
            else if(!initialized && (accepted_count!=0 || selected_download) && !stopped && !prep_timeout) begin
                if(load_age==LOAD_LIMIT-1) prep_timeout<=1;else load_age<=load_age+1;
            end
            if(load_begin) begin accepted_count<=0;upload_invalid<=0;end
            if(accepted_upload) begin
                accepted_count<=expected_address+32'd1;
                if({5'd0,ioctl_addr}!=expected_address || expected_address>=32'd262272)
                    upload_invalid<=1;
            end
            // New-session admission wins over an old owner END on the same edge.
            if(transport_finish && !selected_download && !track_begin) stopped<=1;
        end
    end
    wire lifecycle=reset || selected_download || stopped;
    logic [31:0] backend_file_size;
    logic [7:0] backend_ddram_burstcnt,backend_ddram_be;
    logic [28:0] backend_ddram_addr;
    logic backend_ddram_rd,backend_ddram_we,golden_busy;
    logic [63:0] backend_ddram_din;
    logic golden_request,golden_ready,golden_valid;
    logic [22:0] golden_byte_address;
    logic [7:0] golden_data;
    logic request_valid,request_ready,response_valid,response_ready;
    vgm_reader_vnext_pkg::read_request_t request_data;
    vgm_reader_vnext_pkg::read_response_t response_data;
    logic boundary_fault,drain_blocked;
    wire file_bad=backend_file_size<=128 || backend_file_size>262272 || upload_invalid;
    wire backend_bad=backend_load_error || backend_overflow_error || file_bad || prep_timeout;
    wire [7:0] native_error;
    wire [15:0] native_audio;wire [7:0] native_activity;
    logic [31:0] accumulator;
    logic [1:0] phase;
    logic is_get;
    wire running=resident_ready && !lifecycle && !track_begin && !preload_start && native_error==0 && !boundary_fault;
    wire [32:0] sum={1'b0,accumulator}+33'd315000000;
    wire quarter=running && sum>=33'd880000000;
    assign native_ce=quarter && phase==3;
    wire phi2=phase==1 || phase==2;
    always_ff @(posedge clk) begin
        if(!running) begin accumulator<=0;phase<=0;is_get<=1;end
        else begin
            accumulator<=quarter ? 32'(sum-33'd880000000) : sum[31:0];
            if(quarter) phase<=phase+2'd1;
            if(native_ce) is_get<=!is_get;
        end
    end
    wire execution_reset;
    wire execution_enable;
    assign cpu_reset=execution_reset || lifecycle || track_begin || preload_start || boundary_fault || backend_bad;
    assign cpu_enable=execution_enable && native_ce && !cpu_reset;
    e_golden_execution #(.INIT_LIMIT(INIT_LIMIT)) plugin(
        .clk,.reset(lifecycle),.start(preload_start),
        .backend_loaded(backend_load_done && !backend_bad),.backend_error(backend_bad),
        .file_size(backend_file_size),.epoch,.track,
        .request_valid,.request_ready,.request_data,.response_valid,.response_ready,.response_data,
        .ce(native_ce),.phi2,.is_get,.cpu_address,.cpu_out,.cpu_read,.cpu_sync,
        .cpu_in,.cpu_reset(execution_reset),.cpu_enable(execution_enable),.cpu_rdy,.irq_n,
        .loaded(resident_ready),.initialized,.error(native_error),.cycle,.plays,
        .digital,.audio(native_audio),.activity(native_activity),.sound_write,.selected_bank,
        .dmc_get,.dmc_address,.dmc_byte);
    // Frozen Reader and physical debt ledger: only configuration clears debt.
    engine_a_vnext_strict_golden_read_binding reader(
        .clk,.power_reset,.backend_reset(reset),.download_active(selected_download),
        .session_reload(transport_finish || stopped),.current_epoch(epoch),
        .request_valid,.request_ready,.request_data,.response_valid,.response_ready,.response_data,
        .backend_loaded(backend_load_done),.backend_load_error(backend_bad),.backend_file_size,
        .golden_request,.golden_byte_address,.golden_ready,.golden_valid,
        .golden_read(backend_ddram_rd),.golden_write(backend_ddram_we),.golden_address(backend_ddram_addr),
        .golden_be(backend_ddram_be),.golden_burst(backend_ddram_burstcnt),.golden_busy,
        .avalon_read(ddram_rd),.avalon_address(ddram_addr),.avalon_be(ddram_be),.avalon_burst(ddram_burstcnt),
        .avalon_busy(ddram_busy),.avalon_valid(ddram_dout_ready),.avalon_data(ddram_dout),
        .logical_active(),.drain_blocked,.boundary_fault,.capture(),.physical_accept(),.physical_response(),
        .cancelled(),.timed_out(),.ledger_transaction_id(),.ledger_epoch(),.acceptance_stalls(),.response_age(),.state_debug());
    assign ddram_din=backend_ddram_din;assign ddram_we=backend_ddram_we;
    vgm_ddram_backend #(.ADDR_WIDTH(23),.FILE_INDEX(8'd1),.WRITE_FIFO_DEPTH(256),
        .DDRAM_BASE_ADDR({4'b0011,25'd0}),.SEGAPCM_ROM_BASE_ADDR(29'h06100000)) production_backend(
        .clk,.reset,.ioctl_download(selected_download),.ioctl_wr(ioctl_wr && selected_download),
        .ioctl_addr({5'd0,ioctl_addr}),.ioctl_dout,.ioctl_index(ioctl_index[7:0]),.ioctl_wait,
        .mem_rd_req(golden_request),.mem_rd_addr(golden_byte_address),.mem_rd_ready(golden_ready),
        .mem_rd_valid(golden_valid),.mem_rd_data(golden_data),
        .segapcm_copy_wr_req(1'b0),.segapcm_copy_wr_addr(19'd0),.segapcm_copy_wr_data(8'd0),.segapcm_copy_flush_req(1'b0),
        .load_busy(backend_load_busy),.load_done(backend_load_done),.load_done_pulse(),
        .load_error(backend_load_error),.overflow_error(backend_overflow_error),.file_size(backend_file_size),
        .ddram_busy(golden_busy),.ddram_burstcnt(backend_ddram_burstcnt),.ddram_addr(backend_ddram_addr),
        .ddram_dout,.ddram_dout_ready,.ddram_rd(backend_ddram_rd),.ddram_din(backend_ddram_din),
        .ddram_be(backend_ddram_be),.ddram_we(backend_ddram_we));
    assign profile_fatal=!lifecycle && (native_error!=0 || boundary_fault || backend_load_error || backend_overflow_error || prep_timeout || (backend_load_done && backend_bad));
    assign error_code=native_error!=0 ? native_error : boundary_fault ? 8'h40 : backend_bad ? 8'h31 : 8'h00;
    assign playback_active=initialized && running && !profile_fatal;
    assign playback_done=stopped;
    assign audio_enable=playback_active;
    // Preserve E2 declared unipolar mixer conversion; no accuracy compensation.
    assign audio_l=$signed({1'b0,native_audio[15:1]});assign audio_r=audio_l;
    assign audio_sample_valid=native_ce && audio_enable;
    assign load_busy=!stopped && !profile_fatal && (selected_download || track_begin || preload_start || backend_load_busy ||
        (accepted_count!=0 && !initialized));
    assign load_done=resident_ready && !profile_fatal;
    assign load_error=!lifecycle && (backend_load_error || backend_overflow_error || (backend_load_done && file_bad) || prep_timeout);
    assign load_overflow=backend_file_size>262272;
    assign uploaded_file_size=backend_file_size[23:0];assign accepted_byte_count=accepted_count[23:0];
    assign wait_reason={1'b0,drain_blocked,ddram_busy,!resident_ready};assign outstanding_fifo=0;
    assign scan_started=backend_load_done;
    // NSF has no universal end/loop metadata. Never synthesize VGM loop facts.
    assign playback_loop_entry_pulse=0;assign playback_loop_boundary_pulse=0;
    assign vgm_sample_time=plays;assign natural_end_count=0;assign command_deadline_miss_count=0;
    assign ym2151_activity_event=native_activity;assign c140_activity_state=0;assign profile_system21=0;
    assign profile_state=profile_fatal ? 3'd4 : playback_active ? 3'd2 : load_busy ? 3'd1 : 3'd0;
    assign debug_command_pc={7'd0,cpu_address};assign debug_last_command=cpu_out;
    assign debug_parser_state={5'd0,resident_ready};assign debug_active_count=0;
    assign debug_underflow_count=0;assign debug_descriptor_miss_count=0;assign debug_stale_response_count=0;
    assign debug_raw_fetch_count=0;assign debug_compressed_fetch_count=0;
    assign debug_first_deadline_valid=0;assign debug_first_deadline_pc=0;assign debug_first_deadline_command=0;
    assign debug_first_deadline_state=0;assign debug_first_deadline_flags=0;assign debug_first_deadline_producer_time=0;
    assign debug_first_deadline_playback_time=0;assign debug_first_deadline_frame_clock=0;
    assign debug_first_deadline_retired=0;assign debug_first_deadline_reason=0;
endmodule
