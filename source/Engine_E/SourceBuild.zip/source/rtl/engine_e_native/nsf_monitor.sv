// SPDX-License-Identifier: GPL-3.0-or-later
// NSF execution control. Ordinary reset/bootstrap/JSR/RTS; no register backdoor.
module e_nsf_monitor #(parameter INIT_LIMIT=1789773)(
 input wire clk,reset,ready,ce,input wire [15:0] cpu_address,
 input wire cpu_sync,input wire [7:0] selected_track,
 input wire [15:0] init_address,play_address,period_us,
 output reg [7:0] monitor_byte,output wire cpu_enable,
 output reg [7:0] error,output reg [31:0] plays,
 output reg [63:0] cycle,output reg initialized
);
 localparam INIT=0,WAIT=1,PLAY=2;
 reg [1:0] state;reg armed;
 reg [31:0] age;
 reg [44:0] phase;
 wire [44:0] threshold={29'd0,period_us}*45'd315000000;
 wire [44:0] next_phase=phase+45'd176000000;
 wire due=initialized && next_phase>=threshold;
 wire returned=armed && cpu_sync && ((state==INIT && cpu_address==16'h5059) || (state==PLAY && cpu_address==16'h505F));
 assign cpu_enable=ready && error==0 && state!=WAIT && !returned;
 always @* begin
  monitor_byte=8'hEA;
  case(cpu_address)
   16'h5000: monitor_byte=8'h78;
   16'h5001: monitor_byte=8'hD8;
   16'h5002: monitor_byte=8'hA2;
   16'h5003: monitor_byte=8'hFF;
   16'h5004: monitor_byte=8'h9A;
   16'h5005: monitor_byte=8'hA9;
   16'h5006: monitor_byte=8'h00;
   16'h5007: monitor_byte=8'h8D;
   16'h5008: monitor_byte=8'h00;
   16'h5009: monitor_byte=8'h40;
   16'h500A: monitor_byte=8'h8D;
   16'h500B: monitor_byte=8'h01;
   16'h500C: monitor_byte=8'h40;
   16'h500D: monitor_byte=8'h8D;
   16'h500E: monitor_byte=8'h02;
   16'h500F: monitor_byte=8'h40;
   16'h5010: monitor_byte=8'h8D;
   16'h5011: monitor_byte=8'h03;
   16'h5012: monitor_byte=8'h40;
   16'h5013: monitor_byte=8'h8D;
   16'h5014: monitor_byte=8'h04;
   16'h5015: monitor_byte=8'h40;
   16'h5016: monitor_byte=8'h8D;
   16'h5017: monitor_byte=8'h05;
   16'h5018: monitor_byte=8'h40;
   16'h5019: monitor_byte=8'h8D;
   16'h501A: monitor_byte=8'h06;
   16'h501B: monitor_byte=8'h40;
   16'h501C: monitor_byte=8'h8D;
   16'h501D: monitor_byte=8'h07;
   16'h501E: monitor_byte=8'h40;
   16'h501F: monitor_byte=8'h8D;
   16'h5020: monitor_byte=8'h08;
   16'h5021: monitor_byte=8'h40;
   16'h5022: monitor_byte=8'h8D;
   16'h5023: monitor_byte=8'h09;
   16'h5024: monitor_byte=8'h40;
   16'h5025: monitor_byte=8'h8D;
   16'h5026: monitor_byte=8'h0A;
   16'h5027: monitor_byte=8'h40;
   16'h5028: monitor_byte=8'h8D;
   16'h5029: monitor_byte=8'h0B;
   16'h502A: monitor_byte=8'h40;
   16'h502B: monitor_byte=8'h8D;
   16'h502C: monitor_byte=8'h0C;
   16'h502D: monitor_byte=8'h40;
   16'h502E: monitor_byte=8'h8D;
   16'h502F: monitor_byte=8'h0D;
   16'h5030: monitor_byte=8'h40;
   16'h5031: monitor_byte=8'h8D;
   16'h5032: monitor_byte=8'h0E;
   16'h5033: monitor_byte=8'h40;
   16'h5034: monitor_byte=8'h8D;
   16'h5035: monitor_byte=8'h0F;
   16'h5036: monitor_byte=8'h40;
   16'h5037: monitor_byte=8'h8D;
   16'h5038: monitor_byte=8'h10;
   16'h5039: monitor_byte=8'h40;
   16'h503A: monitor_byte=8'h8D;
   16'h503B: monitor_byte=8'h11;
   16'h503C: monitor_byte=8'h40;
   16'h503D: monitor_byte=8'h8D;
   16'h503E: monitor_byte=8'h12;
   16'h503F: monitor_byte=8'h40;
   16'h5040: monitor_byte=8'h8D;
   16'h5041: monitor_byte=8'h13;
   16'h5042: monitor_byte=8'h40;
   16'h5043: monitor_byte=8'h8D;
   16'h5044: monitor_byte=8'h15;
   16'h5045: monitor_byte=8'h40;
   16'h5046: monitor_byte=8'hA9;
   16'h5047: monitor_byte=8'h0F;
   16'h5048: monitor_byte=8'h8D;
   16'h5049: monitor_byte=8'h15;
   16'h504A: monitor_byte=8'h40;
   16'h504B: monitor_byte=8'hA9;
   16'h504C: monitor_byte=8'h40;
   16'h504D: monitor_byte=8'h8D;
   16'h504E: monitor_byte=8'h17;
   16'h504F: monitor_byte=8'h40;
   16'h5050: monitor_byte=8'hA9;
   16'h5051: monitor_byte=selected_track-8'd1;
   16'h5052: monitor_byte=8'hA2;
   16'h5053: monitor_byte=8'h00;
   16'h5054: monitor_byte=8'hA0;
   16'h5055: monitor_byte=8'h00;
   16'h5056: monitor_byte=8'h20;
   16'h5057: monitor_byte=init_address[7:0];
   16'h5058: monitor_byte=init_address[15:8];
   16'h5059: monitor_byte=8'h4C;
   16'h505A: monitor_byte=8'h5C;
   16'h505B: monitor_byte=8'h50;
   16'h505C: monitor_byte=8'h20;
   16'h505D: monitor_byte=play_address[7:0];
   16'h505E: monitor_byte=play_address[15:8];
   16'h505F: monitor_byte=8'h4C;
   16'h5060: monitor_byte=8'h5C;
   16'h5061: monitor_byte=8'h50;
   16'hFFFC: monitor_byte=8'h00;
   16'hFFFD: monitor_byte=8'h50;
   default: ;
  endcase
 end
 always @(posedge clk) begin
  if(reset || !ready) begin state<=INIT;armed<=1;error<=0;plays<=0;cycle<=0;initialized<=0;phase<=0;age<=0;end
  else if(ce && error==0) begin
   cycle<=cycle+1;
   if(initialized) phase<=due ? next_phase-threshold : next_phase;
   if(cpu_enable && cpu_address!=16'h5059 && cpu_address!=16'h505F) armed<=1;
   if(returned) begin state<=WAIT;age<=0;if(state==INIT) begin initialized<=1;phase<=0;end end
   else if(state!=WAIT) begin age<=age+1;if(age>=INIT_LIMIT-1) error<=1;end
   if(due) begin
    if(state==WAIT || returned) begin state<=PLAY;plays<=plays+1;armed<=0;age<=0;end
    else error<=2; // PLAY exceeded cadence. Never overlap or silently retime.
   end
  end
 end
endmodule
