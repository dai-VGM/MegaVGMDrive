// SPDX-License-Identifier: GPL-3.0-or-later
// E2 core-only integration; Golden upload/status/Transport attach in a later gate.
module e_nsf_execution #(parameter INIT_LIMIT=1789773)(
 input wire clk,reset,start,input wire [31:0] file_size,input wire [7:0] track,
 input wire stream_valid,stream_finish,input wire [7:0] stream_data,output wire stream_ready,
 input wire ce,phi2,is_get,
 input wire [15:0] cpu_address,input wire [7:0] cpu_out,input wire cpu_read,cpu_sync,
 output wire [7:0] cpu_in,output wire cpu_reset,cpu_enable,cpu_rdy,irq_n,
 output wire loaded,initialized,output wire [7:0] error,
 output wire [63:0] cycle,output wire [31:0] plays,
 output wire [35:0] digital,output wire [15:0] audio,output wire [7:0] activity,
 output wire sound_write,output wire [7:0] selected_bank,
 output wire dmc_get,output wire [15:0] dmc_address,output wire [7:0] dmc_byte
);
 wire clear_write,image_write,banked,vrc6,ready;
 wire [18:0] clear_address;wire [17:0] image_address;
 wire [7:0] image_data,selected_track,songs,load_error,monitor_error;
 wire [15:0] init_address,play_address,period_us;
 wire [63:0] initial_banks;wire [6:0] bank_count;
 e_nsf_loader loader(clk,reset,start,file_size,track,stream_finish,stream_valid,stream_data,stream_ready,
  clear_write,clear_address,image_write,image_address,image_data,ready,load_error,
  init_address,play_address,period_us,selected_track,songs,initial_banks,bank_count,banked,vrc6);
 reg configured;
 always @(posedge clk) if(reset || start || !ready) configured<=0;else configured<=1;
 assign loaded=ready && configured;
 wire [7:0] memory_data,monitor_byte,apu_status,dma_data;
 wire mem_fault,stall,req,ack,irq;
 wire [15:0] requested_addr,dma_addr;
 wire [15:0] bus_address=dmc_get ? dma_addr : cpu_address;
 wire bus_write=ce && cpu_enable && !cpu_read;
 wire bus_read=ce && loaded && (dmc_get || (cpu_enable && cpu_read));
 e_nsf_memory memory(clk,reset||start,ready&&!configured,initial_banks,bank_count,banked,
  clear_write,clear_address,image_write,image_address,image_data,
  bus_write,bus_read,bus_address,cpu_out,memory_data,mem_fault,selected_bank);
 assign error=load_error!=0 ? load_error : mem_fault ? 8'h40 : monitor_error!=0 ? (8'h50+monitor_error) : 8'd0;
 assign cpu_reset=reset || start || !loaded || error!=0;
 wire monitor_enable;
 e_nsf_monitor #(.INIT_LIMIT(INIT_LIMIT)) monitor(clk,reset||start||!loaded,loaded,ce,cpu_address,cpu_sync,selected_track,
  init_address,play_address,period_us,monitor_byte,monitor_enable,monitor_error,plays,cycle,initialized);
 assign cpu_enable=monitor_enable && error==0;
 assign cpu_rdy=!stall;
 wire overlay=(cpu_address>=16'h5000 && cpu_address<16'h5100) || cpu_address==16'hFFFC || cpu_address==16'hFFFD;
 assign cpu_in=overlay ? monitor_byte : cpu_address==16'h4015 && !dmc_get ? apu_status : memory_data;
 e_dmc_dma dma(clk,cpu_reset,ce,is_get,cpu_read,req,requested_addr,memory_data,stall,dmc_get,dma_addr,ack,dma_data);
 assign dmc_address=dma_addr;assign dmc_byte=memory_data;
 wire [15:0] apu_sample;wire [4:0] apu_activity;wire [22:0] apu_digital;
 APU #(.SSREG_INDEX_TOP(16),.SSREG_INDEX_DMC1(17),.SSREG_INDEX_DMC2(18),.SSREG_INDEX_FCT(19),
     .E_SESSION_RESET_DMC_SILENCE(1'b1)) apu(
 .MMC5(1'b0),.clk(clk),.PHI2(phi2),.ce(ce),.reset(cpu_reset),.cold_reset(cpu_reset),.allow_us(1'b1),.PAL(1'b0),
 .ADDR(cpu_address[4:0]),.DIN(cpu_out),.RW(cpu_read),.CS(cpu_enable && cpu_address[15:5]==11'h200 && !dmc_get),
 .audio_channels(5'b11111),.DmaData(dma_data),.get_or_put(is_get),.DmaAck(ack),.DOUT(apu_status),.Sample(apu_sample),.Activity(apu_activity),.Digital(apu_digital),
 .DmaReq(req),.DmaAddr(requested_addr),.IRQ(irq),.get_ce(),.put_ce(),.SaveStateBus_Din(64'd0),.SaveStateBus_Adr(10'd0),
 .SaveStateBus_wren(1'b0),.SaveStateBus_rst(cpu_reset),.SaveStateBus_load(1'b0),.SaveStateBus_Dout());
 wire [3:0] p1,p2;wire [4:0] saw;
 e_vrc6_audio vrc(clk,cpu_reset,ce,bus_write&&vrc6,cpu_address,cpu_out,p1,p2,saw);
 assign irq_n=!irq;
 assign sound_write=bus_write && ((cpu_address>=16'h4000 && cpu_address<=16'h4017) ||
   (vrc6 && ((cpu_address>=16'h9000 && cpu_address<=16'h9003) || (cpu_address>=16'hA000 && cpu_address<=16'hA002) || (cpu_address>=16'hB000 && cpu_address<=16'hB002))));
 assign digital={saw,p2,p1,apu_digital};
 assign activity={|saw,|p2,|p1,apu_activity};
 // E1 provisional output arithmetic retained; no cassette gain/LPF calibration.
 wire [5:0] expansion={2'b0,p1}+{2'b0,p2}+{1'b0,saw};
 assign audio={1'b0,apu_sample[15:1]}+{expansion,8'd0};
endmodule
