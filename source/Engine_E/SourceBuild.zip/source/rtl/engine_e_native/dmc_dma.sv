// SPDX-License-Identifier: GPL-3.0-or-later
// DMC-only arbiter. APU owns request scheduling; this owns halt/dummy/get.
// ce closes a CPU bus cycle. is_get identifies the currently closing cycle.
// CPU read side effects during halt/dummy are retained by the bus binding.
module e_dmc_dma(
    input wire clk, reset, ce, is_get, cpu_read, request,
    input wire [15:0] request_address,
    input wire [7:0] memory_data,
    output wire cpu_stall, memory_read,
    output wire [15:0] memory_address,
    output wire sample_ack,
    output reg [7:0] sample_data
);
    localparam [1:0] IDLE=0, DUMMY=1, GET=2, ACK=3;
    reg [1:0] state;
    reg [15:0] held_address;
    assign cpu_stall = state==DUMMY || state==GET ||
                       (state==IDLE && request && cpu_read);
    assign memory_read = state==GET && is_get;
    assign memory_address = held_address;
    // Pinned MiSTer APU latches DMA data at the following put boundary.
    assign sample_ack = state==ACK && !is_get;
    always @(posedge clk) begin
        if(reset) begin
            state<=IDLE; held_address<=0; sample_data<=0;
        end else if(ce) begin
            case(state)
                IDLE: if(request && cpu_read) begin
                    held_address<=request_address; state<=DUMMY;
                end
                DUMMY: state<=GET;
                GET: if(is_get) begin sample_data<=memory_data; state<=ACK; end
                ACK: if(!is_get) state<=IDLE;
                default: state<=IDLE;
            endcase
        end
    end
endmodule
