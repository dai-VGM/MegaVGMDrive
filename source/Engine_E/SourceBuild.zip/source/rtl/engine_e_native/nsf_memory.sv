// SPDX-License-Identifier: GPL-3.0-or-later
// Synchronous single logical CPU/DMC ROM map. No asynchronous diagnostic reads.
module e_nsf_memory(
 input wire clk,reset,configure,input wire [63:0] initial_banks,
 input wire [6:0] bank_count,input wire banked,
 input wire clear_write,input wire [18:0] clear_address,
 input wire image_write,input wire [17:0] image_address,input wire [7:0] image_data,
 input wire bus_write,bus_read,input wire [15:0] address,input wire [7:0] data,
 output wire [7:0] q,output reg fault,output wire [7:0] selected_bank
);
 (* ramstyle="M10K" *) reg [7:0] rom[0:262143];
 (* ramstyle="M10K" *) reg [7:0] ram[0:2047];
 (* ramstyle="M10K" *) reg [7:0] prg[0:8191];
 reg [7:0] banks[0:7];
 assign selected_bank=banks[address[14:12]];
 wire [17:0] rom_address={selected_bank[5:0],address[11:0]};
 reg [7:0] rq,wq,pq;reg [1:0] region;
 wire [18:0] clear_ram=clear_address-19'd262144;
 always @(posedge clk) begin
  if(clear_write && clear_address<262144) rom[clear_address[17:0]]<=0;
  else if(image_write) rom[image_address]<=image_data;
  if(clear_write && clear_address>=262144 && clear_address<264192) ram[clear_ram[10:0]]<=0;
  else if(bus_write && address<16'h2000) ram[address[10:0]]<=data;
  if(clear_write && clear_address>=264192) prg[clear_ram[12:0]-13'd2048]<=0;
  else if(bus_write && address>=16'h6000 && address<16'h8000) prg[address[12:0]]<=data;
  rq<=rom[rom_address];wq<=ram[address[10:0]];pq<=prg[address[12:0]];
  region<=address[15] ? 3 : address<16'h2000 ? 1 : address>=16'h6000 ? 2 : 0;
 end
 assign q=region==3 ? rq : region==1 ? wq : region==2 ? pq : 8'd0;
 integer i;
 always @(posedge clk) begin
  if(reset) begin fault<=0;for(i=0;i<8;i=i+1) banks[i]<=0;end
  else if(configure) begin fault<=0;for(i=0;i<8;i=i+1) banks[i]<=initial_banks[8*i+:8];end
  else begin
   if(bus_read && address[15] && selected_bank>=bank_count) fault<=1;
   if(bus_write && address>=16'h5FF8 && address<=16'h5FFF) begin
    if(!banked || data>=bank_count) fault<=1;
    else banks[address[2:0]]<=data;
   end
  end
 end
endmodule
