-- Engine E native CPU binding. No claim of cycle accuracy without bus tests.
library ieee;
use ieee.std_logic_1164.all;
use work.T65_Pack.all;

entity e_t65_cpu is
  port(clk, reset, ce, rdy, irq_n : in std_logic;
       din : in std_logic_vector(7 downto 0);
       addr : out std_logic_vector(15 downto 0);
       dout : out std_logic_vector(7 downto 0);
       read_nwrite, sync : out std_logic;
       registers : out std_logic_vector(63 downto 0));
end;
architecture rtl of e_t65_cpu is
  signal a24 : std_logic_vector(23 downto 0);
  signal rw : std_logic;
  signal raw_sync, bus_armed : std_logic := '0';
  signal data_out, data_in : std_logic_vector(7 downto 0);
begin
  addr <= a24(15 downto 0);
  dout <= data_out;
  -- Pwr_n resets CPU registers before T65 establishes WRn_i. Suppress writes
  -- until the first real opcode fetch, rather than exposing that boot transient.
  read_nwrite <= rw when bus_armed='1' else '1';
  sync <= raw_sync;
  process(clk)
  begin
    if rising_edge(clk) then
      if reset='1' then bus_armed<='0';
      elsif ce='1' and raw_sync='1' then bus_armed<='1'; end if;
    end if;
  end process;
  -- Required by the pinned T65 for undocumented RMW instructions.
  data_in <= din when rw='1' else data_out;
  cpu: entity work.T65 port map(
    Mode=>"00", BCD_en=>'0', Res_n=>not reset, Pwr_n=>not reset,
    Enable=>ce, Clk=>clk, Rdy=>rdy, Abort_n=>'1', IRQ_n=>irq_n,
    NMI_n=>'1', SO_n=>'1', R_W_n=>rw, Sync=>raw_sync,
    EF=>open, MF=>open, XF=>open, ML_n=>open, VP_n=>open,
    VDA=>open, VPA=>open, A=>a24, DI=>data_in, DO=>data_out,
    Regs=>registers, DEBUG=>open, NMI_ack=>open, Instrnew=>open,
    SaveStateBus_Din=>(others=>'0'), SaveStateBus_Adr=>(others=>'0'),
    SaveStateBus_wren=>'0', SaveStateBus_rst=>reset,
    SaveStateBus_load=>'0', SaveStateBus_Dout=>open);
end;
