// SPDX-License-Identifier: GPL-3.0-or-later
// Candidate plugin boundary, not a sys_top/MiSTer RBF. External T65/native CE.
module e_golden_execution #(parameter INIT_LIMIT=1789773)(
 input wire clk,reset,start,backend_loaded,backend_error,
 input wire [31:0] file_size,epoch,input wire [7:0] track,
 output wire request_valid,input wire request_ready,
 output vgm_reader_vnext_pkg::read_request_t request_data,
 input wire response_valid,output wire response_ready,
 input vgm_reader_vnext_pkg::read_response_t response_data,
 input wire ce,phi2,is_get,input wire [15:0] cpu_address,
 input wire [7:0] cpu_out,input wire cpu_read,cpu_sync,
 output wire [7:0] cpu_in,output wire cpu_reset,cpu_enable,cpu_rdy,irq_n,
 output wire loaded,initialized,output wire [7:0] error,
 output wire [63:0] cycle,output wire [31:0] plays,
 output wire [35:0] digital,output wire [15:0] audio,output wire [7:0] activity,
 output wire sound_write,output wire [7:0] selected_bank,
 output wire dmc_get,output wire [15:0] dmc_address,output wire [7:0] dmc_byte
);
 wire native_start,stream_valid,stream_finish,stream_ready,preload_busy;
 wire [7:0] stream_data,native_error,preload_error;wire [31:0] extent;
 wire native_reset,native_enable;
 e_golden_preload preload(clk,reset,start,backend_loaded,backend_error,file_size,epoch,
  stream_ready,loaded,native_error,native_start,stream_valid,stream_finish,stream_data,extent,
  request_valid,request_ready,request_data,response_valid,response_ready,response_data,preload_busy,preload_error);
 assign error=preload_error!=0 ? preload_error : native_error;
 assign cpu_reset=native_reset || error!=0;
 assign cpu_enable=native_enable && error==0;
 e_nsf_execution #(.INIT_LIMIT(INIT_LIMIT)) native(
 .clk(clk),.reset(reset||start),.start(native_start),.file_size(extent),.track(track),
 .stream_valid(stream_valid),.stream_finish(stream_finish),.stream_data(stream_data),.stream_ready(stream_ready),
 .ce(ce),.phi2(phi2),.is_get(is_get),.cpu_address(cpu_address),.cpu_out(cpu_out),.cpu_read(cpu_read),.cpu_sync(cpu_sync),
 .cpu_in(cpu_in),.cpu_reset(native_reset),.cpu_enable(native_enable),.cpu_rdy(cpu_rdy),.irq_n(irq_n),
 .loaded(loaded),.initialized(initialized),.error(native_error),.cycle(cycle),.plays(plays),
 .digital(digital),.audio(audio),.activity(activity),.sound_write(sound_write),.selected_bank(selected_bank),
 .dmc_get(dmc_get),.dmc_address(dmc_address),.dmc_byte(dmc_byte));
endmodule
