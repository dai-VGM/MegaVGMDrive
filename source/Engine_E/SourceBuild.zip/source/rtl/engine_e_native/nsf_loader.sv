// SPDX-License-Identifier: GPL-3.0-or-later
// Sequential original NSF stream. start -> clear -> receive -> ready/fault.
module e_nsf_loader(
 input wire clk,reset,start,
 input wire [31:0] file_size,
 input wire [7:0] track, // 1-based; zero selects header starting song
 input wire finish,input wire valid,input wire [7:0] data,output wire accept,
 output wire clear_write,output wire [18:0] clear_address,
 output wire image_write,output wire [17:0] image_address,
 output wire [7:0] image_data,
 output reg ready,output reg [7:0] error,
 output reg [15:0] init_address,play_address,period_us,
 output reg [7:0] selected_track,songs,
 output reg [63:0] initial_banks,
 output reg [6:0] bank_count,output reg banked,vrc6
);
 localparam IDLE=0,CLEAR=1,HEADER=2,CHECK=3,PAYLOAD=4,DONE=5,BAD=6;
 reg [2:0] state;
 reg [18:0] clear_pos;
 reg [31:0] size,pos;
 reg [7:0] chosen;
 reg [7:0] header[0:127];
 reg [18:0] base,extent;
 wire [15:0] load={header[9],header[8]};
 wire [15:0] init_pc={header[11],header[10]};
 wire [15:0] play_pc={header[13],header[12]};
 wire use_banks=|{header[112],header[113],header[114],header[115],header[116],header[117],header[118],header[119]};
 wire [31:0] pad=use_banks ? {20'd0,load[11:0]} : {16'd0,load}-32'h8000;
 wire [31:0] span=pad+size-128;
 wire [31:0] count=(span+4095)>>12;
 integer i;
 reg invalid_bank;
 always @* begin
  invalid_bank=0;
  for(integer j=0;j<8;j=j+1) if(header[112+j]>=count && use_banks) invalid_bank=1;
 end
 assign accept=state==HEADER || state==PAYLOAD;
 assign clear_write=state==CLEAR;
 assign clear_address=clear_pos;
 assign image_write=state==PAYLOAD && valid;
 assign image_address=18'(base+pos-128);
 assign image_data=data;
 always @(posedge clk) begin
  if(reset || start) begin
   ready<=0;error<=0;pos<=0;clear_pos<=0;size<=file_size;chosen<=track;
   state<=start ? CLEAR : IDLE;
   init_address<=0;play_address<=0;period_us<=0;selected_track<=0;songs<=0;
   initial_banks<=0;bank_count<=0;banked<=0;vrc6<=0;base<=0;extent<=0;
  end else begin
   if(finish && (state==HEADER || state==PAYLOAD) && pos!=size) begin error<=10;state<=BAD;end
   else case(state)
    CLEAR: if(clear_pos==19'd272383) begin
      if(size<=128 || size>262272) begin error<=1;state<=BAD;end
      else state<=HEADER;
    end else clear_pos<=clear_pos+19'd1;
    HEADER: if(valid) begin
      header[pos[6:0]]<=data;pos<=pos+1;
      if(pos==127) state<=CHECK;
    end
    CHECK: begin
      if({header[0],header[1],header[2],header[3],header[4]}!=40'h4E45534D1A) begin error<=2;state<=BAD;end
      else if(header[5]!=1) begin error<=3;state<=BAD;end
      else if(header[6]==0 || header[7]==0 || header[7]>header[6] || chosen>header[6]) begin error<=4;state<=BAD;end
      else if(header[122]!=0 && header[122]!=2) begin error<=5;state<=BAD;end
      else if((header[123]&8'hFE)!=0 || (|{header[124],header[125],header[126],header[127]})) begin error<=6;state<=BAD;end
      else if(load<16'h8000 || init_pc<16'h8000 || play_pc<16'h8000) begin error<=7;state<=BAD;end
      else if(span>262144 || (!use_banks && span>32768)) begin error<=8;state<=BAD;end
      else if(invalid_bank) begin error<=9;state<=BAD;end
      else begin
       base<=19'(pad);extent<=19'(span);banked<=use_banks;vrc6<=header[123][0];
       bank_count<=use_banks ? 7'(count) : 7'd8;
       init_address<=init_pc;play_address<=play_pc;
       period_us<={header[111],header[110]}==0 ? 16'd16639 : {header[111],header[110]};
       selected_track<=chosen==0 ? header[7] : chosen;songs<=header[6];
       for(i=0;i<8;i=i+1) initial_banks[i*8+:8]<=use_banks ? header[112+i] : 8'(i);
       state<=PAYLOAD;
      end
    end
    PAYLOAD: if(valid) begin
     pos<=pos+1;
     if(pos+1==size) begin ready<=1;state<=DONE;end
    end
    default: ;
   endcase
  end
 end
endmodule
