// SPDX-License-Identifier: GPL-3.0-or-later
// Independent Engine E implementation from NESdev VRC6 audio register spec.
// No cart mapper, savestate controller or platform dependencies.
module e_vrc6_audio(
    input wire clk, reset, ce, write,
    input wire [15:0] address,
    input wire [7:0] data,
    output wire [3:0] pulse1, pulse2,
    output wire [4:0] saw
);
    reg [7:0] control [0:1];
    reg [11:0] period [0:2];
    reg [11:0] divider [0:2];
    reg [2:0] enabled;
    reg [3:0] phase [0:2];
    reg [5:0] rate;
    reg [7:0] accumulator;
    reg [2:0] frequency_control;
    wire halt = frequency_control[0];
    wire [11:0] effective0 = frequency_control[2] ? {8'd0,period[0][11:8]} :
                           frequency_control[1] ? {4'd0,period[0][11:4]} : period[0];
    wire [11:0] effective1 = frequency_control[2] ? {8'd0,period[1][11:8]} :
                           frequency_control[1] ? {4'd0,period[1][11:4]} : period[1];
    wire [11:0] effective2 = frequency_control[2] ? {8'd0,period[2][11:8]} :
                           frequency_control[1] ? {4'd0,period[2][11:4]} : period[2];
    assign pulse1 = enabled[0] && (control[0][7] || phase[0] <= {1'b0,control[0][6:4]})
                    ? control[0][3:0] : 4'd0;
    assign pulse2 = enabled[1] && (control[1][7] || phase[1] <= {1'b0,control[1][6:4]})
                    ? control[1][3:0] : 4'd0;
    assign saw = enabled[2] ? accumulator[7:3] : 5'd0;
    integer i;
    always @(posedge clk) begin
        if(reset) begin
            for(i=0;i<3;i=i+1) begin period[i]<=0; divider[i]<=0; phase[i]<= i==2 ? 4'd0 : 4'd15; end
            control[0]<=0; control[1]<=0; rate<=0; enabled<=0;
            accumulator<=0; frequency_control<=0;
        end else begin
            if(ce && !halt) begin
                for(i=0;i<3;i=i+1) begin
                    if(divider[i]!=0) divider[i]<=divider[i]-12'd1;
                    else begin
                        case(i)
                            0: divider[i]<=effective0;
                            1: divider[i]<=effective1;
                            2: divider[i]<=effective2;
                        endcase
                        if(i<2) begin
                            if(enabled[i]) phase[i]<=phase[i]-4'd1;
                        end else if(enabled[2]) begin
                            if(phase[2]==13) begin phase[2]<=0; accumulator<=0; end
                            else begin
                                phase[2]<=phase[2]+4'd1;
                                if(phase[2][0]) accumulator<=accumulator+{2'd0,rate};
                            end
                        end
                    end
                end
            end
            // Disable resets phase/accumulator; it does not reset the divider.
            if(!enabled[0]) phase[0]<=15;
            if(!enabled[1]) phase[1]<=15;
            if(!enabled[2]) begin phase[2]<=0; accumulator<=0; end
            if(write) begin
                case(address)
                    16'h9000: control[0]<=data;
                    16'h9001: period[0][7:0]<=data;
                    16'h9002: begin period[0][11:8]<=data[3:0]; enabled[0]<=data[7];
                        if(!data[7]) phase[0]<=15; end
                    16'h9003: frequency_control<=data[2:0];
                    16'hA000: control[1]<=data;
                    16'hA001: period[1][7:0]<=data;
                    16'hA002: begin period[1][11:8]<=data[3:0]; enabled[1]<=data[7];
                        if(!data[7]) phase[1]<=15; end
                    16'hB000: rate<=data[5:0];
                    16'hB001: period[2][7:0]<=data;
                    16'hB002: begin period[2][11:8]<=data[3:0]; enabled[2]<=data[7];
                        if(!data[7]) begin phase[2]<=0; accumulator<=0; end end
                    default: begin end
                endcase
            end
        end
    end
endmodule
