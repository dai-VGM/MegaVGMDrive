// SPDX-License-Identifier: GPL-3.0-or-later
// Engine E candidate only. Connect after unchanged Golden fence/Strict Reader.
// One outstanding byte, no DDR transactions after native loader completion.
module e_golden_preload (
 input wire clk,reset,load_begin,backend_loaded,backend_error,
 input wire [31:0] backend_size,epoch,
 input wire native_accept,native_loaded,input wire [7:0] native_error,
 output reg native_start,stream_valid,stream_finish,
 output reg [7:0] stream_data,output reg [31:0] file_size,
 output wire request_valid,input wire request_ready,
 output vgm_reader_vnext_pkg::read_request_t request_data,
 input wire response_valid,output wire response_ready,
 input vgm_reader_vnext_pkg::read_response_t response_data,
 output wire busy,output reg [7:0] error
);
 import vgm_reader_vnext_pkg::*;
 localparam IDLE=0,FENCE=1,CLEAR=2,READ=3,WAIT=4,DELIVER=5,FINISH=6,COMPLETE=7,FAILED=8;
 reg [3:0] state;
 reg [31:0] offset,transaction,owned_epoch;
 assign request_valid=state==READ && native_accept && !load_begin && native_error==0;
 assign request_data={offset,transaction,owned_epoch,file_size};
 // Old epoch responses are drained here; physical debt belongs to Strict Reader.
 assign response_ready=1'b1;
 assign busy=state!=IDLE && state!=COMPLETE && state!=FAILED;
 always @(posedge clk) begin
  native_start<=0;stream_valid<=0;stream_finish<=0;
  if(reset) begin
   state<=IDLE;offset<=0;transaction<=0;owned_epoch<=0;file_size<=0;error<=0;stream_data<=0;
  end else if(load_begin) begin
   state<=FENCE;offset<=0;transaction<=transaction+1;owned_epoch<=epoch;error<=0;
  end else if(busy && backend_error) begin state<=FAILED;error<=8'h70;end
  else if(busy && native_error!=0) begin state<=FAILED;error<=native_error;end
  else case(state)
   FENCE: if(backend_loaded) begin file_size<=backend_size;native_start<=1;state<=CLEAR;end
   CLEAR: if(native_accept) state<=READ;
   READ: if(request_valid && request_ready) state<=WAIT;
   WAIT: if(response_valid && response_data.epoch==owned_epoch) begin
    if(response_data.transaction_id!=transaction) begin error<=8'h71;state<=FAILED;end
    else if(response_data.result!=READ_OK) begin error<=8'h72+{6'd0,response_data.result};state<=FAILED;end
    else begin stream_data<=response_data.data;state<=DELIVER;end
   end
   DELIVER: if(native_accept) begin stream_valid<=1;state<=FINISH;end
   // stream_valid is consumed on this edge; never issue before it is retired.
   FINISH: begin
    if(offset+1==file_size) begin stream_finish<=1;state<=COMPLETE;end
    else begin offset<=offset+1;transaction<=transaction+1;state<=READ;end
   end
   COMPLETE: if(native_error!=0) begin error<=native_error;state<=FAILED;end
   default: ;
  endcase
 end
endmodule
