// Engine E has no savestate engine. Retain APU's parameterized defaults.
// This is an independent constant binding, not a second savestate subsystem.
module e_apu_default #(
    parameter integer Adr = 0,
    parameter [63:0] def = 64'd0
)(input wire clk, input wire [63:0] BUS_Din, input wire [9:0] BUS_Adr,
  input wire BUS_wren, BUS_rst, output wire [63:0] BUS_Dout,
  input wire [63:0] Din, output wire [63:0] Dout);
    assign Dout = def;
    assign BUS_Dout = 64'd0;
endmodule
