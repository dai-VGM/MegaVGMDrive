module vgm_reader_vnext_strict_adapter #(
    parameter int BACKEND_ADDR_WIDTH = 23,
    parameter int READ_TIMEOUT_CYCLES = 1024,
    parameter int ISSUE_TIMEOUT_CYCLES = 1024
) (
    input logic clk, power_reset,
    input logic backend_reset, download_active, session_reload,
    input logic [31:0] current_epoch,
    input logic request_valid,
    output logic request_ready,
    input vgm_reader_vnext_pkg::read_request_t request_data,
    output logic response_valid,
    input logic response_ready,
    output vgm_reader_vnext_pkg::read_response_t response_data,
    output logic backend_request,
    output logic [BACKEND_ADDR_WIDTH-1:0] backend_address,
    input logic backend_ready, backend_valid,
    input logic [7:0] backend_data,
    input logic backend_loaded, backend_load_error,
    input logic [31:0] backend_file_size,
    input logic physical_read, physical_busy, physical_valid,
    output logic logical_active, drain_blocked, boundary_fault
);
    import vgm_reader_vnext_pkg::*;
    typedef enum logic [1:0] {IDLE, ISSUE, WAIT_RESULT} state_t;
    state_t state;
    read_request_t owned;
    logic [31:0] owned_backend_size;
    localparam int ISSUE_AGE_WIDTH = ISSUE_TIMEOUT_CYCLES <= 2 ? 1 : $clog2(ISSUE_TIMEOUT_CYCLES);
    localparam logic [ISSUE_AGE_WIDTH-1:0] ISSUE_LAST = ISSUE_AGE_WIDTH'(ISSUE_TIMEOUT_CYCLES-1);
    logic [ISSUE_AGE_WIDTH-1:0] issue_age;
    logic download_q, local_fault;
    logic observer_quiet, observer_fault, physical_seen, timeout_seen;
    logic backend_pending, physical_pending, issue_pending, cancelled;
    logic [31:0] ledger_transaction_id, ledger_epoch, wait_age_debug;
    wire download_start = download_active && !download_q;
    wire lifecycle_cancel = backend_reset || download_active || session_reload;
    wire cancel_now = lifecycle_cancel || owned.epoch != current_epoch ||
                      !backend_loaded || backend_load_error || backend_file_size != owned_backend_size;
    wire range_bad = request_data.address >= request_data.file_extent ||
                     request_data.address >= backend_file_size ||
                     (request_data.address >> BACKEND_ADDR_WIDTH) != 0;
    assign boundary_fault = observer_fault || local_fault;
    assign logical_active = state != IDLE;
    assign drain_blocked = !observer_quiet;
    assign request_ready = state == IDLE && !response_valid && observer_quiet &&
                           !lifecycle_cancel && backend_loaded && !backend_load_error &&
                           !boundary_fault && !physical_read && !physical_valid && !backend_valid;
    // Validation is performed on all 32 address bits before this projection.
    assign backend_address = owned.address[BACKEND_ADDR_WIDTH-1:0];
    assign backend_request = state == ISSUE && !cancel_now && !boundary_fault &&
                             !physical_read && !physical_valid && !backend_valid;

    vgm_reader_vnext_golden_observer #(.READ_TIMEOUT_CYCLES(READ_TIMEOUT_CYCLES)) observer (
        .clk, .power_reset, .backend_reset, .download_start, .download_active,
        .cancel_event(logical_active && cancel_now),
        .logical_issue(backend_request && backend_ready), .backend_ready, .backend_valid,
        .issue_transaction_id(owned.transaction_id), .issue_epoch(owned.epoch),
        .physical_read, .physical_busy, .physical_valid, .backend_pending, .physical_pending,
        .issue_pending, .physical_seen, .timeout_seen, .cancelled,
        .quiescent(observer_quiet), .fault_latched(observer_fault),
        .ledger_transaction_id, .ledger_epoch, .wait_age_debug
    );

    task automatic complete(input read_result_t result, input logic [7:0] data,
                            input read_request_t owner);
        response_data.transaction_id <= owner.transaction_id;
        response_data.epoch <= owner.epoch;
        response_data.result <= result;
        response_data.data <= result == READ_OK ? data : 0;
        response_valid <= 1;
        state <= IDLE;
    endtask

    always_ff @(posedge clk) begin
        if (power_reset) begin
            state <= IDLE; owned <= '0; owned_backend_size <= 0;
            issue_age <= 0; response_valid <= 0; response_data <= '0;
            download_q <= 0; local_fault <= 0;
        end else begin
            download_q <= download_active;
            if (response_valid && response_ready) response_valid <= 0;
            case (state)
                IDLE: if (request_valid && request_ready) begin
                    owned <= request_data; owned_backend_size <= backend_file_size;
                    issue_age <= 0;
                    if (request_data.epoch != current_epoch)
                        complete(READ_CANCELLED, 0, request_data);
                    else if (range_bad) complete(READ_RANGE_ERROR, 0, request_data);
                    else state <= ISSUE;
                end
                ISSUE: begin
                    if (cancel_now) complete(READ_CANCELLED, 0, owned);
                    else if (!boundary_fault) begin
                        if (backend_request && backend_ready) state <= WAIT_RESULT;
                        else if (issue_age == ISSUE_LAST) complete(READ_TIMEOUT, 0, owned);
                        else issue_age <= issue_age + 1'b1;
                    end
                end
                WAIT_RESULT: begin
                    // Lifecycle cancellation linearizes before a concurrent result.
                    if (cancel_now) complete(READ_CANCELLED, 0, owned);
                    else if (backend_valid && !boundary_fault) begin
                        if (physical_seen) complete(READ_OK, backend_data, owned);
                        else if (timeout_seen) complete(READ_TIMEOUT, 0, owned);
                        else local_fault <= 1; // Missing observation: fail closed, never guess EOF.
                    end
                end
                default: local_fault <= 1;
            endcase
        end
    end
endmodule
