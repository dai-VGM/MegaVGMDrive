module vgm_reader_vnext_golden_observer #(
    parameter int READ_TIMEOUT_CYCLES = 1024
) (
    input logic clk, power_reset,
    input logic backend_reset, download_start, download_active, cancel_event,
    input logic logical_issue, backend_ready, backend_valid,
    input logic [31:0] issue_transaction_id, issue_epoch,
    input logic physical_read, physical_busy, physical_valid,
    output logic backend_pending, physical_pending, issue_pending,
    output logic physical_seen, timeout_seen, cancelled,
    output logic quiescent, fault_latched,
    output logic [31:0] ledger_transaction_id, ledger_epoch, wait_age_debug
);
    localparam int AGE_WIDTH = READ_TIMEOUT_CYCLES <= 2 ? 1 : $clog2(READ_TIMEOUT_CYCLES);
    localparam logic [AGE_WIDTH-1:0] LAST = AGE_WIDTH'(READ_TIMEOUT_CYCLES-1);
    logic [AGE_WIDTH-1:0] age;
    logic [1:0] quiet_count;
    wire physical_accept = physical_read && !physical_busy;
    wire owned_response = physical_valid && (physical_pending || physical_accept);
    wire quiet_now = !backend_pending && !physical_pending && !issue_pending &&
                     !physical_read && !physical_valid && !backend_valid &&
                     backend_ready && !backend_reset && !download_active;
    assign wait_age_debug = 32'(age);
    assign quiescent = quiet_count == 2 && quiet_now && !fault_latched;

    // power_reset is initialization with an already quiescent physical bus.
    // Live backend reset/download/cancel MUST NOT reset this ledger.
    always_ff @(posedge clk) begin
        if (power_reset) begin
            backend_pending <= 0; physical_pending <= 0; issue_pending <= 0;
            physical_seen <= 0; timeout_seen <= 0; cancelled <= 0;
            fault_latched <= 0; age <= 0; quiet_count <= 0;
            ledger_transaction_id <= 0; ledger_epoch <= 0;
        end else begin
            if (quiet_now && !logical_issue) begin
                if (quiet_count != 2) quiet_count <= quiet_count + 1'b1;
            end else quiet_count <= 0;
            if (cancel_event) cancelled <= 1;
            if (physical_accept) begin
                if (physical_pending || (!issue_pending && !logical_issue)) fault_latched <= 1;
                physical_pending <= !physical_valid;
            end else if (physical_valid) begin
                if (!physical_pending) fault_latched <= 1;
                physical_pending <= 0;
            end
            // Golden emits a registered one-cycle RD pulse after logical issue.
            // A nonaccepted pulse under waitrequest creates no physical debt.
            if (physical_read) issue_pending <= 0;
            if (logical_issue) begin
                if (backend_pending || physical_pending || issue_pending) fault_latched <= 1;
                backend_pending <= 1; issue_pending <= 1;
                physical_seen <= 0; timeout_seen <= 0; cancelled <= 0; age <= 0;
                ledger_transaction_id <= issue_transaction_id; ledger_epoch <= issue_epoch;
            end else if (backend_pending) begin
                if (backend_reset || download_start) backend_pending <= 0;
                else if (backend_valid) backend_pending <= 0;
                else begin
                    // Match Golden's RD_WAIT priority: real response wins on LAST.
                    // After LAST, a late response drains debt but cannot certify OK.
                    if (owned_response && !timeout_seen) physical_seen <= 1;
                    else if (!physical_seen && age == LAST) timeout_seen <= 1;
                    if (age != LAST) age <= age + 1'b1;
                end
            end
        end
    end
endmodule
