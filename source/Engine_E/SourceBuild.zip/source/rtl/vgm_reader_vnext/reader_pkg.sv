package vgm_reader_vnext_pkg;
    typedef enum logic [1:0] {
        READ_OK, READ_RANGE_ERROR, READ_TIMEOUT, READ_CANCELLED
    } read_result_t;
    typedef struct packed {
        logic [31:0] address;
        logic [31:0] transaction_id;
        logic [31:0] epoch;
        logic [31:0] file_extent;
    } read_request_t;
    typedef struct packed {
        logic [31:0] transaction_id;
        logic [31:0] epoch;
        read_result_t result;
        logic [7:0] data; // Meaningful only for READ_OK; zero for faults.
    } read_response_t;
endpackage
