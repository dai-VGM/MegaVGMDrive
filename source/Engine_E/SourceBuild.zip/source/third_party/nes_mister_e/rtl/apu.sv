// Rewritten 6/4/2020 by Kitrinx
// This code is GPLv3.

module LenCounterUnit (
	input  logic       clk,
	input  logic       reset,
	input  logic       cold_reset,
	input  logic       len_clk,
	input  logic       aclk1,
	input  logic       aclk1_d,
	input  logic [7:0] load_value,
	input  logic       halt_in,
	input  logic       addr,
	input  logic       is_triangle,
	input  logic       write,
	input  logic       enabled,
	output logic       lc_on
);

	always_ff @(posedge clk) begin : lenunit
		logic [7:0] len_counter_int;
		logic halt, halt_next;
		logic [7:0] len_counter_next;
		logic lc_on_1;
		logic clear_next;

		if (aclk1_d)
			if (~enabled)
				lc_on <= 0;

		if (aclk1) begin
			lc_on_1 <= lc_on;
			len_counter_next <= halt || ~|len_counter_int ? len_counter_int : len_counter_int - 1'd1;
			clear_next <= ~halt && ~|len_counter_int;
		end

		if (write) begin
			if (~addr) begin
				halt <= halt_in;
			end else begin
				lc_on <= 1;
				len_counter_int <= load_value;
			end
		end

		// This deliberately can overwrite being loaded from writes
		if (len_clk && lc_on_1) begin
			len_counter_int <= halt ? len_counter_int : len_counter_next;
			if (clear_next)
				lc_on <= 0;
		end

		if (reset) begin
			if (~is_triangle || cold_reset) begin
				halt <= 0;
			end
			lc_on <= 0;
			len_counter_int <= 0;
			len_counter_next <= 0;
		end
	end

endmodule

module EnvelopeUnit (
	input  logic       clk,
	input  logic       reset,
	input  logic       env_clk,
	input  logic [5:0] din,
	input  logic       addr,
	input  logic       write,
	output logic [3:0] envelope
);

	logic [3:0] env_count, env_vol;
	logic env_disabled;

	assign envelope = env_disabled ? env_vol : env_count;

	always_ff @(posedge clk) begin : envunit
		logic [3:0] env_div;
		logic env_reload;
		logic env_loop;
		logic env_reset;

		if (env_clk) begin
			if (~env_reload) begin
				env_div <= env_div - 1'd1;
				if (~|env_div) begin
					env_div <= env_vol;
					if (|env_count || env_loop)
						env_count <= env_count - 1'd1;
				end
			end else begin
				env_div <= env_vol;
				env_count <= 4'hF;
				env_reload <= 1'b0;
			end
		end

		if (write) begin
			if (~addr) {env_loop, env_disabled, env_vol} <= din;
			if (addr) env_reload <= 1;
		end

		if (reset) begin
			env_loop <= 0;
			env_div <= 0;
			env_vol <= 0;
			env_count <= 0;
			env_reload <= 0;
		end
	end

endmodule

module SquareChan (
	input  logic       MMC5,
	input  logic       clk,
	input  logic       ce,
	input  logic       aclk1,
	input  logic       aclk1_d,
	input  logic       reset,
	input  logic       cold_reset,
	input  logic       allow_us,
	input  logic       sq2,
	input  logic [1:0] Addr,
	input  logic [7:0] DIN,
	input  logic       write,
	input  logic [7:0] lc_load,
	input  logic       LenCtr_Clock,
	input  logic       Env_Clock,
	input  logic       get_or_put,
	input  logic       Enabled,
	output logic [3:0] Sample,
	output logic       IsNonZero
);

	// Register 1
	logic [1:0] Duty;

	// Register 2
	logic SweepEnable, SweepNegate, SweepReset;
	logic [2:0] SweepPeriod, SweepDivider, SweepShift;

	logic [10:0] Period;
	logic [11:0] TimerCtr;
	logic [2:0] SeqPos;
	logic [10:0] ShiftedPeriod;
	logic [10:0] PeriodRhs;
	logic [11:0] NewSweepPeriod;

	logic ValidFreq;
	logic subunit_write;
	wire [3:0] Envelope;
	wire lc;
	logic DutyEnabledUsed;
	logic DutyEnabled;

	assign DutyEnabledUsed = MMC5 ^ DutyEnabled;
	assign ShiftedPeriod = (Period >> SweepShift);
	assign PeriodRhs = (SweepNegate ? (~ShiftedPeriod + {10'b0, sq2}) : ShiftedPeriod);
	assign NewSweepPeriod = Period + PeriodRhs;
	assign subunit_write = (Addr == 0 || Addr == 3) & write;
	assign IsNonZero = lc;

	assign ValidFreq = (MMC5 && allow_us) || ((|Period[10:3]) && (SweepNegate || ~NewSweepPeriod[11]));
	assign Sample = (~lc | ~ValidFreq | ~DutyEnabledUsed) ? 4'd0 : Envelope;

	LenCounterUnit LenSq (
		.clk            (clk),
		.reset          (reset),
		.cold_reset     (cold_reset),
		.aclk1          (aclk1),
		.aclk1_d        (aclk1_d),
		.len_clk        (MMC5 ? Env_Clock : LenCtr_Clock),
		.load_value     (lc_load),
		.halt_in        (DIN[5]),
		.addr           (Addr[0]),
		.is_triangle    (1'b0),
		.write          (subunit_write),
		.enabled        (Enabled),
		.lc_on          (lc)
	);

	EnvelopeUnit EnvSq (
		.clk            (clk),
		.reset          (reset),
		.env_clk        (Env_Clock),
		.din            (DIN[5:0]),
		.addr           (Addr[0]),
		.write          (subunit_write),
		.envelope       (Envelope)
	);

	always_comb begin
		// The wave forms nad barrel shifter are abstracted simply here
		case (Duty)
			0: DutyEnabled = (SeqPos == 7);
			1: DutyEnabled = (SeqPos >= 6);
			2: DutyEnabled = (SeqPos >= 4);
			3: DutyEnabled = (SeqPos < 6);
		endcase
	end

	always_ff @(posedge clk) begin : sqblock
		// Unusual to APU design, the square timers are clocked overlapping two phi2. This
		// means that writes can impact this operation as they happen, however because of the way
		// the results are presented, we can simply delay it rather than adding complexity for
		// the same results.

		if (aclk1_d) begin
			if (TimerCtr == 0) begin
				TimerCtr <= Period;
				SeqPos <= SeqPos - 1'd1;
			end else begin
				TimerCtr <= TimerCtr - 1'd1;
			end
		end

		// Sweep Unit
		if (LenCtr_Clock) begin
			if (SweepDivider == 0) begin
				SweepDivider <= SweepPeriod;
				if (SweepEnable && SweepShift != 0 && ValidFreq)
					Period <= NewSweepPeriod[10:0];
			end else begin
				SweepDivider <= SweepDivider - 1'd1;
			end
			if (SweepReset)
				SweepDivider <= SweepPeriod;
			SweepReset <= 0;
		end

		if (write) begin
			case (Addr)
				0: Duty <= DIN[7:6];
				1: if (~MMC5) begin
					{SweepEnable, SweepPeriod, SweepNegate, SweepShift} <= DIN;
					SweepReset <= 1;
				end
				2: Period[7:0] <= DIN;
				3: begin
					Period[10:8] <= DIN[2:0];
					SeqPos <= 0;
				end
			endcase
		end

		if (reset) begin
			Duty <= 0;
			SweepEnable <= 0;
			SweepNegate <= 0;
			SweepReset <= 0;
			SweepPeriod <= 0;
			SweepDivider <= 0;
			SweepShift <= 0;
			Period <= 0;
			TimerCtr <= 0;
			SeqPos <= 0;
		end
	end

endmodule

module TriangleChan (
	input  logic       clk,
	input  logic       phi1,
	input  logic       aclk1,
	input  logic       aclk1_d,
	input  logic       reset,
	input  logic       cold_reset,
	input  logic       allow_us,
	input  logic [1:0] Addr,
	input  logic [7:0] DIN,
	input  logic       write,
	input  logic [7:0] lc_load,
	input  logic       LenCtr_Clock,
	input  logic       LinCtr_Clock,
	input  logic       Enabled,
	output logic [3:0] Sample,
	output logic       IsNonZero
);
	logic [10:0] Period, applied_period, TimerCtr;
	logic [4:0] SeqPos;
	logic [6:0] LinCtrPeriod, LinCtrPeriod_1, LinCtr;
	logic LinCtrl, line_reload;
	logic LinCtrZero;
	wire lc;

	logic LenCtrZero;
	logic subunit_write;
	logic [3:0] sample_latch;

	assign LinCtrZero = ~|LinCtr;
	assign IsNonZero = lc;
	assign subunit_write = (Addr == 0 || Addr == 3) & write;

	assign Sample = (applied_period > 1 || allow_us) ? (SeqPos[3:0] ^ {4{~SeqPos[4]}}) : sample_latch;

	LenCounterUnit LenTri (
		.clk            (clk),
		.reset          (reset),
		.cold_reset     (cold_reset),
		.aclk1          (aclk1),
		.aclk1_d        (aclk1_d),
		.len_clk        (LenCtr_Clock),
		.load_value     (lc_load),
		.halt_in        (DIN[7]),
		.addr           (Addr[0]),
		.is_triangle    (1'b1),
		.write          (subunit_write),
		.enabled        (Enabled),
		.lc_on          (lc)
	);

	always_ff @(posedge clk) begin
		if (phi1) begin
			if (TimerCtr == 0) begin
				TimerCtr <= Period;
				applied_period <= Period;
				if (IsNonZero & ~LinCtrZero)
					SeqPos <= SeqPos + 1'd1;
			end else begin
				TimerCtr <= TimerCtr - 1'd1;
			end
		end

		if (aclk1) begin
			LinCtrPeriod_1 <= LinCtrPeriod;
		end

		if (LinCtr_Clock) begin
			if (line_reload)
				LinCtr <= LinCtrPeriod_1;
			else if (!LinCtrZero)
				LinCtr <= LinCtr - 1'd1;

			if (!LinCtrl)
				line_reload <= 0;
		end

		if (write) begin
			case (Addr)
				0: begin
					LinCtrl <= DIN[7];
					LinCtrPeriod <= DIN[6:0];
				end
				2: begin
					Period[7:0] <= DIN;
				end
				3: begin
					Period[10:8] <= DIN[2:0];
					line_reload <= 1;
				end
			endcase
		end

		if (cold_reset) begin
			sample_latch <= 4'hF;
			Period <= 0;
			TimerCtr <= 0;
			SeqPos <= 0;
			LinCtrPeriod <= 0;
			LinCtr <= 0;
			LinCtrl <= 0;
			line_reload <= 0;
		end

		if (applied_period > 1) sample_latch <= Sample;
	end

endmodule

module NoiseChan (
	input  logic       clk,
	input  logic       ce,
	input  logic       aclk1,
	input  logic       aclk1_d,
	input  logic       reset,
	input  logic       cold_reset,
	input  logic [1:0] Addr,
	input  logic [7:0] DIN,
	input  logic       PAL,
	input  logic       write,
	input  logic [7:0] lc_load,
	input  logic       LenCtr_Clock,
	input  logic       Env_Clock,
	input  logic       Enabled,
	output logic [3:0] Sample,
	output logic       IsNonZero
);
	logic ShortMode;
	logic [14:0] Shift;
	logic [3:0] Period;
	logic [11:0] NoisePeriod, TimerCtr;
	wire [3:0] Envelope;
	logic subunit_write;
	wire lc;

	assign IsNonZero = lc;
	assign subunit_write = (Addr == 0 || Addr == 3) & write;

	// Produce the output signal
	assign Sample = (~lc || Shift[14]) ? 4'd0 : Envelope;

	LenCounterUnit LenNoi (
		.clk            (clk),
		.reset          (reset),
		.cold_reset     (cold_reset),
		.aclk1          (aclk1),
		.aclk1_d        (aclk1_d),
		.len_clk        (LenCtr_Clock),
		.load_value     (lc_load),
		.halt_in        (DIN[5]),
		.addr           (Addr[0]),
		.is_triangle    (1'b0),
		.write          (subunit_write),
		.enabled        (Enabled),
		.lc_on          (lc)
	);

	EnvelopeUnit EnvNoi (
		.clk            (clk),
		.reset          (reset),
		.env_clk        (Env_Clock),
		.din            (DIN[5:0]),
		.addr           (Addr[0]),
		.write          (subunit_write),
		.envelope       (Envelope)
	);

	logic [10:0] noise_pal_lut[0:15];
	assign noise_pal_lut[0] = 11'h200;
assign noise_pal_lut[1] = 11'h280;
assign noise_pal_lut[2] = 11'h550;
assign noise_pal_lut[3] = 11'h5D5;
assign noise_pal_lut[4] = 11'h393;
assign noise_pal_lut[5] = 11'h74F;
assign noise_pal_lut[6] = 11'h61B;
assign noise_pal_lut[7] = 11'h41F;
assign noise_pal_lut[8] = 11'h661;
assign noise_pal_lut[9] = 11'h1C5;
assign noise_pal_lut[10] = 11'h6AE;
assign noise_pal_lut[11] = 11'h093;
assign noise_pal_lut[12] = 11'h4FE;
assign noise_pal_lut[13] = 11'h12D;
assign noise_pal_lut[14] = 11'h679;
assign noise_pal_lut[15] = 11'h392;

	// Values read directly from the netlist
	logic [10:0] noise_ntsc_lut[0:15];
	assign noise_ntsc_lut[0] = 11'h200;
assign noise_ntsc_lut[1] = 11'h280;
assign noise_ntsc_lut[2] = 11'h2A8;
assign noise_ntsc_lut[3] = 11'h6EA;
assign noise_ntsc_lut[4] = 11'h4E4;
assign noise_ntsc_lut[5] = 11'h674;
assign noise_ntsc_lut[6] = 11'h630;
assign noise_ntsc_lut[7] = 11'h730;
assign noise_ntsc_lut[8] = 11'h4AC;
assign noise_ntsc_lut[9] = 11'h304;
assign noise_ntsc_lut[10] = 11'h722;
assign noise_ntsc_lut[11] = 11'h230;
assign noise_ntsc_lut[12] = 11'h213;
assign noise_ntsc_lut[13] = 11'h782;
assign noise_ntsc_lut[14] = 11'h006;
assign noise_ntsc_lut[15] = 11'h014;

	logic [10:0] noise_timer;
	logic noise_clock;
	always_ff @(posedge clk) begin
		if (aclk1_d) begin
			noise_timer <= {noise_timer[9:0], (noise_timer[10] ^ noise_timer[8]) | ~|noise_timer};

			if (noise_clock) begin
				noise_clock <= 0;
				noise_timer <= PAL ? noise_pal_lut[Period] : noise_ntsc_lut[Period];
				Shift <= {Shift[13:0], ((Shift[14] ^ (ShortMode ? Shift[8] : Shift[13])) | ~|Shift)};
			end
		end

		if (aclk1) begin
			if (noise_timer == 'h400)
				noise_clock <= 1;
		end

		if (write && Addr == 2) begin
			ShortMode <= DIN[7];
			Period <= DIN[3:0];
		end

		if (reset) begin
			if (|noise_timer) noise_timer <= (PAL ? noise_pal_lut[0] : noise_ntsc_lut[0]);
			ShortMode <= 0;
			Shift <= 0;
			Period <= 0;
		end

		if (cold_reset)
			noise_timer <= 0;
	end
endmodule

module DmcChan #(parameter [9:0] SSREG_INDEX_DMC1, parameter [9:0] SSREG_INDEX_DMC2,
    parameter E_SESSION_RESET_DMC_SILENCE = 1'b0)  (
	input  logic        MMC5,
	input  logic        clk,
	input  logic        aclk1,
	input  logic        aclk1_d,
	input  logic        reset,
	input  logic        cold_reset,
	input  logic  [2:0] ain,
	input  logic  [7:0] DIN,
	input  logic        write,
	input  logic        dma_ack,      // 1 when DMC byte is on DmcData. DmcDmaRequested should go low.
	input  logic  [7:0] dma_data,     // Input data to DMC from memory.
	input  logic        PAL,
	output logic [15:0] dma_address,     // Address DMC wants to read
	output logic        irq,
	output logic  [6:0] Sample,
	output logic        dma_req,      // 1 when DMC wants DMA
	output logic        enable,
	// savestates
	input       [63:0]  SaveStateBus_Din,
	input       [ 9:0]  SaveStateBus_Adr,
	input               SaveStateBus_wren,
	input               SaveStateBus_rst,
	input               SaveStateBus_load,
	output      [63:0]  SaveStateBus_Dout
);
	// Savestates
	localparam SAVESTATE_MODULES    = 2;
	wire [63:0] SaveStateBus_wired_or[0:SAVESTATE_MODULES-1];
	assign SaveStateBus_Dout = SaveStateBus_wired_or[0] | SaveStateBus_wired_or[1];

	wire [63:0] SS_DMC1;
	wire [63:0] SS_DMC1_BACK;
	wire [63:0] SS_DMC2;
	wire [63:0] SS_DMC2_BACK;
	e_apu_default #(SSREG_INDEX_DMC1, 64'h0000000000000000) iREG_SAVESTATE_APU_DMC1 (clk, SaveStateBus_Din, SaveStateBus_Adr, SaveStateBus_wren, SaveStateBus_rst, SaveStateBus_wired_or[0], SS_DMC1_BACK, SS_DMC1);
	e_apu_default #(SSREG_INDEX_DMC2, 64'h0000000000000000) iREG_SAVESTATE_APU_DMC2 (clk, SaveStateBus_Din, SaveStateBus_Adr, SaveStateBus_wren, SaveStateBus_rst, SaveStateBus_wired_or[1], SS_DMC2_BACK, SS_DMC2);

	logic irq_enable;
	logic loop;                 // Looping enabled
	logic [3:0] frequency;           // Current value of frequency register
	logic [7:0] sample_address;  // Base address of sample
	logic [7:0] sample_length;      // Length of sample
	logic [11:0] bytes_remaining;      // 12 bits bytes left counter 0 - 4081.
	logic [7:0] sample_buffer;    // Next value to be loaded into shift reg

	logic [8:0] dmc_lsfr;
	logic [7:0] dmc_volume, dmc_volume_next;
	logic dmc_silence;
	logic have_buffer;
	logic [7:0] sample_shift;
	logic [2:0] dmc_bits; // Simply an 8 cycle counter.
	logic enable_1, enable_2, enable_3;

	logic [8:0] pal_pitch_lut[0:15];
	assign pal_pitch_lut[0] = 9'h1D7;
assign pal_pitch_lut[1] = 9'h067;
assign pal_pitch_lut[2] = 9'h0D9;
assign pal_pitch_lut[3] = 9'h143;
assign pal_pitch_lut[4] = 9'h1E1;
assign pal_pitch_lut[5] = 9'h07B;
assign pal_pitch_lut[6] = 9'h05C;
assign pal_pitch_lut[7] = 9'h132;
assign pal_pitch_lut[8] = 9'h04A;
assign pal_pitch_lut[9] = 9'h1A3;
assign pal_pitch_lut[10] = 9'h1CF;
assign pal_pitch_lut[11] = 9'h1CD;
assign pal_pitch_lut[12] = 9'h02A;
assign pal_pitch_lut[13] = 9'h11C;
assign pal_pitch_lut[14] = 9'h11B;
assign pal_pitch_lut[15] = 9'h157;

	logic [8:0] ntsc_pitch_lut[0:15];
	assign ntsc_pitch_lut[0] = 9'h19D;
assign ntsc_pitch_lut[1] = 9'h0A2;
assign ntsc_pitch_lut[2] = 9'h185;
assign ntsc_pitch_lut[3] = 9'h1B6;
assign ntsc_pitch_lut[4] = 9'h0EF;
assign ntsc_pitch_lut[5] = 9'h1F8;
assign ntsc_pitch_lut[6] = 9'h17C;
assign ntsc_pitch_lut[7] = 9'h117;
assign ntsc_pitch_lut[8] = 9'h120;
assign ntsc_pitch_lut[9] = 9'h076;
assign ntsc_pitch_lut[10] = 9'h11E;
assign ntsc_pitch_lut[11] = 9'h13E;
assign ntsc_pitch_lut[12] = 9'h162;
assign ntsc_pitch_lut[13] = 9'h123;
assign ntsc_pitch_lut[14] = 9'h0E3;
assign ntsc_pitch_lut[15] = 9'h0D5;

	logic dmc_clock;
	assign Sample = dmc_volume_next[6:0];
	// Engine E: expose the load/reload request at its native closing edge,
    // not one CPU cycle after enable_3/have_buffer NBA updates.
    assign dma_req = (~have_buffer & (enable_3 | (aclk1 & enable_2))) |
                     (aclk1_d & dmc_clock & (&dmc_bits) & enable_3);

	assign dma_address[15] = 1;

	logic reload_next;
	always_ff @(posedge clk) begin
		if (write) begin
			case (ain)
				0: begin  // $4010
						irq_enable <= DIN[7];
						loop <= DIN[6];
						frequency <= DIN[3:0];
						if (~DIN[7]) irq <= 0;
					end
				1: begin  // $4011 Applies immediately, can be overwritten before aclk1
						dmc_volume <= {MMC5 & DIN[7], DIN[6:0]};
					end
				2: begin  // $4012
						sample_address <= MMC5 ? 8'h00 : DIN[7:0];
					end
				3: begin  // $4013
						sample_length <= MMC5 ? 8'h00 : DIN[7:0];
					end
				5: begin // $4015
						irq <= 0;
						enable <= DIN[4];

						if (DIN[4] && ~enable) begin
							dma_address[14:0] <= {1'b1, sample_address[7:0], 6'h00};
							bytes_remaining <= {sample_length, 4'h0};
						end
					end
			endcase
		end

		if (aclk1_d) begin // Put cycle
			enable_1 <= enable;
			enable_2 <= enable_1;
			dmc_lsfr <= {dmc_lsfr[7:0], (dmc_lsfr[8] ^ dmc_lsfr[4]) | ~|dmc_lsfr};

			if (dmc_clock) begin
				dmc_clock <= 0;
				dmc_lsfr <= PAL ? pal_pitch_lut[frequency] : ntsc_pitch_lut[frequency];
				sample_shift <= {1'b0, sample_shift[7:1]};
				dmc_bits <= dmc_bits + 1'd1;

				if (&dmc_bits) begin
					dmc_silence <= ~have_buffer;
					sample_shift <= sample_buffer;
					have_buffer <= 0;
				end

				if (~dmc_silence) begin
					if (~sample_shift[0]) begin
						if (|dmc_volume_next[6:1])
							dmc_volume[6:1] <= dmc_volume_next[6:1] - 1'd1;
					end else begin
						if(~&dmc_volume_next[6:1])
							dmc_volume[6:1] <= dmc_volume_next[6:1] + 1'd1;
					end
				end
			end

			// The data is technically clocked at phi2, but because of our implementation, to
			// ensure the right data is latched, we do it on the falling edge of phi2.
			if (dma_ack) begin
				dma_address[14:0] <= dma_address[14:0] + 1'd1;
				have_buffer <= 1;
				sample_buffer <= dma_data;

				if (|bytes_remaining)
					bytes_remaining <= bytes_remaining - 1'd1;
				else begin
					dma_address[14:0] <= {1'b1, sample_address[7:0], 6'h0};
					bytes_remaining <= {sample_length, 4'h0};
					enable <= loop;
					if (~loop & irq_enable)
						irq <= 1;
				end
			end
		end

		// Volume adjustment is done on aclk1. Technically, the value written to 4011 is immediately
		// applied, but won't "stick" if it conflicts with a lsfr clocked do-adjust.
		if (aclk1) begin // Get cycle
            // Engine E: sample enable_1 only on put. Sampling on get after
            // phi2 incorrectly advances get-phase $4015 loads by one APU cycle.
			enable_3 <= enable_2;

			dmc_volume_next <= dmc_volume;

			if (dmc_lsfr == 9'h100) begin
				dmc_clock <= 1;
			end
		end

		if (reset) begin
            // E-only session policy; default-off preserves upstream reset/cold reset.
            // Restore the binding's initial flag, not a claimed NES power-on value.
            if (E_SESSION_RESET_DMC_SILENCE) dmc_silence <= SS_DMC2[47];
			irq                     <= SS_DMC1[    0]; // 0;
			dmc_volume              <= SS_DMC1[ 8: 1]; // {7'h0, dmc_volume[0]};
			dmc_volume_next         <= SS_DMC1[16: 9]; // {7'h0, dmc_volume[0]};
			sample_shift            <= SS_DMC1[24:17]; // 8'h0;
			bytes_remaining         <= SS_DMC1[36:25]; // 0;
			dmc_bits                <= SS_DMC1[39:37]; // 0;
			sample_buffer           <= SS_DMC1[47:40]; // 0;
			have_buffer             <= SS_DMC1[   48]; // 0;
			enable                  <= SS_DMC1[   49]; // 0;
			enable_1                <= SS_DMC1[   50]; // 0;
			enable_2                <= SS_DMC1[   51]; // 0;
			enable_3                <= SS_DMC1[   52]; // 0;
			dma_address[14:0]       <= SS_DMC2[14: 0]; // 15'h0000;
			if (SaveStateBus_load) begin
				dmc_lsfr       <= SS_DMC2[23:15]; // reset value handled seperate below
				loop           <= SS_DMC2[   24];
				frequency      <= SS_DMC2[28:25];
				irq_enable     <= SS_DMC2[   29];
				sample_address <= SS_DMC2[37:30];
				sample_length  <= SS_DMC2[45:38];
				dmc_clock      <= SS_DMC2[   46];
				dmc_silence    <= SS_DMC2[   47];
			end else begin
				if (|dmc_lsfr) dmc_lsfr <= (PAL ? pal_pitch_lut[0] : ntsc_pitch_lut[0]);
			end
		end

		if (cold_reset) begin
            // Engine E: discard a pending get-to-put clock on new-track cold reset.
            // Otherwise reload immediately after get leaks one old DMC tick.
            dmc_clock <= 0;
			dmc_lsfr <= 0;
			loop <= 0;
			frequency <= 0;
			irq_enable <= 0;
			dmc_volume <= 0;
			dmc_volume_next <= 0;
			sample_address <= 0;
			sample_length <= 0;
		end

	end

	assign SS_DMC1_BACK[    0] = irq;
	assign SS_DMC1_BACK[ 8: 1] = dmc_volume;
	assign SS_DMC1_BACK[16: 9] = dmc_volume_next;
	assign SS_DMC1_BACK[24:17] = sample_shift;
	assign SS_DMC1_BACK[36:25] = bytes_remaining;
	assign SS_DMC1_BACK[39:37] = dmc_bits;
	assign SS_DMC1_BACK[47:40] = sample_buffer;
	assign SS_DMC1_BACK[   48] = have_buffer;
	assign SS_DMC1_BACK[   49] = enable;
	assign SS_DMC1_BACK[   50] = enable_1;
	assign SS_DMC1_BACK[   51] = enable_2;
	assign SS_DMC1_BACK[   52] = enable_3;
	assign SS_DMC1_BACK[63:53] = 11'b0; // free to be used

	assign SS_DMC2_BACK[14: 0] = dma_address[14:0];
	assign SS_DMC2_BACK[23:15] = dmc_lsfr;
	assign SS_DMC2_BACK[   24] = loop;
	assign SS_DMC2_BACK[28:25] = frequency;
	assign SS_DMC2_BACK[   29] = irq_enable;
	assign SS_DMC2_BACK[37:30] = sample_address;
	assign SS_DMC2_BACK[45:38] = sample_length;
	assign SS_DMC2_BACK[   46] = dmc_clock;
	assign SS_DMC2_BACK[   47] = dmc_silence;
	assign SS_DMC2_BACK[63:48] = 16'b0; // free to be used

endmodule

module FrameCtr #(parameter [9:0] SSREG_INDEX_FCT) (
	input  logic clk,
	input  logic aclk1,
	input  logic aclk2,
	input  logic reset,
	input  logic cold_reset,
	input  logic write,
	input  logic read,
	input  logic write_ce,
	input  logic [7:0] din,
	input  logic [1:0] addr,
	input  logic PAL,
	input  logic MMC5,
	output logic irq,
	output logic irq_flag,
	output logic frame_half,
	output logic frame_quarter,
	// savestates
	input       [63:0]  SaveStateBus_Din,
	input       [ 9:0]  SaveStateBus_Adr,
	input               SaveStateBus_wren,
	input               SaveStateBus_rst,
	input               SaveStateBus_load,
	output      [63:0]  SaveStateBus_Dout
);

	// Savestates
	wire [63:0] SS_FCT;
	wire [63:0] SS_FCT_BACK;
	e_apu_default #(SSREG_INDEX_FCT, 64'h0000000000007FFF) iREG_SAVESTATE_APU_FCT (clk, SaveStateBus_Din, SaveStateBus_Adr, SaveStateBus_wren, SaveStateBus_rst, SaveStateBus_Dout, SS_FCT_BACK, SS_FCT);

	// NTSC -- Confirmed
	// Binary Frame Value         Decimal  Cycle
	// 15'b001_0000_0110_0001,    04193    03713 -- Quarter
	// 15'b011_0110_0000_0011,    13827    07441 -- Half
	// 15'b010_1100_1101_0011,    11475    11170 -- 3 quarter
	// 15'b000_1010_0001_1111,    02591    14899 -- Reset w/o Seq/Interrupt
	// 15'b111_0001_1000_0101     29061    18625 -- Reset w/ seq

	// PAL -- Speculative
	// Binary Frame Value         Decimal  Cycle
	// 15'b001_1111_1010_0100     08100    04156
	// 15'b100_0100_0011_0000     17456    08313
	// 15'b101_1000_0001_0101     22549    12469
	// 15'b000_1011_1110_1000     03048    16625
	// 15'b000_0100_1111_1010     01274    20782

	logic frame_reset;
	logic frame_interrupt_buffer;
	logic frame_int_disabled;
	logic FrameInterrupt;
	logic frame_irq, set_irq;
	logic FrameSeqMode_2;
	logic frame_reset_2;
	logic w4017_1, w4017_2;
	logic [14:0] frame;

	// Register 4017
	logic DisableFrameInterrupt;
	logic FrameSeqMode;

	assign frame_int_disabled = DisableFrameInterrupt | (write && addr == 5'h17 && din[6]);
	assign irq = FrameInterrupt && ~DisableFrameInterrupt;
	assign irq_flag = frame_interrupt_buffer;

	// This is implemented from the original LSFR frame counter logic taken from the 2A03 netlists. The
	// PAL LFSR numbers are educated guesses based on existing observed cycle numbers, but they may not
	// be perfectly correct.

	logic seq_mode;
	assign seq_mode = aclk1 ? FrameSeqMode : FrameSeqMode_2;

	logic frm_a, frm_b, frm_c, frm_d, frm_e;
	assign frm_a = (PAL ? 15'b001_1111_1010_0100 : 15'b001_0000_0110_0001) == frame;
	assign frm_b = (PAL ? 15'b100_0100_0011_0000 : 15'b011_0110_0000_0011) == frame;
	assign frm_c = (PAL ? 15'b101_1000_0001_0101 : 15'b010_1100_1101_0011) == frame;
	assign frm_d = (PAL ? 15'b000_1011_1110_1000 : 15'b000_1010_0001_1111) == frame && ~seq_mode;
	assign frm_e = (PAL ? 15'b000_0100_1111_1010 : 15'b111_0001_1000_0101) == frame;

	assign set_irq = frm_d & ~FrameSeqMode;
	assign frame_reset = frm_d | frm_e | w4017_2;
	assign frame_half = (frm_b | frm_d | frm_e | (w4017_2 & seq_mode));
	assign frame_quarter = (frm_a | frm_b | frm_c | frm_d | frm_e | (w4017_2 & seq_mode));

	logic frame_interrupt_clear_pending;

	always_ff @(posedge clk) begin : apu_block
		// The priority of all these statements is important in which takes precident
		if (addr == 2'h1 && read)
			FrameInterrupt <= 0;

		if (set_irq) begin
			FrameInterrupt <= 1;
			frame_interrupt_buffer <= 1;
		end

		if (aclk1) begin // Get cycle
			frame <= frame_reset_2 ? 15'h7FFF : {frame[13:0], ((frame[14] ^ frame[13]) | ~|frame)};
			w4017_2 <= w4017_1;
			w4017_1 <= 0;
			FrameSeqMode_2 <= FrameSeqMode;
			frame_reset_2 <= 0;
			if (~FrameInterrupt) frame_interrupt_buffer <= 0;
		end

		if (aclk2 & frame_reset)
			frame_reset_2 <= 1;

		if (frame_int_disabled) begin
			FrameInterrupt <= 0;
		end

		if (write_ce && addr == 3 && ~MMC5) begin  // Register $4017
			FrameSeqMode <= din[7];
			DisableFrameInterrupt <= din[6];
			w4017_1 <= 1;
		end

		if (reset) begin
			frame                  <= SS_FCT[14:0]; // 15'h7FFF;
			FrameInterrupt         <= SS_FCT[  15]; // 0;
			frame_interrupt_buffer <= SS_FCT[  16]; // 0;
			w4017_1                <= SS_FCT[  17]; // 0;
			w4017_2                <= SS_FCT[  18]; // 0;
			DisableFrameInterrupt  <= SS_FCT[  19]; // 0;
			if (SaveStateBus_load) begin
				FrameSeqMode <= SS_FCT[20];
			end
			FrameSeqMode_2         <= SS_FCT[  21]; // 0;
			frame_reset_2          <= SS_FCT[  22]; // 0;

			if (cold_reset) begin
				FrameSeqMode <= 0; // Don't reset this on warm reset
			end
		end
	end

	assign SS_FCT_BACK[14: 0] = frame;
	assign SS_FCT_BACK[   15] = FrameInterrupt;
	assign SS_FCT_BACK[   16] = frame_interrupt_buffer;
	assign SS_FCT_BACK[   17] = w4017_1;
	assign SS_FCT_BACK[   18] = w4017_2;
	assign SS_FCT_BACK[   19] = DisableFrameInterrupt;
	assign SS_FCT_BACK[   20] = FrameSeqMode;
	assign SS_FCT_BACK[   21] = FrameSeqMode_2;
	assign SS_FCT_BACK[   22] = frame_reset_2;
	assign SS_FCT_BACK[63:23] = 41'b0; // free to be used

endmodule

module APU #(parameter [9:0] SSREG_INDEX_TOP, parameter [9:0] SSREG_INDEX_DMC1, parameter [9:0] SSREG_INDEX_DMC2, parameter [9:0] SSREG_INDEX_FCT,
    parameter E_SESSION_RESET_DMC_SILENCE = 1'b0)
(
	input  logic        MMC5,
	input  logic        clk,
	input  logic        PHI2,
	input  logic        ce,
	input  logic        reset,
	input  logic        cold_reset,
	input  logic        allow_us,       // Set to 1 to allow ultrasonic frequencies
	input  logic        PAL,
	input  logic  [4:0] ADDR,           // APU Address Line
	input  logic  [7:0] DIN,            // Data to APU
	input  logic        RW,
	input  logic        CS,
	input  logic  [4:0] audio_channels, // Enabled audio channels
	input  logic  [7:0] DmaData,        // Input data to DMC from memory.
	input  logic        get_or_put,
	input  logic        DmaAck,         // 1 when DMC byte is on DmcData. DmcDmaRequested should go low.
	output logic  [7:0] DOUT,           // Data from APU
	output wire [15:0] Sample,
    output wire [4:0] Activity,
    output wire [22:0] Digital,
	output wire        DmaReq,         // 1 when DMC wants DMA
	output wire [15:0] DmaAddr,        // Address DMC wants to read
	output logic        IRQ,            // IRQ asserted high == asserted
	output logic        get_ce,         // Clock enable for a get cycle
	output logic        put_ce,         // Clock enable for a put cycle
	// savestates
	input       [63:0]  SaveStateBus_Din,
	input       [ 9:0]  SaveStateBus_Adr,
	input               SaveStateBus_wren,
	input               SaveStateBus_rst,
	input               SaveStateBus_load,
	output      [63:0]  SaveStateBus_Dout
);


	// Savestates
	localparam SAVESTATE_MODULES    = 3;
	wire [63:0] SaveStateBus_wired_or[0:SAVESTATE_MODULES-1];
	assign SaveStateBus_Dout = SaveStateBus_wired_or[0] | SaveStateBus_wired_or[1] | SaveStateBus_wired_or[2];

	wire [63:0] SS_APU;
	wire [63:0] SS_APU_BACK;
	e_apu_default #(SSREG_INDEX_TOP, 64'h0000000000000000) iREG_SAVESTATE_APU_TOP (clk, SaveStateBus_Din, SaveStateBus_Adr, SaveStateBus_wren, SaveStateBus_rst, SaveStateBus_wired_or[0], SS_APU_BACK, SS_APU);


	logic [7:0] len_counter_lut[0:31];
	assign len_counter_lut[0] = 8'h09;
assign len_counter_lut[1] = 8'hFD;
assign len_counter_lut[2] = 8'h13;
assign len_counter_lut[3] = 8'h01;
assign len_counter_lut[4] = 8'h27;
assign len_counter_lut[5] = 8'h03;
assign len_counter_lut[6] = 8'h4F;
assign len_counter_lut[7] = 8'h05;
assign len_counter_lut[8] = 8'h9F;
assign len_counter_lut[9] = 8'h07;
assign len_counter_lut[10] = 8'h3B;
assign len_counter_lut[11] = 8'h09;
assign len_counter_lut[12] = 8'h0D;
assign len_counter_lut[13] = 8'h0B;
assign len_counter_lut[14] = 8'h19;
assign len_counter_lut[15] = 8'h0D;
assign len_counter_lut[16] = 8'h0B;
assign len_counter_lut[17] = 8'h0F;
assign len_counter_lut[18] = 8'h17;
assign len_counter_lut[19] = 8'h11;
assign len_counter_lut[20] = 8'h2F;
assign len_counter_lut[21] = 8'h13;
assign len_counter_lut[22] = 8'h5F;
assign len_counter_lut[23] = 8'h15;
assign len_counter_lut[24] = 8'hBF;
assign len_counter_lut[25] = 8'h17;
assign len_counter_lut[26] = 8'h47;
assign len_counter_lut[27] = 8'h19;
assign len_counter_lut[28] = 8'h0F;
assign len_counter_lut[29] = 8'h1B;
assign len_counter_lut[30] = 8'h1F;
assign len_counter_lut[31] = 8'h1D;

	logic [7:0] lc_load;
	assign lc_load = len_counter_lut[DIN[7:3]];

	// APU reads and writes happen at Phi2 of the 6502 core. Note: Not M2.
	logic read, read_old;
	logic write, write_ce, write_old;
	logic phi2_old, phi2_ce;

	assign read = RW & CS;
	assign write = ~RW & CS;
	assign phi2_ce = PHI2 & ~phi2_old;
	assign write_ce = write & phi2_ce;

	// The APU has four primary clocking events that take place:
	// aclk1    -- Aligned with CPU phi1, but every other cpu tick. This drives the majority of the APU
	// aclk1_d  -- Aclk1, except delayed by 1 cpu cycle exactly. Drives he half/quarter signals and len counter
	// aclk2    -- Aligned with CPU phi2, also every other frame
	// write    -- Happens on CPU phi2 (Not M2!). Most of these are latched by one of the above clocks.
	logic aclk1, aclk2, aclk1_delayed, phi1;
	assign aclk1 = ce & get_or_put;          // Defined as the cpu tick when the frame counter increases
	assign aclk2 = phi2_ce & ~get_or_put;    // Tick on odd cycles, not 50% duty cycle so it covers 2 cpu cycles
	assign aclk1_delayed = ce & ~get_or_put; // Ticks 1 cpu cycle after frame counter
	assign phi1 = ce;

	assign get_ce = aclk1;
	assign put_ce = aclk1_delayed;

	logic [4:0] Enabled;
	wire [3:0] Sq1Sample,Sq2Sample,TriSample,NoiSample;
	wire [6:0] DmcSample;
    assign Digital={DmcSample,NoiSample,TriSample,Sq2Sample,Sq1Sample};
    assign Activity={|DmcSample,|NoiSample,|TriSample,|Sq2Sample,|Sq1Sample};
	wire DmcIrq;
	wire IsDmcActive;

	wire irq_flag;
	wire frame_irq;

	// Generate internal memory write signals
	logic ApuMW0, ApuMW1, ApuMW2, ApuMW3, ApuMW4, ApuMW5;
	assign ApuMW0 = ADDR[4:2]==0; // SQ1
	assign ApuMW1 = ADDR[4:2]==1; // SQ2
	assign ApuMW2 = ADDR[4:2]==2; // TRI
	assign ApuMW3 = ADDR[4:2]==3; // NOI
	assign ApuMW4 = ADDR[4:2]==4 || ADDR[4:0]==5'b10101; // DMC
	assign ApuMW5 = ADDR[4:2]==5; // Control registers

	wire Sq1NonZero, Sq2NonZero, TriNonZero, NoiNonZero;
	logic ClkE, ClkL;

	logic [4:0] enabled_buffer, enabled_buffer_1;
	assign Enabled = aclk1 ? enabled_buffer : enabled_buffer_1;

	assign SS_APU_BACK[ 4: 0]    = enabled_buffer;
	assign SS_APU_BACK[ 9: 5]    = enabled_buffer_1;
	assign SS_APU_BACK[   10]    = phi2_old;
	assign SS_APU_BACK[63:11]     = 53'b0; // free to be used

	always_ff @(posedge clk) begin
		phi2_old <= PHI2;

		if (aclk1) begin
			enabled_buffer_1 <= enabled_buffer;
		end

		if (ApuMW5 && write && ADDR[1:0] == 1) begin
			enabled_buffer <= DIN[4:0]; // Register $4015
		end

		if (reset) begin
			enabled_buffer   <= SS_APU[ 4: 0]; // 0;
			enabled_buffer_1 <= SS_APU[ 9: 5]; // 0;
			phi2_old         <= SS_APU[   10]; // 0;
		end
	end

	wire frame_quarter, frame_half;
	assign ClkE = (frame_quarter & aclk1_delayed);
	assign ClkL = (frame_half & aclk1_delayed);

	// Generate bus output
	assign DOUT = {DmcIrq, irq_flag, 1'b0, IsDmcActive, NoiNonZero, TriNonZero,
		Sq2NonZero, Sq1NonZero};

	assign IRQ = frame_irq || DmcIrq;

	// Generate each channel
	SquareChan Squ1 (
		.MMC5         (MMC5),
		.clk          (clk),
		.ce           (ce),
		.aclk1        (aclk1),
		.aclk1_d      (aclk1_delayed),
		.reset        (reset),
		.cold_reset   (cold_reset),
		.allow_us     (allow_us),
		.sq2          (1'b0),
		.Addr         (ADDR[1:0]),
		.DIN          (DIN),
		.write        (ApuMW0 && write),
		.lc_load      (lc_load),
		.LenCtr_Clock (ClkL),
		.Env_Clock    (ClkE),
		.get_or_put   (get_or_put),
		.Enabled      (Enabled[0]),
		.Sample       (Sq1Sample),
		.IsNonZero    (Sq1NonZero)
	);

	SquareChan Squ2 (
		.MMC5         (MMC5),
        .allow_us (allow_us),
		.clk          (clk),
		.ce           (ce),
		.aclk1        (aclk1),
		.aclk1_d      (aclk1_delayed),
		.reset        (reset),
		.cold_reset   (cold_reset),
		.sq2          (1'b1),
		.Addr         (ADDR[1:0]),
		.DIN          (DIN),
		.write        (ApuMW1 && write),
		.lc_load      (lc_load),
		.LenCtr_Clock (ClkL),
		.Env_Clock    (ClkE),
		.get_or_put   (get_or_put),
		.Enabled      (Enabled[1]),
		.Sample       (Sq2Sample),
		.IsNonZero    (Sq2NonZero)
	);

	TriangleChan Tri (
		.clk          (clk),
		.phi1         (phi1),
		.aclk1        (aclk1),
		.aclk1_d      (aclk1_delayed),
		.reset        (reset),
		.cold_reset   (cold_reset),
		.allow_us     (allow_us),
		.Addr         (ADDR[1:0]),
		.DIN          (DIN),
		.write        (ApuMW2 && write),
		.lc_load      (lc_load),
		.LenCtr_Clock (ClkL),
		.LinCtr_Clock (ClkE),
		.Enabled      (Enabled[2]),
		.Sample       (TriSample),
		.IsNonZero    (TriNonZero)
	);

	NoiseChan Noi (
		.clk          (clk),
		.ce           (ce),
		.aclk1        (aclk1),
		.aclk1_d      (aclk1_delayed),
		.reset        (reset),
		.cold_reset   (cold_reset),
		.Addr         (ADDR[1:0]),
		.DIN          (DIN),
		.PAL          (PAL),
		.write        (ApuMW3 && write),
		.lc_load      (lc_load),
		.LenCtr_Clock (ClkL),
		.Env_Clock    (ClkE),
		.Enabled      (Enabled[3]),
		.Sample       (NoiSample),
		.IsNonZero    (NoiNonZero)
	);

	DmcChan #(.SSREG_INDEX_DMC1(SSREG_INDEX_DMC1), .SSREG_INDEX_DMC2(SSREG_INDEX_DMC2),
        .E_SESSION_RESET_DMC_SILENCE(E_SESSION_RESET_DMC_SILENCE)) Dmc (
		.MMC5        (MMC5),
		.clk         (clk),
		.aclk1       (aclk1),
		.aclk1_d     (aclk1_delayed),
		.reset       (reset),
		.cold_reset  (cold_reset),
		.ain         (ADDR[2:0]),
		.DIN         (DIN),
		.write       (write & ApuMW4),
		.dma_ack     (DmaAck),
		.dma_data    (DmaData),
		.PAL         (PAL),
		.dma_address (DmaAddr),
		.irq         (DmcIrq),
		.Sample      (DmcSample),
		.dma_req     (DmaReq),
		.enable      (IsDmcActive),
		// savestates
		.SaveStateBus_Din  (SaveStateBus_Din ),
		.SaveStateBus_Adr  (SaveStateBus_Adr ),
		.SaveStateBus_wren (SaveStateBus_wren),
		.SaveStateBus_rst  (SaveStateBus_rst ),
		.SaveStateBus_load (SaveStateBus_load ),
		.SaveStateBus_Dout (SaveStateBus_wired_or[1])
	);

	APUMixer mixer (
		.square1      (Sq1Sample),
		.square2      (Sq2Sample),
		.noise        (NoiSample),
		.triangle     (TriSample),
		.dmc          (DmcSample),
		.sample       (Sample)
	);

	FrameCtr #(.SSREG_INDEX_FCT(SSREG_INDEX_FCT)) frame_counter (
		.clk          (clk),
		.aclk1        (aclk1),
		.aclk2        (aclk2),
		.reset        (reset),
		.cold_reset   (cold_reset),
		.write        (ApuMW5 & write),
		.read         (ApuMW5 & read),
		.write_ce     (ApuMW5 & write_ce),
		.addr         (ADDR[1:0]),
		.din          (DIN),
		.PAL          (PAL),
		.MMC5         (MMC5),
		.irq          (frame_irq),
		.irq_flag     (irq_flag),
		.frame_half   (frame_half),
		.frame_quarter(frame_quarter),
		// savestates
		.SaveStateBus_Din  (SaveStateBus_Din ),
		.SaveStateBus_Adr  (SaveStateBus_Adr ),
		.SaveStateBus_wren (SaveStateBus_wren),
		.SaveStateBus_rst  (SaveStateBus_rst ),
		.SaveStateBus_load (SaveStateBus_load ),
		.SaveStateBus_Dout (SaveStateBus_wired_or[2])
	);

endmodule

// http://wiki.nesdev.com/w/index.php/APU_Mixer
// I generated three LUT's for each mix channel entry and one lut for the squares, then a
// 284 entry lut for the mix channel. It's more accurate than the original LUT system listed on
// the NesDev page. In addition I boosted the square channel 10% and lowered the mix channel 10%
// to more closely match real systems.

module APUMixer (
	input  logic  [3:0] square1,
	input  logic  [3:0] square2,
	input  logic  [3:0] triangle,
	input  logic  [3:0] noise,
	input  logic  [6:0] dmc,
	output logic [15:0] sample
);

logic [15:0] pulse_lut[0:31];
assign pulse_lut[0] = 16'h0000;
assign pulse_lut[1] = 16'h0331;
assign pulse_lut[2] = 16'h064F;
assign pulse_lut[3] = 16'h0959;
assign pulse_lut[4] = 16'h0C52;
assign pulse_lut[5] = 16'h0F38;
assign pulse_lut[6] = 16'h120E;
assign pulse_lut[7] = 16'h14D3;
assign pulse_lut[8] = 16'h1788;
assign pulse_lut[9] = 16'h1A2E;
assign pulse_lut[10] = 16'h1CC6;
assign pulse_lut[11] = 16'h1F4E;
assign pulse_lut[12] = 16'h21C9;
assign pulse_lut[13] = 16'h2437;
assign pulse_lut[14] = 16'h2697;
assign pulse_lut[15] = 16'h28EB;
assign pulse_lut[16] = 16'h2B32;
assign pulse_lut[17] = 16'h2D6E;
assign pulse_lut[18] = 16'h2F9E;
assign pulse_lut[19] = 16'h31C3;
assign pulse_lut[20] = 16'h33DD;
assign pulse_lut[21] = 16'h35EC;
assign pulse_lut[22] = 16'h37F2;
assign pulse_lut[23] = 16'h39ED;
assign pulse_lut[24] = 16'h3BDF;
assign pulse_lut[25] = 16'h3DC7;
assign pulse_lut[26] = 16'h3FA6;
assign pulse_lut[27] = 16'h417D;
assign pulse_lut[28] = 16'h434B;
assign pulse_lut[29] = 16'h4510;
assign pulse_lut[30] = 16'h46CD;
assign pulse_lut[31] = 16'h0000;

logic [5:0] tri_lut[0:15];
assign tri_lut[0] = 6'h00;
assign tri_lut[1] = 6'h04;
assign tri_lut[2] = 6'h08;
assign tri_lut[3] = 6'h0C;
assign tri_lut[4] = 6'h10;
assign tri_lut[5] = 6'h14;
assign tri_lut[6] = 6'h18;
assign tri_lut[7] = 6'h1C;
assign tri_lut[8] = 6'h20;
assign tri_lut[9] = 6'h24;
assign tri_lut[10] = 6'h28;
assign tri_lut[11] = 6'h2C;
assign tri_lut[12] = 6'h30;
assign tri_lut[13] = 6'h34;
assign tri_lut[14] = 6'h38;
assign tri_lut[15] = 6'h3C;

logic [5:0] noise_lut[0:15];
assign noise_lut[0] = 6'h00;
assign noise_lut[1] = 6'h03;
assign noise_lut[2] = 6'h05;
assign noise_lut[3] = 6'h08;
assign noise_lut[4] = 6'h0B;
assign noise_lut[5] = 6'h0D;
assign noise_lut[6] = 6'h10;
assign noise_lut[7] = 6'h13;
assign noise_lut[8] = 6'h15;
assign noise_lut[9] = 6'h18;
assign noise_lut[10] = 6'h1B;
assign noise_lut[11] = 6'h1D;
assign noise_lut[12] = 6'h20;
assign noise_lut[13] = 6'h23;
assign noise_lut[14] = 6'h25;
assign noise_lut[15] = 6'h28;

logic [7:0] dmc_lut[0:127];
assign dmc_lut[0] = 8'h00;
assign dmc_lut[1] = 8'h01;
assign dmc_lut[2] = 8'h03;
assign dmc_lut[3] = 8'h04;
assign dmc_lut[4] = 8'h06;
assign dmc_lut[5] = 8'h07;
assign dmc_lut[6] = 8'h09;
assign dmc_lut[7] = 8'h0A;
assign dmc_lut[8] = 8'h0C;
assign dmc_lut[9] = 8'h0D;
assign dmc_lut[10] = 8'h0E;
assign dmc_lut[11] = 8'h10;
assign dmc_lut[12] = 8'h11;
assign dmc_lut[13] = 8'h13;
assign dmc_lut[14] = 8'h14;
assign dmc_lut[15] = 8'h16;
assign dmc_lut[16] = 8'h17;
assign dmc_lut[17] = 8'h19;
assign dmc_lut[18] = 8'h1A;
assign dmc_lut[19] = 8'h1C;
assign dmc_lut[20] = 8'h1D;
assign dmc_lut[21] = 8'h1E;
assign dmc_lut[22] = 8'h20;
assign dmc_lut[23] = 8'h21;
assign dmc_lut[24] = 8'h23;
assign dmc_lut[25] = 8'h24;
assign dmc_lut[26] = 8'h26;
assign dmc_lut[27] = 8'h27;
assign dmc_lut[28] = 8'h29;
assign dmc_lut[29] = 8'h2A;
assign dmc_lut[30] = 8'h2B;
assign dmc_lut[31] = 8'h2D;
assign dmc_lut[32] = 8'h2E;
assign dmc_lut[33] = 8'h30;
assign dmc_lut[34] = 8'h31;
assign dmc_lut[35] = 8'h33;
assign dmc_lut[36] = 8'h34;
assign dmc_lut[37] = 8'h36;
assign dmc_lut[38] = 8'h37;
assign dmc_lut[39] = 8'h38;
assign dmc_lut[40] = 8'h3A;
assign dmc_lut[41] = 8'h3B;
assign dmc_lut[42] = 8'h3D;
assign dmc_lut[43] = 8'h3E;
assign dmc_lut[44] = 8'h40;
assign dmc_lut[45] = 8'h41;
assign dmc_lut[46] = 8'h43;
assign dmc_lut[47] = 8'h44;
assign dmc_lut[48] = 8'h45;
assign dmc_lut[49] = 8'h47;
assign dmc_lut[50] = 8'h48;
assign dmc_lut[51] = 8'h4A;
assign dmc_lut[52] = 8'h4B;
assign dmc_lut[53] = 8'h4D;
assign dmc_lut[54] = 8'h4E;
assign dmc_lut[55] = 8'h50;
assign dmc_lut[56] = 8'h51;
assign dmc_lut[57] = 8'h53;
assign dmc_lut[58] = 8'h54;
assign dmc_lut[59] = 8'h55;
assign dmc_lut[60] = 8'h57;
assign dmc_lut[61] = 8'h58;
assign dmc_lut[62] = 8'h5A;
assign dmc_lut[63] = 8'h5B;
assign dmc_lut[64] = 8'h5D;
assign dmc_lut[65] = 8'h5E;
assign dmc_lut[66] = 8'h60;
assign dmc_lut[67] = 8'h61;
assign dmc_lut[68] = 8'h62;
assign dmc_lut[69] = 8'h64;
assign dmc_lut[70] = 8'h65;
assign dmc_lut[71] = 8'h67;
assign dmc_lut[72] = 8'h68;
assign dmc_lut[73] = 8'h6A;
assign dmc_lut[74] = 8'h6B;
assign dmc_lut[75] = 8'h6D;
assign dmc_lut[76] = 8'h6E;
assign dmc_lut[77] = 8'h6F;
assign dmc_lut[78] = 8'h71;
assign dmc_lut[79] = 8'h72;
assign dmc_lut[80] = 8'h74;
assign dmc_lut[81] = 8'h75;
assign dmc_lut[82] = 8'h77;
assign dmc_lut[83] = 8'h78;
assign dmc_lut[84] = 8'h7A;
assign dmc_lut[85] = 8'h7B;
assign dmc_lut[86] = 8'h7C;
assign dmc_lut[87] = 8'h7E;
assign dmc_lut[88] = 8'h7F;
assign dmc_lut[89] = 8'h81;
assign dmc_lut[90] = 8'h82;
assign dmc_lut[91] = 8'h84;
assign dmc_lut[92] = 8'h85;
assign dmc_lut[93] = 8'h87;
assign dmc_lut[94] = 8'h88;
assign dmc_lut[95] = 8'h8A;
assign dmc_lut[96] = 8'h8B;
assign dmc_lut[97] = 8'h8C;
assign dmc_lut[98] = 8'h8E;
assign dmc_lut[99] = 8'h8F;
assign dmc_lut[100] = 8'h91;
assign dmc_lut[101] = 8'h92;
assign dmc_lut[102] = 8'h94;
assign dmc_lut[103] = 8'h95;
assign dmc_lut[104] = 8'h97;
assign dmc_lut[105] = 8'h98;
assign dmc_lut[106] = 8'h99;
assign dmc_lut[107] = 8'h9B;
assign dmc_lut[108] = 8'h9C;
assign dmc_lut[109] = 8'h9E;
assign dmc_lut[110] = 8'h9F;
assign dmc_lut[111] = 8'hA1;
assign dmc_lut[112] = 8'hA2;
assign dmc_lut[113] = 8'hA4;
assign dmc_lut[114] = 8'hA5;
assign dmc_lut[115] = 8'hA6;
assign dmc_lut[116] = 8'hA8;
assign dmc_lut[117] = 8'hA9;
assign dmc_lut[118] = 8'hAB;
assign dmc_lut[119] = 8'hAC;
assign dmc_lut[120] = 8'hAE;
assign dmc_lut[121] = 8'hAF;
assign dmc_lut[122] = 8'hB1;
assign dmc_lut[123] = 8'hB2;
assign dmc_lut[124] = 8'hB3;
assign dmc_lut[125] = 8'hB5;
assign dmc_lut[126] = 8'hB6;
assign dmc_lut[127] = 8'hB8;

logic [15:0] mix_lut[0:511];
assign mix_lut[0] = 16'h0000;
assign mix_lut[1] = 16'h0128;
assign mix_lut[2] = 16'h024F;
assign mix_lut[3] = 16'h0374;
assign mix_lut[4] = 16'h0497;
assign mix_lut[5] = 16'h05B8;
assign mix_lut[6] = 16'h06D7;
assign mix_lut[7] = 16'h07F5;
assign mix_lut[8] = 16'h0911;
assign mix_lut[9] = 16'h0A2B;
assign mix_lut[10] = 16'h0B44;
assign mix_lut[11] = 16'h0C5B;
assign mix_lut[12] = 16'h0D71;
assign mix_lut[13] = 16'h0E84;
assign mix_lut[14] = 16'h0F96;
assign mix_lut[15] = 16'h10A7;
assign mix_lut[16] = 16'h11B6;
assign mix_lut[17] = 16'h12C3;
assign mix_lut[18] = 16'h13CF;
assign mix_lut[19] = 16'h14DA;
assign mix_lut[20] = 16'h15E2;
assign mix_lut[21] = 16'h16EA;
assign mix_lut[22] = 16'h17EF;
assign mix_lut[23] = 16'h18F4;
assign mix_lut[24] = 16'h19F6;
assign mix_lut[25] = 16'h1AF8;
assign mix_lut[26] = 16'h1BF7;
assign mix_lut[27] = 16'h1CF6;
assign mix_lut[28] = 16'h1DF3;
assign mix_lut[29] = 16'h1EEE;
assign mix_lut[30] = 16'h1FE9;
assign mix_lut[31] = 16'h20E1;
assign mix_lut[32] = 16'h21D9;
assign mix_lut[33] = 16'h22CF;
assign mix_lut[34] = 16'h23C3;
assign mix_lut[35] = 16'h24B7;
assign mix_lut[36] = 16'h25A9;
assign mix_lut[37] = 16'h2699;
assign mix_lut[38] = 16'h2788;
assign mix_lut[39] = 16'h2876;
assign mix_lut[40] = 16'h2963;
assign mix_lut[41] = 16'h2A4F;
assign mix_lut[42] = 16'h2B39;
assign mix_lut[43] = 16'h2C22;
assign mix_lut[44] = 16'h2D09;
assign mix_lut[45] = 16'h2DF0;
assign mix_lut[46] = 16'h2ED5;
assign mix_lut[47] = 16'h2FB9;
assign mix_lut[48] = 16'h309B;
assign mix_lut[49] = 16'h317D;
assign mix_lut[50] = 16'h325D;
assign mix_lut[51] = 16'h333C;
assign mix_lut[52] = 16'h341A;
assign mix_lut[53] = 16'h34F7;
assign mix_lut[54] = 16'h35D3;
assign mix_lut[55] = 16'h36AD;
assign mix_lut[56] = 16'h3787;
assign mix_lut[57] = 16'h385F;
assign mix_lut[58] = 16'h3936;
assign mix_lut[59] = 16'h3A0C;
assign mix_lut[60] = 16'h3AE1;
assign mix_lut[61] = 16'h3BB5;
assign mix_lut[62] = 16'h3C87;
assign mix_lut[63] = 16'h3D59;
assign mix_lut[64] = 16'h3E29;
assign mix_lut[65] = 16'h3EF9;
assign mix_lut[66] = 16'h3FC7;
assign mix_lut[67] = 16'h4095;
assign mix_lut[68] = 16'h4161;
assign mix_lut[69] = 16'h422C;
assign mix_lut[70] = 16'h42F7;
assign mix_lut[71] = 16'h43C0;
assign mix_lut[72] = 16'h4488;
assign mix_lut[73] = 16'h4550;
assign mix_lut[74] = 16'h4616;
assign mix_lut[75] = 16'h46DB;
assign mix_lut[76] = 16'h47A0;
assign mix_lut[77] = 16'h4863;
assign mix_lut[78] = 16'h4925;
assign mix_lut[79] = 16'h49E7;
assign mix_lut[80] = 16'h4AA7;
assign mix_lut[81] = 16'h4B67;
assign mix_lut[82] = 16'h4C25;
assign mix_lut[83] = 16'h4CE3;
assign mix_lut[84] = 16'h4DA0;
assign mix_lut[85] = 16'h4E5C;
assign mix_lut[86] = 16'h4F17;
assign mix_lut[87] = 16'h4FD1;
assign mix_lut[88] = 16'h508A;
assign mix_lut[89] = 16'h5142;
assign mix_lut[90] = 16'h51F9;
assign mix_lut[91] = 16'h52B0;
assign mix_lut[92] = 16'h5365;
assign mix_lut[93] = 16'h541A;
assign mix_lut[94] = 16'h54CE;
assign mix_lut[95] = 16'h5581;
assign mix_lut[96] = 16'h5633;
assign mix_lut[97] = 16'h56E5;
assign mix_lut[98] = 16'h5795;
assign mix_lut[99] = 16'h5845;
assign mix_lut[100] = 16'h58F4;
assign mix_lut[101] = 16'h59A2;
assign mix_lut[102] = 16'h5A4F;
assign mix_lut[103] = 16'h5AFC;
assign mix_lut[104] = 16'h5BA7;
assign mix_lut[105] = 16'h5C52;
assign mix_lut[106] = 16'h5CFC;
assign mix_lut[107] = 16'h5DA5;
assign mix_lut[108] = 16'h5E4E;
assign mix_lut[109] = 16'h5EF6;
assign mix_lut[110] = 16'h5F9D;
assign mix_lut[111] = 16'h6043;
assign mix_lut[112] = 16'h60E8;
assign mix_lut[113] = 16'h618D;
assign mix_lut[114] = 16'h6231;
assign mix_lut[115] = 16'h62D4;
assign mix_lut[116] = 16'h6377;
assign mix_lut[117] = 16'h6418;
assign mix_lut[118] = 16'h64B9;
assign mix_lut[119] = 16'h655A;
assign mix_lut[120] = 16'h65F9;
assign mix_lut[121] = 16'h6698;
assign mix_lut[122] = 16'h6736;
assign mix_lut[123] = 16'h67D4;
assign mix_lut[124] = 16'h6871;
assign mix_lut[125] = 16'h690D;
assign mix_lut[126] = 16'h69A8;
assign mix_lut[127] = 16'h6A43;
assign mix_lut[128] = 16'h6ADD;
assign mix_lut[129] = 16'h6B76;
assign mix_lut[130] = 16'h6C0F;
assign mix_lut[131] = 16'h6CA7;
assign mix_lut[132] = 16'h6D3E;
assign mix_lut[133] = 16'h6DD5;
assign mix_lut[134] = 16'h6E6B;
assign mix_lut[135] = 16'h6F00;
assign mix_lut[136] = 16'h6F95;
assign mix_lut[137] = 16'h7029;
assign mix_lut[138] = 16'h70BD;
assign mix_lut[139] = 16'h7150;
assign mix_lut[140] = 16'h71E2;
assign mix_lut[141] = 16'h7273;
assign mix_lut[142] = 16'h7304;
assign mix_lut[143] = 16'h7395;
assign mix_lut[144] = 16'h7424;
assign mix_lut[145] = 16'h74B4;
assign mix_lut[146] = 16'h7542;
assign mix_lut[147] = 16'h75D0;
assign mix_lut[148] = 16'h765D;
assign mix_lut[149] = 16'h76EA;
assign mix_lut[150] = 16'h7776;
assign mix_lut[151] = 16'h7802;
assign mix_lut[152] = 16'h788D;
assign mix_lut[153] = 16'h7917;
assign mix_lut[154] = 16'h79A1;
assign mix_lut[155] = 16'h7A2A;
assign mix_lut[156] = 16'h7AB3;
assign mix_lut[157] = 16'h7B3B;
assign mix_lut[158] = 16'h7BC3;
assign mix_lut[159] = 16'h7C4A;
assign mix_lut[160] = 16'h7CD0;
assign mix_lut[161] = 16'h7D56;
assign mix_lut[162] = 16'h7DDB;
assign mix_lut[163] = 16'h7E60;
assign mix_lut[164] = 16'h7EE4;
assign mix_lut[165] = 16'h7F68;
assign mix_lut[166] = 16'h7FEB;
assign mix_lut[167] = 16'h806E;
assign mix_lut[168] = 16'h80F0;
assign mix_lut[169] = 16'h8172;
assign mix_lut[170] = 16'h81F3;
assign mix_lut[171] = 16'h8274;
assign mix_lut[172] = 16'h82F4;
assign mix_lut[173] = 16'h8373;
assign mix_lut[174] = 16'h83F2;
assign mix_lut[175] = 16'h8471;
assign mix_lut[176] = 16'h84EF;
assign mix_lut[177] = 16'h856C;
assign mix_lut[178] = 16'h85E9;
assign mix_lut[179] = 16'h8666;
assign mix_lut[180] = 16'h86E2;
assign mix_lut[181] = 16'h875E;
assign mix_lut[182] = 16'h87D9;
assign mix_lut[183] = 16'h8853;
assign mix_lut[184] = 16'h88CD;
assign mix_lut[185] = 16'h8947;
assign mix_lut[186] = 16'h89C0;
assign mix_lut[187] = 16'h8A39;
assign mix_lut[188] = 16'h8AB1;
assign mix_lut[189] = 16'h8B29;
assign mix_lut[190] = 16'h8BA0;
assign mix_lut[191] = 16'h8C17;
assign mix_lut[192] = 16'h8C8E;
assign mix_lut[193] = 16'h8D03;
assign mix_lut[194] = 16'h8D79;
assign mix_lut[195] = 16'h8DEE;
assign mix_lut[196] = 16'h8E63;
assign mix_lut[197] = 16'h8ED7;
assign mix_lut[198] = 16'h8F4A;
assign mix_lut[199] = 16'h8FBE;
assign mix_lut[200] = 16'h9030;
assign mix_lut[201] = 16'h90A3;
assign mix_lut[202] = 16'h9115;
assign mix_lut[203] = 16'h9186;
assign mix_lut[204] = 16'h91F7;
assign mix_lut[205] = 16'h9268;
assign mix_lut[206] = 16'h92D8;
assign mix_lut[207] = 16'h9348;
assign mix_lut[208] = 16'h93B8;
assign mix_lut[209] = 16'h9427;
assign mix_lut[210] = 16'h9495;
assign mix_lut[211] = 16'h9503;
assign mix_lut[212] = 16'h9571;
assign mix_lut[213] = 16'h95DF;
assign mix_lut[214] = 16'h964C;
assign mix_lut[215] = 16'h96B8;
assign mix_lut[216] = 16'h9724;
assign mix_lut[217] = 16'h9790;
assign mix_lut[218] = 16'h97FB;
assign mix_lut[219] = 16'h9866;
assign mix_lut[220] = 16'h98D1;
assign mix_lut[221] = 16'h993B;
assign mix_lut[222] = 16'h99A5;
assign mix_lut[223] = 16'h9A0E;
assign mix_lut[224] = 16'h9A77;
assign mix_lut[225] = 16'h9AE0;
assign mix_lut[226] = 16'h9B48;
assign mix_lut[227] = 16'h9BB0;
assign mix_lut[228] = 16'h9C18;
assign mix_lut[229] = 16'h9C7F;
assign mix_lut[230] = 16'h9CE6;
assign mix_lut[231] = 16'h9D4C;
assign mix_lut[232] = 16'h9DB2;
assign mix_lut[233] = 16'h9E18;
assign mix_lut[234] = 16'h9E7D;
assign mix_lut[235] = 16'h9EE2;
assign mix_lut[236] = 16'h9F47;
assign mix_lut[237] = 16'h9FAB;
assign mix_lut[238] = 16'hA00F;
assign mix_lut[239] = 16'hA073;
assign mix_lut[240] = 16'hA0D6;
assign mix_lut[241] = 16'hA139;
assign mix_lut[242] = 16'hA19B;
assign mix_lut[243] = 16'hA1FD;
assign mix_lut[244] = 16'hA25F;
assign mix_lut[245] = 16'hA2C1;
assign mix_lut[246] = 16'hA322;
assign mix_lut[247] = 16'hA383;
assign mix_lut[248] = 16'hA3E3;
assign mix_lut[249] = 16'hA443;
assign mix_lut[250] = 16'hA4A3;
assign mix_lut[251] = 16'hA502;
assign mix_lut[252] = 16'hA562;
assign mix_lut[253] = 16'hA5C0;
assign mix_lut[254] = 16'hA61F;
assign mix_lut[255] = 16'hA67D;
assign mix_lut[256] = 16'hA6DB;
assign mix_lut[257] = 16'hA738;
assign mix_lut[258] = 16'hA796;
assign mix_lut[259] = 16'hA7F2;
assign mix_lut[260] = 16'hA84F;
assign mix_lut[261] = 16'hA8AB;
assign mix_lut[262] = 16'hA907;
assign mix_lut[263] = 16'hA963;
assign mix_lut[264] = 16'hA9BE;
assign mix_lut[265] = 16'hAA19;
assign mix_lut[266] = 16'hAA74;
assign mix_lut[267] = 16'hAACE;
assign mix_lut[268] = 16'hAB28;
assign mix_lut[269] = 16'hAB82;
assign mix_lut[270] = 16'hABDB;
assign mix_lut[271] = 16'hAC35;
assign mix_lut[272] = 16'hAC8E;
assign mix_lut[273] = 16'hACE6;
assign mix_lut[274] = 16'hAD3E;
assign mix_lut[275] = 16'hAD96;
assign mix_lut[276] = 16'hADEE;
assign mix_lut[277] = 16'hAE46;
assign mix_lut[278] = 16'hAE9D;
assign mix_lut[279] = 16'hAEF4;
assign mix_lut[280] = 16'hAF4A;
assign mix_lut[281] = 16'hAFA0;
assign mix_lut[282] = 16'hAFF6;
assign mix_lut[283] = 16'hB04C;
assign mix_lut[284] = 16'hB0A2;
assign mix_lut[285] = 16'h0000;
assign mix_lut[286] = 16'h0000;
assign mix_lut[287] = 16'h0000;
assign mix_lut[288] = 16'h0000;
assign mix_lut[289] = 16'h0000;
assign mix_lut[290] = 16'h0000;
assign mix_lut[291] = 16'h0000;
assign mix_lut[292] = 16'h0000;
assign mix_lut[293] = 16'h0000;
assign mix_lut[294] = 16'h0000;
assign mix_lut[295] = 16'h0000;
assign mix_lut[296] = 16'h0000;
assign mix_lut[297] = 16'h0000;
assign mix_lut[298] = 16'h0000;
assign mix_lut[299] = 16'h0000;
assign mix_lut[300] = 16'h0000;
assign mix_lut[301] = 16'h0000;
assign mix_lut[302] = 16'h0000;
assign mix_lut[303] = 16'h0000;
assign mix_lut[304] = 16'h0000;
assign mix_lut[305] = 16'h0000;
assign mix_lut[306] = 16'h0000;
assign mix_lut[307] = 16'h0000;
assign mix_lut[308] = 16'h0000;
assign mix_lut[309] = 16'h0000;
assign mix_lut[310] = 16'h0000;
assign mix_lut[311] = 16'h0000;
assign mix_lut[312] = 16'h0000;
assign mix_lut[313] = 16'h0000;
assign mix_lut[314] = 16'h0000;
assign mix_lut[315] = 16'h0000;
assign mix_lut[316] = 16'h0000;
assign mix_lut[317] = 16'h0000;
assign mix_lut[318] = 16'h0000;
assign mix_lut[319] = 16'h0000;
assign mix_lut[320] = 16'h0000;
assign mix_lut[321] = 16'h0000;
assign mix_lut[322] = 16'h0000;
assign mix_lut[323] = 16'h0000;
assign mix_lut[324] = 16'h0000;
assign mix_lut[325] = 16'h0000;
assign mix_lut[326] = 16'h0000;
assign mix_lut[327] = 16'h0000;
assign mix_lut[328] = 16'h0000;
assign mix_lut[329] = 16'h0000;
assign mix_lut[330] = 16'h0000;
assign mix_lut[331] = 16'h0000;
assign mix_lut[332] = 16'h0000;
assign mix_lut[333] = 16'h0000;
assign mix_lut[334] = 16'h0000;
assign mix_lut[335] = 16'h0000;
assign mix_lut[336] = 16'h0000;
assign mix_lut[337] = 16'h0000;
assign mix_lut[338] = 16'h0000;
assign mix_lut[339] = 16'h0000;
assign mix_lut[340] = 16'h0000;
assign mix_lut[341] = 16'h0000;
assign mix_lut[342] = 16'h0000;
assign mix_lut[343] = 16'h0000;
assign mix_lut[344] = 16'h0000;
assign mix_lut[345] = 16'h0000;
assign mix_lut[346] = 16'h0000;
assign mix_lut[347] = 16'h0000;
assign mix_lut[348] = 16'h0000;
assign mix_lut[349] = 16'h0000;
assign mix_lut[350] = 16'h0000;
assign mix_lut[351] = 16'h0000;
assign mix_lut[352] = 16'h0000;
assign mix_lut[353] = 16'h0000;
assign mix_lut[354] = 16'h0000;
assign mix_lut[355] = 16'h0000;
assign mix_lut[356] = 16'h0000;
assign mix_lut[357] = 16'h0000;
assign mix_lut[358] = 16'h0000;
assign mix_lut[359] = 16'h0000;
assign mix_lut[360] = 16'h0000;
assign mix_lut[361] = 16'h0000;
assign mix_lut[362] = 16'h0000;
assign mix_lut[363] = 16'h0000;
assign mix_lut[364] = 16'h0000;
assign mix_lut[365] = 16'h0000;
assign mix_lut[366] = 16'h0000;
assign mix_lut[367] = 16'h0000;
assign mix_lut[368] = 16'h0000;
assign mix_lut[369] = 16'h0000;
assign mix_lut[370] = 16'h0000;
assign mix_lut[371] = 16'h0000;
assign mix_lut[372] = 16'h0000;
assign mix_lut[373] = 16'h0000;
assign mix_lut[374] = 16'h0000;
assign mix_lut[375] = 16'h0000;
assign mix_lut[376] = 16'h0000;
assign mix_lut[377] = 16'h0000;
assign mix_lut[378] = 16'h0000;
assign mix_lut[379] = 16'h0000;
assign mix_lut[380] = 16'h0000;
assign mix_lut[381] = 16'h0000;
assign mix_lut[382] = 16'h0000;
assign mix_lut[383] = 16'h0000;
assign mix_lut[384] = 16'h0000;
assign mix_lut[385] = 16'h0000;
assign mix_lut[386] = 16'h0000;
assign mix_lut[387] = 16'h0000;
assign mix_lut[388] = 16'h0000;
assign mix_lut[389] = 16'h0000;
assign mix_lut[390] = 16'h0000;
assign mix_lut[391] = 16'h0000;
assign mix_lut[392] = 16'h0000;
assign mix_lut[393] = 16'h0000;
assign mix_lut[394] = 16'h0000;
assign mix_lut[395] = 16'h0000;
assign mix_lut[396] = 16'h0000;
assign mix_lut[397] = 16'h0000;
assign mix_lut[398] = 16'h0000;
assign mix_lut[399] = 16'h0000;
assign mix_lut[400] = 16'h0000;
assign mix_lut[401] = 16'h0000;
assign mix_lut[402] = 16'h0000;
assign mix_lut[403] = 16'h0000;
assign mix_lut[404] = 16'h0000;
assign mix_lut[405] = 16'h0000;
assign mix_lut[406] = 16'h0000;
assign mix_lut[407] = 16'h0000;
assign mix_lut[408] = 16'h0000;
assign mix_lut[409] = 16'h0000;
assign mix_lut[410] = 16'h0000;
assign mix_lut[411] = 16'h0000;
assign mix_lut[412] = 16'h0000;
assign mix_lut[413] = 16'h0000;
assign mix_lut[414] = 16'h0000;
assign mix_lut[415] = 16'h0000;
assign mix_lut[416] = 16'h0000;
assign mix_lut[417] = 16'h0000;
assign mix_lut[418] = 16'h0000;
assign mix_lut[419] = 16'h0000;
assign mix_lut[420] = 16'h0000;
assign mix_lut[421] = 16'h0000;
assign mix_lut[422] = 16'h0000;
assign mix_lut[423] = 16'h0000;
assign mix_lut[424] = 16'h0000;
assign mix_lut[425] = 16'h0000;
assign mix_lut[426] = 16'h0000;
assign mix_lut[427] = 16'h0000;
assign mix_lut[428] = 16'h0000;
assign mix_lut[429] = 16'h0000;
assign mix_lut[430] = 16'h0000;
assign mix_lut[431] = 16'h0000;
assign mix_lut[432] = 16'h0000;
assign mix_lut[433] = 16'h0000;
assign mix_lut[434] = 16'h0000;
assign mix_lut[435] = 16'h0000;
assign mix_lut[436] = 16'h0000;
assign mix_lut[437] = 16'h0000;
assign mix_lut[438] = 16'h0000;
assign mix_lut[439] = 16'h0000;
assign mix_lut[440] = 16'h0000;
assign mix_lut[441] = 16'h0000;
assign mix_lut[442] = 16'h0000;
assign mix_lut[443] = 16'h0000;
assign mix_lut[444] = 16'h0000;
assign mix_lut[445] = 16'h0000;
assign mix_lut[446] = 16'h0000;
assign mix_lut[447] = 16'h0000;
assign mix_lut[448] = 16'h0000;
assign mix_lut[449] = 16'h0000;
assign mix_lut[450] = 16'h0000;
assign mix_lut[451] = 16'h0000;
assign mix_lut[452] = 16'h0000;
assign mix_lut[453] = 16'h0000;
assign mix_lut[454] = 16'h0000;
assign mix_lut[455] = 16'h0000;
assign mix_lut[456] = 16'h0000;
assign mix_lut[457] = 16'h0000;
assign mix_lut[458] = 16'h0000;
assign mix_lut[459] = 16'h0000;
assign mix_lut[460] = 16'h0000;
assign mix_lut[461] = 16'h0000;
assign mix_lut[462] = 16'h0000;
assign mix_lut[463] = 16'h0000;
assign mix_lut[464] = 16'h0000;
assign mix_lut[465] = 16'h0000;
assign mix_lut[466] = 16'h0000;
assign mix_lut[467] = 16'h0000;
assign mix_lut[468] = 16'h0000;
assign mix_lut[469] = 16'h0000;
assign mix_lut[470] = 16'h0000;
assign mix_lut[471] = 16'h0000;
assign mix_lut[472] = 16'h0000;
assign mix_lut[473] = 16'h0000;
assign mix_lut[474] = 16'h0000;
assign mix_lut[475] = 16'h0000;
assign mix_lut[476] = 16'h0000;
assign mix_lut[477] = 16'h0000;
assign mix_lut[478] = 16'h0000;
assign mix_lut[479] = 16'h0000;
assign mix_lut[480] = 16'h0000;
assign mix_lut[481] = 16'h0000;
assign mix_lut[482] = 16'h0000;
assign mix_lut[483] = 16'h0000;
assign mix_lut[484] = 16'h0000;
assign mix_lut[485] = 16'h0000;
assign mix_lut[486] = 16'h0000;
assign mix_lut[487] = 16'h0000;
assign mix_lut[488] = 16'h0000;
assign mix_lut[489] = 16'h0000;
assign mix_lut[490] = 16'h0000;
assign mix_lut[491] = 16'h0000;
assign mix_lut[492] = 16'h0000;
assign mix_lut[493] = 16'h0000;
assign mix_lut[494] = 16'h0000;
assign mix_lut[495] = 16'h0000;
assign mix_lut[496] = 16'h0000;
assign mix_lut[497] = 16'h0000;
assign mix_lut[498] = 16'h0000;
assign mix_lut[499] = 16'h0000;
assign mix_lut[500] = 16'h0000;
assign mix_lut[501] = 16'h0000;
assign mix_lut[502] = 16'h0000;
assign mix_lut[503] = 16'h0000;
assign mix_lut[504] = 16'h0000;
assign mix_lut[505] = 16'h0000;
assign mix_lut[506] = 16'h0000;
assign mix_lut[507] = 16'h0000;
assign mix_lut[508] = 16'h0000;
assign mix_lut[509] = 16'h0000;
assign mix_lut[510] = 16'h0000;
assign mix_lut[511] = 16'h0000;

wire [4:0] squares = square1 + square2;
wire [15:0] ch1 = pulse_lut[squares];
wire [8:0] mix = tri_lut[triangle] + noise_lut[noise] + dmc_lut[dmc];
wire [15:0] ch2 = mix_lut[mix];

assign sample = ch1 + ch2;

endmodule
