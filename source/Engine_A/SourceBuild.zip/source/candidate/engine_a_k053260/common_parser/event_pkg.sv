package vgm_parser_vnext_event_pkg;
    // Phase 1 event layout. Numeric values are local to this candidate.
    typedef enum logic [1:0] {
        EVENT_WRITE, EVENT_WAIT, EVENT_END, EVENT_DIAGNOSTIC
    } event_kind_t;

    typedef enum logic [3:0] {
        REASON_NONE,
        REASON_SHORT_HEADER,
        REASON_BAD_MAGIC,
        REASON_BAD_EXTENT,
        REASON_BAD_DATA_OFFSET,
        REASON_BAD_LOOP_OFFSET,
        REASON_TRUNCATED,
        REASON_UNSUPPORTED_OPCODE,
        REASON_LOOP_NOT_BOUNDARY,
        REASON_BAD_DATA_BLOCK
    } diagnostic_reason_t;

    typedef struct packed {
        event_kind_t kind;
        logic [31:0] source_pc;
        logic [7:0] opcode;
        logic [1:0] operand_count;
        logic [15:0] operands; // First byte in bits 7:0; second in 15:8.
        logic [15:0] value;    // WRITE data byte or logical WAIT sample delta.
        diagnostic_reason_t reason;
    } decode_event_t;

    // Additive WRITE sideband; Phase 1 event layout and numeric values stay fixed.
    typedef enum logic [2:0] {
        CHIP_PSG, CHIP_YM2612, CHIP_YM2151, CHIP_YM2203, CHIP_YM2610_FAMILY,
        CHIP_SEGAPCM, CHIP_C140, CHIP_K053260
    } write_chip_t;
    typedef enum logic [1:0] {
        ACCESS_DATA, ACCESS_REGISTER, ACCESS_CONTROL, ACCESS_MEMORY
    } write_access_t;
    typedef struct packed {
        write_chip_t chip;
        logic instance_id; // Encoded identity only; no capability/admission policy.
        write_access_t access_kind;
        logic port;
        logic [15:0] address;
        logic [7:0] data;
        logic [23:0] raw_operands; // First byte low; unused bytes zero.
    } write_descriptor_t;

    typedef enum logic {DATA_BLOCK, DATA_SEEK} data_kind_t;
    // File spans and encoded metadata only. No physical address or bank cursor.
    typedef struct packed {
        data_kind_t kind;
        logic [31:0] source_pc;
        logic [7:0] opcode;
        logic [4:0] operand_count;
        logic [127:0] operands; // Header operands then format prefix, first byte low.
        logic [7:0] block_type;
        logic instance_id; // Size bit31 for ROM/RAM categories only.
        logic [31:0] declared_length; // Raw encoded size, including instance bit.
        logic [3:0] metadata_bytes; // Opaque prefix; no decompression or mapping.
        logic [31:0] payload_offset, payload_length, next_pc;
        logic [31:0] seek_offset; // E0 has no encoded bank/resource ID.
    } data_event_t;

    // Option C: atomic grammar fact, not a resolved WRITE or storage command.
    // 8n implies type00 resource, consume1, YM2612 instance0/port0/register2A.
    typedef struct packed {
        logic [31:0] source_pc;
        logic [7:0] opcode;
        logic [31:0] next_pc;
        logic [3:0] wait_samples;
    } dac_stream_fact_t;
endpackage
