module vgm_parser_vnext_decoder #(
    // Keep Phase 1/2 proof grammar frozen; Phase 3 opts in explicitly.
    parameter bit DATA_GRAMMAR = 0,
    parameter bit DAC_GRAMMAR = 0,
    parameter bit COMMON_WRITE_GRAMMAR = 0
    // PHASE10A_RESUME_BEGIN
    ,parameter bit RESUME_CONTROL = 0
    // PHASE10A_RESUME_END
) (
    input logic clk, reset, start,
    // PHASE10A_RESUME_BEGIN
    input logic resume_valid,
    input logic [31:0] resume_pc,
    output logic resume_ready, resume_fault,
    // PHASE10A_RESUME_END
    input logic [31:0] image_size,
    output logic reader_req_valid,
    input logic reader_req_ready,
    output logic [31:0] reader_req_addr,
    input logic reader_rsp_valid,
    input logic [7:0] reader_rsp_byte,
    output logic event_valid,
    input logic event_ready,
    output vgm_parser_vnext_event_pkg::decode_event_t event_data,
    output vgm_parser_vnext_event_pkg::write_descriptor_t write_info,
    output logic data_event_valid,
    output vgm_parser_vnext_event_pkg::data_event_t data_event_data,
    output logic dac_fact_valid,
    output vgm_parser_vnext_event_pkg::dac_stream_fact_t dac_fact_data,
    output logic done,
    output logic [31:0] file_extent, data_start,
    output logic loop_present,
    output logic [31:0] loop_target,
    // First traversal facts only; not END, a redirect, or playback policy.
    output logic loop_terminal_valid,
    output logic [31:0] loop_terminal_pc,
    output logic loop_entry_seen
);
    import vgm_parser_vnext_event_pkg::*;
    typedef enum logic [3:0] {
        IDLE, HEADER_START, HEADER_WAIT, COMMAND_REQUEST, COMMAND_RESPONSE,
        OPERAND_REQUEST, OPERAND_RESPONSE, EMIT, LOOP_TERMINAL, COMPLETE,
        DATA_START, DATA_WAIT, DATA_EMIT, DAC_EMIT
    } state_t;
    state_t state;
    // PHASE10A_RESUME_BEGIN
    logic resume_allowed;
    assign resume_ready = RESUME_CONTROL && state == COMPLETE && resume_allowed &&
                          !reset && !start && !resume_fault;
    // PHASE10A_RESUME_END
    logic h_req, h_done, h_valid;
    logic [31:0] h_addr, h_error_pc;
    diagnostic_reason_t h_reason;
    logic [31:0] pc, next_pc;
    logic [1:0] operand_index;
    logic stop_after_event;
    logic header_owns_reader;
    logic [32:0] command_end;
    logic fm_command, common_write_command;
    logic [7:0] third_operand;
    logic d_req, d_done, data_owns_reader, data_loop_crossed;
    logic [31:0] d_addr;
    diagnostic_reason_t d_reason;
    data_event_t d_data;
    assign data_owns_reader = state == DATA_START || state == DATA_WAIT;
    assign data_event_valid = state == DATA_EMIT;
    assign data_event_data = data_event_valid ? d_data : '0;
    assign dac_fact_valid = state == DAC_EMIT;
    always @* begin
        dac_fact_data = '0;
        if (dac_fact_valid) begin
            dac_fact_data.source_pc = event_data.source_pc;
            dac_fact_data.opcode = event_data.opcode;
            dac_fact_data.next_pc = next_pc;
            dac_fact_data.wait_samples = event_data.opcode[3:0];
        end
    end
    generate if (DATA_GRAMMAR) begin : data_grammar
        assign data_loop_crossed = loop_present && pc < loop_target && d_data.next_pc > loop_target;
        vgm_parser_vnext_data_decode grammar (
            .clk, .reset, .start(state == DATA_START), .command_pc(pc), .file_extent,
            .opcode(event_data.opcode), .reader_req_valid(d_req),
            .reader_req_ready(reader_req_ready && data_owns_reader), .reader_req_addr(d_addr),
            .reader_rsp_valid(reader_rsp_valid && data_owns_reader), .reader_rsp_byte,
            .done(d_done), .reason(d_reason), .result(d_data)
        );
    end else begin : frozen_grammar
        assign data_loop_crossed = 0;
        assign d_req = 0;
        assign d_done = 0;
        assign d_addr = 0;
        assign d_reason = REASON_NONE;
        assign d_data = '0;
    end endgenerate
    assign fm_command = (reader_rsp_byte == 8'h52 || reader_rsp_byte == 8'h53 ||
                         reader_rsp_byte == 8'h54 || reader_rsp_byte == 8'h55 ||
                         reader_rsp_byte == 8'h58 || reader_rsp_byte == 8'h59 ||
                         (COMMON_WRITE_GRAMMAR && reader_rsp_byte == 8'hba));

    assign common_write_command = COMMON_WRITE_GRAMMAR &&
        (reader_rsp_byte == 8'h4f || reader_rsp_byte == 8'hc0 || reader_rsp_byte == 8'hd4);

    // Combinational sideband; @* avoids Icarus packed-struct select notices.
    always @* begin
        write_info = '0;
        if (event_valid && event_data.kind == EVENT_WRITE) begin
            write_info.data = event_data.value[7:0];
            write_info.raw_operands = {third_operand, event_data.operands};
            if (event_data.opcode != 8'h50) begin
                write_info.access_kind = ACCESS_REGISTER;
                write_info.address = {8'd0, event_data.operands[7:0]};
            end
            case (event_data.opcode)
                8'h52, 8'h53: begin
                    write_info.chip = CHIP_YM2612;
                    write_info.port = (event_data.opcode == 8'h53);
                end
                8'h54: write_info.chip = CHIP_YM2151;
                8'hba: begin
                    write_info.chip = CHIP_K053260;
                    write_info.instance_id = event_data.operands[7];
                    write_info.address = {9'd0,event_data.operands[6:0]};
                end
                8'h55: write_info.chip = CHIP_YM2203;
                8'h58, 8'h59: begin
                    write_info.chip = CHIP_YM2610_FAMILY;
                    write_info.port = (event_data.opcode == 8'h59);
                end
                8'h4f: begin
                    write_info.chip = CHIP_PSG;
                    write_info.access_kind = ACCESS_CONTROL;
                    write_info.address = 16'h0006;
                end
                8'hc0: begin
                    write_info.chip = CHIP_SEGAPCM;
                    write_info.access_kind = ACCESS_MEMORY;
                    write_info.instance_id = event_data.operands[15];
                    write_info.address = {1'b0, event_data.operands[14:0]};
                end
                8'hd4: begin
                    write_info.chip = CHIP_C140;
                    write_info.instance_id = event_data.operands[7];
                    write_info.address = {1'b0, event_data.operands[6:0], event_data.operands[15:8]};
                end
                default: write_info.chip = CHIP_PSG;
            endcase
        end
    end

    vgm_parser_vnext_header_decode header (
        .clk, .reset, .start(state == HEADER_START), .image_size,
        .reader_req_valid(h_req),
        .reader_req_ready(reader_req_ready && header_owns_reader),
        .reader_req_addr(h_addr),
        .reader_rsp_valid(reader_rsp_valid && header_owns_reader),
        .reader_rsp_byte, .done(h_done), .valid(h_valid),
        .file_extent, .data_start, .loop_present, .loop_target,
        .reason(h_reason), .error_pc(h_error_pc)
    );

    assign header_owns_reader = (state == HEADER_START || state == HEADER_WAIT);
    assign reader_req_valid = header_owns_reader ? h_req : data_owns_reader ? d_req :
                              ((state == COMMAND_REQUEST && pc < file_extent) ||
                               state == OPERAND_REQUEST);
    assign reader_req_addr = header_owns_reader ? h_addr : data_owns_reader ? d_addr :
                             (state == OPERAND_REQUEST ? pc + 32'd1 +
                              {30'd0, operand_index} : pc);
    assign event_valid = (state == EMIT);
    assign loop_terminal_valid = (state == LOOP_TERMINAL);
    assign loop_terminal_pc = pc;
    // Operand length is grammar, not an engine capability check.
    always_comb begin
        command_end = {1'b0, pc} + 33'd1;
        if (reader_rsp_byte == 8'h50 || (common_write_command && reader_rsp_byte == 8'h4f)) command_end = {1'b0, pc} + 33'd2;
        if (reader_rsp_byte == 8'h61 || fm_command) command_end = {1'b0, pc} + 33'd3;
        if (common_write_command && reader_rsp_byte != 8'h4f) command_end = {1'b0, pc} + 33'd4;
    end

    task automatic reject(input diagnostic_reason_t why,
                          input logic [31:0] at, input logic [7:0] opcode);
        event_data <= '0;
        event_data.kind <= EVENT_DIAGNOSTIC;
        event_data.source_pc <= at;
        event_data.opcode <= opcode;
        event_data.reason <= why;
        stop_after_event <= 1;
        state <= EMIT;
    endtask

    always_ff @(posedge clk) begin
        if (reset) begin
            state <= IDLE;
            pc <= 0;
            next_pc <= 0;
            operand_index <= 0;
            third_operand <= 0;
            stop_after_event <= 0;
            event_data <= '0;
            done <= 0;
            loop_entry_seen <= 0;
            // PHASE10A_RESUME_BEGIN
            resume_allowed <= 0;
            resume_fault <= 0;
            // PHASE10A_RESUME_END
        end else begin
            case (state)
                IDLE, COMPLETE: if (start) begin
                    done <= 0;
                    // PHASE10A_RESUME_BEGIN
                    resume_allowed <= 0; resume_fault <= 0;
                    // PHASE10A_RESUME_END
                    loop_entry_seen <= 0;
                    stop_after_event <= 0;
                    event_data <= '0;
                    state <= HEADER_START;
                end
                // PHASE10A_RESUME_BEGIN
                else if (RESUME_CONTROL && resume_valid && resume_ready) begin
                    // The decoded traversal certified this exact command boundary.
                    // No header read, session reset, or grammar/event change.
                    if (resume_pc != loop_target || resume_pc < data_start || resume_pc >= file_extent)
                        resume_fault <= 1;
                    else begin
                        pc <= resume_pc; done <= 0; stop_after_event <= 0;
                        state <= COMMAND_REQUEST;
                    end
                end
                // PHASE10A_RESUME_END
                HEADER_START: state <= HEADER_WAIT;
                HEADER_WAIT: if (h_done) begin
                    if (!h_valid) reject(h_reason, h_error_pc, 0);
                    else begin pc <= data_start; state <= COMMAND_REQUEST; end
                end
                COMMAND_REQUEST: begin
                    if (pc >= file_extent) reject(REASON_TRUNCATED, pc, 0);
                    else if (reader_req_ready) state <= COMMAND_RESPONSE;
                end
                COMMAND_RESPONSE: if (reader_rsp_valid) begin
                    event_data <= '0;
                    third_operand <= 0;
                    event_data.source_pc <= pc;
                    event_data.opcode <= reader_rsp_byte;
                    if (loop_present && pc == loop_target) loop_entry_seen <= 1;
                    next_pc <= command_end[31:0];
                    stop_after_event <= 0;
                    if (DATA_GRAMMAR && (reader_rsp_byte == 8'h67 || reader_rsp_byte == 8'he0))
                        state <= DATA_START;
                    else if (reader_rsp_byte != 8'h50 && reader_rsp_byte != 8'h61 &&
                        reader_rsp_byte != 8'h62 && reader_rsp_byte != 8'h63 &&
                        reader_rsp_byte != 8'h66 && reader_rsp_byte[7:4] != 4'h7 && !fm_command && !common_write_command &&
                        !(DAC_GRAMMAR && reader_rsp_byte[7:4] == 4'h8))
                        reject(REASON_UNSUPPORTED_OPCODE, pc, reader_rsp_byte);
                    else if (command_end[32] || command_end > {1'b0, file_extent})
                        reject(REASON_TRUNCATED, pc, reader_rsp_byte);
                    else if (loop_present && pc < loop_target &&
                             command_end > {1'b0, loop_target})
                        reject(REASON_LOOP_NOT_BOUNDARY, pc, reader_rsp_byte);
                    else begin
                        case (reader_rsp_byte)
                            8'h50, 8'h4f, 8'hc0, 8'hd4, 8'h61, 8'h52, 8'h53, 8'h54, 8'h55, 8'h58, 8'h59, 8'hba: begin
                                if (reader_rsp_byte == 8'h61) event_data.kind <= EVENT_WAIT;
                                else event_data.kind <= EVENT_WRITE;
                                event_data.operand_count <= (reader_rsp_byte == 8'h50 || reader_rsp_byte == 8'h4f) ? 1 :
                                    (reader_rsp_byte == 8'hc0 || reader_rsp_byte == 8'hd4) ? 3 : 2;
                                operand_index <= 0;
                                state <= OPERAND_REQUEST;
                            end
                            8'h66: begin
                                if (loop_present) begin
                                    if (!loop_entry_seen && pc != loop_target)
                                        reject(REASON_LOOP_NOT_BOUNDARY, pc, 8'h66);
                                    else state <= LOOP_TERMINAL;
                                end else begin
                                    event_data.kind <= EVENT_END;
                                    stop_after_event <= 1;
                                    state <= EMIT;
                                end
                            end
                            default: begin
                                if (DAC_GRAMMAR && reader_rsp_byte[7:4] == 4'h8)
                                    state <= DAC_EMIT;
                                else begin
                                    event_data.kind <= EVENT_WAIT;
                                    event_data.value <= reader_rsp_byte == 8'h62 ? 16'd735 :
                                                        reader_rsp_byte == 8'h63 ? 16'd882 :
                                                        {12'd0, reader_rsp_byte[3:0]} + 16'd1;
                                    state <= EMIT;
                                end
                            end
                        endcase
                    end
                end
                OPERAND_REQUEST: if (reader_req_ready) state <= OPERAND_RESPONSE;
                OPERAND_RESPONSE: if (reader_rsp_valid) begin
                    if (operand_index == 0) begin
                        event_data.operands[7:0] <= reader_rsp_byte;
                        if (event_data.kind == EVENT_WAIT)
                            event_data.value[7:0] <= reader_rsp_byte;
                    end else if (operand_index == 1) begin
                        event_data.operands[15:8] <= reader_rsp_byte;
                        if (event_data.kind == EVENT_WAIT)
                            event_data.value[15:8] <= reader_rsp_byte;
                    end else third_operand <= reader_rsp_byte;
                    if (event_data.kind == EVENT_WRITE &&
                        operand_index + 1'b1 == event_data.operand_count)
                        event_data.value <= {8'd0, reader_rsp_byte};
                    if (operand_index + 1'b1 == event_data.operand_count) state <= EMIT;
                    else begin operand_index <= operand_index + 1'b1; state <= OPERAND_REQUEST; end
                end
                DATA_START: state <= DATA_WAIT;
                DATA_WAIT: if (DATA_GRAMMAR && d_done) begin
                    if (d_reason != REASON_NONE) reject(d_reason, pc, event_data.opcode);
                    else if (data_loop_crossed)
                        reject(REASON_LOOP_NOT_BOUNDARY, pc, event_data.opcode);
                    else state <= DATA_EMIT;
                end
                DATA_EMIT: if (event_ready) begin pc <= d_data.next_pc; state <= COMMAND_REQUEST; end
                DAC_EMIT: if (event_ready) begin pc <= next_pc; state <= COMMAND_REQUEST; end
                EMIT: if (event_ready) begin
                    if (stop_after_event) begin done <= 1; state <= COMPLETE; end
                    else begin pc <= next_pc; state <= COMMAND_REQUEST; end
                end
                LOOP_TERMINAL: if (event_ready) begin done <= 1; state <= COMPLETE;
                    // PHASE10A_RESUME_BEGIN
                    resume_allowed <= 1;
                    // PHASE10A_RESUME_END
                end
                default: state <= IDLE;
            endcase
        end
    end
endmodule
