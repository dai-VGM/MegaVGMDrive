// Passive Engine A chip-clock metadata capture at accepted Golden upload edges.
// Parser remains the sole file/header grammar validator. No ready/reset feedback.
module engine_a_vnext_uploaded_header_observer(
 input logic clk,reset,new_track,download,write_accepted,ym2151_write_accepted,
 input logic [31:0] address,input logic [7:0] data,
 input logic parser_header_valid,input logic [31:0] data_start,
 output logic [31:0] segapcm_clock,segapcm_interface,ym2203_clock,k053260_clock,
 output logic [1:0] activity_psg_source,
 output logic [31:0] ym2151_clock,output logic ym2151_clock_supported,
 output logic segapcm_clock_supported,
 output logic clock_commit,output logic [3:0] bank_shift,output logic [7:0] bank_mask
);
 logic [31:0] pcm_clock,pcm_interface,opn_clock;
 logic [31:0] konami_clock,sn_clock,opm_clock;
 assign k053260_clock=konami_clock;
 logic committed,ym2151_committed;
 logic [3:0] pcm_clock_seen,pcm_interface_seen;
 logic [31:0] selected_interface;
 assign segapcm_clock=parser_header_valid ? pcm_clock : 32'd0;
 assign segapcm_interface=parser_header_valid ? pcm_interface : 32'd0;
 // Admission uses the full delivered field; do not mask flags or substitute
 // a fallback for absent/incomplete metadata. Other nonzero single-chip
 // clocks remain unchanged (including the retained 4,026,987Hz fixture).
 assign segapcm_clock_supported=parser_header_valid && !download &&
   data_start>=32'h40 && (&pcm_clock_seen) && (&pcm_interface_seen) &&
   pcm_clock[31:30]==2'b00 && pcm_clock[29:0]!=0;
 // A long command stream does not imply that the extended header field exists.
 assign ym2203_clock=parser_header_valid && data_start>32'h47 ? opn_clock : 32'd0;
 assign clock_commit=parser_header_valid && !committed;
 assign selected_interface=segapcm_interface==0 ? 32'hc : segapcm_interface;
 assign bank_shift=selected_interface[3:0];
 assign bank_mask=8'h70 | (selected_interface[23:16] & 8'hfc);
 always_ff @(posedge clk)begin
  if(reset || new_track)begin pcm_clock_seen<=0;pcm_interface_seen<=0;pcm_clock<=0;pcm_interface<=0;opn_clock<=0;konami_clock<=0;sn_clock<=0;opm_clock<=0;ym2151_clock<=0;ym2151_clock_supported<=0;activity_psg_source<=0;committed<=0;ym2151_committed<=0;end
  else begin
   if(clock_commit)begin
    committed<=1;
    // SN takes deterministic priority if both headers advertise PSG sources.
    // No audio selection or Activity OR is introduced.
    activity_psg_source <= (sn_clock[29:0]!=0) ? 2'd1 :
      ((ym2203_clock[29:0]!=0) ? 2'd2 : 2'd0);
   end
   if(parser_header_valid && !download && !ym2151_committed)begin
    ym2151_committed<=1;
    ym2151_clock <= data_start>=32'h34 ? opm_clock : 32'd0;
    // Current admitted A clock set. Flags, absent and unsupported values
    // remain unaltered and are rejected on a PASS1 YM2151 WRITE.
    ym2151_clock_supported <= data_start>=32'h34 &&
      (opm_clock==32'd3579545 || opm_clock==32'd4000000 || opm_clock==32'd4026987);
   end
   // Same delivered index-1 edge as backend accept_wr; wait can rise
   // on this edge, after the sender has already committed the byte.
   if(download && ym2151_write_accepted && address>=32'h30 && address<=32'h33)
    opm_clock[address[1:0]*8+:8]<=data;
   // SegaPCM shares YM2151's delivered index-1 edge. Post-delivery wait
   // may rise on this cycle and must not discard an already delivered byte.
   if(download && ym2151_write_accepted)begin
    if(address>=32'h38 && address<=32'h3b)begin
     pcm_clock[address[1:0]*8+:8]<=data;pcm_clock_seen[address[1:0]]<=1;
    end
    if(address>=32'h3c && address<=32'h3f)begin
     pcm_interface[address[1:0]*8+:8]<=data;pcm_interface_seen[address[1:0]]<=1;
    end
   end
   if(download && write_accepted)begin
    if(address>=32'h0c && address<=32'h0f)sn_clock[address[1:0]*8+:8]<=data;
    if(address>=32'hac && address<=32'haf)konami_clock[address[1:0]*8+:8]<=data;
    if(address>=32'h44 && address<=32'h47)opn_clock[address[1:0]*8+:8]<=data;
   end
  end
 end
endmodule
