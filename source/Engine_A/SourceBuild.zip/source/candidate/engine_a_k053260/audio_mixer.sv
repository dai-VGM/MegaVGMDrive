// Final signed mixer used by the production mode-5 JT51/SegaPCM path when a
// YM2203 is present. The existing lanes arrive after the established OSD
// selector and SegaPCM gain handling. YM2203 is sampled independently, held
// between core sample strobes, and all lanes are added before one final clamp.
module k053260_candidate_audio_mixer (
    input logic signed [31:0] konami_l,konami_r,
    input logic konami_valid,konami_enable,
    input  logic               clk,
    input  logic               reset,
    input  logic signed [15:0] existing_nonpcm_l,
    input  logic signed [15:0] existing_nonpcm_r,
    input  logic signed [15:0] segapcm_l,
    input  logic signed [15:0] segapcm_r,
    input  logic signed [15:0] md_l,
    input  logic signed [15:0] md_r,
    input  logic signed [15:0] ym2203_raw_l,
    input  logic signed [15:0] ym2203_raw_r,
    input  logic               ym2203_raw_sample_valid,
    input  logic               ym2203_chip_present,
    input  logic               ym2203_lane_enable,
    output logic signed [15:0] ym2203_held_l,
    output logic signed [15:0] ym2203_held_r,
    output wire signed [15:0]  ym2203_selected_l,
    output wire signed [15:0]  ym2203_selected_r,
    output wire signed [17:0]  mix_sum_l,
    output wire signed [17:0]  mix_sum_r,
    output wire                mix_clipped_l,
    output wire                mix_clipped_r,
    output wire signed [15:0]  audio_l,
    output wire signed [15:0]  audio_r
);
    function automatic logic signed [15:0] saturate_18_to_16(
        input logic signed [17:0] value
    );
        begin
            if (value[17:15] == 3'b000 || value[17:15] == 3'b111) begin
                saturate_18_to_16 = value[15:0];
            end else begin
                saturate_18_to_16 = value[17] ? 16'sh8000 : 16'sh7fff;
            end
        end
    endfunction

    always_ff @(posedge clk) begin
        if (reset) begin
            ym2203_held_l <= 16'sd0;
            ym2203_held_r <= 16'sd0;
        end else if (ym2203_raw_sample_valid) begin
            ym2203_held_l <= ym2203_raw_l;
            ym2203_held_r <= ym2203_raw_r;
        end
    end

    assign ym2203_selected_l =
        (ym2203_chip_present && ym2203_lane_enable) ?
        ym2203_held_l : 16'sd0;
    assign ym2203_selected_r =
        (ym2203_chip_present && ym2203_lane_enable) ?
        ym2203_held_r : 16'sd0;
    assign mix_sum_l = {{2{existing_nonpcm_l[15]}}, existing_nonpcm_l} +
                       {{2{segapcm_l[15]}}, segapcm_l} +
                       {{2{md_l[15]}}, md_l} +
                       {{2{ym2203_selected_l[15]}}, ym2203_selected_l};
    assign mix_sum_r = {{2{existing_nonpcm_r[15]}}, existing_nonpcm_r} +
                       {{2{segapcm_r[15]}}, segapcm_r} +
                       {{2{md_r[15]}}, md_r} +
                       {{2{ym2203_selected_r[15]}}, ym2203_selected_r};
    assign mix_clipped_l = wide_l>32767 || wide_l< -32768;
    assign mix_clipped_r = wide_r>32767 || wide_r< -32768;
    logic signed [31:0] held_k_l,held_k_r;
    logic signed [32:0] wide_l,wide_r;
    always_ff @(posedge clk)begin
        if(reset || !konami_enable)begin held_k_l<=0;held_k_r<=0;end
        else if(konami_valid)begin held_k_l<=konami_l;held_k_r<=konami_r;end
    end
    assign wide_l={{15{mix_sum_l[17]}},mix_sum_l}+(konami_enable?{held_k_l[31],held_k_l}:33'sd0);
    assign wide_r={{15{mix_sum_r[17]}},mix_sum_r}+(konami_enable?{held_k_r[31],held_k_r}:33'sd0);
    function automatic logic signed [15:0] clamp(input logic signed [32:0] x);
        if(x>32767)clamp=16'sh7fff;else if(x< -32768)clamp=16'sh8000;else clamp=x[15:0];
    endfunction
    assign audio_l = clamp(wide_l);
    assign audio_r = clamp(wide_r);
endmodule
