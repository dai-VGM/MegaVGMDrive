// Candidate-only PASS1 admission. Common Parser owns grammar and resume-PC validation.
// Literal register writes reach a fixed point after one carried-state loop; extra
// carried traversals remain the fallback if the exact boundary state differs.
module k053260_resident_admission #(parameter bit ENABLE_FIXED_POINT=1)(
 input logic clk,reset,stop,start,input logic[31:0] clock_hz,data_start,file_extent,
 input logic event_valid,data_valid,dac_valid,terminal_valid,
 input vgm_parser_vnext_event_pkg::decode_event_t event_data,
 input vgm_parser_vnext_event_pkg::write_descriptor_t write_info,
 input vgm_parser_vnext_event_pkg::data_event_t data_fact,
 input logic loop_present,parser_done,resume_ready,input logic[31:0] loop_target,
 output logic event_ready,resume_valid,output logic[31:0] resume_pc,
 output logic requires_k,scanned,fault,output logic[7:0] fault_code,
 output logic[31:0] rom_size,output logic[5:0] block_count,
 output logic block_valid,input logic block_ready,output logic[31:0] block_start,block_bytes,block_file,
 output logic page_valid,input logic page_ready,output logic[10:0] page_number,output logic[8:0] page_count,output logic list_done
);
 import vgm_parser_vnext_event_pkg::*;
 typedef enum logic[2:0]{OFF,SCAN,WAIT_END,RESUME,SEAL,READY,BAD} state_t;
 state_t state;
 logic[1:0] traversal;logic first_key,audit_ready,audited,audit_fault,audit_seal,audit_write;
 logic[31:0] declared,rom_start;logic[32:0] rom_end,file_end;
 logic write_k;
 logic audit_checkpoint,audit_fixed_point,boundary_valid;
 logic[168:0] boundary_metadata,live_metadata;
 // The active file/clock/loop identity and descriptor authority must remain
 // fixed as well as the literal voice envelopes. No snapshot survives Reload.
 assign live_metadata={clock_hz,data_start,file_extent,loop_target,rom_size,
                       block_count,first_key,requires_k,loop_present};
 assign audit_checkpoint=state==WAIT_END && parser_done && audit_ready && traversal==0 && !fault;
 always_ff @(posedge clk)begin
  if(reset||stop||start)boundary_valid<=0;
  else if(ENABLE_FIXED_POINT && audit_checkpoint)begin
   boundary_metadata<=live_metadata;boundary_valid<=1;
  end
 end

 assign declared=data_fact.operands[79:48];assign rom_start=data_fact.operands[111:80];
 assign rom_end={1'b0,rom_start}+{1'b0,data_fact.payload_length};
 assign file_end={1'b0,data_fact.payload_offset}+{1'b0,data_fact.payload_length};
 assign write_k=event_valid&&event_data.kind==EVENT_WRITE&&write_info.chip==CHIP_K053260;
 assign event_ready=state==SCAN&&audit_ready&&(!data_valid||data_fact.block_type!=8'h8e||traversal!=0||data_fact.payload_length==0||block_ready)&&!fault;
 assign audit_write=event_ready&&write_k&&!write_info.instance_id&&write_info.address<64;
 assign audit_seal=state==SEAL;
 assign block_valid=state==SCAN&&audit_ready&&data_valid&&data_fact.block_type==8'h8e&&traversal==0&&data_fact.payload_length!=0&&!first_key&&!fault;
 assign block_start=rom_start;assign block_bytes=data_fact.payload_length;assign block_file=data_fact.payload_offset;
 assign resume_valid=state==RESUME&&!fault;assign resume_pc=loop_target;
 assign scanned=state==READY&&!fault;
 k053260_page_audit #(.ENABLE_FIXED_POINT(ENABLE_FIXED_POINT)) audit(.clk,.reset,.stop,.start,.write_valid(audit_write),.write_ready(audit_ready),
  .checkpoint(audit_checkpoint),.fixed_point(audit_fixed_point),
  .write_address(write_info.address[5:0]),.write_data(write_info.data),.seal(audit_seal),.audited,.fault(audit_fault),
  .page_count,.page_valid,.page_ready,.page_number,.list_done);
 task automatic reject(input logic[7:0] code);fault<=1;fault_code<=code;state<=BAD;endtask
 always_ff @(posedge clk)begin
  if(reset||stop)begin state<=OFF;fault<=0;fault_code<=0;rom_size<=0;block_count<=0;first_key<=0;traversal<=0;requires_k<=0;end
  else if(start)begin state<=SCAN;fault<=0;fault_code<=0;rom_size<=0;block_count<=0;first_key<=0;traversal<=0;requires_k<=0;end
  else if(audit_fault)reject(8'he1);
  else begin
  if(state==SCAN&&data_start>=32'hb0&&clock_hz!=0)requires_k<=1;
  case(state)
   OFF,BAD:begin end
   SCAN:if(event_ready&&(event_valid||data_valid||dac_valid||terminal_valid))begin
    if(event_valid&&event_data.kind==EVENT_DIAGNOSTIC)reject(8'he2);
    else if(event_valid&&event_data.kind==EVENT_WRITE&&(write_info.chip==CHIP_YM2610_FAMILY||write_info.chip==CHIP_C140))reject(8'he8);
    else if(data_valid&&(data_fact.kind==DATA_BLOCK&&data_fact.block_type!=0&&data_fact.block_type!=8'h80&&data_fact.block_type!=8'h8e))reject(8'he9);
    else if(write_k)begin
     requires_k<=1;
     if(clock_hz==0||clock_hz>3579545||clock_hz[31:30]!=0||data_start<32'hb0||write_info.instance_id||write_info.address>=64)reject(8'he3);
     else if(write_info.address==40&&write_info.data[3:0]!=0)first_key<=1;
    end
    else if(data_valid&&data_fact.block_type==8'h8e)begin
     requires_k<=1;
     if(data_fact.kind!=DATA_BLOCK||data_fact.instance_id||declared==0||declared>32'h400000||data_fact.metadata_bytes!=8||rom_end>{1'b0,declared}||file_end>{1'b0,file_extent}|| (rom_size!=0&&rom_size!=declared))reject(8'he4);
     else if(traversal==0)begin
      if(first_key||(data_fact.payload_length!=0&&block_count==32))reject(8'he5);
      else begin
       // A size-only declaration has no upload descriptor and never clears ROM.
       rom_size<=declared;if(data_fact.payload_length!=0)block_count<=block_count+1'b1;
      end
     end
     // Loop revisits refer to the same checked immutable file PCs, not new uploads.
    end
    if(terminal_valid||(event_valid&&event_data.kind==EVENT_END))state<=WAIT_END;
   end
   WAIT_END:if(parser_done&&audit_ready)begin
    // Always complete the first carried-state loop. Equal shadow/cache
    // and a monotonic union imply identical future intermediate ranges for
    // this immutable literal-write grammar. A mismatch keeps all four scans.
    if(loop_present&&traversal!=3 &&
       !(ENABLE_FIXED_POINT && traversal==1 && boundary_valid && audit_fixed_point &&
         live_metadata==boundary_metadata))state<=RESUME;
    else if(requires_k&&(rom_size==0||(page_count!=0&&block_count==0)))reject(8'he6);
    else state<=SEAL;
   end
   RESUME:if(resume_valid&&resume_ready)begin traversal<=traversal+1'b1;state<=SCAN;end
   SEAL:state<=READY;
   READY:begin end
   default:reject(8'he7);
  endcase
  end
 end
endmodule
