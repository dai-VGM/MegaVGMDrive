// Candidate resource preparation: immutable chronological block overlays -> file/gap
// fragments. Serialized descriptor resolution occurs only in LOADING, not native time.
module k053260_preload_plan(
 input logic clk,reset,stop,input logic[31:0] epoch,file_extent,rom_size,input logic[8:0] page_count,
 input logic begin_load,upload_complete,input logic[5:0] block_count,
 input logic block_valid,output logic block_ready,input logic[31:0] block_start,block_bytes,block_file,
 input logic page_valid,output logic page_ready,input logic[10:0] page_number,input logic list_done,
 output logic cfg_valid,input logic cfg_ready,
 output logic meta_valid,input logic meta_ready,output logic[31:0] meta_start,meta_bytes,meta_file,
 output logic store_page_valid,input logic store_page_ready,output logic[10:0] store_page_number,
 output logic commit_valid,input logic resident_ready,
 input logic store_fill_ready,input logic[8:0] pages_filled,
 output logic fill_valid,output logic[63:0] fill_data,output logic[31:0] fill_epoch,
 input logic reader_quiescent,output logic reader_valid,input logic reader_ready,
 output vgm_reader_vnext_pkg::read_request_t reader_request,
 input logic reader_response_valid,output logic reader_response_ready,input vgm_reader_vnext_pkg::read_response_t reader_response,
 input logic word_valid,input logic[31:0] word_id,word_epoch,input logic[63:0] word_data,
 output logic preload_idle,output logic fault,output logic[3:0] fault_code
);
 typedef enum logic[3:0]{CAPTURE,CFG,META_REQ,META_WAIT,META_SEND,PAGE_WAIT,RESOLVE_REQ,RESOLVE_CHECK,FRAGMENT,WORD_WAIT,COMMIT,DONE,BAD} state_t;
 state_t state;
 logic[95:0] descriptors[32],descriptor_q;
 logic[4:0] captured,descriptor_index;logic[31:0] base;
 logic[7:0] resident_word;logic[2:0] byte_index,fragment_cursor;
 logic[31:0] files[8];logic gaps[8];logic[3:0] fragment_count;
 logic[31:0] logical_byte,selected_start,selected_bytes,selected_file;
 logic[32:0] selected_end;
 logic segment_ready,preload_fault;logic[3:0] preload_code;
 logic segment_valid,segment_gap;logic[31:0] segment_file;logic[3:0] segment_bytes;
 logic[5:0] captured_count;
 assign block_ready=state==CAPTURE&&captured_count<32&&!stop&&!reset;
 always_ff @(posedge clk)begin
  descriptor_q<=descriptors[descriptor_index];
  if(block_valid&&block_ready)descriptors[captured]<={block_start,block_bytes,block_file};
 end
 assign selected_start=descriptor_q[95:64];assign selected_bytes=descriptor_q[63:32];assign selected_file=descriptor_q[31:0];
 assign selected_end={1'b0,selected_start}+{1'b0,selected_bytes};
 assign logical_byte=base+{21'd0,resident_word,byte_index};
 assign cfg_valid=state==CFG&&!stop&&!reset;
 assign meta_valid=state==META_SEND&&!stop&&!reset;
 assign meta_start=selected_start;assign meta_bytes=selected_bytes;assign meta_file=selected_file;
 assign page_ready=state==PAGE_WAIT&&store_page_ready&&!stop&&!reset;
 assign store_page_valid=state==PAGE_WAIT&&page_valid&&!stop&&!reset;assign store_page_number=page_number;
 assign commit_valid=state==COMMIT&&preload_idle&&reader_quiescent&&upload_complete&&!stop&&!reset;
 always_comb begin
  fragment_count=1;
  for(integer j=1;j<8;j=j+1)begin
   if(int'(fragment_cursor)+j<8 && int'(fragment_count)==j && gaps[int'(fragment_cursor)+j]==gaps[fragment_cursor] &&
    (gaps[fragment_cursor]||files[int'(fragment_cursor)+j]==files[fragment_cursor]+32'(j)))fragment_count=4'(j+1);
  end
 end
 assign segment_valid=state==FRAGMENT&&!stop&&!reset;
 assign segment_file=files[fragment_cursor];assign segment_gap=gaps[fragment_cursor];assign segment_bytes=fragment_count;
 k053260_resident_preloader transfer(.clk,.reset,.stop,.epoch,.file_extent,.reader_quiescent,
  .segment_valid,.segment_ready,.segment_file_address(segment_file),.segment_bytes,.segment_gap,
  .fill_valid,.fill_ready(store_fill_ready),.fill_data,.fill_epoch,
  .idle(preload_idle),.fault(preload_fault),.fault_code(preload_code),
  .reader_valid,.reader_ready,.reader_request,.reader_response_valid,.reader_response_ready,.reader_response,
  .word_valid,.word_id,.word_epoch,.word_data);
 task automatic bad(input logic[3:0] code);fault<=1;fault_code<=code;state<=BAD;endtask
 always_ff @(posedge clk)begin
  if(reset||stop)begin state<=CAPTURE;captured<=0;captured_count<=0;fault<=0;fault_code<=0;end
  else if(preload_fault)bad(preload_code);
  else case(state)
   CAPTURE:begin
    if(block_valid&&block_ready)begin captured<=captured+1'b1;captured_count<=captured_count+1'b1;end
    if(begin_load)begin
     if(!upload_complete||block_count==0||captured_count!=block_count)bad(4'd8);
     else begin state<=CFG;descriptor_index<=0;end
    end
   end
   CFG:if(cfg_valid&&cfg_ready)state<=META_REQ;
   META_REQ:state<=META_WAIT;
   META_WAIT:state<=META_SEND;
   META_SEND:if(meta_valid&&meta_ready)begin
    if({1'b0,descriptor_index}+6'd1==block_count)state<=PAGE_WAIT;
    else begin descriptor_index<=descriptor_index+1'b1;state<=META_REQ;end
   end
   PAGE_WAIT:if(page_valid&&page_ready)begin
    base<={10'd0,page_number,11'd0};resident_word<=0;byte_index<=0;descriptor_index<=0;
    for(integer i=0;i<8;i=i+1)begin files[i]<=0;gaps[i]<=1;end
    state<=RESOLVE_REQ;
   end else if(list_done&&pages_filled==page_count)state<=COMMIT;
   RESOLVE_REQ:state<=RESOLVE_CHECK;
   RESOLVE_CHECK:begin
    if({1'b0,logical_byte}>={1'b0,selected_start}&&{1'b0,logical_byte}<selected_end)begin
     files[byte_index]<=selected_file+(logical_byte-selected_start);gaps[byte_index]<=0;
    end
    if({1'b0,descriptor_index}+6'd1==block_count)begin
     descriptor_index<=0;
     if(byte_index==7)begin fragment_cursor<=0;state<=FRAGMENT;end
     else begin byte_index<=byte_index+1'b1;state<=RESOLVE_REQ;end
    end else begin descriptor_index<=descriptor_index+1'b1;state<=RESOLVE_REQ;end
   end
   FRAGMENT:if(segment_valid&&segment_ready)begin
    if({1'b0,fragment_cursor}+fragment_count==8)state<=WORD_WAIT;
    else fragment_cursor<=fragment_cursor+3'(fragment_count);
   end
   WORD_WAIT:if(fill_valid&&store_fill_ready)begin
    if(resident_word==255)state<=PAGE_WAIT;
    else begin
     resident_word<=resident_word+1'b1;byte_index<=0;descriptor_index<=0;
     for(integer i=0;i<8;i=i+1)begin files[i]<=0;gaps[i]<=1;end
     state<=RESOLVE_REQ;
    end
   end
   COMMIT:if(resident_ready)state<=DONE;
   DONE,BAD:begin end
   default:bad(4'd9);
  endcase
 end
endmodule
