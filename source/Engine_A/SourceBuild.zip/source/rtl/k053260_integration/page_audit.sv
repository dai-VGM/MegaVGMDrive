// Candidate chip-local preflight. Literal register envelopes, never playback execution.
module k053260_page_audit #(parameter bit ENABLE_FIXED_POINT=1)(
 input logic clk,reset,stop,start,
 input logic write_valid,output logic write_ready,input logic[5:0] write_address,input logic[7:0] write_data,
 input logic seal,output logic audited,fault,output logic[8:0] page_count,
 input logic checkpoint,output logic fixed_point,
 output logic page_valid,input logic page_ready,output logic[10:0] page_number,output logic list_done
);
 typedef enum logic[3:0]{OFF,CLEAR,IDLE,VOICE,LOOKUP,CHECK,ADVANCE,SEALED,LIST_REQ,LIST_CHECK,LIST_OFFER,FINISHED,BAD} state_t;
 state_t state;
 logic[20:0] sample_start[4];logic[15:0] sample_length[4];logic[7:0] keys;
 logic[2:0] voice;logic[9:0] cursor,last_page;logic reverse_direction;
 logic[10:0] clear_index,list_index,read_address;
 logic mask[2048];logic mask_q;
 logic write_mask;logic[10:0] mask_address;logic mask_value;
 logic[20:0] endpoint;
 // Monotonic page union: reuse only a voice envelope fully audited in this
 // admission. Literal shadow writes and all intermediate ranges are retained.
 logic[20:0] audited_start[4];
 logic[15:0] audited_length[4];
 logic[3:0] audited_valid,audited_reverse;
 // Exact boundary state, not a digest and not page-count-only admission.
 // Within one admission the page mask is monotonic: equal counts certify
 // no new pages only when all state determining future ranges also matches.
 logic boundary_valid;
 logic[155:0] boundary_shadow,boundary_cache,live_shadow,live_cache;
 logic[8:0] boundary_pages;
 assign live_shadow={sample_start[3],sample_start[2],sample_start[1],sample_start[0],
                     sample_length[3],sample_length[2],sample_length[1],sample_length[0],keys};
 genvar n;
 generate for(n=0;n<4;n=n+1)begin: cache_boundary
  // Invalid cache payload is uninitialized and has no semantic identity.
  assign live_cache[n*39+:39]=audited_valid[n] ?
    {1'b1,audited_start[n],audited_length[n],audited_reverse[n]} : 39'd0;
 end endgenerate
 assign fixed_point=ENABLE_FIXED_POINT && boundary_valid && state==IDLE && !fault &&
   !reset && !stop && !start && live_shadow==boundary_shadow &&
   live_cache==boundary_cache && page_count==boundary_pages;
 always_ff @(posedge clk)begin
  if(reset||stop||start)boundary_valid<=0;
  else if(ENABLE_FIXED_POINT && checkpoint && write_ready && !fault)begin
   boundary_shadow<=live_shadow;boundary_cache<=live_cache;
   boundary_pages<=page_count;boundary_valid<=1;
  end
 end
 assign endpoint=keys[voice[1:0]+4] ? sample_start[voice[1:0]]-{5'd0,sample_length[voice[1:0]]} : sample_start[voice[1:0]]+{5'd0,sample_length[voice[1:0]]};
 assign write_ready=state==IDLE&&!stop&&!reset;
 assign audited=state==SEALED||state==LIST_REQ||state==LIST_CHECK||state==LIST_OFFER||state==FINISHED;
 assign page_valid=state==LIST_OFFER&&!stop&&!reset;
 assign page_number=list_index;assign list_done=state==FINISHED;
 assign read_address=(state==LIST_REQ||state==LIST_CHECK||state==LIST_OFFER)?list_index:{1'b0,cursor};
 always_comb begin
  write_mask=0;mask_address=0;mask_value=0;
  if(!stop&&!reset)begin
   if(state==CLEAR)begin write_mask=1;mask_address=clear_index;end
   if(state==CHECK&&!mask_q&&page_count<192)begin write_mask=1;mask_address={1'b0,cursor};mask_value=1;end
  end
 end
 // Dedicated synchronous RAM port. Directory clear does not reset an inferred RAM.
 always_ff @(posedge clk)begin
  mask_q<=mask[read_address];
  if(write_mask)mask[mask_address]<=mask_value;
 end
 always_ff @(posedge clk)begin
  if(reset||stop)begin state<=OFF;page_count<=0;fault<=0;audited_valid<=0;end
  else if(start)begin
   state<=CLEAR;clear_index<=0;page_count<=0;fault<=0;keys<=0;voice<=0;list_index<=0;audited_valid<=0;
   for(integer i=0;i<4;i=i+1)begin sample_start[i]<=0;sample_length[i]<=0;end
  end else case(state)
   OFF:begin end
   CLEAR:if(clear_index==2047)state<=IDLE;else clear_index<=clear_index+1'b1;
   IDLE:if(write_valid&&write_ready)begin
    if(write_address>=8&&write_address<=39)case(write_address[2:0])
     2:sample_length[(write_address-8)>>3][7:0]<=write_data;
     3:sample_length[(write_address-8)>>3][15:8]<=write_data;
     4:sample_start[(write_address-8)>>3][7:0]<=write_data;
     5:sample_start[(write_address-8)>>3][15:8]<=write_data;
     6:sample_start[(write_address-8)>>3][20:16]<=write_data[4:0];
     default:begin end
    endcase
    if(write_address==40)keys<=write_data;
    voice<=0;state<=VOICE;
   end else if(seal)begin state<=SEALED;list_index<=0;end
   VOICE:if(voice==4)state<=IDLE;
    else if(!keys[voice])voice<=voice+1'b1;
    else if(audited_valid[voice[1:0]] &&
            audited_start[voice[1:0]]==sample_start[voice[1:0]] &&
            audited_length[voice[1:0]]==sample_length[voice[1:0]] &&
            audited_reverse[voice[1:0]]==keys[voice[1:0]+4])voice<=voice+1'b1;
    else begin cursor<=sample_start[voice[1:0]][20:11];last_page<=endpoint[20:11];reverse_direction<=keys[voice[1:0]+4];state<=LOOKUP;end
   LOOKUP:state<=CHECK;
   CHECK:begin
    if(!mask_q)begin
     if(page_count==192)begin fault<=1;state<=BAD;end
     else begin page_count<=page_count+1'b1;state<=ADVANCE;end
    end else state<=ADVANCE;
   end
   ADVANCE:if(cursor==last_page)begin
    // Never cache a partial scan or a capacity fault.
    audited_start[voice[1:0]]<=sample_start[voice[1:0]];
    audited_length[voice[1:0]]<=sample_length[voice[1:0]];
    audited_reverse[voice[1:0]]<=reverse_direction;
    audited_valid[voice[1:0]]<=1;
    voice<=voice+1'b1;state<=VOICE;
   end
    else begin cursor<=reverse_direction?cursor-1'b1:cursor+1'b1;state<=LOOKUP;end
   SEALED:state<=LIST_REQ;
   LIST_REQ:state<=LIST_CHECK;
   LIST_CHECK:if(mask_q)state<=LIST_OFFER;
    else if(list_index==1023)state<=FINISHED;
    else begin list_index<=list_index+1'b1;state<=LIST_REQ;end
   LIST_OFFER:if(page_valid&&page_ready)begin
    if(list_index==1023)state<=FINISHED;
    else begin list_index<=list_index+1'b1;state<=LIST_REQ;end
   end
   FINISHED,BAD:begin end
   default:begin state<=BAD;fault<=1;end
  endcase
 end
endmodule
