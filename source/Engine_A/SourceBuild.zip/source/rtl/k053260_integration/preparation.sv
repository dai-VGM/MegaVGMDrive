module k053260_resource_preparation #(parameter bit ENABLE_FIXED_POINT=1)(
 input logic clk,reset,stop,start,input logic[31:0] epoch,file_extent,clock_hz,data_start,
 input logic event_valid,data_valid,dac_valid,terminal_valid,
 input vgm_parser_vnext_event_pkg::decode_event_t event_data,
 input vgm_parser_vnext_event_pkg::write_descriptor_t write_info,
 input vgm_parser_vnext_event_pkg::data_event_t data_fact,
 input logic loop_present,parser_done,resume_ready,input logic[31:0] loop_target,
 output logic event_ready,resume_valid,output logic[31:0] resume_pc,
 input logic upload_complete,output logic requires_k,prepared,fault,output logic[7:0] fault_code,
 input logic reader_quiescent,output logic reader_valid,input logic reader_ready,
 output vgm_reader_vnext_pkg::read_request_t reader_request,
 input logic reader_response_valid,output logic reader_response_ready,input vgm_reader_vnext_pkg::read_response_t reader_response,
 input logic word_valid,input logic[31:0] word_id,word_epoch,input logic[63:0] word_data,
 input logic rom_valid,output logic rom_ready,input logic[20:0] chip_address,input logic[31:0] rom_id,rom_epoch,
 output logic rsp_valid,output logic[31:0] rsp_id,rsp_epoch,output logic[7:0] rsp_data,output logic[1:0] rsp_result,
 output logic[8:0] resident_pages
);
 logic preload_idle,store_ready,empty_plan_ready;
 logic scanned,scan_fault,plan_fault,store_fault;logic[7:0] scan_code;logic[3:0] plan_code,store_code;
 logic[31:0] rom_size;logic[5:0] block_count;
 logic block_valid,block_ready,page_valid,page_ready,list_done;
 logic[31:0] block_start,block_bytes,block_file;logic[10:0] page_number;
 logic cfg_valid,cfg_ready,meta_valid,meta_ready,store_page_valid,store_page_ready,commit_valid;
 logic[31:0] meta_start,meta_bytes,meta_file;logic[10:0] store_page_number;
 logic fill_valid,fill_ready;logic[63:0] fill_data;logic[31:0] fill_epoch;
 logic[8:0] pages_filled;
 // A complete scan with no sample pages needs no resident store. Latch only
 // after upload and Reader drain; live playback reads must not revoke READY.
 always_ff @(posedge clk) begin
  if(reset||stop||start)empty_plan_ready<=0;
  else if(scanned&&requires_k&&resident_pages==0&&upload_complete&&reader_quiescent&&preload_idle&&!fault)
   empty_plan_ready<=1;
 end
 assign prepared=scanned&&(!requires_k||empty_plan_ready||store_ready)&&!fault;
 assign fault=scan_fault||plan_fault||store_fault;
 assign fault_code=scan_fault?scan_code:plan_fault?{4'he,plan_code}:store_fault?{4'hf,store_code}:8'd0;
 k053260_resident_admission #(.ENABLE_FIXED_POINT(ENABLE_FIXED_POINT)) admission(.clk,.reset,.stop,.start,.clock_hz,.data_start,.file_extent,
  .event_valid,.data_valid,.dac_valid,.terminal_valid,.event_data,.write_info,.data_fact,
  .loop_present,.parser_done,.resume_ready,.loop_target,.event_ready,.resume_valid,.resume_pc,
  .requires_k,.scanned,.fault(scan_fault),.fault_code(scan_code),.rom_size,.block_count,
  .block_valid,.block_ready,.block_start,.block_bytes,.block_file,
  .page_valid,.page_ready,.page_number,.page_count(resident_pages),.list_done);
 k053260_preload_plan plan(.clk,.reset,.stop,.epoch,.file_extent,.rom_size,.page_count(resident_pages),
  .begin_load(scanned&&requires_k&&resident_pages!=0&&!fault),.upload_complete,.block_count,.block_valid,.block_ready,.block_start,.block_bytes,.block_file,
  .page_valid,.page_ready,.page_number,.list_done,.cfg_valid,.cfg_ready,.meta_valid,.meta_ready,.meta_start,.meta_bytes,.meta_file,
  .store_page_valid,.store_page_ready,.store_page_number,.commit_valid,.resident_ready(store_ready),.store_fill_ready(fill_ready),.pages_filled,
  .fill_valid,.fill_data,.fill_epoch,.reader_quiescent,.reader_valid,.reader_ready,.reader_request,
  .reader_response_valid,.reader_response_ready,.reader_response,.word_valid,.word_id,.word_epoch,.word_data,
  .preload_idle,.fault(plan_fault),.fault_code(plan_code));
 k053260_resident_store store(.clk,.reset,.stop,.epoch,.cfg_valid,.cfg_ready,.cfg_rom_size(rom_size),.file_extent,
  .cfg_pages(resident_pages),.upload_complete,.block_valid(meta_valid),.block_ready(meta_ready),.block_rom_size(rom_size),
  .block_start(meta_start),.block_bytes(meta_bytes),.block_file(meta_file),.block_late(1'b0),
  .page_valid(store_page_valid),.page_ready(store_page_ready),.page_number(store_page_number),
  .fill_valid,.fill_ready,.fill_data,.fill_epoch,.commit_valid,.preload_idle,
  .resident_ready(store_ready),.loading(),.fault(store_fault),.fault_code(store_code),.pages_filled,.generation(),
  .rom_valid,.rom_ready,.logical_address({1'b0,chip_address}),.rom_id,.rom_epoch,.rsp_valid,.rsp_id,.rsp_epoch,.rsp_data,.rsp_result);
endmodule
