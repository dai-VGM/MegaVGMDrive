// SPDX-License-Identifier: GPL-2.0-or-later
//
// Observation-only Engine A channel activity. The decoder watches accepted
// parser-to-chip writes; none of these signals feed back into audio or
// transport control.

module megavgm_engine_a_activity_source (
	input  logic        clk,
	input  logic        reset,
	input  logic        ym_cmd_valid,
	input  logic        ym_cmd_ready,
	input  logic        ym_cmd_port,
	input  logic [7:0]  ym_cmd_reg,
	input  logic [7:0]  ym_cmd_data,
	input  logic        ym2151_cmd_valid,
	input  logic        ym2151_cmd_ready,
	input  logic [7:0]  ym2151_cmd_reg,
	input  logic [7:0]  ym2151_cmd_data,
	input  logic        segapcm_cmd_valid,
	input  logic [15:0] segapcm_cmd_addr,
	input  logic        ym2203_cmd_valid,
	input  logic        ym2203_cmd_ready,
	input  logic [7:0]  ym2203_cmd_reg,
	input  logic [7:0]  ym2203_cmd_data,
	input  logic        psg_cmd_valid,
	input  logic        psg_cmd_ready,
	input  logic [7:0]  psg_cmd_data,
	output logic [39:0] channel_activity_event
);

	logic [1:0] psg_latched_channel;
	logic [1:0] psg_write_channel;

	always_ff @(posedge clk) begin
		if(reset)
			psg_latched_channel <= 2'd0;
		else if(psg_cmd_valid && psg_cmd_ready && psg_cmd_data[7])
			psg_latched_channel <= psg_cmd_data[6:5];
	end

	always_comb begin
		channel_activity_event = 40'd0;
		psg_write_channel = psg_cmd_data[7] ?
			psg_cmd_data[6:5] : psg_latched_channel;

		// YM2612: key-on selects 0,1,2,4,5,6; channel registers use
		// port*3 + register[1:0]. DAC data belongs to channel 6.
		if(ym_cmd_valid && ym_cmd_ready) begin
			if(!ym_cmd_port && (ym_cmd_reg == 8'h28) &&
			   (ym_cmd_data[7:4] != 4'd0)) begin
				unique case(ym_cmd_data[2:0])
					3'd0: channel_activity_event[0] = 1'b1;
					3'd1: channel_activity_event[1] = 1'b1;
					3'd2: channel_activity_event[2] = 1'b1;
					3'd4: channel_activity_event[3] = 1'b1;
					3'd5: channel_activity_event[4] = 1'b1;
					3'd6: channel_activity_event[5] = 1'b1;
					default: ;
				endcase
			end
			else if(!ym_cmd_port && (ym_cmd_reg == 8'h2a)) begin
				channel_activity_event[5] = 1'b1;
			end
			else if((ym_cmd_reg >= 8'h30) && (ym_cmd_reg <= 8'hb6) &&
			        (ym_cmd_reg[1:0] != 2'b11)) begin
				if((ym_cmd_reg >= 8'ha8) && (ym_cmd_reg <= 8'hae))
					channel_activity_event[2] = 1'b1;
				else if(ym_cmd_port)
					channel_activity_event[6'd3 + {4'd0, ym_cmd_reg[1:0]}] = 1'b1;
				else
					channel_activity_event[{4'd0, ym_cmd_reg[1:0]}] = 1'b1;
			end
		end

		// YM2151 channel registers carry the channel in register[2:0].
		// Register 08 is the explicit operator key-on command.
		if(ym2151_cmd_valid && ym2151_cmd_ready) begin
			if((ym2151_cmd_reg == 8'h08) &&
			   (ym2151_cmd_data[6:3] != 4'd0))
				channel_activity_event[6'd6 + {3'd0, ym2151_cmd_data[2:0]}] = 1'b1;
			else if(ym2151_cmd_reg >= 8'h20)
				channel_activity_event[6'd6 + {3'd0, ym2151_cmd_reg[2:0]}] = 1'b1;
		end

		// Every SegaPCM register is in one of sixteen 8-byte channel slots.
		if(segapcm_cmd_valid)
			channel_activity_event[6'd14 + {2'd0, segapcm_cmd_addr[6:3]}] = 1'b1;

		// YM2203 FM channel registers map like YM2612 port 0. SSG tone
		// period and level registers are unambiguously channel-specific.
		if(ym2203_cmd_valid && ym2203_cmd_ready) begin
			if((ym2203_cmd_reg == 8'h28) &&
			   (ym2203_cmd_data[7:4] != 4'd0) &&
			   (ym2203_cmd_data[1:0] != 2'b11))
				channel_activity_event[6'd30 + {4'd0, ym2203_cmd_data[1:0]}] = 1'b1;
			else if((ym2203_cmd_reg >= 8'h30) &&
			        (ym2203_cmd_reg <= 8'hb6) &&
			        (ym2203_cmd_reg[1:0] != 2'b11))
				channel_activity_event[6'd30 + {4'd0, ym2203_cmd_reg[1:0]}] = 1'b1;
			else begin
				unique case(ym2203_cmd_reg)
					8'h00, 8'h01, 8'h08: channel_activity_event[33] = 1'b1;
					8'h02, 8'h03, 8'h09: channel_activity_event[34] = 1'b1;
					8'h04, 8'h05, 8'h0a: channel_activity_event[35] = 1'b1;
					default: ;
				endcase
			end
		end

		// SN76489 latch bytes select the channel; continuation bytes retain it.
		if(psg_cmd_valid && psg_cmd_ready)
			channel_activity_event[6'd36 + {4'd0, psg_write_channel}] = 1'b1;
	end

endmodule

module megavgm_source_activity_hold #(
	parameter int WIDTH = 40
) (
	input  logic             clk,
	input  logic             reset,
	input  logic             vblank_start,
	input  logic [WIDTH-1:0] source_event,
	output logic [WIDTH-1:0] source_activity
);

	logic [WIDTH-1:0] frame_accumulator;
	logic [WIDTH-1:0] current_frame;
	logic [WIDTH-1:0] previous_frame;

	always_ff @(posedge clk) begin
		if(reset) begin
			frame_accumulator <= '0;
			current_frame <= '0;
			previous_frame <= '0;
		end
		else if(vblank_start) begin
			// Include an event coincident with the VBlank boundary.
			previous_frame <= current_frame;
			current_frame <= frame_accumulator | source_event;
			frame_accumulator <= '0;
		end
		else begin
			frame_accumulator <= frame_accumulator | source_event;
		end
	end

	always_comb source_activity = current_frame | previous_frame;

endmodule
