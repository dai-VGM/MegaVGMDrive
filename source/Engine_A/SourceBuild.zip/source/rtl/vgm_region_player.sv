// Synthesizable fixed-region VGM player for first MiSTer hardware bring-up.
//
// This is intentionally tiny: it does not load files, parse VGZ, handle loops,
// or expose an SD/HPS interface. It only plays one built-in VGM-like command
// region after reset/start, then stops.
//
// Connect this module to md_sound_module like this:
//
//   vgm_region_player -> ym_cmd_valid/port/reg/data -> md_sound_module
//                     -> psg_cmd_valid/data          -> md_sound_module
//
// Wait commands count vgm_wait_tick rising edges. Keep this separate from
// audio_sample_valid: JT12's sample strobe is useful for audio dumping/debug,
// but VGM waits are defined in 44100 Hz VGM sample units.
//
// Default region mode:
//   0 = proven hardware bring-up tone
//   1 = short VGM-style snippet for the next hardware check
//   2 = short real-VGM-derived YM/PSG snippet
//   3 = longer real-VGM-derived YM/PSG phrase
//   4 = timing calibration, 1 second tone / 1 second silence
//
// Temporary hardware-source check:
//   fixed_region_mode.vh currently defaults to REGION_MODE=2 without depending
//   on a QSF VERILOG_MACRO. If the real MiSTer build still behaves differently,
//   Quartus is likely using an older source tree or an older RBF.
`include "rtl/fixed_region_mode.vh"

module vgm_region_player #(
    parameter int REGION_MODE = `FIXED_REGION_MODE
) (
    input  logic       clk,
    input  logic       reset,

    // Hold high to auto-start after reset, or pulse high to start once.
    input  logic       start,

    // Dedicated VGM wait timing strobe. One rising edge is one VGM sample.
    // For standard VGM timing, drive this at 44100 Hz.
    input  logic       vgm_wait_tick,

    // Command-ready handshakes from md_sound_module.
    input  logic       ym_cmd_ready,
    input  logic       psg_cmd_ready,

    // YM2612 command output, matching md_sound_module inputs.
    output logic       ym_cmd_valid,
    output logic       ym_cmd_port,
    output logic [7:0] ym_cmd_reg,
    output logic [7:0] ym_cmd_data,

    // SN76489 command output, matching md_sound_module inputs.
    output logic       psg_cmd_valid,
    output logic [7:0] psg_cmd_data,

    // Bring-up status.
    output logic       busy,
    output logic       done,
    output logic [9:0] pc_debug,
    output logic [7:0] last_cmd_debug
);

    typedef enum logic [3:0] {
        ST_IDLE,
        ST_FETCH,
        ST_DECODE,
        ST_YM_WAIT_READY,
        ST_YM_PULSE,
        ST_PSG_WAIT_READY,
        ST_PSG_PULSE,
        ST_WAIT_SAMPLES,
        ST_DONE
    } state_t;

    state_t state;

    logic [12:0] pc;
    logic [7:0] cmd;

    logic [15:0] wait_remaining;
    logic        vgm_wait_tick_d;

    logic [9:0] pcm_pos;

    assign pc_debug = pc[9:0];

    localparam int REGION_MODE_BRINGUP_TONE = 0;
    localparam int REGION_MODE_VGM_SNIPPET  = 1;
    localparam int REGION_MODE_VGM_REAL_SNIPPET = 2;
    localparam int REGION_MODE_VGM_REAL_PHRASE  = 3;
    localparam int REGION_MODE_TIMING_CALIBRATION = 4;

    // Small fixed command ROM.
    //
    // Supported opcodes in this bring-up ROM:
    //   0x52 rr dd       YM2612 port 0 write
    //   0x53 rr dd       YM2612 port 1 write
    //   0x4f dd          Game Gear stereo command, skipped here
    //   0x50 dd          SN76489 write
    //   0x61 ll hh       wait n samples
    //   0x70-0x7f        short wait 1..16 samples
    //   0xe0 oooo        PCM bank seek, used by following 0x80-0x8f commands
    //   0x80-0x8f        generate YM 0x2A DAC data write, then wait low nibble
    //   0x66             end
    //
    // The YM register sequence is a compact channel-1 tone based on the
    // successful TEST_YM_TONE setup. For real hardware bring-up, the ROM keeps
    // the FM tone audible for about two seconds, silences it, then plays a PSG
    // tone for about two seconds before the final silence/end sequence.
    function automatic logic [7:0] bringup_tone_rom_byte(input logic [12:0] addr);
        unique case (addr)
            // YM setup: LFO/timer/DAC off/key off.
            10'd0:   bringup_tone_rom_byte = 8'h52; 10'd1:   bringup_tone_rom_byte = 8'h28; 10'd2:   bringup_tone_rom_byte = 8'h00;
            10'd3:   bringup_tone_rom_byte = 8'h52; 10'd4:   bringup_tone_rom_byte = 8'h22; 10'd5:   bringup_tone_rom_byte = 8'h00;
            10'd6:   bringup_tone_rom_byte = 8'h52; 10'd7:   bringup_tone_rom_byte = 8'h27; 10'd8:   bringup_tone_rom_byte = 8'h00;
            10'd9:   bringup_tone_rom_byte = 8'h52; 10'd10:  bringup_tone_rom_byte = 8'h2B; 10'd11:  bringup_tone_rom_byte = 8'h00;

            // Detune/multiple.
            10'd12:  bringup_tone_rom_byte = 8'h52; 10'd13:  bringup_tone_rom_byte = 8'h30; 10'd14:  bringup_tone_rom_byte = 8'h01;
            10'd15:  bringup_tone_rom_byte = 8'h52; 10'd16:  bringup_tone_rom_byte = 8'h34; 10'd17:  bringup_tone_rom_byte = 8'h01;
            10'd18:  bringup_tone_rom_byte = 8'h52; 10'd19:  bringup_tone_rom_byte = 8'h38; 10'd20:  bringup_tone_rom_byte = 8'h01;
            10'd21:  bringup_tone_rom_byte = 8'h52; 10'd22:  bringup_tone_rom_byte = 8'h3C; 10'd23:  bringup_tone_rom_byte = 8'h01;

            // Total level.
            10'd24:  bringup_tone_rom_byte = 8'h52; 10'd25:  bringup_tone_rom_byte = 8'h40; 10'd26:  bringup_tone_rom_byte = 8'h28;
            10'd27:  bringup_tone_rom_byte = 8'h52; 10'd28:  bringup_tone_rom_byte = 8'h44; 10'd29:  bringup_tone_rom_byte = 8'h28;
            10'd30:  bringup_tone_rom_byte = 8'h52; 10'd31:  bringup_tone_rom_byte = 8'h48; 10'd32:  bringup_tone_rom_byte = 8'h28;
            10'd33:  bringup_tone_rom_byte = 8'h52; 10'd34:  bringup_tone_rom_byte = 8'h4C; 10'd35:  bringup_tone_rom_byte = 8'h28;

            // Attack rate.
            10'd36:  bringup_tone_rom_byte = 8'h52; 10'd37:  bringup_tone_rom_byte = 8'h50; 10'd38:  bringup_tone_rom_byte = 8'h1F;
            10'd39:  bringup_tone_rom_byte = 8'h52; 10'd40:  bringup_tone_rom_byte = 8'h54; 10'd41:  bringup_tone_rom_byte = 8'h1F;
            10'd42:  bringup_tone_rom_byte = 8'h52; 10'd43:  bringup_tone_rom_byte = 8'h58; 10'd44:  bringup_tone_rom_byte = 8'h1F;
            10'd45:  bringup_tone_rom_byte = 8'h52; 10'd46:  bringup_tone_rom_byte = 8'h5C; 10'd47:  bringup_tone_rom_byte = 8'h1F;

            // Decay/sustain/release.
            10'd48:  bringup_tone_rom_byte = 8'h52; 10'd49:  bringup_tone_rom_byte = 8'h60; 10'd50:  bringup_tone_rom_byte = 8'h00;
            10'd51:  bringup_tone_rom_byte = 8'h52; 10'd52:  bringup_tone_rom_byte = 8'h64; 10'd53:  bringup_tone_rom_byte = 8'h00;
            10'd54:  bringup_tone_rom_byte = 8'h52; 10'd55:  bringup_tone_rom_byte = 8'h68; 10'd56:  bringup_tone_rom_byte = 8'h00;
            10'd57:  bringup_tone_rom_byte = 8'h52; 10'd58:  bringup_tone_rom_byte = 8'h6C; 10'd59:  bringup_tone_rom_byte = 8'h00;
            10'd60:  bringup_tone_rom_byte = 8'h52; 10'd61:  bringup_tone_rom_byte = 8'h80; 10'd62:  bringup_tone_rom_byte = 8'h0F;
            10'd63:  bringup_tone_rom_byte = 8'h52; 10'd64:  bringup_tone_rom_byte = 8'h84; 10'd65:  bringup_tone_rom_byte = 8'h0F;
            10'd66:  bringup_tone_rom_byte = 8'h52; 10'd67:  bringup_tone_rom_byte = 8'h88; 10'd68:  bringup_tone_rom_byte = 8'h0F;
            10'd69:  bringup_tone_rom_byte = 8'h52; 10'd70:  bringup_tone_rom_byte = 8'h8C; 10'd71:  bringup_tone_rom_byte = 8'h0F;

            // Frequency, algorithm, pan, key on.
            10'd72:  bringup_tone_rom_byte = 8'h52; 10'd73:  bringup_tone_rom_byte = 8'hA4; 10'd74:  bringup_tone_rom_byte = 8'h22;
            10'd75:  bringup_tone_rom_byte = 8'h52; 10'd76:  bringup_tone_rom_byte = 8'hA0; 10'd77:  bringup_tone_rom_byte = 8'h69;
            10'd78:  bringup_tone_rom_byte = 8'h52; 10'd79:  bringup_tone_rom_byte = 8'hB0; 10'd80:  bringup_tone_rom_byte = 8'h07;
            10'd81:  bringup_tone_rom_byte = 8'h52; 10'd82:  bringup_tone_rom_byte = 8'hB4; 10'd83:  bringup_tone_rom_byte = 8'hC0;
            10'd84:  bringup_tone_rom_byte = 8'h52; 10'd85:  bringup_tone_rom_byte = 8'h28; 10'd86:  bringup_tone_rom_byte = 8'hF0;

            // FM tone hold: two 44100-sample waits, about two seconds total.
            10'd87:  bringup_tone_rom_byte = 8'h61; 10'd88:  bringup_tone_rom_byte = 8'h44; 10'd89:  bringup_tone_rom_byte = 8'hAC;
            10'd90:  bringup_tone_rom_byte = 8'h61; 10'd91:  bringup_tone_rom_byte = 8'h44; 10'd92:  bringup_tone_rom_byte = 8'hAC;

            // Silence FM and keep DAC safely off before the PSG-only section.
            10'd93:  bringup_tone_rom_byte = 8'h52; 10'd94:  bringup_tone_rom_byte = 8'h28; 10'd95:  bringup_tone_rom_byte = 8'h00;
            10'd96:  bringup_tone_rom_byte = 8'h52; 10'd97:  bringup_tone_rom_byte = 8'h2A; 10'd98:  bringup_tone_rom_byte = 8'h00;
            10'd99:  bringup_tone_rom_byte = 8'h52; 10'd100: bringup_tone_rom_byte = 8'h2B; 10'd101: bringup_tone_rom_byte = 8'h00;
            10'd102: bringup_tone_rom_byte = 8'h61; 10'd103: bringup_tone_rom_byte = 8'h00; 10'd104: bringup_tone_rom_byte = 8'h04;

            // PSG tone, same basic command shape as TEST_PSG_TONE. Other PSG
            // channels stay muted so the bring-up tone is easy to identify.
            10'd105: bringup_tone_rom_byte = 8'h50; 10'd106: bringup_tone_rom_byte = 8'hBF;
            10'd107: bringup_tone_rom_byte = 8'h50; 10'd108: bringup_tone_rom_byte = 8'hDF;
            10'd109: bringup_tone_rom_byte = 8'h50; 10'd110: bringup_tone_rom_byte = 8'hFF;
            10'd111: bringup_tone_rom_byte = 8'h50; 10'd112: bringup_tone_rom_byte = 8'h80;
            10'd113: bringup_tone_rom_byte = 8'h50; 10'd114: bringup_tone_rom_byte = 8'h10;
            10'd115: bringup_tone_rom_byte = 8'h50; 10'd116: bringup_tone_rom_byte = 8'h90;

            // PSG tone hold: two 44100-sample waits, about two seconds total.
            10'd117: bringup_tone_rom_byte = 8'h61; 10'd118: bringup_tone_rom_byte = 8'h44; 10'd119: bringup_tone_rom_byte = 8'hAC;
            10'd120: bringup_tone_rom_byte = 8'h61; 10'd121: bringup_tone_rom_byte = 8'h44; 10'd122: bringup_tone_rom_byte = 8'hAC;

            // Explicit final silence sequence for hardware bring-up:
            // key off FM ch1, clear DAC data, keep DAC disabled, mute all PSG
            // channels, then wait briefly before reporting end.
            10'd123: bringup_tone_rom_byte = 8'h52; 10'd124: bringup_tone_rom_byte = 8'h28; 10'd125: bringup_tone_rom_byte = 8'h00;
            10'd126: bringup_tone_rom_byte = 8'h52; 10'd127: bringup_tone_rom_byte = 8'h2A; 10'd128: bringup_tone_rom_byte = 8'h00;
            10'd129: bringup_tone_rom_byte = 8'h52; 10'd130: bringup_tone_rom_byte = 8'h2B; 10'd131: bringup_tone_rom_byte = 8'h00;
            10'd132: bringup_tone_rom_byte = 8'h50; 10'd133: bringup_tone_rom_byte = 8'h9F;
            10'd134: bringup_tone_rom_byte = 8'h50; 10'd135: bringup_tone_rom_byte = 8'hBF;
            10'd136: bringup_tone_rom_byte = 8'h50; 10'd137: bringup_tone_rom_byte = 8'hDF;
            10'd138: bringup_tone_rom_byte = 8'h50; 10'd139: bringup_tone_rom_byte = 8'hFF;

            // Let the silence writes settle, then stop.
            10'd140: bringup_tone_rom_byte = 8'h61; 10'd141: bringup_tone_rom_byte = 8'h00; 10'd142: bringup_tone_rom_byte = 8'h04;
            10'd143: bringup_tone_rom_byte = 8'h66;

            default: bringup_tone_rom_byte = 8'h66;
        endcase
    endfunction

    function automatic logic [7:0] vgm_snippet_rom_byte(input logic [12:0] addr);
        if (addr <= 10'd19) begin
            unique case (addr)
                // Explicit cold-boot silence initialization before the audible
                // snippet body. This is intentionally duplicated in the
                // VGM_SNIPPET path and does not modify BRINGUP_TONE.
                10'd0:  vgm_snippet_rom_byte = 8'h52; 10'd1:  vgm_snippet_rom_byte = 8'h28; 10'd2:  vgm_snippet_rom_byte = 8'h00;
                10'd3:  vgm_snippet_rom_byte = 8'h52; 10'd4:  vgm_snippet_rom_byte = 8'h2A; 10'd5:  vgm_snippet_rom_byte = 8'h00;
                10'd6:  vgm_snippet_rom_byte = 8'h52; 10'd7:  vgm_snippet_rom_byte = 8'h2B; 10'd8:  vgm_snippet_rom_byte = 8'h00;
                10'd9:  vgm_snippet_rom_byte = 8'h50; 10'd10: vgm_snippet_rom_byte = 8'h9F;
                10'd11: vgm_snippet_rom_byte = 8'h50; 10'd12: vgm_snippet_rom_byte = 8'hBF;
                10'd13: vgm_snippet_rom_byte = 8'h50; 10'd14: vgm_snippet_rom_byte = 8'hDF;
                10'd15: vgm_snippet_rom_byte = 8'h50; 10'd16: vgm_snippet_rom_byte = 8'hFF;
                10'd17: vgm_snippet_rom_byte = 8'h61; 10'd18: vgm_snippet_rom_byte = 8'h44; 10'd19: vgm_snippet_rom_byte = 8'hAC;
                default: vgm_snippet_rom_byte = 8'h66;
            endcase
        end else if (addr <= 10'd106) begin
            // Reuse the exact YM init/timbre/frequency/pan/key-on sequence
            // that already produced sound on MiSTer hardware.
            vgm_snippet_rom_byte = bringup_tone_rom_byte(addr - 10'd20);
        end else begin
            unique case (addr)
                // Known-good FM lead-in: 44100 samples, about one second.
                10'd107: vgm_snippet_rom_byte = 8'h61; 10'd108: vgm_snippet_rom_byte = 8'h44; 10'd109: vgm_snippet_rom_byte = 8'hAC;

                // Key off FM and keep DAC safely disabled before PSG testing.
                10'd110: vgm_snippet_rom_byte = 8'h52; 10'd111: vgm_snippet_rom_byte = 8'h28; 10'd112: vgm_snippet_rom_byte = 8'h00;
                10'd113: vgm_snippet_rom_byte = 8'h52; 10'd114: vgm_snippet_rom_byte = 8'h2A; 10'd115: vgm_snippet_rom_byte = 8'h00;
                10'd116: vgm_snippet_rom_byte = 8'h52; 10'd117: vgm_snippet_rom_byte = 8'h2B; 10'd118: vgm_snippet_rom_byte = 8'h00;
                10'd119: vgm_snippet_rom_byte = 8'h61; 10'd120: vgm_snippet_rom_byte = 8'h74; 10'd121: vgm_snippet_rom_byte = 8'h22;

                // PSG setup: mute ch1/ch2/noise and ch0 before the note test.
                10'd122: vgm_snippet_rom_byte = 8'h50; 10'd123: vgm_snippet_rom_byte = 8'h9F;
                10'd124: vgm_snippet_rom_byte = 8'h50; 10'd125: vgm_snippet_rom_byte = 8'hBF;
                10'd126: vgm_snippet_rom_byte = 8'h50; 10'd127: vgm_snippet_rom_byte = 8'hDF;
                10'd128: vgm_snippet_rom_byte = 8'h50; 10'd129: vgm_snippet_rom_byte = 8'hFF;
                10'd130: vgm_snippet_rom_byte = 8'h61; 10'd131: vgm_snippet_rom_byte = 8'h74; 10'd132: vgm_snippet_rom_byte = 8'h22;

                // PSG ch0 note 1: period 0x180, loud enough to identify.
                // SN76489 tone writes are latch-low-nibble, data-high-bits,
                // then volume. This avoids treating the period as one byte.
                10'd133: vgm_snippet_rom_byte = 8'h50; 10'd134: vgm_snippet_rom_byte = 8'h80;
                10'd135: vgm_snippet_rom_byte = 8'h50; 10'd136: vgm_snippet_rom_byte = 8'h18;
                10'd137: vgm_snippet_rom_byte = 8'h50; 10'd138: vgm_snippet_rom_byte = 8'h91;
                10'd139: vgm_snippet_rom_byte = 8'h61; 10'd140: vgm_snippet_rom_byte = 8'hE8; 10'd141: vgm_snippet_rom_byte = 8'h44;
                10'd142: vgm_snippet_rom_byte = 8'h50; 10'd143: vgm_snippet_rom_byte = 8'h9F;
                10'd144: vgm_snippet_rom_byte = 8'h61; 10'd145: vgm_snippet_rom_byte = 8'h74; 10'd146: vgm_snippet_rom_byte = 8'h22;

                // PSG ch0 note 2: period 0x0C0, clearly higher.
                10'd147: vgm_snippet_rom_byte = 8'h50; 10'd148: vgm_snippet_rom_byte = 8'h80;
                10'd149: vgm_snippet_rom_byte = 8'h50; 10'd150: vgm_snippet_rom_byte = 8'h0C;
                10'd151: vgm_snippet_rom_byte = 8'h50; 10'd152: vgm_snippet_rom_byte = 8'h91;
                10'd153: vgm_snippet_rom_byte = 8'h61; 10'd154: vgm_snippet_rom_byte = 8'hE8; 10'd155: vgm_snippet_rom_byte = 8'h44;
                10'd156: vgm_snippet_rom_byte = 8'h50; 10'd157: vgm_snippet_rom_byte = 8'h9F;
                10'd158: vgm_snippet_rom_byte = 8'h61; 10'd159: vgm_snippet_rom_byte = 8'h74; 10'd160: vgm_snippet_rom_byte = 8'h22;

                // PSG ch0 note 3: period 0x060, clearly higher again.
                10'd161: vgm_snippet_rom_byte = 8'h50; 10'd162: vgm_snippet_rom_byte = 8'h80;
                10'd163: vgm_snippet_rom_byte = 8'h50; 10'd164: vgm_snippet_rom_byte = 8'h06;
                10'd165: vgm_snippet_rom_byte = 8'h50; 10'd166: vgm_snippet_rom_byte = 8'h91;
                10'd167: vgm_snippet_rom_byte = 8'h61; 10'd168: vgm_snippet_rom_byte = 8'hE8; 10'd169: vgm_snippet_rom_byte = 8'h44;
                10'd170: vgm_snippet_rom_byte = 8'h50; 10'd171: vgm_snippet_rom_byte = 8'h9F;
                10'd172: vgm_snippet_rom_byte = 8'h61; 10'd173: vgm_snippet_rom_byte = 8'h74; 10'd174: vgm_snippet_rom_byte = 8'h22;

                // Explicit final silence sequence for hardware bring-up.
                10'd175: vgm_snippet_rom_byte = 8'h52; 10'd176: vgm_snippet_rom_byte = 8'h28; 10'd177: vgm_snippet_rom_byte = 8'h00;
                10'd178: vgm_snippet_rom_byte = 8'h52; 10'd179: vgm_snippet_rom_byte = 8'h2A; 10'd180: vgm_snippet_rom_byte = 8'h00;
                10'd181: vgm_snippet_rom_byte = 8'h52; 10'd182: vgm_snippet_rom_byte = 8'h2B; 10'd183: vgm_snippet_rom_byte = 8'h00;
                10'd184: vgm_snippet_rom_byte = 8'h50; 10'd185: vgm_snippet_rom_byte = 8'h9F;
                10'd186: vgm_snippet_rom_byte = 8'h50; 10'd187: vgm_snippet_rom_byte = 8'hBF;
                10'd188: vgm_snippet_rom_byte = 8'h50; 10'd189: vgm_snippet_rom_byte = 8'hDF;
                10'd190: vgm_snippet_rom_byte = 8'h50; 10'd191: vgm_snippet_rom_byte = 8'hFF;
                10'd192: vgm_snippet_rom_byte = 8'h61; 10'd193: vgm_snippet_rom_byte = 8'h00; 10'd194: vgm_snippet_rom_byte = 8'h04;
                10'd195: vgm_snippet_rom_byte = 8'h66;

                default: vgm_snippet_rom_byte = 8'h66;
            endcase
        end
    endfunction

    function automatic logic [7:0] vgm_real_context_rom_byte(input logic [12:0] addr);
        unique case (addr)
`include "rtl/vgm_real_snippet_mode2_case.vh"
            default: vgm_real_context_rom_byte = 8'h66;
        endcase
    endfunction

    function automatic logic [7:0] vgm_real_phrase_rom_byte(input logic [12:0] addr);
        unique case (addr)
`include "rtl/vgm_real_phrase_mode3_case.vh"
            default: vgm_real_phrase_rom_byte = 8'h66;
        endcase
    endfunction

    function automatic logic [7:0] timing_calibration_rom_byte(input logic [12:0] addr);
        if (addr <= 13'd86) begin
            // Reuse the known-good FM setup/key-on part of BRINGUP_TONE.
            timing_calibration_rom_byte = bringup_tone_rom_byte(addr);
        end else begin
            unique case (addr)
                // 1 second tone, then 1 second silence. Repeat three times.
                13'd87: timing_calibration_rom_byte = 8'h61;
                13'd88: timing_calibration_rom_byte = 8'h44;
                13'd89: timing_calibration_rom_byte = 8'hAC;
                13'd90: timing_calibration_rom_byte = 8'h52;
                13'd91: timing_calibration_rom_byte = 8'h28;
                13'd92: timing_calibration_rom_byte = 8'h00;
                13'd93: timing_calibration_rom_byte = 8'h52;
                13'd94: timing_calibration_rom_byte = 8'h28;
                13'd95: timing_calibration_rom_byte = 8'h01;
                13'd96: timing_calibration_rom_byte = 8'h52;
                13'd97: timing_calibration_rom_byte = 8'h28;
                13'd98: timing_calibration_rom_byte = 8'h02;
                13'd99: timing_calibration_rom_byte = 8'h52;
                13'd100: timing_calibration_rom_byte = 8'h28;
                13'd101: timing_calibration_rom_byte = 8'h04;
                13'd102: timing_calibration_rom_byte = 8'h52;
                13'd103: timing_calibration_rom_byte = 8'h28;
                13'd104: timing_calibration_rom_byte = 8'h05;
                13'd105: timing_calibration_rom_byte = 8'h52;
                13'd106: timing_calibration_rom_byte = 8'h28;
                13'd107: timing_calibration_rom_byte = 8'h06;
                13'd108: timing_calibration_rom_byte = 8'h52;
                13'd109: timing_calibration_rom_byte = 8'h2A;
                13'd110: timing_calibration_rom_byte = 8'h00;
                13'd111: timing_calibration_rom_byte = 8'h52;
                13'd112: timing_calibration_rom_byte = 8'h2B;
                13'd113: timing_calibration_rom_byte = 8'h00;
                13'd114: timing_calibration_rom_byte = 8'h50;
                13'd115: timing_calibration_rom_byte = 8'h9F;
                13'd116: timing_calibration_rom_byte = 8'h50;
                13'd117: timing_calibration_rom_byte = 8'hBF;
                13'd118: timing_calibration_rom_byte = 8'h50;
                13'd119: timing_calibration_rom_byte = 8'hDF;
                13'd120: timing_calibration_rom_byte = 8'h50;
                13'd121: timing_calibration_rom_byte = 8'hFF;
                13'd122: timing_calibration_rom_byte = 8'h61;
                13'd123: timing_calibration_rom_byte = 8'h44;
                13'd124: timing_calibration_rom_byte = 8'hAC;
                13'd125: timing_calibration_rom_byte = 8'h52;
                13'd126: timing_calibration_rom_byte = 8'h28;
                13'd127: timing_calibration_rom_byte = 8'hF0;
                13'd128: timing_calibration_rom_byte = 8'h61;
                13'd129: timing_calibration_rom_byte = 8'h44;
                13'd130: timing_calibration_rom_byte = 8'hAC;
                13'd131: timing_calibration_rom_byte = 8'h52;
                13'd132: timing_calibration_rom_byte = 8'h28;
                13'd133: timing_calibration_rom_byte = 8'h00;
                13'd134: timing_calibration_rom_byte = 8'h52;
                13'd135: timing_calibration_rom_byte = 8'h28;
                13'd136: timing_calibration_rom_byte = 8'h01;
                13'd137: timing_calibration_rom_byte = 8'h52;
                13'd138: timing_calibration_rom_byte = 8'h28;
                13'd139: timing_calibration_rom_byte = 8'h02;
                13'd140: timing_calibration_rom_byte = 8'h52;
                13'd141: timing_calibration_rom_byte = 8'h28;
                13'd142: timing_calibration_rom_byte = 8'h04;
                13'd143: timing_calibration_rom_byte = 8'h52;
                13'd144: timing_calibration_rom_byte = 8'h28;
                13'd145: timing_calibration_rom_byte = 8'h05;
                13'd146: timing_calibration_rom_byte = 8'h52;
                13'd147: timing_calibration_rom_byte = 8'h28;
                13'd148: timing_calibration_rom_byte = 8'h06;
                13'd149: timing_calibration_rom_byte = 8'h52;
                13'd150: timing_calibration_rom_byte = 8'h2A;
                13'd151: timing_calibration_rom_byte = 8'h00;
                13'd152: timing_calibration_rom_byte = 8'h52;
                13'd153: timing_calibration_rom_byte = 8'h2B;
                13'd154: timing_calibration_rom_byte = 8'h00;
                13'd155: timing_calibration_rom_byte = 8'h50;
                13'd156: timing_calibration_rom_byte = 8'h9F;
                13'd157: timing_calibration_rom_byte = 8'h50;
                13'd158: timing_calibration_rom_byte = 8'hBF;
                13'd159: timing_calibration_rom_byte = 8'h50;
                13'd160: timing_calibration_rom_byte = 8'hDF;
                13'd161: timing_calibration_rom_byte = 8'h50;
                13'd162: timing_calibration_rom_byte = 8'hFF;
                13'd163: timing_calibration_rom_byte = 8'h61;
                13'd164: timing_calibration_rom_byte = 8'h44;
                13'd165: timing_calibration_rom_byte = 8'hAC;
                13'd166: timing_calibration_rom_byte = 8'h52;
                13'd167: timing_calibration_rom_byte = 8'h28;
                13'd168: timing_calibration_rom_byte = 8'hF0;
                13'd169: timing_calibration_rom_byte = 8'h61;
                13'd170: timing_calibration_rom_byte = 8'h44;
                13'd171: timing_calibration_rom_byte = 8'hAC;
                13'd172: timing_calibration_rom_byte = 8'h52;
                13'd173: timing_calibration_rom_byte = 8'h28;
                13'd174: timing_calibration_rom_byte = 8'h00;
                13'd175: timing_calibration_rom_byte = 8'h52;
                13'd176: timing_calibration_rom_byte = 8'h28;
                13'd177: timing_calibration_rom_byte = 8'h01;
                13'd178: timing_calibration_rom_byte = 8'h52;
                13'd179: timing_calibration_rom_byte = 8'h28;
                13'd180: timing_calibration_rom_byte = 8'h02;
                13'd181: timing_calibration_rom_byte = 8'h52;
                13'd182: timing_calibration_rom_byte = 8'h28;
                13'd183: timing_calibration_rom_byte = 8'h04;
                13'd184: timing_calibration_rom_byte = 8'h52;
                13'd185: timing_calibration_rom_byte = 8'h28;
                13'd186: timing_calibration_rom_byte = 8'h05;
                13'd187: timing_calibration_rom_byte = 8'h52;
                13'd188: timing_calibration_rom_byte = 8'h28;
                13'd189: timing_calibration_rom_byte = 8'h06;
                13'd190: timing_calibration_rom_byte = 8'h52;
                13'd191: timing_calibration_rom_byte = 8'h2A;
                13'd192: timing_calibration_rom_byte = 8'h00;
                13'd193: timing_calibration_rom_byte = 8'h52;
                13'd194: timing_calibration_rom_byte = 8'h2B;
                13'd195: timing_calibration_rom_byte = 8'h00;
                13'd196: timing_calibration_rom_byte = 8'h50;
                13'd197: timing_calibration_rom_byte = 8'h9F;
                13'd198: timing_calibration_rom_byte = 8'h50;
                13'd199: timing_calibration_rom_byte = 8'hBF;
                13'd200: timing_calibration_rom_byte = 8'h50;
                13'd201: timing_calibration_rom_byte = 8'hDF;
                13'd202: timing_calibration_rom_byte = 8'h50;
                13'd203: timing_calibration_rom_byte = 8'hFF;
                13'd204: timing_calibration_rom_byte = 8'h61;
                13'd205: timing_calibration_rom_byte = 8'h44;
                13'd206: timing_calibration_rom_byte = 8'hAC;
                13'd207: timing_calibration_rom_byte = 8'h66;

                default: timing_calibration_rom_byte = 8'h66;
            endcase
        end
    endfunction

    function automatic logic [7:0] vgm_real_snippet_rom_byte(input logic [12:0] addr);
        unique case (addr)
            // Initial silence before the real-VGM-derived register state.
            10'd0:   vgm_real_snippet_rom_byte = 8'h52; 10'd1:   vgm_real_snippet_rom_byte = 8'h28; 10'd2:   vgm_real_snippet_rom_byte = 8'h00;
            10'd3:   vgm_real_snippet_rom_byte = 8'h52; 10'd4:   vgm_real_snippet_rom_byte = 8'h2A; 10'd5:   vgm_real_snippet_rom_byte = 8'h00;
            10'd6:   vgm_real_snippet_rom_byte = 8'h52; 10'd7:   vgm_real_snippet_rom_byte = 8'h2B; 10'd8:   vgm_real_snippet_rom_byte = 8'h00;
            10'd9:   vgm_real_snippet_rom_byte = 8'h50; 10'd10:  vgm_real_snippet_rom_byte = 8'h9F;
            10'd11:  vgm_real_snippet_rom_byte = 8'h50; 10'd12:  vgm_real_snippet_rom_byte = 8'hBF;
            10'd13:  vgm_real_snippet_rom_byte = 8'h50; 10'd14:  vgm_real_snippet_rom_byte = 8'hDF;
            10'd15:  vgm_real_snippet_rom_byte = 8'h50; 10'd16:  vgm_real_snippet_rom_byte = 8'hFF;
            10'd17:  vgm_real_snippet_rom_byte = 8'h61; 10'd18:  vgm_real_snippet_rom_byte = 8'h00; 10'd19:  vgm_real_snippet_rom_byte = 8'h04;

            // Distilled from /Users/daizo/Downloads/fm_only_test.vgm:
            // first active YM2612 KeyOn at VGM pc=0x0000044B. These are the
            // latest channel-1 register values seen before that KeyOn, kept as
            // VGM opcodes so the fixed player still exercises the same command
            // path as a real VGM stream.
            10'd20:  vgm_real_snippet_rom_byte = 8'h52; 10'd21:  vgm_real_snippet_rom_byte = 8'h22; 10'd22:  vgm_real_snippet_rom_byte = 8'h00;
            10'd23:  vgm_real_snippet_rom_byte = 8'h52; 10'd24:  vgm_real_snippet_rom_byte = 8'h27; 10'd25:  vgm_real_snippet_rom_byte = 8'h40;
            10'd26:  vgm_real_snippet_rom_byte = 8'h52; 10'd27:  vgm_real_snippet_rom_byte = 8'h2B; 10'd28:  vgm_real_snippet_rom_byte = 8'h00;
            10'd29:  vgm_real_snippet_rom_byte = 8'h52; 10'd30:  vgm_real_snippet_rom_byte = 8'h30; 10'd31:  vgm_real_snippet_rom_byte = 8'h61;
            10'd32:  vgm_real_snippet_rom_byte = 8'h52; 10'd33:  vgm_real_snippet_rom_byte = 8'h34; 10'd34:  vgm_real_snippet_rom_byte = 8'h31;
            10'd35:  vgm_real_snippet_rom_byte = 8'h52; 10'd36:  vgm_real_snippet_rom_byte = 8'h38; 10'd37:  vgm_real_snippet_rom_byte = 8'h31;
            10'd38:  vgm_real_snippet_rom_byte = 8'h52; 10'd39:  vgm_real_snippet_rom_byte = 8'h3C; 10'd40:  vgm_real_snippet_rom_byte = 8'h61;
            10'd41:  vgm_real_snippet_rom_byte = 8'h52; 10'd42:  vgm_real_snippet_rom_byte = 8'h40; 10'd43:  vgm_real_snippet_rom_byte = 8'h1E;
            10'd44:  vgm_real_snippet_rom_byte = 8'h52; 10'd45:  vgm_real_snippet_rom_byte = 8'h44; 10'd46:  vgm_real_snippet_rom_byte = 8'h1B;
            10'd47:  vgm_real_snippet_rom_byte = 8'h52; 10'd48:  vgm_real_snippet_rom_byte = 8'h48; 10'd49:  vgm_real_snippet_rom_byte = 8'h1A;
            10'd50:  vgm_real_snippet_rom_byte = 8'h52; 10'd51:  vgm_real_snippet_rom_byte = 8'h4C; 10'd52:  vgm_real_snippet_rom_byte = 8'h1A;
            10'd53:  vgm_real_snippet_rom_byte = 8'h52; 10'd54:  vgm_real_snippet_rom_byte = 8'h50; 10'd55:  vgm_real_snippet_rom_byte = 8'h4F;
            10'd56:  vgm_real_snippet_rom_byte = 8'h52; 10'd57:  vgm_real_snippet_rom_byte = 8'h54; 10'd58:  vgm_real_snippet_rom_byte = 8'h4F;
            10'd59:  vgm_real_snippet_rom_byte = 8'h52; 10'd60:  vgm_real_snippet_rom_byte = 8'h58; 10'd61:  vgm_real_snippet_rom_byte = 8'h9F;
            10'd62:  vgm_real_snippet_rom_byte = 8'h52; 10'd63:  vgm_real_snippet_rom_byte = 8'h5C; 10'd64:  vgm_real_snippet_rom_byte = 8'h1F;
            10'd65:  vgm_real_snippet_rom_byte = 8'h52; 10'd66:  vgm_real_snippet_rom_byte = 8'h60; 10'd67:  vgm_real_snippet_rom_byte = 8'h03;
            10'd68:  vgm_real_snippet_rom_byte = 8'h52; 10'd69:  vgm_real_snippet_rom_byte = 8'h64; 10'd70:  vgm_real_snippet_rom_byte = 8'h0E;
            10'd71:  vgm_real_snippet_rom_byte = 8'h52; 10'd72:  vgm_real_snippet_rom_byte = 8'h68; 10'd73:  vgm_real_snippet_rom_byte = 8'h01;
            10'd74:  vgm_real_snippet_rom_byte = 8'h52; 10'd75:  vgm_real_snippet_rom_byte = 8'h6C; 10'd76:  vgm_real_snippet_rom_byte = 8'h15;
            10'd77:  vgm_real_snippet_rom_byte = 8'h52; 10'd78:  vgm_real_snippet_rom_byte = 8'h70; 10'd79:  vgm_real_snippet_rom_byte = 8'h01;
            10'd80:  vgm_real_snippet_rom_byte = 8'h52; 10'd81:  vgm_real_snippet_rom_byte = 8'h74; 10'd82:  vgm_real_snippet_rom_byte = 8'h08;
            10'd83:  vgm_real_snippet_rom_byte = 8'h52; 10'd84:  vgm_real_snippet_rom_byte = 8'h78; 10'd85:  vgm_real_snippet_rom_byte = 8'h01;
            10'd86:  vgm_real_snippet_rom_byte = 8'h52; 10'd87:  vgm_real_snippet_rom_byte = 8'h7C; 10'd88:  vgm_real_snippet_rom_byte = 8'h15;
            10'd89:  vgm_real_snippet_rom_byte = 8'h52; 10'd90:  vgm_real_snippet_rom_byte = 8'h80; 10'd91:  vgm_real_snippet_rom_byte = 8'h27;
            10'd92:  vgm_real_snippet_rom_byte = 8'h52; 10'd93:  vgm_real_snippet_rom_byte = 8'h84; 10'd94:  vgm_real_snippet_rom_byte = 8'h47;
            10'd95:  vgm_real_snippet_rom_byte = 8'h52; 10'd96:  vgm_real_snippet_rom_byte = 8'h88; 10'd97:  vgm_real_snippet_rom_byte = 8'h28;
            10'd98:  vgm_real_snippet_rom_byte = 8'h52; 10'd99:  vgm_real_snippet_rom_byte = 8'h8C; 10'd100: vgm_real_snippet_rom_byte = 8'h28;
            10'd101: vgm_real_snippet_rom_byte = 8'h52; 10'd102: vgm_real_snippet_rom_byte = 8'h90; 10'd103: vgm_real_snippet_rom_byte = 8'h00;
            10'd104: vgm_real_snippet_rom_byte = 8'h52; 10'd105: vgm_real_snippet_rom_byte = 8'h94; 10'd106: vgm_real_snippet_rom_byte = 8'h00;
            10'd107: vgm_real_snippet_rom_byte = 8'h52; 10'd108: vgm_real_snippet_rom_byte = 8'h98; 10'd109: vgm_real_snippet_rom_byte = 8'h00;
            10'd110: vgm_real_snippet_rom_byte = 8'h52; 10'd111: vgm_real_snippet_rom_byte = 8'h9C; 10'd112: vgm_real_snippet_rom_byte = 8'h00;
            10'd113: vgm_real_snippet_rom_byte = 8'h52; 10'd114: vgm_real_snippet_rom_byte = 8'hA4; 10'd115: vgm_real_snippet_rom_byte = 8'h14;
            10'd116: vgm_real_snippet_rom_byte = 8'h52; 10'd117: vgm_real_snippet_rom_byte = 8'hA0; 10'd118: vgm_real_snippet_rom_byte = 8'h0D;
            10'd119: vgm_real_snippet_rom_byte = 8'h52; 10'd120: vgm_real_snippet_rom_byte = 8'hB0; 10'd121: vgm_real_snippet_rom_byte = 8'h3C;
            10'd122: vgm_real_snippet_rom_byte = 8'h52; 10'd123: vgm_real_snippet_rom_byte = 8'hB4; 10'd124: vgm_real_snippet_rom_byte = 8'hC0;
            10'd125: vgm_real_snippet_rom_byte = 8'h52; 10'd126: vgm_real_snippet_rom_byte = 8'h28; 10'd127: vgm_real_snippet_rom_byte = 8'hF0;

            // Hold the real VGM-derived tone for about 0.11 seconds.
            10'd128: vgm_real_snippet_rom_byte = 8'h61; 10'd129: vgm_real_snippet_rom_byte = 8'h88; 10'd130: vgm_real_snippet_rom_byte = 8'h13;

            // Explicit final silence sequence.
            10'd131: vgm_real_snippet_rom_byte = 8'h52; 10'd132: vgm_real_snippet_rom_byte = 8'h28; 10'd133: vgm_real_snippet_rom_byte = 8'h00;
            10'd134: vgm_real_snippet_rom_byte = 8'h52; 10'd135: vgm_real_snippet_rom_byte = 8'h2A; 10'd136: vgm_real_snippet_rom_byte = 8'h00;
            10'd137: vgm_real_snippet_rom_byte = 8'h52; 10'd138: vgm_real_snippet_rom_byte = 8'h2B; 10'd139: vgm_real_snippet_rom_byte = 8'h00;
            10'd140: vgm_real_snippet_rom_byte = 8'h50; 10'd141: vgm_real_snippet_rom_byte = 8'h9F;
            10'd142: vgm_real_snippet_rom_byte = 8'h50; 10'd143: vgm_real_snippet_rom_byte = 8'hBF;
            10'd144: vgm_real_snippet_rom_byte = 8'h50; 10'd145: vgm_real_snippet_rom_byte = 8'hDF;
            10'd146: vgm_real_snippet_rom_byte = 8'h50; 10'd147: vgm_real_snippet_rom_byte = 8'hFF;
            10'd148: vgm_real_snippet_rom_byte = 8'h61; 10'd149: vgm_real_snippet_rom_byte = 8'h00; 10'd150: vgm_real_snippet_rom_byte = 8'h04;
            10'd151: vgm_real_snippet_rom_byte = 8'h66;

            default: vgm_real_snippet_rom_byte = 8'h66;
        endcase
    endfunction

    function automatic logic [7:0] rom_byte(input logic [12:0] addr);
        if (REGION_MODE == REGION_MODE_TIMING_CALIBRATION) begin
            rom_byte = timing_calibration_rom_byte(addr);
        end else if (REGION_MODE == REGION_MODE_VGM_REAL_PHRASE) begin
            rom_byte = vgm_real_phrase_rom_byte(addr);
        end else if (REGION_MODE == REGION_MODE_VGM_REAL_SNIPPET) begin
            rom_byte = vgm_real_context_rom_byte(addr);
        end else if (REGION_MODE == REGION_MODE_VGM_SNIPPET) begin
            rom_byte = vgm_snippet_rom_byte(addr);
        end else begin
            rom_byte = bringup_tone_rom_byte(addr);
        end
    endfunction

    function automatic logic [7:0] pcm_byte(input logic [9:0] index);
        unique case (index[3:0])
            4'h0: pcm_byte = 8'h80;
            4'h1: pcm_byte = 8'h98;
            4'h2: pcm_byte = 8'hB0;
            4'h3: pcm_byte = 8'hD0;
            4'h4: pcm_byte = 8'hF0;
            4'h5: pcm_byte = 8'hD0;
            4'h6: pcm_byte = 8'hB0;
            4'h7: pcm_byte = 8'h98;
            4'h8: pcm_byte = 8'h80;
            4'h9: pcm_byte = 8'h68;
            4'hA: pcm_byte = 8'h50;
            4'hB: pcm_byte = 8'h30;
            4'hC: pcm_byte = 8'h10;
            4'hD: pcm_byte = 8'h30;
            4'hE: pcm_byte = 8'h50;
            default: pcm_byte = 8'h68;
        endcase
    endfunction

    wire vgm_wait_tick_edge = vgm_wait_tick && !vgm_wait_tick_d;

    always_ff @(posedge clk) begin
        if (reset) begin
            state                <= ST_IDLE;
            pc                   <= 13'd0;
            cmd                  <= 8'h00;
            wait_remaining       <= 16'd0;
            pcm_pos              <= 10'd0;
            vgm_wait_tick_d      <= 1'b0;

            ym_cmd_valid         <= 1'b0;
            ym_cmd_port          <= 1'b0;
            ym_cmd_reg           <= 8'h00;
            ym_cmd_data          <= 8'h00;
            psg_cmd_valid        <= 1'b0;
            psg_cmd_data         <= 8'h00;

            busy                 <= 1'b0;
            done                 <= 1'b0;
            last_cmd_debug       <= 8'h00;
        end else begin
            vgm_wait_tick_d      <= vgm_wait_tick;
            ym_cmd_valid         <= 1'b0;
            psg_cmd_valid        <= 1'b0;

            unique case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    done <= 1'b0;
                    if (start) begin
                        pc    <= 13'd0;
                        busy  <= 1'b1;
                        state <= ST_FETCH;
                    end
                end

                ST_FETCH: begin
                    cmd            <= rom_byte(pc);
                    last_cmd_debug <= rom_byte(pc);
                    state          <= ST_DECODE;
                end

                ST_DECODE: begin
                    unique case (cmd)
                        8'h52: begin
                            ym_cmd_port <= 1'b0;
                            ym_cmd_reg  <= rom_byte(pc + 13'd1);
                            ym_cmd_data <= rom_byte(pc + 13'd2);
                            state       <= ST_YM_WAIT_READY;
                        end

                        8'h53: begin
                            ym_cmd_port <= 1'b1;
                            ym_cmd_reg  <= rom_byte(pc + 13'd1);
                            ym_cmd_data <= rom_byte(pc + 13'd2);
                            state       <= ST_YM_WAIT_READY;
                        end

                        8'h50: begin
                            psg_cmd_data <= rom_byte(pc + 13'd1);
                            state        <= ST_PSG_WAIT_READY;
                        end

                        8'h4F: begin
                            pc    <= pc + 13'd2;
                            state <= ST_FETCH;
                        end

                        8'h61: begin
                            wait_remaining <= {rom_byte(pc + 13'd2), rom_byte(pc + 13'd1)};
                            pc             <= pc + 13'd3;
                            state          <= ST_WAIT_SAMPLES;
                        end

                        8'h62: begin
                            wait_remaining <= 16'd735;
                            pc             <= pc + 13'd1;
                            state          <= ST_WAIT_SAMPLES;
                        end

                        8'h63: begin
                            wait_remaining <= 16'd882;
                            pc             <= pc + 13'd1;
                            state          <= ST_WAIT_SAMPLES;
                        end

                        8'h66: begin
                            busy  <= 1'b0;
                            done  <= 1'b1;
                            state <= ST_DONE;
                        end

                        8'hE0: begin
                            // Only a tiny local PCM bank is implemented here,
                            // so the high offset bits are intentionally ignored.
                            pcm_pos <= {2'b00, rom_byte(pc + 13'd1)};
                            pc      <= pc + 13'd5;
                            state   <= ST_FETCH;
                        end

                        default: begin
                            if (cmd[7:4] == 4'h7) begin
                                wait_remaining <= {12'd0, cmd[3:0]} + 16'd1;
                                pc             <= pc + 13'd1;
                                state          <= ST_WAIT_SAMPLES;
                            end else if (cmd[7:4] == 4'h8) begin
                                ym_cmd_port <= 1'b0;
                                ym_cmd_reg  <= 8'h2A;
                                ym_cmd_data <= pcm_byte(pcm_pos);
                                pcm_pos     <= pcm_pos + 10'd1;
                                state       <= ST_YM_WAIT_READY;
                            end else begin
                                // Unknown command in this fixed region:
                                // stop rather than running off into garbage.
                                busy  <= 1'b0;
                                done  <= 1'b1;
                                state <= ST_DONE;
                            end
                        end
                    endcase
                end

                ST_YM_WAIT_READY: begin
                    if (ym_cmd_ready) begin
                        ym_cmd_valid <= 1'b1;
                        state        <= ST_YM_PULSE;
                    end
                end

                ST_YM_PULSE: begin
                    if (cmd[7:4] == 4'h8) begin
                        wait_remaining <= {12'd0, cmd[3:0]};
                        pc             <= pc + 13'd1;
                        state          <= ST_WAIT_SAMPLES;
                    end else begin
                        pc    <= pc + 13'd3;
                        state <= ST_FETCH;
                    end
                end

                ST_PSG_WAIT_READY: begin
                    if (psg_cmd_ready) begin
                        psg_cmd_valid <= 1'b1;
                        state         <= ST_PSG_PULSE;
                    end
                end

                ST_PSG_PULSE: begin
                    pc    <= pc + 13'd2;
                    state <= ST_FETCH;
                end

                ST_WAIT_SAMPLES: begin
                    if (wait_remaining == 16'd0) begin
                        state <= ST_FETCH;
                    end else if (vgm_wait_tick_edge) begin
                        wait_remaining <= wait_remaining - 16'd1;
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    if (!start) begin
                        state <= ST_IDLE;
                    end
                end

                default: begin
                    state <= ST_DONE;
                    busy  <= 1'b0;
                    done  <= 1'b1;
                end
            endcase
        end
    end

endmodule

// Convenience wrapper for the first hardware smoke test.
//
// A MiSTer/top-level experiment can instantiate this wrapper directly and route
// audio_l/audio_r to the platform audio output. For a larger design, instantiate
// vgm_region_player and md_sound_module separately and keep the same wiring.
module md_sound_fixed_region_test #(
    parameter int REGION_MODE = `FIXED_REGION_MODE
) (
    input  logic              clk,
    input  logic              reset,
    input  logic              player_reset,
    input  logic              start,
    input  logic              vgm_wait_tick,

    output signed      [15:0] audio_l,
    output signed      [15:0] audio_r,
    output logic              audio_sample_valid,
    input  logic        [1:0] audio_lpf_mode,
    input  logic              audio_gain_boost,
    input  logic        [1:0] audio_psg_level,

    output logic              player_busy,
    output logic              player_done,
    output logic        [9:0] player_pc_debug,
    output logic        [7:0] player_last_cmd_debug,
    output logic       [15:0] fm_adjust_clip_count_l,
    output logic       [15:0] fm_adjust_clip_count_r,
    output logic       [15:0] genmix_wrap_count_l,
    output logic       [15:0] genmix_wrap_count_r,
    output logic       [31:0] ym_write_requested_count,
    output logic       [31:0] ym_write_accepted_count,
    output logic       [31:0] ym_write_dropped_or_busy_count,
    output logic       [31:0] ym_port0_count,
    output logic       [31:0] ym_port1_count,
    output logic              last_ym_port,
    output logic        [7:0] last_ym_addr,
    output logic        [7:0] last_ym_data,
    output logic       [15:0] jt12_cen_interval_1_count,
    output logic       [15:0] jt12_cen_interval_2_count,
    output logic       [15:0] jt12_cen_interval_3_count,
    output logic       [15:0] jt12_cen_interval_4_count,
    output logic       [15:0] jt12_cen_interval_ge5_count,
    output logic        [7:0] jt12_cen_interval_min,
    output logic        [7:0] jt12_cen_interval_max,
    output logic        [7:0] jt12_cen_interval_last,
    output logic       [15:0] fm_raw_abs_peak,
    output logic       [15:0] fm_adjust_abs_peak,
    output logic       [15:0] fm_lpf_abs_peak,
    output logic       [15:0] genmix_abs_peak,
    output logic       [15:0] final_audio_abs_peak
);

    logic       ym_cmd_valid;
    logic       ym_cmd_port;
    logic [7:0] ym_cmd_reg;
    logic [7:0] ym_cmd_data;
    logic       psg_cmd_valid;
    logic [7:0] psg_cmd_data;
    logic       ym_cmd_ready;
    logic       psg_cmd_ready;
    logic       player_reset_combined;

    assign player_reset_combined = reset | player_reset;

    vgm_region_player #(
        .REGION_MODE (REGION_MODE)
    ) player (
        .clk                   (clk),
        .reset                 (player_reset_combined),
        .start                 (start),
        .vgm_wait_tick         (vgm_wait_tick),
        .ym_cmd_ready          (ym_cmd_ready),
        .psg_cmd_ready         (psg_cmd_ready),
        .ym_cmd_valid          (ym_cmd_valid),
        .ym_cmd_port           (ym_cmd_port),
        .ym_cmd_reg            (ym_cmd_reg),
        .ym_cmd_data           (ym_cmd_data),
        .psg_cmd_valid         (psg_cmd_valid),
        .psg_cmd_data          (psg_cmd_data),
        .busy                  (player_busy),
        .done                  (player_done),
        .pc_debug              (player_pc_debug),
        .last_cmd_debug        (player_last_cmd_debug)
    );

    md_sound_module sound (
        .clk                   (clk),
        .reset                 (reset),
        .ym_cmd_valid          (ym_cmd_valid),
        .ym_cmd_port           (ym_cmd_port),
        .ym_cmd_reg            (ym_cmd_reg),
        .ym_cmd_data           (ym_cmd_data),
        .psg_cmd_valid         (psg_cmd_valid),
        .psg_cmd_data          (psg_cmd_data),
        .ym_cmd_ready          (ym_cmd_ready),
        .psg_cmd_ready         (psg_cmd_ready),
        .audio_l               (audio_l),
        .audio_r               (audio_r),
        .audio_sample_valid    (audio_sample_valid),
        .audio_lpf_mode        (audio_lpf_mode),
        .audio_gain_boost      (audio_gain_boost),
        .audio_psg_level       (audio_psg_level),
        .fm_adjust_clip_count_l(fm_adjust_clip_count_l),
        .fm_adjust_clip_count_r(fm_adjust_clip_count_r),
        .genmix_wrap_count_l   (genmix_wrap_count_l),
        .genmix_wrap_count_r   (genmix_wrap_count_r),
        .ym_write_requested_count(ym_write_requested_count),
        .ym_write_accepted_count(ym_write_accepted_count),
        .ym_write_dropped_or_busy_count(ym_write_dropped_or_busy_count),
        .ym_port0_count        (ym_port0_count),
        .ym_port1_count        (ym_port1_count),
        .last_ym_port          (last_ym_port),
        .last_ym_addr          (last_ym_addr),
        .last_ym_data          (last_ym_data),
        .jt12_cen_interval_1_count(jt12_cen_interval_1_count),
        .jt12_cen_interval_2_count(jt12_cen_interval_2_count),
        .jt12_cen_interval_3_count(jt12_cen_interval_3_count),
        .jt12_cen_interval_4_count(jt12_cen_interval_4_count),
        .jt12_cen_interval_ge5_count(jt12_cen_interval_ge5_count),
        .jt12_cen_interval_min(jt12_cen_interval_min),
        .jt12_cen_interval_max(jt12_cen_interval_max),
        .jt12_cen_interval_last(jt12_cen_interval_last),
        .fm_raw_abs_peak      (fm_raw_abs_peak),
        .fm_adjust_abs_peak   (fm_adjust_abs_peak),
        .fm_lpf_abs_peak      (fm_lpf_abs_peak),
        .genmix_abs_peak      (genmix_abs_peak),
        .final_audio_abs_peak (final_audio_abs_peak)
    );

endmodule
