// SPDX-License-Identifier: BSD-3-Clause
// Host-planned file/gap fragments, packed into full resident64bit words.
// Strict owner supplies correlated physical64bit witness; no second DDR reader.
module k053260_resident_preloader(
 input logic clk,reset,stop,input logic[31:0] epoch,file_extent,
 input logic reader_quiescent,
 input logic segment_valid,output logic segment_ready,
 input logic[31:0] segment_file_address,input logic[3:0] segment_bytes,input logic segment_gap,
 output logic fill_valid,input logic fill_ready,output logic[63:0] fill_data,output logic[31:0] fill_epoch,
 output logic idle,fault,output logic[3:0] fault_code,
 output logic reader_valid,input logic reader_ready,
 output vgm_reader_vnext_pkg::read_request_t reader_request,
 input logic reader_response_valid,output logic reader_response_ready,
 input vgm_reader_vnext_pkg::read_response_t reader_response,
 input logic word_valid,input logic[31:0] word_id,word_epoch,input logic[63:0] word_data
);
 import vgm_reader_vnext_pkg::*;
 typedef enum logic[2:0]{IDLE,ISSUE0,WAIT0,ISSUE1,WAIT1,ASSEMBLE,DRAIN} state_t;
 state_t state;
 logic[31:0] active_epoch,owned_epoch,owned_id,sequence_id,address;
 logic[3:0] count;logic[2:0] shift,cursor;
 logic[63:0] first,second,packed_word,witness,fragment,selected_word,byte_mask;
 logic witnessed;logic[32:0] finish_address,second_address;
 assign segment_ready=state==IDLE&&!fill_valid&&!fault&&!reset&&!stop&&active_epoch==epoch&&reader_quiescent;
 assign idle=state==IDLE&&!fill_valid&&cursor==0&&!fault;
 assign finish_address={1'b0,segment_file_address}+{29'd0,segment_bytes};
 assign second_address={1'b0,address}+33'd8;
 assign reader_valid=(state==ISSUE0||state==ISSUE1)&&!reset&&!stop&&!fault&&active_epoch==epoch;
 always_comb begin
  reader_request='0;reader_request.address=state==ISSUE1?second_address[31:0]:address;
  reader_request.epoch=active_epoch;reader_request.transaction_id=sequence_id;reader_request.file_extent=file_extent;
 end
 assign reader_response_ready=state==WAIT0||state==WAIT1||state==DRAIN;
 assign selected_word=witnessed?witness:word_data;
 assign fragment=(first>>(int'(shift)*8))|(second<<((8-int'(shift))*8));
 assign byte_mask=count==8?64'hffffffffffffffff:(64'd1<<(int'(count)*8))-64'd1;
 task automatic fail(input logic[3:0] code);fault<=1;fault_code<=code;state<=IDLE;fill_valid<=0;endtask
 always_ff @(posedge clk)begin
  if(reset)begin
   state<=IDLE;active_epoch<=epoch;owned_epoch<=0;owned_id<=0;sequence_id<=32'h60000000;address<=0;
   count<=0;shift<=0;cursor<=0;first<=0;second<=0;packed_word<=0;witness<=0;witnessed<=0;
   fill_valid<=0;fill_data<=0;fill_epoch<=0;fault<=0;fault_code<=0;
  end else begin
   if(fill_valid&&fill_ready)fill_valid<=0;
   if(word_valid&&(state==WAIT0||state==WAIT1)&&word_id==owned_id&&word_epoch==owned_epoch)begin witness<=word_data;witnessed<=1;end
   if(stop||active_epoch!=epoch)begin
    active_epoch<=epoch;cursor<=0;packed_word<=0;fill_valid<=0;fault<=0;fault_code<=0;
    if(state==WAIT0||state==WAIT1||state==DRAIN)begin
     if(reader_response_valid&&reader_response_ready)state<=IDLE;else state<=DRAIN;
    end else state<=IDLE;
   end else case(state)
    IDLE:if(segment_valid&&segment_ready)begin
     if(segment_bytes==0||segment_bytes>8||{1'b0,segment_bytes}+{2'd0,cursor}>8||(!segment_gap&&(finish_address>{1'b0,file_extent})))fail(4'd1);
     else begin
      count<=segment_bytes;shift<=segment_gap?3'd0:segment_file_address[2:0];address<={segment_file_address[31:3],3'd0};second<=0;
      if(segment_gap)begin first<=64'hffffffffffffffff;state<=ASSEMBLE;end
      else state<=ISSUE0;
     end
    end
    ISSUE0,ISSUE1:if(reader_valid&&reader_ready)begin
     owned_id<=sequence_id;owned_epoch<=active_epoch;sequence_id<=sequence_id+1'b1;witnessed<=0;
     state<=state==ISSUE0?WAIT0:WAIT1;
    end
    WAIT0,WAIT1:if(reader_response_valid&&reader_response_ready)begin
     if(reader_response.transaction_id!=owned_id||reader_response.epoch!=owned_epoch)fail(4'd2);
     else if(reader_response.result!=READ_OK)fail(4'd3);
     else if(!(witnessed||(word_valid&&word_id==owned_id&&word_epoch==owned_epoch))||reader_response.data!=selected_word[7:0])fail(4'd4);
     else if(state==WAIT0)begin first<=selected_word;state<=(int'(shift)+int'(count)>8)?ISSUE1:ASSEMBLE;end
     else begin second<=selected_word;state<=ASSEMBLE;end
    end
    ASSEMBLE:begin
     packed_word<=packed_word|((fragment&byte_mask)<<(int'(cursor)*8));
     if(int'(cursor)+int'(count)==8)begin
      fill_data<=packed_word|((fragment&byte_mask)<<(int'(cursor)*8));fill_epoch<=active_epoch;fill_valid<=1;cursor<=0;packed_word<=0;
     end else cursor<=cursor+3'(count);
     state<=IDLE;
    end
    DRAIN:if(reader_response_valid&&reader_response_ready)state<=IDLE;
    default:fail(4'd2);
   endcase
  end
 end
endmodule
