// SPDX-License-Identifier: BSD-3-Clause
// Chip-local host-planned immutable resident store. No chip address/decoder changes.
module k053260_resident_store(
 input logic clk,reset,stop,input logic[31:0] epoch,
 input logic cfg_valid,output logic cfg_ready,input logic[31:0] cfg_rom_size,file_extent,
 input logic[8:0] cfg_pages,input logic upload_complete,
 input logic block_valid,output logic block_ready,input logic[31:0] block_rom_size,block_start,block_bytes,block_file,
 input logic block_late,
 input logic page_valid,output logic page_ready,input logic[10:0] page_number,
 input logic fill_valid,output logic fill_ready,input logic[63:0] fill_data,input logic[31:0] fill_epoch,
 input logic commit_valid,input logic preload_idle,
 output logic resident_ready,loading,fault,output logic[3:0] fault_code,
 output logic[8:0] pages_filled,output logic[31:0] generation,
 input logic rom_valid,output logic rom_ready,input logic[21:0] logical_address,
 input logic[31:0] rom_id,rom_epoch,
 output logic rsp_valid,output logic[31:0] rsp_id,rsp_epoch,
 output logic[7:0] rsp_data,output logic[1:0] rsp_result
);
 localparam integer WORDS=192*256;
 // Dedicated inference processes: synchronous reads, no data RAM reset or async port.
 logic[8:0] map_ram[0:2047];logic[63:0] data_ram[0:WORDS-1];
 logic[8:0] map_q;logic[63:0] data_q;
 typedef enum logic[3:0]{OFF,CLEAR,PLAN,OPEN_WAIT,OPEN_CHECK,FILL,SEALED,BAD} state_t;
 state_t state;
 logic[31:0] owned_epoch,size,extent;logic[8:0] expected;
 logic[10:0] clear_cursor,opened_page;logic[7:0] word_cursor;
 logic[5:0] blocks;logic[10:0] map_index;logic map_read,map_write;
 logic[8:0] map_wdata;logic[15:0] data_index;logic data_read,data_write;
 logic alive,fire;logic v1,v2;logic[31:0] id1,id2,e1,e2,g1,g2;
 logic[21:0] a1;logic[2:0] lane2;logic[1:0] result2;
 logic[32:0] block_end,file_end;
 assign alive=owned_epoch==epoch && !reset && !stop;
 assign cfg_ready=(state==OFF||state==BAD||state==SEALED)&&!reset&&!stop;
 assign block_ready=state==PLAN&&alive&&!fault;
 assign page_ready=state==PLAN&&alive&&!fault&&blocks!=0&&!block_valid;
 assign fill_ready=state==FILL&&alive&&!fault;
 assign loading=state!=OFF&&state!=SEALED&&state!=BAD;
 assign rom_ready=resident_ready&&alive;
 assign fire=rom_valid&&rom_ready;
 assign block_end={1'b0,block_start}+{1'b0,block_bytes};
 assign file_end={1'b0,block_file}+{1'b0,block_bytes};
 always_comb begin
  map_read=fire||(page_valid&&page_ready);
  map_index=fire?logical_address[21:11]:page_number;
  map_write=state==CLEAR&&alive || (fill_valid&&fill_ready&&fill_epoch==owned_epoch&&word_cursor==255);
  map_wdata=state==CLEAR?9'd0:{1'b1,pages_filled[7:0]};
  if(map_write)map_index=state==CLEAR?clear_cursor:opened_page;
  data_read=v1&&e1==epoch&&g1==generation&&resident_ready&&alive&&a1<size&&map_q[8]&&map_q[7:0]<192;
  data_index={map_q[7:0],a1[10:3]};
  data_write=fill_valid&&fill_ready&&fill_epoch==owned_epoch;
 end
 always_ff @(posedge clk)begin
  if(map_read)map_q<=map_ram[map_index];
  if(map_write)map_ram[map_index]<=map_wdata;
 end
 always_ff @(posedge clk)begin
  if(data_read)data_q<=data_ram[data_index];
  if(data_write)data_ram[{pages_filled[7:0],word_cursor}]<=fill_data;
 end
 task automatic fail(input logic[3:0] reason);
  fault<=1;fault_code<=reason;resident_ready<=0;state<=BAD;
 endtask
 always_ff @(posedge clk)begin
  rsp_valid<=v2;v2<=v1;v1<=fire;
  if(fire)begin id1<=rom_id;e1<=rom_epoch;g1<=generation;a1<=logical_address;end
  if(v1)begin
   id2<=id1;e2<=e1;g2<=g1;lane2<=a1[2:0];
   result2<=e1!=epoch||g1!=generation||!alive?2'd3:a1>=size?2'd1:!map_q[8]||map_q[7:0]>=192?2'd2:2'd0;
  end
  if(v2)begin
   rsp_id<=id2;rsp_epoch<=e2;rsp_data<=0;
   if(e2!=epoch||g2!=generation||!alive)rsp_result<=3;
   else begin
    rsp_result<=result2;
    if(result2==0)rsp_data<=data_q[lane2*8+:8];
    else if(result2!=3)fail(result2==1?4'd2:4'd3);
   end
  end
  if(reset)begin
   state<=OFF;resident_ready<=0;fault<=0;fault_code<=0;owned_epoch<=epoch;
   size<=0;extent<=0;expected<=0;pages_filled<=0;generation<=0;clear_cursor<=0;opened_page<=0;word_cursor<=0;blocks<=0;
   v1<=0;v2<=0;rsp_valid<=0;rsp_id<=0;rsp_epoch<=0;rsp_data<=0;rsp_result<=0;
   id1<=0;id2<=0;e1<=0;e2<=0;g1<=0;g2<=0;a1<=0;lane2<=0;result2<=0;
  end else if(stop||owned_epoch!=epoch)begin
   state<=OFF;resident_ready<=0;fault<=0;fault_code<=0;owned_epoch<=epoch;generation<=generation+1'b1;
   pages_filled<=0;blocks<=0;
  end else if(cfg_valid&&cfg_ready)begin
   generation<=generation+1'b1;resident_ready<=0;fault<=0;fault_code<=0;pages_filled<=0;blocks<=0;
   owned_epoch<=epoch;size<=cfg_rom_size;extent<=file_extent;expected<=cfg_pages;clear_cursor<=0;
   if(!upload_complete||cfg_rom_size==0||cfg_rom_size>32'h400000||cfg_pages==0||cfg_pages>192)fail(4'd1);
   else state<=CLEAR;
  end else begin
   case(state)
    CLEAR:if(clear_cursor==2047)state<=PLAN;else clear_cursor<=clear_cursor+1'b1;
    PLAN:begin
     if(block_valid&&block_ready)begin
      if(block_late||block_rom_size!=size||block_bytes==0||block_end>{1'b0,size}||file_end>{1'b0,extent}||blocks==32)fail(4'd4);
      else blocks<=blocks+1'b1;
     end else if(page_valid&&page_ready)begin
      if(pages_filled>=expected||{10'd0,page_number,11'd0}>=size)fail(4'd5);
      else begin opened_page<=page_number;state<=OPEN_WAIT;end
     end else if(commit_valid)begin
      if(!preload_idle||!upload_complete||pages_filled!=expected||blocks==0)fail(4'd6);
      else begin state<=SEALED;resident_ready<=1;end
     end
    end
    OPEN_WAIT:state<=OPEN_CHECK;
    OPEN_CHECK:if(map_q[8])fail(4'd7);else begin word_cursor<=0;state<=FILL;end
    FILL:if(fill_valid&&fill_ready)begin
     if(fill_epoch!=owned_epoch)fail(4'd8);
     else if(word_cursor==255)begin pages_filled<=pages_filled+1'b1;state<=PLAN;end
     else word_cursor<=word_cursor+1'b1;
    end
    SEALED:if(block_valid||fill_valid||page_valid)fail(4'd9);
    default:begin end
   endcase
  end
 end
endmodule
