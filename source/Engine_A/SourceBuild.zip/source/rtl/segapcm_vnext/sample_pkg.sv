package segapcm_vnext_pkg;
    typedef enum logic [1:0] {SAMPLE_OK, SAMPLE_FAULT, SAMPLE_CANCELLED} sample_result_t;
    typedef struct packed {
        logic [31:0] epoch, request_id;
        logic [3:0] voice_id;
        logic [20:0] address;
    } sample_request_t;
    typedef struct packed {
        logic [31:0] epoch, request_id;
        logic [3:0] voice_id;
        sample_result_t result;
        logic [7:0] data;
    } sample_response_t;
    typedef enum logic [2:0] {
        FAULT_NONE, FAULT_DEADLINE, FAULT_OVERRUN, FAULT_CLIENT,
        FAULT_EPOCH, FAULT_CONFIGURATION, FAULT_ID_EXHAUSTED
    } core_fault_t;
    // Observation only; no client timing or storage policy encoded here.
    typedef struct packed {
        logic [3:0] voice_id;
        logic [23:0] before_address, after_address;
        logic [7:0] control;
        logic fetched, looped, stopped;
        logic [20:0] sample_address;
        logic [7:0] sample_byte;
        logic signed [14:0] left_product, right_product;
    } voice_trace_t;
endpackage
