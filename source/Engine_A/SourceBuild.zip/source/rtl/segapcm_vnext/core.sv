module segapcm_vnext_core #(
    parameter int MAX_FRAME_CYCLES=600
) (
    input logic clk, reset, native_tick,
    input logic [31:0] epoch,
    input logic [3:0] bank_shift,
    input logic [7:0] bank_mask,
    input logic register_valid,
    output logic register_ready,
    input logic [7:0] register_address, register_data,
    input logic [7:0] read_address,
    output logic [7:0] read_data,
    output logic request_valid,
    input logic request_ready,
    output segapcm_vnext_pkg::sample_request_t request,
    input logic response_valid,
    output logic response_ready,
    input segapcm_vnext_pkg::sample_response_t response,
    output logic mix_valid,
    output logic signed [18:0] mix_left, mix_right,
    output logic trace_valid,
    output segapcm_vnext_pkg::voice_trace_t trace,
    output logic busy, fault_latched,
    output segapcm_vnext_pkg::core_fault_t fault_reason,
    output logic [31:0] stale_responses
);
    import segapcm_vnext_pkg::*;
    typedef enum logic [1:0] {IDLE,VISIT,ISSUE,WAIT_RESPONSE} state_t;
    state_t state;
    logic [7:0] registers [256];
    logic [23:0] current [16];
    logic [3:0] voice;
    logic [7:0] base;
    logic [23:0] fetch_current, before_current;
    logic pending_loop;
    sample_request_t owned;
    logic [31:0] next_id, frame_epoch;
    logic [3:0] frame_shift;
    logic [7:0] frame_mask;
    logic [$clog2(MAX_FRAME_CYCLES+1)-1:0] age;
    logic signed [18:0] accumulator_left, accumulator_right;
    logic signed [14:0] product_left, product_right;
    logic [23:0] selected_current;
    logic end_hit, matching, reply;
    logic [7:0] end_page;
    assign base={1'b0,voice,3'b000};
    assign end_page=registers[base+8'd6]+8'd1;
    assign end_hit=current[voice][23:16]==end_page;
    assign selected_current=end_hit ? {registers[base+8'd5],registers[base+8'd4],8'd0} : current[voice];
    assign register_ready=!reset && !fault_latched && state==IDLE;
    assign busy=state!=IDLE;
    assign request_valid=!reset && !fault_latched && state==ISSUE;
    assign request=request_valid ? owned : '0;
    assign response_ready=!reset && !fault_latched && state!=VISIT;
    assign matching=response.epoch==owned.epoch && response.request_id==owned.request_id && response.voice_id==owned.voice_id;
    assign reply=response_valid && response_ready && matching &&
                  (state==WAIT_RESPONSE || (state==ISSUE && request_ready));
    always @* begin
        read_data=registers[read_address];
        if(read_address[7] && read_address[2:0]==4) read_data=current[read_address[6:3]][15:8];
        if(read_address[7] && read_address[2:0]==5) read_data=current[read_address[6:3]][23:16];
    end
    segapcm_vnext_mixer products (
        .sample_byte(response.data),.left_volume(registers[base+8'd2][6:0]),
        .right_volume(registers[base+8'd3][6:0]),.left_product(product_left),.right_product(product_right)
    );
    task automatic fail(input core_fault_t reason);
        fault_latched<=1; fault_reason<=reason; state<=IDLE;
    endtask
    task automatic retire_voice(input logic [23:0] after_address,
        input logic [7:0] control, input logic fetched,looped,stopped,
        input logic signed [14:0] left_value,right_value);
        logic signed [18:0] next_left,next_right;
        begin
            next_left=accumulator_left+{{4{left_value[14]}},left_value};
            next_right=accumulator_right+{{4{right_value[14]}},right_value};
            current[voice]<=after_address;
            registers[base+8'h86]<=control;
            trace_valid<=1;
            trace.voice_id<=voice;
            trace.before_address<=state==VISIT ? current[voice] : before_current;
            trace.after_address<=after_address; trace.control<=control;
            trace.fetched<=fetched; trace.looped<=looped; trace.stopped<=stopped;
            trace.sample_address<=fetched ? owned.address : 21'd0;
            trace.sample_byte<=fetched ? response.data : 8'd0;
            trace.left_product<=left_value; trace.right_product<=right_value;
            accumulator_left<=next_left; accumulator_right<=next_right;
            if(voice==15) begin
                mix_left<=next_left; mix_right<=next_right; mix_valid<=1;state<=IDLE;
            end else begin voice<=voice+1'b1;state<=VISIT;end
        end
    endtask
    initial if(MAX_FRAME_CYCLES<32) $fatal(1,"frame deadline below inactive walk");
    always @(posedge clk) begin
        mix_valid<=0; trace_valid<=0;
        if(reset) begin
            state<=IDLE; voice<=0; age<=0; owned<='0;
            next_id<=0; frame_epoch<=0; frame_shift<=0; frame_mask<=0;
            fetch_current<=0;before_current<=0;pending_loop<=0;
            accumulator_left<=0;accumulator_right<=0;mix_left<=0;mix_right<=0;
            trace<='0;fault_latched<=0;fault_reason<=FAULT_NONE;stale_responses<=0;
            for(integer n=0;n<256;n=n+1) registers[n]<=8'hff;
            for(integer n=0;n<16;n=n+1) current[n]<=24'hffff00;
        end else if(!fault_latched) begin
            if(response_valid && response_ready && !reply) stale_responses<=stale_responses+1'b1;
            if(state!=IDLE) age<=age+1'b1;
            if(native_tick && state!=IDLE) fail(FAULT_OVERRUN);
            else if(state!=IDLE && epoch!=frame_epoch) fail(FAULT_EPOCH);
            else if(state!=IDLE && (bank_shift!=frame_shift || bank_mask!=frame_mask)) fail(FAULT_CONFIGURATION);
            else if(state!=IDLE && int'(age)>=MAX_FRAME_CYCLES-1 && !reply) fail(FAULT_DEADLINE);
            else if(reply) begin
                if(response.result!=SAMPLE_OK) fail(FAULT_CLIENT);
                else retire_voice(fetch_current+{16'd0,registers[base+8'd7]},registers[base+8'h86],1,pending_loop,0,product_left,product_right);
                if(state==ISSUE) begin
                    if(next_id==32'hffffffff) fail(FAULT_ID_EXHAUSTED);
                    else next_id<=next_id+1'b1;
                end
            end else case(state)
                IDLE: begin
                    if(register_valid && register_ready) begin
                        registers[register_address]<=register_data;
                        if(register_address[7] && register_address[2:0]==4) current[register_address[6:3]][15:8]<=register_data;
                        if(register_address[7] && register_address[2:0]==5) current[register_address[6:3]][23:16]<=register_data;
                    end
                    if(native_tick) begin
                        if(!((bank_shift==11 || bank_shift==12) && bank_mask==8'h70) && !(bank_shift==13 && bank_mask==8'hf8)) fail(FAULT_CONFIGURATION);
                        else begin
                            voice<=0; age<=0;frame_epoch<=epoch;frame_shift<=bank_shift;frame_mask<=bank_mask;
                            accumulator_left<=0;accumulator_right<=0;state<=VISIT;
                        end
                    end
                end
                VISIT: begin
                    if(registers[base+8'h86][0]) retire_voice({current[voice][23:8],8'd0},registers[base+8'h86],0,0,0,0,0);
                    else if(end_hit && registers[base+8'h86][1]) retire_voice(current[voice],registers[base+8'h86]|8'd1,0,0,1,0,0);
                    else if(next_id==32'hffffffff) fail(FAULT_ID_EXHAUSTED);
                    else begin
                        before_current<=current[voice];fetch_current<=selected_current;pending_loop<=end_hit;
                        owned.epoch<=frame_epoch;owned.request_id<=next_id;owned.voice_id<=voice;
                        owned.address<=({13'd0,(registers[base+8'h86]&frame_mask)}<<frame_shift)+{5'd0,selected_current[23:8]};
                        state<=ISSUE;
                    end
                end
                ISSUE: if(request_ready) begin next_id<=next_id+1'b1;state<=WAIT_RESPONSE;end
                default: begin end
            endcase
        end
    end
endmodule
