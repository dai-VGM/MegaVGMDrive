module segapcm_vnext_mixer (
    input logic [7:0] sample_byte,
    input logic [6:0] left_volume, right_volume,
    output logic signed [14:0] left_product, right_product
);
    logic signed [7:0] signed_sample;
    // Offset binary minus128, exactly represented without a wider subtractor.
    assign signed_sample=$signed(sample_byte ^ 8'h80);
    assign left_product=signed_sample * $signed({1'b0,left_volume});
    assign right_product=signed_sample * $signed({1'b0,right_volume});
endmodule
