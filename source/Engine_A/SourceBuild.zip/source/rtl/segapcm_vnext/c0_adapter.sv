module segapcm_vnext_c0_adapter (
    input logic valid,
    output logic ready,
    input vgm_parser_vnext_event_pkg::decode_event_t event_data,
    input vgm_parser_vnext_event_pkg::write_descriptor_t write_info,
    output logic register_valid,
    input logic register_ready,
    output logic [7:0] register_address, register_data,
    output logic rejected
);
    import vgm_parser_vnext_event_pkg::*;
    logic supported;
    assign supported=event_data.kind==EVENT_WRITE && event_data.opcode==8'hc0 &&
        write_info.chip==CHIP_SEGAPCM && !write_info.instance_id && !write_info.port && write_info.access_kind==ACCESS_MEMORY;
    assign register_valid=valid && supported;
    assign ready=supported ? register_ready : 1'b1;
    assign rejected=valid && !supported;
    // Audited single-instance aperture mode1; full logical address stays in trace.
    assign register_address=write_info.address[7:0];
    assign register_data=write_info.data;
endmodule
