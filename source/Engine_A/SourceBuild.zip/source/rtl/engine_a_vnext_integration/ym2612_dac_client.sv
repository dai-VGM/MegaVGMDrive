// Type00 storage client. No WAIT, VGM decode, Transport or chip execution policy.
// One immutable bank span is sufficient for the admitted production DAC corpus.
module engine_a_vnext_ym2612_dac_client (
    input logic clk, power_reset, new_track, cancel, channel_quiescent,
    input logic [31:0] epoch, file_extent,
    input logic data_valid,
    output logic data_ready,
    input vgm_parser_vnext_event_pkg::data_event_t data_fact,
    input logic dac_valid,
    output logic dac_ready,
    input vgm_scheduler_vnext_pkg::scheduled_fact_t dac_event,
    output logic reader_valid,
    input logic reader_ready,
    output vgm_reader_vnext_pkg::read_request_t reader_request,
    input logic reader_response_valid,
    output logic reader_response_ready,
    input vgm_reader_vnext_pkg::read_response_t reader_response,
    input logic reader_boundary_fault,
    output logic write_valid,
    input logic write_ready,
    output vgm_parser_vnext_event_pkg::write_descriptor_t write_descriptor,
    output vgm_scheduler_vnext_pkg::scheduled_fact_t write_source,
    output logic fault_valid,
    input logic fault_ready,
    output segapcm_vnext_adapter_pkg::resource_result_t fault_result,
    output logic [31:0] fault_epoch,
    output vgm_scheduler_vnext_pkg::scheduled_fact_t fault_source,
    output logic fatal_latched, active,
    output logic [31:0] cursor, bank_size, owned_file_address
);
    import vgm_parser_vnext_event_pkg::*;
    import vgm_scheduler_vnext_pkg::*;
    import vgm_reader_vnext_pkg::*;
    import segapcm_vnext_adapter_pkg::*;
    typedef enum logic [2:0] {IDLE, ISSUE, WAIT_REPLY, WRITE, FAULT} state_t;
    state_t state;
    logic bank_present, cancelled, cancelled_stream;
    logic [31:0] bank_pc, bank_offset, bank_epoch, next_id, owned_cursor;
    read_request_t owned_read;
    scheduled_fact_t owned_event;
    logic [7:0] resolved_byte;
    logic [32:0] address_sum, span_end;
    wire lifecycle_cancel=cancel || new_track || owned_read.epoch!=epoch;
    assign span_end={1'b0,data_fact.payload_offset}+{1'b0,data_fact.payload_length};
    assign address_sum={1'b0,bank_offset}+{1'b0,cursor};
    assign active=state!=IDLE;
    assign data_ready=state==IDLE && !power_reset && !new_track && !cancel && !fatal_latched && !cancelled_stream;
    // A Scheduler head retires with its actual chip write, not its read issue.
    assign dac_ready=write_valid && write_ready;
    assign reader_valid=state==ISSUE && !lifecycle_cancel && !reader_boundary_fault;
    assign reader_request=owned_read;
    assign reader_response_ready=state==WAIT_REPLY;
    assign owned_file_address=owned_read.address;
    assign write_valid=state==WRITE && !lifecycle_cancel && !power_reset;
    assign write_source=owned_event;
    always @* begin
        write_descriptor='0;
        write_descriptor.chip=CHIP_YM2612;write_descriptor.access_kind=ACCESS_REGISTER;
        write_descriptor.address=16'h002a;write_descriptor.data=resolved_byte;
    end
    assign fault_valid=state==FAULT;
    task automatic fail(input resource_result_t result);
        fault_result<=result;fault_epoch<=owned_read.epoch;fault_source<=owned_event;
        fatal_latched<=result!=RESOURCE_CANCELLED;state<=FAULT;
        if(result==RESOURCE_CANCELLED && owned_read.epoch==epoch) cancelled_stream<=1;
    endtask
    always_ff @(posedge clk) begin
        if(power_reset) begin
            state<=IDLE;bank_present<=0;bank_pc<=0;bank_offset<=0;bank_size<=0;bank_epoch<=0;
            cursor<=0;next_id<=0;owned_cursor<=0;owned_read<='0;owned_event<='0;
            resolved_byte<=0;cancelled<=0;cancelled_stream<=0;fatal_latched<=0;
            fault_result<=RESOURCE_OK;fault_epoch<=0;fault_source<='0;
        end else begin
            if(new_track || (bank_present && bank_epoch!=epoch)) begin
                bank_present<=0;bank_size<=0;cursor<=0;fatal_latched<=0;cancelled_stream<=0;
            end
            case(state)
                IDLE: begin
                    if(data_valid && data_ready) begin
                        if(data_fact.kind==DATA_SEEK) cursor<=data_fact.seek_offset;
                        else if(data_fact.block_type==0) begin
                            if(span_end[32] || span_end>{1'b0,file_extent} || data_fact.instance_id) begin
                                fatal_latched<=1;fault_result<=RESOURCE_METADATA;fault_epoch<=epoch;
                                fault_source<='0;fault_source.fact.kind<=S_DATA;
                                fault_source.fact.payload<=data_fact;state<=FAULT;
                            end else if(bank_present && (bank_pc!=data_fact.source_pc ||
                                bank_offset!=data_fact.payload_offset || bank_size!=data_fact.payload_length)) begin
                                fatal_latched<=1;fault_result<=RESOURCE_TABLE_FULL;fault_epoch<=epoch;
                                fault_source<='0;fault_source.fact.kind<=S_DATA;
                                fault_source.fact.payload<=data_fact;state<=FAULT;
                            end else begin
                                bank_present<=1;bank_pc<=data_fact.source_pc;bank_offset<=data_fact.payload_offset;
                                bank_size<=data_fact.payload_length;bank_epoch<=epoch;
                                // Revisit is idempotent. Only SEEK or new track changes cursor.
                            end
                        end
                    end else if(dac_valid && !fatal_latched && !cancelled_stream && !new_track && !cancel && channel_quiescent) begin
                        owned_event<=dac_event;owned_cursor<=cursor;cancelled<=0;
                        owned_read<={address_sum[31:0],next_id,epoch,file_extent};
                        if(!bank_present || bank_epoch!=epoch) begin
                            fault_result<=RESOURCE_MISSING;fatal_latched<=1;state<=FAULT;
                            fault_epoch<=epoch;fault_source<=dac_event;
                        end else if(cursor>=bank_size || address_sum[32] || address_sum>={1'b0,file_extent}) begin
                            fault_result<=RESOURCE_RANGE;fatal_latched<=1;state<=FAULT;
                            fault_epoch<=epoch;fault_source<=dac_event;
                        end else if(next_id==32'hffffffff) begin
                            fault_result<=RESOURCE_IDENTITY;fatal_latched<=1;state<=FAULT;
                            fault_epoch<=epoch;fault_source<=dac_event;
                        end else state<=ISSUE;
                    end
                end
                ISSUE: if(lifecycle_cancel) fail(RESOURCE_CANCELLED);
                    else if(reader_boundary_fault) fail(RESOURCE_READER_BOUNDARY);
                    else if(reader_ready) begin next_id<=next_id+1'b1;state<=WAIT_REPLY;end
                WAIT_REPLY: begin
                    if(lifecycle_cancel) cancelled<=1;
                    if(reader_response_valid) begin
                        if(reader_response.epoch!=owned_read.epoch ||
                           reader_response.transaction_id!=owned_read.transaction_id) fail(RESOURCE_IDENTITY);
                        else if(cancelled || lifecycle_cancel || reader_response.result==READ_CANCELLED) fail(RESOURCE_CANCELLED);
                        else case(reader_response.result)
                            READ_OK: begin resolved_byte<=reader_response.data;cursor<=owned_cursor+1'b1;state<=WRITE;end
                            READ_RANGE_ERROR: fail(RESOURCE_READER_RANGE);
                            READ_TIMEOUT: fail(RESOURCE_TIMEOUT);
                            default:fail(RESOURCE_IDENTITY);
                        endcase
                    end else if(reader_boundary_fault) fail(RESOURCE_READER_BOUNDARY);
                end
                WRITE: if(lifecycle_cancel) fail(RESOURCE_CANCELLED);
                    else if(write_ready) state<=IDLE;
                FAULT: if(fault_ready) state<=IDLE;
                default: fail(RESOURCE_IDENTITY);
            endcase
        end
    end
endmodule
