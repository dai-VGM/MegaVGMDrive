// Candidate control aperture. Musical/output boundaries never wait for storage.
module engine_a_vnext_c0_frame_boundary #(parameter int DEADLINE=600)(
 input logic clk,reset,enabled,execution_arm,native_tick,core_busy,mix_valid,
 input logic [63:0] playback_time,decoded_due,
 input logic stream_complete,scheduler_valid,queue_valid,
 input logic [63:0] scheduler_due,queue_due,
 output logic control_window,frame_tick,pending,deadline_fault,
 output logic [63:0] boundary_time,
 output logic [$clog2(DEADLINE+1)-1:0] age
);
 logic waiting,processing,horizon,control_debt,budget_expired;
 logic [63:0] cut;
 assign pending=enabled && execution_arm && (waiting || native_tick);
 assign cut=waiting ? boundary_time : playback_time;
 assign horizon=decoded_due>cut || stream_complete;
 assign control_debt=(scheduler_valid && scheduler_due<=cut) || (queue_valid && queue_due<=cut);
 // Age includes horizon acquisition and RF settlement, not just the Core walk.
 assign budget_expired=processing && int'(age)>=DEADLINE && !mix_valid;
 assign control_window=pending && !budget_expired && horizon && !core_busy && queue_due<=cut && !deadline_fault;
 assign frame_tick=(!enabled || !execution_arm) ? native_tick :
                   pending && !budget_expired && horizon && !control_debt && !core_busy && !deadline_fault;
 always_ff @(posedge clk)begin
  if(reset)begin waiting<=0;processing<=0;boundary_time<=0;age<=0;deadline_fault<=0;end
  else if(enabled && execution_arm && !deadline_fault)begin
   if(native_tick)begin
    boundary_time<=playback_time;age<=0;
    if(waiting || processing || core_busy)deadline_fault<=1;
    else begin waiting<=!frame_tick;processing<=1;end
   end else if(processing)begin
    if(int'(age)<DEADLINE)age<=age+1'b1;
    if(mix_valid)processing<=0;
    // mix_valid reports the completion edge one clock later.
    else if(int'(age)>=DEADLINE)deadline_fault<=1;
   end
   if(waiting && frame_tick)waiting<=0;
  end
 end
endmodule
