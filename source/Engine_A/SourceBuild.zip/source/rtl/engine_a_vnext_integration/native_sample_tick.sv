// Accepted SegaPCM input-clock /128 cadence, independent of storage completion.
module engine_a_vnext_native_sample_tick #(parameter int unsigned CLK_SYS_HZ=20000000)(
 input logic clk,reset,enabled,input logic [31:0] clock_hz,
 output logic native_tick
);
 localparam logic [32:0] DENOMINATOR=33'(CLK_SYS_HZ)*33'd128;
 logic [32:0] accumulator,next_accumulator;
 logic armed;
 assign next_accumulator=accumulator+{3'd0,clock_hz[29:0]};
 // The initial snapshot has frame identity zero, before the running cadence.
 assign native_tick=enabled && clock_hz[29:0]!=0 && (!armed || next_accumulator>=DENOMINATOR);
 always_ff @(posedge clk)begin
  if(reset || !enabled)begin accumulator<=0;armed<=0;end
  else if(!armed)begin accumulator<=0;armed<=1;end
  else accumulator<=next_accumulator>=DENOMINATOR ? next_accumulator-DENOMINATOR : next_accumulator;
 end
endmodule
