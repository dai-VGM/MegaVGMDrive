// Parser-only word-fill byte FIFO. No speculative physical reads or grammar.
// Fill provenance is the dedicated single-owner Strict Reader transaction.
module engine_a_vnext_command_byte_fifo #(
 parameter int CAPACITY_BYTES=8,
 parameter logic [28:0] DDR_BASE=29'h06000000
)(
 input logic clk,session_reset,enable,flush,
 input logic [31:0] epoch,file_extent,
 input logic byte_request_valid,output logic byte_request_ready,byte_response_valid,
 input logic [31:0] byte_address,output logic [7:0] byte_data,
 output logic reader_valid,input logic reader_ready,
 output vgm_reader_vnext_pkg::read_request_t reader_request,
 input logic reader_response_valid,
 input vgm_reader_vnext_pkg::read_response_t reader_response,
 input logic physical_accept,physical_response,
 input logic [28:0] physical_address,
 input logic [63:0] physical_data,
 input logic [31:0] physical_transaction_id,physical_epoch,
 output logic fatal_latched,
 output vgm_reader_vnext_pkg::read_result_t fault_result,
 output logic hit_pulse,miss_pulse,fill_pulse
);
 import vgm_reader_vnext_pkg::*;
 localparam int LINES=CAPACITY_BYTES/8;
 typedef enum logic {IDLE,PENDING} state_t;
 state_t state;
 logic [63:0] words[LINES];logic [28:0] tags[LINES];logic [LINES-1:0] valid_lines;
 logic [31:0] next_id,owned_id,owned_epoch,owned_address,owned_extent,cache_epoch,cache_extent,next_address;
 logic sequential,have_word,accepted_word,reply_valid;
 logic [63:0] observed_word;
 wire matching=state==PENDING && reader_response.transaction_id==owned_id &&
               reader_response.epoch==owned_epoch && owned_epoch==epoch;
 wire lifecycle_ok=!session_reset && !flush && enable && !fatal_latched;
 wire identity_ok=cache_epoch==epoch && cache_extent==file_extent;
 wire range_ok=byte_address<file_extent;
 wire [31:0] slot=(byte_address>>3)%LINES;
 wire [31:0] owned_slot=(owned_address>>3)%LINES;
 wire hit=identity_ok && sequential && byte_address==next_address && range_ok &&
          valid_lines[slot] && tags[slot]==byte_address[31:3];
 wire physical_matches=state==PENDING && physical_transaction_id==owned_id &&
      physical_epoch==owned_epoch && owned_epoch==epoch &&
      physical_address==DDR_BASE+{9'd0,owned_address[22:3]};
 assign byte_response_valid=reply_valid && lifecycle_ok && identity_ok;
 assign reader_valid=lifecycle_ok && state==IDLE && byte_request_valid && !hit && next_id!=32'hffffffff;
 assign reader_request={byte_address,next_id,epoch,file_extent};
 assign byte_request_ready=lifecycle_ok && state==IDLE && next_id!=32'hffffffff && (hit || reader_ready);
 assign hit_pulse=byte_request_valid && byte_request_ready && hit;
 assign miss_pulse=reader_valid && reader_ready;
 // A logical OK alone cannot authorize adjacent bytes. Require the matching
 // accepted full word, and agreement with the Strict Reader's demanded lane.
 assign fill_pulse=lifecycle_ok && reader_response_valid && matching &&
                   reader_response.result==READ_OK && have_word && accepted_word &&
                   observed_word[owned_address[2:0]*8+:8]==reader_response.data;
 always_ff @(posedge clk)begin
  if(session_reset)begin
   state<=IDLE;valid_lines<='0;next_id<=0;owned_id<=0;owned_epoch<=0;owned_address<=0;owned_extent<=0;
   cache_epoch<=epoch;cache_extent<=file_extent;next_address<=0;sequential<=0;
   have_word<=0;accepted_word<=0;observed_word<=0;reply_valid<=0;byte_data<=0;
   fatal_latched<=0;fault_result<=READ_OK;
  end else begin
   reply_valid<=0;
   if(flush || !enable || !identity_ok)begin valid_lines<='0;sequential<=0;end
   if(physical_accept && physical_matches)accepted_word<=1;
   if(physical_response && physical_matches)begin have_word<=1;observed_word<=physical_data;end
   if(byte_request_valid && byte_request_ready)begin
    cache_epoch<=epoch;cache_extent<=file_extent;next_address<=byte_address+1'b1;sequential<=1;
    if(!identity_ok || !sequential || byte_address!=next_address)valid_lines<='0;
    if(hit)begin reply_valid<=1;byte_data<=words[slot][byte_address[2:0]*8+:8];end
    else begin
     state<=PENDING;owned_id<=next_id;next_id<=next_id+1'b1;owned_epoch<=epoch;
     owned_address<=byte_address;owned_extent<=file_extent;have_word<=0;accepted_word<=0;
    end
   end
   if(reader_response_valid && state==PENDING)begin
    state<=IDLE;
    if(!matching || reader_response.result!=READ_OK)begin
     valid_lines<='0;sequential<=0;fatal_latched<=1;
     if(matching)fault_result<=reader_response.result;else fault_result<=READ_CANCELLED;
    end else if(lifecycle_ok && identity_ok && owned_extent==file_extent)begin
     reply_valid<=1;byte_data<=reader_response.data;
     if(fill_pulse)begin words[owned_slot]<=observed_word;tags[owned_slot]<=owned_address[31:3];valid_lines[owned_slot]<=1;end
     // Missing/mismatched physical provenance is an explicit boundary fault;
     // never populate a word from timeout synthetic bytes or another owner.
     else begin valid_lines<='0;sequential<=0;fatal_latched<=1;fault_result<=READ_CANCELLED;reply_valid<=0;end
    end
   end
   if(enable && byte_request_valid && next_id==32'hffffffff)begin fatal_latched<=1;fault_result<=READ_CANCELLED;end
  end
 end
endmodule
