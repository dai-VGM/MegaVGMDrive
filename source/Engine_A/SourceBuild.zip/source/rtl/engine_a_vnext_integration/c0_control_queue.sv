// Candidate-only control queue: ownership ends at the Core register handshake.
module engine_a_vnext_c0_control_queue #(parameter int DEPTH=16, PTR_WIDTH=$clog2(DEPTH))(
 input logic clk,reset,
 input logic input_valid, output logic input_ready,
 input vgm_scheduler_vnext_pkg::scheduled_fact_t input_fact,
 output logic output_valid, input logic output_ready,
 output vgm_scheduler_vnext_pkg::scheduled_fact_t output_fact,
 output logic [PTR_WIDTH:0] level
);
 import vgm_scheduler_vnext_pkg::*;
 scheduled_fact_t entries[DEPTH];
 logic [PTR_WIDTH-1:0] rd,wr;
 logic push,pop;
 initial if(DEPTH<2 || DEPTH!=(1<<PTR_WIDTH))$fatal(1,"queue depth must be a power of two");
 assign input_ready=!reset && int'(level)<DEPTH;
 assign output_valid=!reset && (level!=0 || input_valid);
 assign output_fact=level!=0 ? entries[rd] : input_fact;
 assign push=input_valid && input_ready && !(level==0 && output_ready);
 assign pop=level!=0 && output_valid && output_ready;
 always_ff @(posedge clk)begin
  if(reset)begin rd<=0;wr<=0;level<=0;end
  else begin
   if(push)begin entries[wr]<=input_fact;wr<=wr+1'b1;end
   if(pop)rd<=rd+1'b1;
   case({push,pop})2'b10:level<=level+1'b1;2'b01:level<=level-1'b1;default:begin end endcase
  end
 end
endmodule
