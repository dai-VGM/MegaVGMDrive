// SPDX-License-Identifier: BSD-3-Clause
// Independently authored K053260 chip-local candidate. No OKI/JT decoder reuse.
// Resource responses must preserve issue order within a voice; other voices may interleave.
module k053260_core #(parameter integer SLOTS=16, DEADLINE=350, parameter bit TRACE_OBSERVE=1)(
 input logic clk,power_reset,reload,input logic [31:0] epoch,
 input logic native_tick,
 input logic wr_valid,output logic wr_ready,input logic [5:0] wr_addr,input logic [7:0] wr_data,
 input logic rd_valid,output logic rd_ready,input logic [5:0] rd_addr,
 output logic rd_rsp_valid,output logic [7:0] rd_data,
 output logic rom_valid,input logic rom_ready,output logic [20:0] rom_addr,
 output logic [31:0] rom_epoch,output logic [31:0] rom_id,
 input logic rsp_valid,input logic [31:0] rsp_epoch,input logic [31:0] rsp_id,
 input logic [7:0] rsp_data,input logic [1:0] rsp_fault,
 output logic audio_valid,output logic signed [31:0] audio_l,audio_r,
 output logic busy,fault,output logic [3:0] fault_code,activity,
 output logic trace_valid,output logic [1:0] trace_voice,
 output logic [31:0] trace_position,output logic [15:0] trace_counter,
 output logic signed [7:0] trace_sample,output logic [15:0] frame_cycles,
 output logic [15:0] frame_reads,output logic [31:0] stale_responses
);
 localparam integer IW=$clog2(SLOTS);
 localparam logic [3:0] F_DEADLINE=1,F_RESOURCE=2,F_PROTOCOL=3;
 logic [11:0] pitch[4];logic [15:0] length[4];logic [20:0] start_addr[4];
 logic [6:0] volume[4];logic [2:0] pan[4];
 logic [3:0] looping,kadpcm,reverse,playing,complete;
 logic [31:0] position[4];logic [15:0] counter[4];logic signed [7:0] sample[4];
 logic [7:0] key_bits,mode,ports[4];
 logic [1:0] scan,mix_voice;logic mix_side;
 typedef enum logic [1:0] {IDLE,SCAN,MIX,READBACK} state_t;
 state_t state;
 logic [SLOTS-1:0] occupied;
 logic [31:0] issued_id;
 logic [31:0] saved_id[SLOTS];logic [1:0] saved_voice[SLOTS];
 logic saved_adpcm[SLOTS],saved_high[SLOTS],saved_loop[SLOTS],saved_read[SLOTS];
 logic [31:0] saved_position[SLOTS];logic [15:0] saved_counter[SLOTS];
 logic [31:0] last_voice_id[4];
 logic [3:0] voice_had_response;
 logic [31:0] next_position,byte_position;logic wraps,ends;
 logic [15:0] next_counter;logic needs_read,request_fire;
 logic [IW-1:0] issue_slot,response_slot;
 logic signed [31:0] sum_l,sum_r,contribution;
 logic [6:0] pan_gain;logic [13:0] gain;
 logic [15:0] age; logic read_issued,deadline_now,response_bad;
 assign deadline_now=busy && ((native_tick && state!=READBACK) || age>=16'(DEADLINE));
 assign response_bad=rsp_valid && rsp_epoch==epoch && (!occupied[response_slot] || saved_id[response_slot]!=rsp_id || rsp_fault!=0 || (!saved_read[response_slot] && voice_had_response[saved_voice[response_slot]] && $signed(rsp_id-last_voice_id[saved_voice[response_slot]])<=0));
 function automatic logic [6:0] pan_value(input logic [2:0] p,input logic right);
  case(p)
   0:pan_value=0;
   1:pan_value=right?0:127;
   2:pan_value=right?52:116;
   3:pan_value=right?73:104;
   4:pan_value=90;
   5:pan_value=right?104:73;
   6:pan_value=right?116:52;
   default:pan_value=right?127:0;
  endcase
 endfunction
 function automatic logic signed [7:0] delta(input logic [3:0] n);
  case(n)
   0:delta=0;1:delta=1;2:delta=2;3:delta=4;4:delta=8;5:delta=16;6:delta=32;7:delta=64;
   8:delta=-128;9:delta=-64;10:delta=-32;11:delta=-16;12:delta=-8;13:delta=-4;14:delta=-2;default:delta=-1;
  endcase
 endfunction
 assign busy=state!=IDLE;
 assign activity=playing;
 // Atomic native snapshots: writes accepted only between frames, never retime native_tick.
 assign wr_ready=!busy && !native_tick && !reload && !power_reset && !fault && !rd_valid && !response_bad;
 assign rd_ready=!busy && !native_tick && !reload && !power_reset && !fault && !response_bad;
 assign issue_slot=issued_id[IW-1:0];assign response_slot=rsp_id[IW-1:0];
 assign next_position=position[scan]+32'd1;
 assign byte_position=kadpcm[scan] ? next_position>>1 : next_position;
 assign wraps=byte_position>{16'd0,length[scan]} && looping[scan];
 assign ends=byte_position>{16'd0,length[scan]} && !looping[scan];
 assign next_counter=counter[scan]-16'd4096+{4'd0,pitch[scan]};
 assign needs_read=state==SCAN && !complete[scan] && playing[scan] && counter[scan]>=4096 && !ends;
 assign rom_valid=!fault && !reload && !power_reset && !deadline_now && !response_bad && !occupied[issue_slot] &&
                  (needs_read || (state==READBACK && !read_issued));
 assign rom_addr=state==READBACK ? start_addr[0]+21'(position[0]) :
                 (reverse[scan] ? start_addr[scan]-21'(wraps?32'd0:byte_position) :
                                  start_addr[scan]+21'(wraps?32'd0:byte_position));
 assign rom_epoch=epoch;assign rom_id=issued_id;
 assign request_fire=rom_valid && rom_ready;
 assign pan_gain=pan_value(pan[mix_voice],mix_side);
 assign gain=volume[mix_voice]*pan_gain;
 assign contribution=playing[mix_voice] ? ($signed(sample[mix_voice])*$signed({1'b0,gain}))>>>6 : 32'sd0;
 always_ff @(posedge clk)begin
  audio_valid<=0;rd_rsp_valid<=0;trace_valid<=0;
  if(power_reset || reload)begin
   read_issued<=0;state<=IDLE;fault<=0;fault_code<=0;occupied<='0;issued_id<=0;
   playing<=0;complete<=0;looping<=0;kadpcm<=0;reverse<=0;voice_had_response<=0;
   key_bits<=0;mode<=0;scan<=0;mix_voice<=0;mix_side<=0;
   sum_l<=0;sum_r<=0;audio_l<=0;audio_r<=0;rd_data<=0;age<=0;frame_cycles<=0;frame_reads<=0;
   trace_voice<=0;trace_position<=0;trace_counter<=0;trace_sample<=0;
   if(power_reset)stale_responses<=0;
   for(integer v=0;v<4;v=v+1)begin
    pitch[v]<=0;length[v]<=0;start_addr[v]<=0;volume[v]<=0;pan[v]<=0;
    position[v]<=0;counter[v]<=0;sample[v]<=0;ports[v]<=0;
    last_voice_id[v]<=0;
   end
  end else begin
   if(busy)age<=age+1'b1;
   // No old-epoch response can complete a new request, even when IDs have restarted.
   if(rsp_valid && rsp_epoch!=epoch)stale_responses<=stale_responses+1'b1;
   if(rsp_valid && rsp_epoch==epoch && !fault && !deadline_now)begin
    if(!occupied[response_slot] || saved_id[response_slot]!=rsp_id)begin fault<=1;fault_code<=F_PROTOCOL;end
    else begin
     occupied[response_slot]<=0;
     if(rsp_fault!=0)begin fault<=1;fault_code<=F_RESOURCE;end
     else if(!fault)begin
      if(saved_read[response_slot])begin rd_rsp_valid<=1;rd_data<=rsp_data;state<=IDLE;end
      else begin
       // Tagged bus supplies ordered responses within each voice. Nonconforming transport faults.
       if(voice_had_response[saved_voice[response_slot]] &&
          $signed(rsp_id-last_voice_id[saved_voice[response_slot]])<=0)begin fault<=1;fault_code<=F_PROTOCOL;end
       last_voice_id[saved_voice[response_slot]]<=rsp_id;voice_had_response[saved_voice[response_slot]]<=1;
       sample[saved_voice[response_slot]]<=saved_adpcm[response_slot] ?
        (saved_loop[response_slot]?8'sd0:sample[saved_voice[response_slot]])+
          delta(saved_high[response_slot]?rsp_data[7:4]:rsp_data[3:0]) : $signed(rsp_data);
       trace_valid<=TRACE_OBSERVE;trace_voice<=TRACE_OBSERVE?saved_voice[response_slot]:2'd0;
       trace_position<=TRACE_OBSERVE?saved_position[response_slot]:32'd0;trace_counter<=TRACE_OBSERVE?saved_counter[response_slot]:16'd0;
       trace_sample<=!TRACE_OBSERVE?8'sd0:saved_adpcm[response_slot] ?
        (saved_loop[response_slot]?8'sd0:sample[saved_voice[response_slot]])+
          delta(saved_high[response_slot]?rsp_data[7:4]:rsp_data[3:0]) : $signed(rsp_data);
      end
     end
    end
   end
   if(deadline_now && !fault)begin fault<=1;fault_code<=F_DEADLINE;end
   if(!fault && !deadline_now && !response_bad)begin
    if(wr_valid && wr_ready)begin
     if(wr_addr>=8 && wr_addr<=39)begin
      case(wr_addr[2:0])
       0:pitch[(wr_addr-8)>>3][7:0]<=wr_data;
       1:pitch[(wr_addr-8)>>3][11:8]<=wr_data[3:0];
       2:length[(wr_addr-8)>>3][7:0]<=wr_data;
       3:length[(wr_addr-8)>>3][15:8]<=wr_data;
       4:start_addr[(wr_addr-8)>>3][7:0]<=wr_data;
       5:start_addr[(wr_addr-8)>>3][15:8]<=wr_data;
       6:start_addr[(wr_addr-8)>>3][20:16]<=wr_data[4:0];
       7:volume[(wr_addr-8)>>3]<=wr_data[6:0];
      endcase
     end else case(wr_addr)
      2:ports[2]<=wr_data;3:ports[3]<=wr_data;
      40:begin
       key_bits<=wr_data;reverse<=wr_data[7:4];
       for(integer v=0;v<4;v=v+1)begin
        if(wr_data[v] && !key_bits[v])begin playing[v]<=1;position[v]<=kadpcm[v]?32'd1:32'd0;counter[v]<=4032;sample[v]<=0;end
        else if(!wr_data[v])begin playing[v]<=0;position[v]<=0;sample[v]<=0;end
       end
      end
      42:begin looping<=wr_data[3:0];kadpcm<=wr_data[7:4];end
      44:begin pan[0]<=wr_data[2:0];pan[1]<=wr_data[5:3];end
      45:begin pan[2]<=wr_data[2:0];pan[3]<=wr_data[5:3];end
      47:mode<=wr_data;
      default:begin end
     endcase
    end
    if(rd_valid && rd_ready)begin
     if(rd_addr==46 && mode[0])begin state<=READBACK;read_issued<=0;age<=0;end
     else begin rd_rsp_valid<=1;rd_data<=rd_addr==41?{4'd0,playing}:(rd_addr<2?ports[rd_addr[1:0]]:8'd0);end
    end
    case(state)
     IDLE:if(native_tick)begin
      age<=0;frame_reads<=0;scan<=0;sum_l<=0;sum_r<=0;complete<=~playing;
      if(mode[1])begin
       state<=SCAN;for(integer v=0;v<4;v=v+1)if(playing[v])counter[v]<=counter[v]+16'd64;
      end else begin audio_l<=0;audio_r<=0;audio_valid<=1;frame_cycles<=1;end
     end
     SCAN:begin
      if(!(rom_valid && !rom_ready))scan<=scan+1'b1;
      if(!complete[scan])begin
       if(!playing[scan] || counter[scan]<4096)complete[scan]<=1;
       else if(ends)begin
        counter[scan]<=next_counter;position[scan]<=next_position;playing[scan]<=0;complete[scan]<=1;
       end else if(request_fire)begin
        counter[scan]<=next_counter;position[scan]<=wraps?32'd0:next_position;
        if(next_counter<4096)complete[scan]<=1;
       end
      end
      if(&complete && occupied=='0)begin state<=MIX;mix_voice<=0;mix_side<=0;end
     end
     MIX:begin
      if(!mix_side)begin sum_l<=sum_l+contribution;mix_side<=1;end
      else begin
       sum_r<=sum_r+contribution;mix_side<=0;mix_voice<=mix_voice+1'b1;
       if(mix_voice==3)begin audio_l<=sum_l;audio_r<=sum_r+contribution;audio_valid<=1;state<=IDLE;frame_cycles<=age+1'b1;end
      end
     end
     READBACK:if(request_fire)begin read_issued<=1;position[0]<={16'd0,position[0][15:0]+16'd1};end
     default:begin end
    endcase
    if(request_fire)begin
     occupied[issue_slot]<=1;saved_id[issue_slot]<=issued_id;issued_id<=issued_id+1'b1;frame_reads<=frame_reads+1'b1;
     saved_voice[issue_slot]<=scan;saved_adpcm[issue_slot]<=kadpcm[scan];
     saved_high[issue_slot]<=!wraps && next_position[0];saved_loop[issue_slot]<=wraps;
     saved_position[issue_slot]<=TRACE_OBSERVE?(wraps?32'd0:next_position):32'd0;saved_counter[issue_slot]<=TRACE_OBSERVE?next_counter:16'd0;
     saved_read[issue_slot]<=state==READBACK;
     if(state==READBACK)begin state<=READBACK;end
    end
   end
  end
 end
endmodule
