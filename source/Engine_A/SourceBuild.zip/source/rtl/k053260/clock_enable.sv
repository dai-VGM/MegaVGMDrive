// SPDX-License-Identifier: BSD-3-Clause
// Exact rational input-clock /64 cadence in the existing clk_sys domain.
module k053260_clock_enable #(parameter integer SYS_HZ=20000000)(
 input logic clk,reset,enabled,input logic [31:0] clock_hz,output logic native_tick
);
 localparam logic [32:0] MODULUS=33'(SYS_HZ)*33'd64;
 logic [32:0] phase,next_phase;
 assign next_phase=phase+{1'b0,clock_hz};
 assign native_tick=enabled && clock_hz!=0 && next_phase>=MODULUS;
 always_ff @(posedge clk)
  if(reset || !enabled)phase<=0;
  else phase<=native_tick?next_phase-MODULUS:next_phase;
endmodule
