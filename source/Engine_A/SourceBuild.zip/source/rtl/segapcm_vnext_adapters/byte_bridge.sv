// Simulation/candidate byte client ownership; no grammar or physical DDR knowledge.
module segapcm_vnext_byte_bridge (
    input logic clk,session_reset,enable,
    input logic [31:0] epoch,file_extent,
    input logic byte_request_valid,
    output logic byte_request_ready,byte_response_valid,
    input logic [31:0] byte_address,
    output logic [7:0] byte_data,
    output logic reader_valid,
    input logic reader_ready,
    output vgm_reader_vnext_pkg::read_request_t reader_request,
    input logic reader_response_valid,
    input vgm_reader_vnext_pkg::read_response_t reader_response,
    output logic fatal_latched
);
    import vgm_reader_vnext_pkg::*;
    logic pending;
    logic [31:0] next_id,owned_id,owned_epoch;
    wire matching=pending && reader_response.epoch==owned_epoch &&
        reader_response.transaction_id==owned_id && owned_epoch==epoch;
    assign reader_valid=enable && byte_request_valid && !pending && !session_reset &&
        !fatal_latched && next_id!=32'hffffffff;
    assign byte_request_ready=reader_ready && enable && !pending && !session_reset && !fatal_latched && next_id!=32'hffffffff;
    assign reader_request={byte_address,next_id,epoch,file_extent};
    assign byte_response_valid=reader_response_valid && matching && reader_response.result==READ_OK && !session_reset;
    assign byte_data=reader_response.data;
    always_ff @(posedge clk) begin
        if(session_reset)begin pending<=0;next_id<=0;owned_id<=0;owned_epoch<=0;fatal_latched<=0;end
        else begin
            if(reader_valid && reader_ready)begin pending<=1;owned_id<=next_id;owned_epoch<=epoch;next_id<=next_id+1'b1;end
            if(reader_response_valid && pending)begin
                pending<=0;
                if(!matching || reader_response.result!=READ_OK)fatal_latched<=1;
            end
            if(enable && byte_request_valid && next_id==32'hffffffff)fatal_latched<=1;
        end
    end
endmodule
