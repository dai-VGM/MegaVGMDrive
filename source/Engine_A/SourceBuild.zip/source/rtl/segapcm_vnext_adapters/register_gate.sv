// Buffer commits within the same native interval, after the bounded core walk.
// The Scheduler still owns VGM due time; this gate owns chip-port readiness.
module segapcm_vnext_register_gate #(parameter int CORE_DEADLINE=600)(
    input logic clk,reset,native_tick,execution_arm,
    output logic window_open
);
    logic [$clog2(CORE_DEADLINE+1)-1:0] age;
    assign window_open=!execution_arm || (int'(age)>=CORE_DEADLINE && !native_tick);
    always_ff @(posedge clk) begin
        if(reset || !execution_arm || native_tick)age<=0;
        else if(int'(age)<CORE_DEADLINE)age<=age+1'b1;
    end
endmodule
