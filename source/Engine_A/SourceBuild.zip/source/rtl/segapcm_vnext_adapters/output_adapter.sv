module segapcm_vnext_output_adapter #(parameter int OUTPUT_SHIFT=-1)(
    input logic clk, reset, invalidate, native_tick, raw_valid,
    input logic signed [18:0] raw_left,raw_right,
    output logic audio_valid,
    output logic signed [15:0] audio_left,audio_right,
    output logic clipped_left,clipped_right,
    output logic pending, overflow_latched
);
    logic signed [18:0] held_left,held_right;
    logic signed [19:0] scaled_left,scaled_right;
    assign scaled_left=OUTPUT_SHIFT<0 ? ($signed({held_left[18],held_left}) <<< (-OUTPUT_SHIFT)) : ($signed({held_left[18],held_left}) >>> OUTPUT_SHIFT);
    assign scaled_right=OUTPUT_SHIFT<0 ? ($signed({held_right[18],held_right}) <<< (-OUTPUT_SHIFT)) : ($signed({held_right[18],held_right}) >>> OUTPUT_SHIFT);
    function automatic logic signed [15:0] saturate(input logic signed [19:0] x);
        if(x>20'sd32767) return 16'sh7fff;
        else if(x< -20'sd32768) return 16'sh8000;
        else return x[15:0];
    endfunction
    initial if(OUTPUT_SHIFT< -1 || OUTPUT_SHIFT>3)$fatal(1,"unsupported output shift");
    always_ff @(posedge clk) begin
        audio_valid<=0;
        if(reset) overflow_latched<=0;
        else if(raw_valid && pending && !native_tick && !invalidate)overflow_latched<=1;
        if(reset || invalidate || overflow_latched || (raw_valid && pending && !native_tick)) begin
            pending<=0;held_left<=0;held_right<=0;audio_left<=0;audio_right<=0;
            clipped_left<=0;clipped_right<=0;
        end else begin
            if(native_tick && pending) begin
                audio_valid<=1;audio_left<=saturate(scaled_left);audio_right<=saturate(scaled_right);
                clipped_left<=scaled_left>20'sd32767 || scaled_left< -20'sd32768;
                clipped_right<=scaled_right>20'sd32767 || scaled_right< -20'sd32768;
                pending<=0;
            end
            if(raw_valid)begin pending<=1;held_left<=raw_left;held_right<=raw_right;end
        end
    end
endmodule
