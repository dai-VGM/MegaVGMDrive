module segapcm_vnext_sample_adapter (
    input logic clk, power_reset, new_track, channel_quiescent,
    input logic [31:0] current_epoch, file_extent, mapped_file_address,
    input segapcm_vnext_adapter_pkg::resource_result_t mapping_result,
    input logic request_valid,
    output logic request_ready,
    input segapcm_vnext_pkg::sample_request_t request,
    output logic response_valid,
    input logic response_ready,
    output segapcm_vnext_pkg::sample_response_t response,
    output logic reader_request_valid,
    input logic reader_request_ready,
    output vgm_reader_vnext_pkg::read_request_t reader_request,
    input logic reader_response_valid,
    output logic reader_response_ready,
    input vgm_reader_vnext_pkg::read_response_t reader_response,
    input logic reader_boundary_fault,
    output logic fatal_latched,
    output segapcm_vnext_adapter_pkg::resource_result_t fatal_reason,
    output logic gap_hit,
    output logic [31:0] gap_count,
    output logic active
);
    import segapcm_vnext_pkg::*;
    import vgm_reader_vnext_pkg::*;
    import segapcm_vnext_adapter_pkg::*;
    typedef enum logic [1:0] {IDLE,ISSUE,WAIT_REPLY,REPLY} state_t;
    state_t state;
    sample_request_t owned;
    read_request_t read_owned;
    logic cancel_owned;
    assign request_ready=state==IDLE && !power_reset && !new_track && channel_quiescent && !fatal_latched;
    assign active=state!=IDLE;
    assign reader_request_valid=state==ISSUE && !new_track && owned.epoch==current_epoch && !reader_boundary_fault;
    assign reader_request=read_owned;
    assign reader_response_ready=state==WAIT_REPLY;
    assign response_valid=state==REPLY;
    task automatic complete(input sample_result_t result,input logic[7:0] value);
        response.epoch<=owned.epoch;response.request_id<=owned.request_id;response.voice_id<=owned.voice_id;
        response.result<=result;response.data<=result==SAMPLE_OK ? value : 0;state<=REPLY;
    endtask
    task automatic fatal(input resource_result_t reason);
        fatal_latched<=1;fatal_reason<=reason;
    endtask
    always_ff @(posedge clk) begin
        if(power_reset) begin
            state<=IDLE;owned<='0;read_owned<='0;response<='0;cancel_owned<=0;
            fatal_latched<=0;fatal_reason<=RESOURCE_OK;gap_hit<=0;gap_count<=0;
        end else begin
            gap_hit<=0;
            if(new_track) begin fatal_latched<=0;fatal_reason<=RESOURCE_OK;gap_count<=0;end
            if(state!=IDLE && (new_track || owned.epoch!=current_epoch)) cancel_owned<=1;
            case(state)
                IDLE: if(request_valid && request_ready) begin
                    owned<=request;cancel_owned<=0;
                    read_owned.address<=mapped_file_address;read_owned.file_extent<=file_extent;
                    read_owned.epoch<=request.epoch;read_owned.transaction_id<=request.request_id;
                    response.epoch<=request.epoch;response.request_id<=request.request_id;response.voice_id<=request.voice_id;
                    response.data<=0;
                    if(request.epoch!=current_epoch) begin response.result<=SAMPLE_CANCELLED;state<=REPLY;end
                    else if(mapping_result==DECLARED_ROM_GAP) begin
                        response.result<=SAMPLE_OK;response.data<=8'h80;state<=REPLY;gap_hit<=1;
                        if(gap_count!=32'hffffffff)gap_count<=gap_count+1'b1;
                    end else if(mapping_result!=RESOURCE_OK) begin
                        response.result<=SAMPLE_FAULT;state<=REPLY;fatal(mapping_result);
                    end else state<=ISSUE;
                end
                ISSUE: begin
                    if(new_track || owned.epoch!=current_epoch) complete(SAMPLE_CANCELLED,0);
                    else if(reader_boundary_fault) begin fatal(RESOURCE_READER_BOUNDARY);complete(SAMPLE_FAULT,0);end
                    else if(reader_request_ready) state<=WAIT_REPLY;
                end
                WAIT_REPLY: if(reader_boundary_fault && !reader_response_valid) begin
                    fatal(RESOURCE_READER_BOUNDARY);complete(SAMPLE_FAULT,0);
                end else if(reader_response_valid) begin
                    if(reader_response.epoch!=owned.epoch || reader_response.transaction_id!=owned.request_id) begin
                        fatal(RESOURCE_IDENTITY);complete(SAMPLE_FAULT,0);
                    end else if(cancel_owned || new_track || owned.epoch!=current_epoch || reader_response.result==READ_CANCELLED)
                        complete(SAMPLE_CANCELLED,0);
                    else case(reader_response.result)
                        READ_OK: complete(SAMPLE_OK,reader_response.data);
                        READ_RANGE_ERROR:begin fatal(RESOURCE_READER_RANGE);complete(SAMPLE_FAULT,0);end
                        default:begin fatal(RESOURCE_TIMEOUT);complete(SAMPLE_FAULT,0);end
                    endcase
                end
                REPLY: if(response_ready) state<=IDLE;
                default:begin fatal(RESOURCE_IDENTITY);state<=IDLE;end
            endcase
        end
    end
endmodule
