// One physical-channel owner. Strict Reader retains late-response drain debt.
module segapcm_vnext_reader_arbiter (
    input logic clk,power_reset,
    input logic parser_valid,
    output logic parser_ready,
    input vgm_reader_vnext_pkg::read_request_t parser_request,
    output logic parser_response_valid,
    input logic parser_response_ready,
    output vgm_reader_vnext_pkg::read_response_t parser_response,
    input logic sample_valid, sample_pending,
    output logic sample_ready,
    input vgm_reader_vnext_pkg::read_request_t sample_request,
    output logic sample_response_valid,
    input logic sample_response_ready,
    output vgm_reader_vnext_pkg::read_response_t sample_response,
    output logic reader_valid,
    input logic reader_ready,
    output vgm_reader_vnext_pkg::read_request_t reader_request,
    input logic reader_response_valid,
    output logic reader_response_ready,
    input vgm_reader_vnext_pkg::read_response_t reader_response,
    output logic active
);
    logic owned_sample;
    assign reader_valid=!active && (sample_valid || (parser_valid && !sample_pending)) && !power_reset;
    assign reader_request=sample_valid ? sample_request : parser_request;
    assign sample_ready=!active && reader_ready && !power_reset;
    assign parser_ready=sample_ready && !sample_valid && !sample_pending;
    assign sample_response_valid=active && owned_sample && reader_response_valid;
    assign parser_response_valid=active && !owned_sample && reader_response_valid;
    assign sample_response=reader_response;
    assign parser_response=reader_response;
    assign reader_response_ready=active && (owned_sample ? sample_response_ready : parser_response_ready);
    always_ff @(posedge clk) begin
        if(power_reset)begin active<=0;owned_sample<=0;end
        else begin
            if(reader_valid && reader_ready)begin active<=1;owned_sample<=sample_valid;end
            if(reader_response_valid && reader_response_ready)active<=0;
        end
    end
endmodule
