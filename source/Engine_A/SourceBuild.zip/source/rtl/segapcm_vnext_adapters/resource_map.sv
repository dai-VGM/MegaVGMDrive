module segapcm_vnext_resource_map #(parameter int REGIONS=32)(
    input logic clk, power_reset, new_track,
    input logic [31:0] current_epoch, file_extent,
    input logic register_valid,
    output logic register_ready,
    input vgm_parser_vnext_event_pkg::data_event_t block_fact,
    input logic [31:0] query_epoch,
    input logic [20:0] query_address,
    output logic [31:0] file_address,
    output segapcm_vnext_adapter_pkg::resource_result_t query_result,
    output logic registration_fault,
    output segapcm_vnext_adapter_pkg::resource_result_t registration_reason,
    output logic [31:0] generation, rom_extent
);
    import vgm_parser_vnext_event_pkg::*;
    import segapcm_vnext_adapter_pkg::*;
    logic valid[REGIONS];
    logic [31:0] base[REGIONS], length[REGIONS], offset[REGIONS], pc[REGIONS], order_id[REGIONS];
    logic [31:0] map_epoch, map_file_extent;
    logic present;
    integer slot;
    logic [31:0] declared_rom, declared_start, newest;
    logic [32:0] logical_end, file_end, translated;
    logic changed_size, metadata_bad;
    assign declared_rom=block_fact.operands[79:48];
    assign declared_start=block_fact.operands[111:80];
    assign logical_end={1'b0,declared_start}+{1'b0,block_fact.payload_length};
    assign file_end={1'b0,block_fact.payload_offset}+{1'b0,block_fact.payload_length};
    assign changed_size=present && declared_rom!=rom_extent;
    assign metadata_bad=block_fact.kind!=DATA_BLOCK || block_fact.opcode!=8'h67 ||
        block_fact.block_type!=8'h80 || block_fact.instance_id || block_fact.metadata_bytes!=8 ||
        declared_rom>32'h200000 || logical_end>{1'b0,declared_rom} ||
        file_end>{1'b0,file_extent} || block_fact.payload_offset>file_extent;
    assign register_ready=!power_reset && !new_track && !registration_fault;
    // A1: maximum order stamp, with the higher slot winning equal stamps.
    // The old ascending >= fold has exactly this priority. Padded leaves never
    // match. No register/pipeline stage is added to the combinational lookup.
    localparam int LEAVES = 1 << $clog2(REGIONS);
    wire hit [2*LEAVES];
    wire [31:0] winner_order [2*LEAVES];
    wire [31:0] winner_base [2*LEAVES], winner_offset [2*LEAVES];
    genvar leaf, node;
    generate
        for (leaf=0; leaf<LEAVES; leaf=leaf+1) begin : query_leaf
            if (leaf<REGIONS) begin : populated
                assign hit[LEAVES+leaf] = valid[leaf] &&
                    {11'd0,query_address}>=base[leaf] &&
                    {12'd0,query_address}<{1'b0,base[leaf]}+{1'b0,length[leaf]};
                assign winner_order[LEAVES+leaf] = order_id[leaf];
                assign winner_base[LEAVES+leaf] = base[leaf];
                assign winner_offset[LEAVES+leaf] = offset[leaf];
            end else begin : padding
                assign hit[LEAVES+leaf] = 1'b0;
                assign winner_order[LEAVES+leaf] = 32'd0;
                assign winner_base[LEAVES+leaf] = 32'd0;
                assign winner_offset[LEAVES+leaf] = 32'd0;
            end
        end
        for (node=1; node<LEAVES; node=node+1) begin : query_branch
            wire take_right;
            assign take_right = hit[2*node+1] && (!hit[2*node] ||
                winner_order[2*node+1]>=winner_order[2*node]);
            assign hit[node] = hit[2*node] || hit[2*node+1];
            assign winner_order[node] = take_right ? winner_order[2*node+1] : winner_order[2*node];
            assign winner_base[node] = take_right ? winner_base[2*node+1] : winner_base[2*node];
            assign winner_offset[node] = take_right ? winner_offset[2*node+1] : winner_offset[2*node];
        end
    endgenerate
    always @* begin
        slot=-1;
        // Revisited source PC reuses capacity but acquires a new order stamp.
        for(integer n=REGIONS-1;n>=0;n=n-1)
            if(!valid[n]) slot=n;
        for(integer n=0;n<REGIONS;n=n+1)
            if(valid[n] && pc[n]==block_fact.source_pc) slot=n;
        if(changed_size) slot=0;
        query_result=RESOURCE_MISSING; file_address=0; newest=0; translated=0;
        if(query_epoch!=current_epoch || (present && (query_epoch!=map_epoch || file_extent!=map_file_extent)))
            query_result=RESOURCE_STALE;
        else if(present) begin
            query_result={11'd0,query_address}>=rom_extent ? RESOURCE_RANGE : DECLARED_ROM_GAP;
            if(hit[1]) begin
                newest=winner_order[1];
                translated={1'b0,winner_offset[1]}+({12'd0,query_address}-{1'b0,winner_base[1]});
                file_address=translated[31:0];
                query_result=translated<{1'b0,file_extent} ? RESOURCE_OK : RESOURCE_METADATA;
            end
        end
    end
    always_ff @(posedge clk) begin
        if(power_reset || new_track) begin
            present<=0; rom_extent<=0; map_epoch<=current_epoch;map_file_extent<=file_extent;
            registration_fault<=0;registration_reason<=RESOURCE_OK;generation<=0;
            for(integer n=0;n<REGIONS;n=n+1) begin
                valid[n]<=0;base[n]<=0;length[n]<=0;offset[n]<=0;pc[n]<=0;order_id[n]<=0;
            end
        end else if(register_valid && register_ready) begin
            if(metadata_bad || (present && (map_epoch!=current_epoch || map_file_extent!=file_extent))) begin
                registration_fault<=1;registration_reason<=RESOURCE_METADATA;
            end else if(generation==32'hffffffff) begin
                registration_fault<=1;registration_reason<=RESOURCE_GENERATION;
            end else if(slot<0) begin
                registration_fault<=1;registration_reason<=RESOURCE_TABLE_FULL;
            end else begin
                if(changed_size) for(integer n=0;n<REGIONS;n=n+1) valid[n]<=0;
                present<=1;rom_extent<=declared_rom;map_epoch<=current_epoch;map_file_extent<=file_extent;
                generation<=generation+1'b1; valid[slot]<=1;
                base[slot]<=declared_start;length[slot]<=block_fact.payload_length;
                offset[slot]<=block_fact.payload_offset;pc[slot]<=block_fact.source_pc;
                order_id[slot]<=generation+1'b1;
            end
        end
    end
endmodule
