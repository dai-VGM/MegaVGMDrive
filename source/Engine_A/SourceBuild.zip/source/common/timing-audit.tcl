load_package sta
set project MegaVGMDrive_A_K053260_Candidate_MiSTer
project_open $project -revision $project
create_timing_netlist
read_sdc
set receipt [open output/endpoint-summary.tsv w]
puts $receipt "model\ttemperature_C\tcheck\tworst_slack_ns\tviolating_endpoints\tendpoint_TNS_ns\tworst_from\tworst_to"
foreach model {slow fast} {
 foreach temp {100 -40} {
  set_operating_conditions -model $model -temperature $temp -voltage 1100
  update_timing_netlist
  set label "${model}_${temp}"
  foreach check {setup hold recovery removal} {
   set worst [get_timing_paths -$check -npaths 1]
   set worst_slack NA;set start NA;set end NA
   foreach_in_collection path $worst {
    set worst_slack [get_path_info $path -slack]
    set start [get_node_info -name [get_path_info $path -from]]
    set end [get_node_info -name [get_path_info $path -to]]
   }
   set paths [get_timing_paths -$check -npaths 0 -nworst 1 -less_than_slack 0]
   set endpoints [dict create]
   set details [open "output/${label}_${check}_violating_endpoints.tsv" w]
   puts $details "slack_ns\tfrom\tto"
   foreach_in_collection path $paths {
    set slack [get_path_info $path -slack]
    set from [get_node_info -name [get_path_info $path -from]]
    set to [get_node_info -name [get_path_info $path -to]]
    if {![dict exists $endpoints $to] || $slack < [dict get $endpoints $to]} {dict set endpoints $to $slack}
    puts $details "$slack\t$from\t$to"
   }
   close $details
   set tns 0.0
   dict for {endpoint slack} $endpoints {set tns [expr {$tns+$slack}]}
   puts $receipt "$model\t$temp\t$check\t$worst_slack\t[dict size $endpoints]\t[format %.6f $tns]\t$start\t$end"
   flush $receipt
   puts "AUDIT_CORNER $label $check slack=$worst_slack violating_endpoints=[dict size $endpoints] endpoint_TNS=$tns"
   report_timing -$check -npaths 1 -detail full_path -file "output/${label}_${check}_worst.rpt"
  }
  set registers [get_registers *]
  foreach check {setup hold} {
   report_timing -$check -from $registers -to $registers -npaths 10 -detail full_path -file "output/${label}_internal_${check}.rpt"
   set paths [get_timing_paths -$check -from $registers -to $registers -npaths 1]
   foreach_in_collection path $paths {puts "INTERNAL_CORNER $label $check slack=[get_path_info $path -slack] from=[get_node_info -name [get_path_info $path -from]] to=[get_node_info -name [get_path_info $path -to]]"}
  }
  set pulse [lindex [get_min_pulse_width -nworst 1] 0]
  set pulse_slack [lindex $pulse 0]
  set pulse_target [lindex $pulse 6]
  set pulse_endpoints [dict create]
  set pulse_checks 0
  if {$pulse_slack < 0} {
   foreach item [get_min_pulse_width -nworst 1000000] {
    set slack [lindex $item 0]
    if {$slack < 0} {
     incr pulse_checks
     set target [lindex $item 6]
     if {![dict exists $pulse_endpoints $target] || $slack < [dict get $pulse_endpoints $target]} {dict set pulse_endpoints $target $slack}
    }
   }
  }
  set pulse_tns 0.0
  dict for {target slack} $pulse_endpoints {set pulse_tns [expr {$pulse_tns+$slack}]}
  puts $receipt "$model\t$temp\tpulse_width\t$pulse_slack\t[dict size $pulse_endpoints]\t[format %.6f $pulse_tns]\t[lindex $pulse 4]\t$pulse_target"
  flush $receipt
  report_min_pulse_width -nworst 1 -detail full_path -file "output/${label}_pulse_width_worst.rpt"
 }
}
close $receipt
report_ucp -file output/unconstrained.rpt
report_clocks -file output/clocks.rpt
report_sdc -file output/sdc.rpt
delete_timing_netlist
project_close
puts AUDIT_MULTICORNER_COMPLETE
