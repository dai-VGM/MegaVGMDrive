// SPDX-License-Identifier: GPL-2.0-or-later
//
// Two-line native prepared-name panel renderer.
//
// Coordinates are native active-picture coordinates. Each printable ASCII
// character occupies a 6x7 cell containing one 5x7 glyph plus one blank
// horizontal pixel.

module megavgm_title_renderer (
	input  logic [9:0] h_count,
	input  logic [8:0] v_count,
	input  logic       drawing_active,

	input  logic       title_valid,
	input  logic [5:0] directory_length,
	input  logic [5:0] basename_length,
	output logic [6:0] title_read_addr,
	input  logic [7:0] title_read_data,
	input  logic       source_activity_visible,
	input  logic [4:0] source_activity,
	input  logic       engine_d_activity_visible,
	input  logic [7:0] engine_d_ym_activity,
	input  logic [23:0] engine_d_c140_activity,
	input  logic       engine_d_system21,
	input  logic [1:0] player_state,

	output logic       text_pixel,
	output logic       panel_pixel,
	output logic [23:0] panel_rgb
);

	// Center the historical 320x240 player surface in the Template's
	// 529x240 active picture. The 288-pixel basename has 16-pixel margins.
	localparam logic [9:0] PANEL_LEFT = 10'd104;
	localparam logic [9:0] PANEL_RIGHT = 10'd423;
	localparam logic [8:0] PANEL_BOTTOM = 9'd239;
	localparam logic [9:0] TEXT_X = 10'd120;
	localparam logic [8:0] DIRECTORY_Y = 9'd24;
	localparam logic [8:0] BASENAME_Y = 9'd34;
	localparam logic [8:0] ACTIVITY_0_Y = 9'd56;
	localparam logic [8:0] ACTIVITY_1_Y = 9'd68;
	localparam logic [8:0] ACTIVITY_2_Y = 9'd80;
	localparam logic [8:0] ACTIVITY_3_Y = 9'd92;
	localparam logic [8:0] ACTIVITY_4_Y = 9'd104;
	localparam logic [9:0] INDICATOR_LEFT = 10'd176;
	localparam logic [9:0] INDICATOR_RIGHT = 10'd181;
	localparam logic [8:0] ENGINE_D_PROFILE_Y = 9'd56;
	localparam logic [8:0] ENGINE_D_YM2151_Y = 9'd80;
	localparam logic [8:0] ENGINE_D_C140_0_Y = 9'd104;
	localparam logic [8:0] ENGINE_D_C140_1_Y = 9'd116;
	localparam logic [9:0] ENGINE_D_INDICATOR_X = 10'd192;
	localparam logic [9:0] ENGINE_D_INDICATOR_STEP_X = 10'd18;
	localparam logic [9:0] ENGINE_D_INDICATOR_LAST_X = 10'd5;
	localparam logic [8:0] ENGINE_D_INDICATOR_LAST_Y = 9'd4;
	localparam logic [9:0] STATUS_BADGE_X = 10'd388;
	localparam logic [8:0] STATUS_BADGE_Y = 9'd224;
	localparam logic [23:0] PANEL_COLOR = 24'h000818;
	localparam logic [23:0] ACTIVITY_OFF_COLOR = 24'h102838;
	localparam logic [23:0] ACTIVITY_ON_COLOR = 24'h40c5d8;

	logic [7:0] character;
	logic [2:0] glyph_x;
	logic [2:0] glyph_y;
	logic       cell_visible;
	logic       glyph_pixel;
	logic [9:0] relative_x;
	logic [6:0] character_index;
	logic [9:0] character_cell_x;
	logic [2:0] activity_row;
	logic [8:0] activity_row_y;
	logic       activity_row_valid;
	logic       indicator_pixel;
	logic       indicator_on;
	logic       engine_d_profile_row;
	logic [4:0] engine_d_indicator_base;
	logic [3:0] engine_d_indicator_count;
	logic [4:0] engine_d_indicator_index;
	logic [31:0] engine_d_activity_bus;
	logic       status_badge_cell;
	logic       status_badge_pixel;
	logic [1:0] status_badge_index;
	logic [23:0] status_badge_color;

	function automatic logic [7:0] status_badge_character(
		input logic [1:0] state,
		input logic [1:0] index
	);
		begin
			status_badge_character = " ";
			unique case(state)
				2'd0: unique case(index)
					0: status_badge_character = "S"; 1: status_badge_character = "T";
					2: status_badge_character = "O"; 3: status_badge_character = "P";
				endcase
				2'd1: unique case(index)
					0: status_badge_character = "L"; 1: status_badge_character = "O";
					2: status_badge_character = "A"; 3: status_badge_character = "D";
				endcase
				2'd2: unique case(index)
					0: status_badge_character = "P"; 1: status_badge_character = "L";
					2: status_badge_character = "A"; 3: status_badge_character = "Y";
				endcase
				default: status_badge_character = " ";
			endcase
		end
	endfunction

	function automatic logic [7:0] activity_label_character(
		input logic [2:0] row,
		input logic [3:0] index
	);
		begin
			activity_label_character = " ";
			unique case(row)
				3'd0: unique case(index)
					0: activity_label_character = "Y"; 1: activity_label_character = "M";
					2: activity_label_character = "2"; 3: activity_label_character = "6";
					4: activity_label_character = "1"; 5: activity_label_character = "2";
					default: activity_label_character = " ";
				endcase
				3'd1: unique case(index)
					0: activity_label_character = "P"; 1: activity_label_character = "S";
					2: activity_label_character = "G";
					default: activity_label_character = " ";
				endcase
				3'd2: unique case(index)
					0: activity_label_character = "Y"; 1: activity_label_character = "M";
					2: activity_label_character = "2"; 3: activity_label_character = "1";
					4: activity_label_character = "5"; 5: activity_label_character = "1";
					default: activity_label_character = " ";
				endcase
				3'd3: unique case(index)
					0: activity_label_character = "S"; 1: activity_label_character = "E";
					2: activity_label_character = "G"; 3: activity_label_character = "A";
					4: activity_label_character = " "; 5: activity_label_character = "P";
					6: activity_label_character = "C"; 7: activity_label_character = "M";
					default: activity_label_character = " ";
				endcase
				3'd4: unique case(index)
					0: activity_label_character = "Y"; 1: activity_label_character = "M";
					2: activity_label_character = "2"; 3: activity_label_character = "2";
					4: activity_label_character = "0"; 5: activity_label_character = "3";
					default: activity_label_character = " ";
				endcase
				default: activity_label_character = " ";
			endcase
		end
	endfunction

	function automatic logic [7:0] engine_d_profile_character(
		input logic system21,
		input logic [3:0] index
	);
		begin
			engine_d_profile_character = " ";
`ifdef MEGAVGM_ENGINE_F_VNEXT
            case(index)
                0: engine_d_profile_character="P";
                1: engine_d_profile_character="C";
                2: engine_d_profile_character=" ";
                3: engine_d_profile_character="E";
                4: engine_d_profile_character="N";
                5: engine_d_profile_character="G";
                6: engine_d_profile_character="I";
                7: engine_d_profile_character="N";
                8: engine_d_profile_character="E";
                default: engine_d_profile_character=" ";
            endcase
`else
			unique case(index)
				0: engine_d_profile_character = "S";
				1: engine_d_profile_character = "Y";
				2: engine_d_profile_character = "S";
				3: engine_d_profile_character = "T";
				4: engine_d_profile_character = "E";
				5: engine_d_profile_character = "M";
				6: engine_d_profile_character = " ";
				7: engine_d_profile_character = "2";
				8: engine_d_profile_character = system21 ? "1" : " ";
				default: engine_d_profile_character = " ";
			endcase
`endif
		end
	endfunction

	function automatic logic [7:0] engine_d_activity_label_character(
		input logic [2:0] row,
		input logic [3:0] index
	);
		begin
			engine_d_activity_label_character = " ";
`ifdef MEGAVGM_ENGINE_F_VNEXT
            if(row==1)case(index)
                0: engine_d_activity_label_character="H";
                1: engine_d_activity_label_character="U";
                2: engine_d_activity_label_character="C";
                3: engine_d_activity_label_character="6";
                4: engine_d_activity_label_character="2";
                5: engine_d_activity_label_character="8";
                6: engine_d_activity_label_character="0";
                default: engine_d_activity_label_character=" ";
            endcase
`else
			unique case(row)
				3'd1: unique case(index)
					0: engine_d_activity_label_character = "Y";
					1: engine_d_activity_label_character = "M";
					2: engine_d_activity_label_character = "2";
					3: engine_d_activity_label_character = "1";
					4: engine_d_activity_label_character = "5";
					5: engine_d_activity_label_character = "1";
					default: engine_d_activity_label_character = " ";
				endcase
				3'd2: unique case(index)
					0: engine_d_activity_label_character = "C";
					1: engine_d_activity_label_character = "1";
					2: engine_d_activity_label_character = "4";
					3: engine_d_activity_label_character = "0";
					default: engine_d_activity_label_character = " ";
				endcase
				default: engine_d_activity_label_character = " ";
			endcase
`endif
		end
	endfunction

	megavgm_font5x7 font (
		.character(character),
		.glyph_x(glyph_x),
		.glyph_y(glyph_y),
		.pixel(glyph_pixel)
	);

	always @* begin
		character = " ";
		glyph_x = 0;
		glyph_y = 0;
		title_read_addr = 0;
		cell_visible = 1'b0;
		relative_x = 0;
		character_index = 0;
		character_cell_x = 0;
		activity_row = 0;
		activity_row_y = 0;
		activity_row_valid = 1'b0;
		indicator_pixel = 1'b0;
		indicator_on = 1'b0;
		engine_d_profile_row = 1'b0;
		engine_d_indicator_base = 5'd0;
		engine_d_indicator_count = 4'd0;
		engine_d_indicator_index = 5'd0;
		engine_d_activity_bus = {engine_d_c140_activity,
		                         engine_d_ym_activity};
		status_badge_cell = 1'b0;
		status_badge_pixel = 1'b0;
		status_badge_index = 2'd0;
		status_badge_color = (player_state == 2'd0) ?
			ACTIVITY_OFF_COLOR : ACTIVITY_ON_COLOR;
		panel_pixel =
			drawing_active &&
			(h_count >= PANEL_LEFT) && (h_count <= PANEL_RIGHT) &&
			(v_count <= PANEL_BOTTOM);

		if(engine_d_activity_visible) begin
			if((v_count >= ENGINE_D_PROFILE_Y) &&
			   (v_count < ENGINE_D_PROFILE_Y + 9'd7)) begin
				engine_d_profile_row = 1'b1;
			end
			else if((v_count >= ENGINE_D_YM2151_Y) &&
			        (v_count < ENGINE_D_YM2151_Y + 9'd7)) begin
				activity_row = 3'd1; activity_row_y = ENGINE_D_YM2151_Y;
				activity_row_valid = 1'b1;
				engine_d_indicator_base = 5'd0;
				`ifdef MEGAVGM_ENGINE_F_VNEXT
                engine_d_indicator_count = 4'd6;
`else
                engine_d_indicator_count = 4'd8;
`endif
			end
`ifndef MEGAVGM_ENGINE_F_VNEXT
			else if((v_count >= ENGINE_D_C140_0_Y) &&
			        (v_count < ENGINE_D_C140_0_Y + 9'd7)) begin
				activity_row = 3'd2; activity_row_y = ENGINE_D_C140_0_Y;
				activity_row_valid = 1'b1;
				engine_d_indicator_base = 5'd8;
				engine_d_indicator_count = 4'd12;
			end
			else if((v_count >= ENGINE_D_C140_1_Y) &&
			        (v_count < ENGINE_D_C140_1_Y + 9'd7)) begin
				activity_row = 3'd3; activity_row_y = ENGINE_D_C140_1_Y;
				activity_row_valid = 1'b1;
				engine_d_indicator_base = 5'd20;
				engine_d_indicator_count = 4'd12;
			end
`endif
		end
		else if(source_activity_visible) begin
			if((v_count >= ACTIVITY_0_Y) && (v_count < ACTIVITY_0_Y + 9'd7)) begin
				activity_row = 3'd0; activity_row_y = ACTIVITY_0_Y; activity_row_valid = 1'b1;
			end
			else if((v_count >= ACTIVITY_1_Y) && (v_count < ACTIVITY_1_Y + 9'd7)) begin
				activity_row = 3'd1; activity_row_y = ACTIVITY_1_Y; activity_row_valid = 1'b1;
			end
			else if((v_count >= ACTIVITY_2_Y) && (v_count < ACTIVITY_2_Y + 9'd7)) begin
				activity_row = 3'd2; activity_row_y = ACTIVITY_2_Y; activity_row_valid = 1'b1;
			end
			else if((v_count >= ACTIVITY_3_Y) && (v_count < ACTIVITY_3_Y + 9'd7)) begin
				activity_row = 3'd3; activity_row_y = ACTIVITY_3_Y; activity_row_valid = 1'b1;
			end
			else if((v_count >= ACTIVITY_4_Y) && (v_count < ACTIVITY_4_Y + 9'd7)) begin
				activity_row = 3'd4; activity_row_y = ACTIVITY_4_Y; activity_row_valid = 1'b1;
			end
		end

		if(engine_d_activity_visible) begin
			if(activity_row_valid && panel_pixel &&
			   (v_count <= activity_row_y + ENGINE_D_INDICATOR_LAST_Y)) begin
				for(integer engine_d_col = 0; engine_d_col < 12;
				    engine_d_col = engine_d_col + 1) begin
					if((engine_d_col < engine_d_indicator_count) &&
					   (h_count >= ENGINE_D_INDICATOR_X +
					               engine_d_col[9:0] * ENGINE_D_INDICATOR_STEP_X) &&
					   (h_count <= ENGINE_D_INDICATOR_X +
					               engine_d_col[9:0] * ENGINE_D_INDICATOR_STEP_X +
					               ENGINE_D_INDICATOR_LAST_X)) begin
						indicator_pixel = 1'b1;
						engine_d_indicator_index = engine_d_indicator_base +
						                           engine_d_col[4:0];
					end
				end
				indicator_on = indicator_pixel &&
				               engine_d_activity_bus[engine_d_indicator_index];
			end
		end else begin
			indicator_pixel = panel_pixel && activity_row_valid &&
				(h_count >= INDICATOR_LEFT) && (h_count <= INDICATOR_RIGHT) &&
				(v_count >= activity_row_y + 9'd1) &&
				(v_count <= activity_row_y + 9'd5);
			indicator_on = indicator_pixel && source_activity[activity_row];
		end
		panel_rgb = !panel_pixel ? 24'h000000 :
			indicator_on ? ACTIVITY_ON_COLOR :
			indicator_pixel ? ACTIVITY_OFF_COLOR : PANEL_COLOR;

		if(panel_pixel &&
		   (h_count >= STATUS_BADGE_X) && (h_count < STATUS_BADGE_X + 10'd24) &&
		   (v_count >= STATUS_BADGE_Y) && (v_count < STATUS_BADGE_Y + 9'd7)) begin
			status_badge_cell = 1'b1;
			if(h_count < STATUS_BADGE_X + 10'd6) begin
				status_badge_index = 2'd0;
				glyph_x = h_count - STATUS_BADGE_X;
			end else if(h_count < STATUS_BADGE_X + 10'd12) begin
				status_badge_index = 2'd1;
				glyph_x = h_count - (STATUS_BADGE_X + 10'd6);
			end else if(h_count < STATUS_BADGE_X + 10'd18) begin
				status_badge_index = 2'd2;
				glyph_x = h_count - (STATUS_BADGE_X + 10'd12);
			end else begin
				status_badge_index = 2'd3;
				glyph_x = h_count - (STATUS_BADGE_X + 10'd18);
			end
			glyph_y = v_count - STATUS_BADGE_Y;
			character = status_badge_character(player_state, status_badge_index);
			cell_visible = 1'b1;
		end
		else if(panel_pixel && (h_count >= TEXT_X)) begin
			relative_x = h_count - TEXT_X;
			/* verilator lint_off WIDTHTRUNC */
			character_index = relative_x / 10'd6;
			character_cell_x = character_index * 10'd6;
			glyph_x = relative_x - character_cell_x;
			/* verilator lint_on WIDTHTRUNC */

			if((v_count >= DIRECTORY_Y) && (v_count < DIRECTORY_Y + 9'd7) &&
			   title_valid && (character_index < {1'b0, directory_length})) begin
				/* verilator lint_off WIDTHTRUNC */
				glyph_y = v_count - DIRECTORY_Y;
				/* verilator lint_on WIDTHTRUNC */
				title_read_addr = character_index;
				character = title_read_data;
				cell_visible = 1'b1;
			end
			else if((v_count >= BASENAME_Y) && (v_count < BASENAME_Y + 9'd7) &&
			        title_valid && (character_index < {1'b0, basename_length})) begin
				/* verilator lint_off WIDTHTRUNC */
				glyph_y = v_count - BASENAME_Y;
				/* verilator lint_on WIDTHTRUNC */
				title_read_addr = 7'd32 + character_index;
				character = title_read_data;
				cell_visible = 1'b1;
			end
			else if(engine_d_activity_visible && engine_d_profile_row &&
			        (character_index < 7'd9)) begin
				glyph_y = v_count - ENGINE_D_PROFILE_Y;
				character = engine_d_profile_character(
					engine_d_system21, character_index[3:0]);
				cell_visible = 1'b1;
			end
			else if(engine_d_activity_visible && activity_row_valid &&
			        (character_index < 7'd8)) begin
				glyph_y = v_count - activity_row_y;
				character = engine_d_activity_label_character(
					activity_row, character_index[3:0]);
				cell_visible = 1'b1;
			end
			else if(source_activity_visible && activity_row_valid &&
			        (character_index < 7'd8)) begin
				/* verilator lint_off WIDTHTRUNC */
				glyph_y = v_count - activity_row_y;
				/* verilator lint_on WIDTHTRUNC */
				character = activity_label_character(activity_row, character_index[3:0]);
				cell_visible = 1'b1;
			end
		end

		status_badge_pixel = status_badge_cell && (glyph_x < 5) && glyph_pixel;
		if(status_badge_pixel)
			panel_rgb = status_badge_color;
		text_pixel = !status_badge_cell && cell_visible && (glyph_x < 5) && glyph_pixel;
	end

endmodule
