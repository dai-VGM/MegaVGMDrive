// Command bytes only: one demand-filled Golden word, no speculative reads.
// A fill requires a matching physical word AND its Strict READ_OK demanded lane.
module engine_b_vnext_command_word_buffer (
 input logic clk,reset,enable,
 input logic [31:0] epoch,file_extent,
 input logic byte_request, input logic [31:0] byte_address,
 output logic byte_ready,byte_valid,output logic [7:0] byte_data,
 output logic memory_request,output logic [31:0] memory_address,
 input logic memory_ready,memory_valid,input logic [7:0] memory_data,
 input logic word_valid,input logic [31:0] word_address,word_epoch,input logic [63:0] word_data
);
 logic pending,reply,line_valid,sequential,have_word;logic[7:0] cached_byte;
 logic [31:0] owned_address,owned_epoch,owned_extent,next_address,line_epoch,line_extent;
 logic [28:0] line_tag;logic [63:0] line_word,observed_word;
 wire hit=enable && !pending && line_valid && sequential && byte_address==next_address &&
          line_tag==byte_address[31:3] && line_epoch==epoch && line_extent==file_extent && byte_address<file_extent;
 assign memory_request=byte_request && !pending && !hit && !reset;
 assign memory_address=byte_address;
 assign byte_ready=!reset && !pending && (hit || memory_ready);
 assign byte_valid=!reset && ((reply && line_epoch==epoch && line_extent==file_extent) ||
                  (memory_valid && pending && owned_epoch==epoch && owned_extent==file_extent));
 assign byte_data=reply ? cached_byte : memory_data;
 always_ff @(posedge clk)begin
  if(reset)begin
   pending<=0;reply<=0;line_valid<=0;sequential<=0;have_word<=0;
   owned_address<=0;owned_epoch<=0;owned_extent<=0;next_address<=0;line_epoch<=0;line_extent<=0;
   line_tag<=0;line_word<=0;observed_word<=0;cached_byte<=0;
  end else begin
   reply<=0;
   if(line_epoch!=epoch || line_extent!=file_extent || !enable)line_valid<=0;
   if(byte_request && byte_ready)begin
    next_address<=byte_address+1'b1;sequential<=1;
    if(hit)begin reply<=1;cached_byte<=line_word[byte_address[2:0]*8+:8];end
    else begin
     line_valid<=0;pending<=1;owned_address<=byte_address;owned_epoch<=epoch;owned_extent<=file_extent;have_word<=0;
    end
   end
   if(word_valid && pending && word_address==owned_address && word_epoch==owned_epoch && word_epoch==epoch)begin
    observed_word<=word_data;have_word<=1;
   end
   // memory_valid is strictly READ_OK, never a timeout/cancel synthetic byte.
   if(memory_valid && pending)begin
    pending<=0;
    if(owned_epoch==epoch && owned_extent==file_extent)begin
     // Strict demanded byte is passed through on this same edge.
     reply<=0;
     if(enable && have_word && observed_word[owned_address[2:0]*8+:8]==memory_data)begin
      line_word<=observed_word;line_tag<=owned_address[31:3];line_epoch<=owned_epoch;line_extent<=owned_extent;line_valid<=1;
     end
    end
   end
  end
 end
endmodule
