// Global arbiter exit, not a Parser-only observer: every PCM/command owner crosses
// this single physical ledger. Frozen arbiter routes only OK back to its owner.
module engine_b_vnext_shared_reader_binding (
 input logic clk,power_reset,backend_reset,download_active,session_reload,
 input logic [31:0] current_epoch,file_extent,
 input logic backend_loaded,backend_load_error,
 input logic request_valid, output logic request_ready,
 input logic [31:0] request_address,
 output logic response_valid, output logic [7:0] response_byte,
 output logic fault_valid,
 output vgm_reader_vnext_pkg::read_response_t fault_response,
 output logic golden_request, output logic [22:0] golden_byte_address,
 input logic golden_ready,golden_valid,golden_read,golden_write,
 input logic [28:0] golden_address,
 input logic [7:0] golden_be,golden_burst,
 output logic golden_busy,avalon_read,
 output logic [28:0] avalon_address,
 output logic [7:0] avalon_be,avalon_burst,
 input logic avalon_busy,avalon_valid,
 input logic [63:0] avalon_data,
 output logic word_valid,output logic [31:0] word_address,word_epoch,output logic [63:0] word_data,
 output logic request_captured,
 output logic logical_active,drain_blocked,boundary_fault
);
 import vgm_reader_vnext_pkg::*;
 read_request_t request;
 read_response_t response;
 logic strict_valid,strict_ready,physical_accept,physical_response;
 logic [31:0] owned_address;
 typedef enum logic [1:0] {OFFER,CAPTURED,ACKED} state_t;
 state_t state;logic [31:0] owned_epoch;
 wire lifecycle=backend_reset || download_active || session_reload;
 // Do not start the retained arbiter response watchdog at Strict frontend
 // capture. Its byte request is acknowledged only at physical ACCEPT.
 assign request_ready=state==CAPTURED && physical_accept && logical_active &&
                       owned_epoch==current_epoch && !lifecycle;
 logic [31:0] next_transaction;
 assign request={request_address,next_transaction,current_epoch,file_extent};
 assign request_captured=state==OFFER && request_valid && strict_ready && !lifecycle;
 // Faults are explicit, never converted to a byte or routed into Parser/cache.
 assign response_valid=strict_valid && response.result==READ_OK;
 assign response_byte=response.data;
 assign fault_valid=strict_valid && response.result!=READ_OK;
 assign fault_response=response;
 assign word_valid=physical_response && state==ACKED && logical_active && owned_epoch==current_epoch && !lifecycle;
 assign word_address=owned_address;assign word_epoch=owned_epoch;assign word_data=avalon_data;
 always_ff @(posedge clk)begin
  if(power_reset)begin next_transaction<=0;state<=OFFER;owned_epoch<=0;owned_address<=0;end
  else begin
   if(state==OFFER && request_valid && strict_ready && !lifecycle)begin
    next_transaction<=next_transaction+1'b1;state<=CAPTURED;owned_epoch<=current_epoch;owned_address<=request_address;
   end
   if(request_valid && request_ready)state<=ACKED;
   if(strict_valid)state<=OFFER;
  end
 end
 engine_a_vnext_strict_golden_read_binding strict_boundary(
  .clk,.power_reset,.backend_reset,.download_active,.session_reload,.current_epoch,
  .request_valid(request_valid && state==OFFER && !lifecycle),.request_ready(strict_ready),.request_data(request),.response_valid(strict_valid),
  .response_ready(1'b1),.response_data(response),.backend_loaded,.backend_load_error,
  .backend_file_size(file_extent),.golden_request,.golden_byte_address,
  .golden_ready,.golden_valid,.golden_read,.golden_write,.golden_address,.golden_be,.golden_burst,
  .golden_busy,.avalon_read,.avalon_address,.avalon_be,.avalon_burst,
  .avalon_busy,.avalon_valid,.avalon_data,.logical_active,.drain_blocked,.boundary_fault,
  .capture(),.physical_accept,.physical_response,.cancelled(),.timed_out(),
  .ledger_transaction_id(),.ledger_epoch(),.acceptance_stalls(),.response_age(),.state_debug());
endmodule
