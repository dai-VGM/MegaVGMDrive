// Descriptor-to-existing-wrapper handshake only. No opcode/time/resource policy.
module engine_a_vnext_chip_write_adapter #(parameter int TARGET=0)(
 input logic enabled,valid,core_ready,
 input vgm_parser_vnext_event_pkg::write_descriptor_t descriptor,
 output logic ready,write_pulse,port,rejected,control_noop,
 output logic [7:0] address,data
);
 import vgm_parser_vnext_event_pkg::*;
 logic supported;
 // Production A has no Game Gear stereo input. Keep the grammar fact, retire
 // it at this explicit adapter capability boundary without a PSG data write.
 assign control_noop=TARGET==0 && descriptor.access_kind==ACCESS_CONTROL;
 assign supported=int'(descriptor.chip)==TARGET && !descriptor.instance_id &&
    descriptor.address[15:8]==0 &&
    ((TARGET==0 && (descriptor.access_kind==ACCESS_DATA || control_noop)) ||
     (TARGET>=1 && TARGET<=3 && descriptor.access_kind==ACCESS_REGISTER &&
      (TARGET==1 || !descriptor.port)));
 assign rejected=enabled && valid && !supported;
 assign ready=enabled && (supported ? (control_noop || core_ready) : 1'b1);
 assign write_pulse=valid && ready && supported && !control_noop;
 assign port=descriptor.port;assign address=descriptor.address[7:0];assign data=descriptor.data;
endmodule
