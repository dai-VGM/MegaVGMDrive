// Playback-to-decoder control only. Transport owns policy; Scheduler owns time.
module engine_a_vnext_loop_continuation_client (
    input logic clk, reset, new_track,
    input logic boundary_valid, boundary_ready,
    input logic [31:0] boundary_target,
    input logic owner_halt,
    input logic scheduler_waiting, scheduler_release,
    output logic decision_valid, decision_halt,
    output logic resume_valid,
    input logic resume_ready,
    output logic [31:0] resume_pc,
    output logic busy
);
    typedef enum logic [1:0] {IDLE, DECISION, RELEASE, RESUME} state_t;
    state_t state;
    assign decision_valid=state==DECISION && scheduler_waiting && !reset && !new_track;
    assign resume_valid=state==RESUME && !reset && !new_track;
    assign busy=state!=IDLE;
    always_ff @(posedge clk) begin
        if(reset || new_track) begin state<=IDLE;decision_halt<=0;resume_pc<=0;end
        else case(state)
            IDLE: if(boundary_valid && boundary_ready) begin
                // Sample BEFORE the owner's registered first/second-boundary update.
                decision_halt<=owner_halt;resume_pc<=boundary_target;state<=DECISION;
            end
            DECISION: if(decision_valid) begin
                if(decision_halt) state<=IDLE; else state<=RELEASE;
            end
            RELEASE: if(scheduler_release) state<=RESUME;
            RESUME: if(resume_ready) state<=IDLE;
            default:state<=IDLE;
        endcase
    end
endmodule
