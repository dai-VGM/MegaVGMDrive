`timescale 1ns/1ps

// Engine D adaptation for the production playlist-status ABI. This block is
// observation-only glue: it never gates upload, parser, or audio work.
module megavgm_engine_d_runtime_status_bridge (
    input  logic        clk,
    input  logic        reset,
    input  logic        ioctl_download,
    input  logic [15:0] ioctl_index,
    input  logic        ioctl_wr,
    input  logic [26:0] ioctl_addr,
    input  logic  [7:0] ioctl_dout,
    input  logic        ioctl_wait,
    input  logic        load_done,
    input  logic        player_done,
    input  logic        player_fatal,
    input  logic        loop_policy_active,
    input  logic        playback_loop_boundary_pulse,
    input  logic  [5:0] parser_state,
    input  logic  [7:0] parser_command,

    output logic        runtime_ready,
    output logic [31:0] playback_session_id,
    output logic [31:0] done_session_id,
    output logic [31:0] error_session_id,
    output logic        player_loop_valid,
    output logic        player_loop_boundary_pulse
);
    localparam logic [7:0] FILE_INDEX = 8'd1;

    logic selected_download_d;
    logic player_done_d;
    logic player_fatal_d;
    logic [31:0] header_loop_offset;

    wire selected_download =
        ioctl_download && (ioctl_index[7:0] == FILE_INDEX);
    wire load_begin = selected_download && !selected_download_d;
    wire accepted_header_byte =
        selected_download && ioctl_wr && !ioctl_wait;

    // Unlike Engine A, Engine D has no long internal cold-start sequencer.
    // The profile is host-ready when its shared outer reset is released, not
    // after a VGM has already been uploaded.
    assign runtime_ready = !reset;
    assign player_loop_valid = load_done && (header_loop_offset != 32'd0);
    // Playback facts are authoritative for every policy, including OFF.
    assign player_loop_boundary_pulse = player_loop_valid && playback_loop_boundary_pulse;

    always_ff @(posedge clk) begin
        if (reset) begin
            selected_download_d <= 1'b0;
            player_done_d <= 1'b0;
            player_fatal_d <= 1'b0;
            playback_session_id <= 32'd0;
            done_session_id <= 32'd0;
            error_session_id <= 32'd0;
            header_loop_offset <= 32'd0;
        end else begin
            selected_download_d <= selected_download;
            player_done_d <= player_done;
            player_fatal_d <= player_fatal;

            if (load_begin) begin
                playback_session_id <= playback_session_id + 32'd1;
                header_loop_offset <= 32'd0;
            end else if (accepted_header_byte) begin
                unique case (ioctl_addr)
                    27'h000001c: header_loop_offset[7:0] <= ioctl_dout;
                    27'h000001d: header_loop_offset[15:8] <= ioctl_dout;
                    27'h000001e: header_loop_offset[23:16] <= ioctl_dout;
                    27'h000001f: header_loop_offset[31:24] <= ioctl_dout;
                    default: begin end
                endcase
            end

            if (player_done && !player_done_d)
                done_session_id <= playback_session_id;
            if (player_fatal && !player_fatal_d)
                error_session_id <= playback_session_id;
        end
    end
endmodule
