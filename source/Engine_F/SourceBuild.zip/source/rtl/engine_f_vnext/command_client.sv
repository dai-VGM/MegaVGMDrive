// SPDX-License-Identifier: GPL-2.0-or-later
// Composition of the existing Parser/Normalizer/Scheduler/continuation client.
// External Reader owns byte provenance/epoch/drain. No Parser/Transport fork.
module engine_f_vnext_command_client #(parameter DEPTH=8)(
 input logic clk,reset,start,playback_tick,transport_halt_loop,transport_finish,strict_fault,
 input logic [31:0] image_size,
 output logic memory_request,input logic memory_ready,memory_valid,
 output logic [31:0] memory_address,input logic [7:0] memory_data,
 input logic chip_ready,
 output logic chip_reset,chip_write,output logic [3:0] chip_address,output logic [7:0] chip_data,
 output logic running,accepted,fault,finished,loop_entry,loop_boundary,
 output logic [63:0] playback_time,due_time,
 output logic [63:0] write_due,write_sequence,
 output logic [31:0] write_pc,
 output logic [31:0] maximum_lateness);
 import vgm_parser_vnext_event_pkg::*;import vgm_scheduler_vnext_pkg::*;
 typedef enum logic[3:0]{IDLE,SCAN_ARM,SCAN,CHIP_CLEAR,REPLAY,INITIALIZE,PLAY,STOP,FAIL}phase_t;
 phase_t phase;
 logic parser_start,event_valid,event_ready,data_valid,dac_valid,parser_done,loop_present,loop_terminal,resume_ready,resume_fault;
 logic [31:0] extent,data_start,loop_target,terminal_pc,resume_pc;
 decode_event_t ev;write_descriptor_t wi;data_event_t de;dac_stream_fact_t da;
 logic norm_ready,fact_valid,fact_ready,barrier_valid,barrier_ready,waiting,released,halted,terminal,scheduler_fault;
 logic [2:0] scheduler_reason;logic[63:0] sequence_next;
 normalized_fact_t fact;scheduled_fact_t commits[8],barrier,chosen;
 logic[7:0] commit_valid,commit_ready;logic[$clog2(DEPTH):0] levels[8];
 logic decision_valid,decision_halt,resume_valid,continuation_busy;
 write_descriptor_t selected_write;decode_event_t selected_event;
 logic [63:0] late;
 logic initial_wait_seen,queues_empty;
 assign parser_start=phase==SCAN_ARM || phase==REPLAY;
 assign chip_reset=reset || start || phase==IDLE || phase==SCAN_ARM || phase==SCAN;
 assign running=phase==PLAY && !fault;
 assign event_ready=phase==SCAN ? 1'b1 : norm_ready;
 assign accepted=phase==CHIP_CLEAR || phase==REPLAY || phase==INITIALIZE || phase==PLAY || phase==STOP;
 assign finished=phase==STOP;
 assign chosen=commits[7];
 always @* begin
 commit_ready=0;commit_ready[7]=chip_ready && (phase==INITIALIZE || phase==PLAY) && !fault && !transport_finish;
 chip_write=commit_valid[7] && commit_ready[7];
 chip_address=selected_write.address[3:0];
 chip_data=selected_write.data;
 write_due=chosen.due_time;write_sequence=chosen.sequence_id;write_pc=selected_event.source_pc;
 queues_empty=1;for(integer j=0;j<8;j=j+1)if(levels[j]!=0)queues_empty=0;
 end
 always @* begin
 selected_write=chosen.fact.payload[134:80];selected_event=chosen.fact.payload[79:0];
 end
 // Typed adapter avoids relying on hand-packed offsets at chip boundary.
 wire [3:0] adapted_address=selected_write.address[3:0];
 wire [7:0] adapted_data=selected_write.data;
 // Chip boundary outputs are assigned from the typed descriptor.
 assign late=playback_time>chosen.due_time?playback_time-chosen.due_time:64'd0;
 assign loop_entry=barrier_valid && barrier_ready && barrier.fact.kind==S_LOOP_ENTRY;
 assign loop_boundary=barrier_valid && barrier_ready && barrier.fact.kind==S_LOOP_BOUNDARY;
 assign barrier_ready=phase==PLAY || phase==INITIALIZE;
 vgm_parser_vnext_decoder #(.HUC6280_WRITE_GRAMMAR(1),.RESUME_CONTROL(1)) parser(
 .clk,.reset(reset || start),.start(parser_start),.resume_valid,.resume_pc,.resume_ready,.resume_fault,.image_size,
 .reader_req_valid(memory_request),.reader_req_ready(memory_ready),.reader_req_addr(memory_address),.reader_rsp_valid(memory_valid),.reader_rsp_byte(memory_data),
 .event_valid,.event_ready,.event_data(ev),.write_info(wi),.data_event_valid(data_valid),.data_event_data(de),.dac_fact_valid(dac_valid),.dac_fact_data(da),
 .done(parser_done),.file_extent(extent),.data_start,.loop_present,.loop_target,.loop_terminal_valid(loop_terminal),.loop_terminal_pc(terminal_pc),.loop_entry_seen());
 vgm_scheduler_vnext_normalizer normalizer(.clk,.reset(reset || start),
 .event_valid(event_valid && phase!=SCAN),.data_event_valid(data_valid && phase!=SCAN),.dac_fact_valid(dac_valid && phase!=SCAN),.loop_terminal_valid(loop_terminal && phase!=SCAN),
 .event_data(ev),.write_info(wi),.data_event_data(de),.dac_fact_data(da),.loop_present,.loop_target,.loop_terminal_pc(terminal_pc),
 .event_ready(norm_ready),.fact_valid,.fact_ready,.fact);
 vgm_scheduler_vnext #(.TARGETS(8),.DEPTH(DEPTH)) scheduler(.clk,.reset(reset || start),.play_start(phase==REPLAY),.playback_tick(playback_tick && running),
 .fact_valid,.fact_ready,.fact,.commit_valid,.commit_ready,.commits,.barrier_valid,.barrier_ready,.barrier,
 .loop_decision_valid(decision_valid),.loop_halt(decision_halt),.loop_waiting(waiting),.loop_release_pulse(released),.halted,.terminal,.fault_latched(scheduler_fault),.fault_reason(scheduler_reason),
 .due_time,.playback_time,.next_sequence(sequence_next),.levels);
 engine_a_vnext_loop_continuation_client continuation(.clk,.reset,.new_track(start),.boundary_valid(loop_boundary),.boundary_ready(1'b1),
 .boundary_target(loop_target),.owner_halt(transport_halt_loop),.scheduler_waiting(waiting),.scheduler_release(released),.decision_valid,.decision_halt,
 .resume_valid,.resume_ready,.resume_pc,.busy(continuation_busy));
 always @(posedge clk) begin
 if(reset || start) begin phase<=start?SCAN_ARM:IDLE;fault<=0;initial_wait_seen<=0;maximum_lateness<=0;end
 else begin
 case(phase)
 SCAN_ARM:phase<=SCAN;
 SCAN:if(parser_done)phase<=CHIP_CLEAR;
 CHIP_CLEAR:if(chip_ready)phase<=REPLAY;
 REPLAY:phase<=INITIALIZE;
 INITIALIZE:if(initial_wait_seen && queues_empty)phase<=PLAY;
 PLAY:if(halted || terminal || transport_finish)phase<=STOP;
 default:begin end
 endcase
 if(phase==SCAN && ((event_valid && (ev.kind==EVENT_DIAGNOSTIC || (ev.kind==EVENT_WRITE &&
 (wi.chip!=CHIP_HUC6280 || wi.instance_id || wi.address>15)))) || data_valid || dac_valid))begin fault<=1;phase<=FAIL;end
 if(fact_valid && fact_ready && fact.kind==S_WAIT && fact.time_advance!=0)initial_wait_seen<=1;
 if(phase==INITIALIZE && (loop_terminal || (event_valid && ev.kind==EVENT_END)))initial_wait_seen<=1;
 if(chip_write && late>{32'd0,maximum_lateness})maximum_lateness<=late > 64'hffffffff ? 32'hffffffff : late[31:0];
 if(strict_fault || scheduler_fault || resume_fault)begin fault<=1;phase<=FAIL;end
 end
 end
endmodule
