// SPDX-License-Identifier: GPL-2.0-or-later
// New Engine F implementation; semantics audited against pinned Mednafen.
// ce_native is the 7.159MHz master enable (wave divider period = 2*frequency).
// On coincident ce/write, advance OLD state, then apply the write at that timestamp.
// Reset clears one address per sys cycle in each independent 32x5 bank.
module engine_f_huc6280_psg #(parameter GAIN_FILE="rtl/engine_f_vnext/gain.hex")(
 input logic clk, reset, ce_native, write_valid,
 input logic [3:0] write_address, input logic [7:0] write_data,
 output logic ready, output logic [5:0] activity,
 output logic signed [19:0] native_left, native_right);
 logic [2:0] selected, ns;
 logic [7:0] global_balance, lfo_freq, lfo_ctrl, ng, nf, nl;
 logic [11:0] frequency[0:5], dfrequency[0:5];
 logic [7:0] control[0:5], balance[0:5], noise[0:5];
 logic [7:0] dc[0:5], db[0:5], dn[0:5];
 logic [4:0] position[0:5], dda[0:5], dp[0:5], dd[0:5];
 logic [21:0] counter[0:5], period[0:5], dt[0:5], dr[0:5];
 logic [11:0] noise_count[0:5], dnc[0:5];
 logic [17:0] lfsr[0:5], dlfsr[0:5];
 logic [4:0] vl[0:5], vr[0:5], dvl[0:5], dvr[0:5];
 logic [4:0] wave[0:5][0:31];
 logic [7:0] vol_count, dvc;
 logic [4:0] vol_which, dvw, vol_latch, dlat;
 logic vol_pending, dvpend;
 logic [5:0] clear_index;
 logic [5:0] wave_we;
 logic [4:0] wave_addr[0:5];
 logic [4:0] wave_data;
 logic signed [15:0] voice_l[0:5], voice_r[0:5];
 logic [4:0] sample_code[0:5];
 integer i, idx, reduction, nperiod;
 logic lfo_on;
 function automatic integer scale(input logic [3:0] v);
 case(v)
 0:scale=0;1:scale=3;2:scale=5;3:scale=7;4:scale=9;5:scale=11;6:scale=13;7:scale=15;
 8:scale=16;9:scale=19;10:scale=21;11:scale=23;12:scale=25;13:scale=27;14:scale=29;15:scale=31;
 endcase
 endfunction
 function automatic logic [21:0] calc_period(input integer ch,
 input logic [11:0] f,input logic [7:0] lf,lc,input logic [4:0] modulator);
 integer ef;
 begin
 ef=integer'(f);
 if(ch==0) begin
 case(lc[1:0])
 1:ef=(ef+integer'(modulator)-16)&4095;
 2:ef=(ef+(integer'(modulator)-16)*4)&4095;
 3:ef=(ef+(integer'(modulator)-16)*16)&4095;
 default:begin end
 endcase
 end
 if(ef==0) ef=4096;
 ef=ef*2;
 if(ch==1 && lc[1:0]!=0) ef=ef*(lf==0?256:integer'(lf));
 calc_period=22'(ef);
 end
 endfunction
 genvar c;
 generate for(c=0;c<6;c=c+1) begin: voice
   // Small bank-local async read: never a 192-entry cross-channel debug mux.
   always @(posedge clk) begin
     if(reset) wave[c][0] <= 0;
     else if(!ready) wave[c][clear_index[4:0]] <= 0;
     else if(wave_we[c]) wave[c][wave_addr[c]] <= wave_data;
   end
   assign sample_code[c] = noise[c][7] && c>=4 ? (lfsr[c][0]?5'd31:5'd0) : dda[c];
   assign activity[c] = ready && control[c][7] && (vl[c]!=31 || vr[c]!=31);
   engine_f_huc6280_gain #(.ROM_FILE(GAIN_FILE)) gain_rom(
    .clk,.reset(reset || !ready),.sample_code(sample_code[c]),
    .attenuation_l(vl[c]),.attenuation_r(vr[c]),.enabled(control[c][7]),
    .left(voice_l[c]),.right(voice_r[c]));
 end endgenerate
 always @* begin
 native_left=0;native_right=0;
 for(integer m=0;m<6;m=m+1) begin
 native_left=native_left+{{4{voice_l[m][15]}},voice_l[m]};
 native_right=native_right+{{4{voice_r[m][15]}},voice_r[m]};
 end
 end
 always @* begin
 ns=selected;ng=global_balance;nf=lfo_freq;nl=lfo_ctrl;
 dvc=vol_count;dvw=vol_which;dlat=vol_latch;dvpend=vol_pending;
 wave_we=0;wave_data=write_data[4:0];idx=0;reduction=0;nperiod=0;
 lfo_on=lfo_ctrl[1:0]!=0 && control[1][7] && !lfo_ctrl[7];
 for(i=0;i<6;i=i+1) begin
 dfrequency[i]=frequency[i];dc[i]=control[i];db[i]=balance[i];dn[i]=noise[i];
 dp[i]=position[i];dd[i]=dda[i];dt[i]=counter[i];dr[i]=period[i];
 dnc[i]=noise_count[i];dlfsr[i]=lfsr[i];dvl[i]=vl[i];dvr[i]=vr[i];wave_addr[i]=position[i];
 end
 if(ready && (ce_native || (write_valid && write_address!=0))) begin
   if(dvpend && dvc==0 && dvw==0) begin dvc=1;dvpend=0;end
 end
 if(ce_native && ready) begin
   // Channel 1 advances before the channel-0 LFO reload samples its latch.
   for(i=5;i>=0;i=i-1) begin
     if(i>=4) begin
       if(noise_count[i]<=1) begin
         dlfsr[i]={lfsr[i][0]^lfsr[i][1]^lfsr[i][11]^lfsr[i][12]^lfsr[i][17],lfsr[i][17:1]};
         nperiod=31-integer'(noise[i][4:0]);
         dnc[i]=12'(nperiod==0?64:nperiod*128);
       end else dnc[i]=noise_count[i]-1'b1;
     end
     if(control[i][7] && !control[i][6] && !(i==1 && lfo_ctrl[7])) begin
       if(counter[i]<=1) begin
         dp[i]=position[i]+5'd1; dd[i]=wave[i][dp[i]];
         if(i==0 && lfo_on) begin
           dr[i]=calc_period(0,frequency[0],lfo_freq,lfo_ctrl,dd[1]);
           // Native period is exact. Mednafen clamps periods <=7 in its LFO
           // fast path; those reference-domain differences are NOT waived.
           dt[i]=dr[i];
         end else dt[i]=period[i];
       end else dt[i]=counter[i]-1'b1;
     end
   end
   if(dvc!=0) begin
     if(dvc==1) begin
       idx=integer'(dvw[4:2]);
       if(idx<6) begin
         if(!dvw[0]) begin
           reduction=93-scale(dvw[1]?global_balance[7:4]:global_balance[3:0])
                         -scale(dvw[1]?balance[idx][7:4]:balance[idx][3:0])-integer'(control[idx][4:0]);
           dlat=5'(reduction>31?31:reduction);
         end else if(dvw[1]) dvl[idx]=vol_latch;else dvr[idx]=vol_latch;
       end
       dvw=vol_which+5'd1;
       if(dvw!=0 || dvpend) begin dvc=vol_which[0]?8'd1:8'd255;if(dvw==0) dvpend=0;end
       else dvc=0;
     end else dvc=dvc-1'b1;
   end
 end
 if(write_valid && ready) begin
 case(write_address)
 0:ns=write_data[2:0];
 1:begin ng=write_data;dvpend=1;end
 2,3:for(i=0;i<6;i=i+1) if(selected==3'(i)) begin
   if(write_address==2) dfrequency[i]={frequency[i][11:8],write_data};
   else dfrequency[i]={write_data[3:0],frequency[i][7:0]};
   dr[i]=calc_period(i,dfrequency[i],nf,nl,dd[1]);
 end
 4:for(i=0;i<6;i=i+1) if(selected==3'(i)) begin
   if(dc[i][6] && !write_data[6]) begin dp[i]=0;dd[i]=wave[i][0];dt[i]=dr[i];end
   if(!dc[i][7] && write_data[7] && !write_data[6]) begin dp[i]=dp[i]+5'd1;dd[i]=wave[i][dp[i]];end
   dc[i]=write_data;dr[i]=calc_period(i,dfrequency[i],nf,nl,dd[1]);dvpend=1;
 end
 5:for(i=0;i<6;i=i+1) if(selected==3'(i)) begin db[i]=write_data;dvpend=1;end
 6:for(i=0;i<6;i=i+1) if(selected==3'(i)) begin
   if(!dc[i][6]) begin wave_we[i]=1;wave_addr[i]=dp[i];end
   if(dc[i][7:6]==0) dp[i]=dp[i]+5'd1;
   if(dc[i][7]) dd[i]=write_data[4:0];
 end
 7:for(i=4;i<6;i=i+1) if(selected==3'(i)) dn[i]=write_data;
 8:nf=write_data;
 9:begin
   if(write_data[7]) begin dp[1]=0;dd[1]=wave[1][0];dt[1]=dr[1];end
   nl=write_data;
   dr[0]=calc_period(0,dfrequency[0],nf,nl,dd[1]);dr[1]=calc_period(1,dfrequency[1],nf,nl,dd[1]);
 end
 default:begin end
 endcase
 end
 end
 always @(posedge clk) begin
 if(reset) begin
 ready<=0;clear_index<=1;selected<=0;global_balance<=0;lfo_freq<=0;lfo_ctrl<=0;
 vol_count<=0;vol_which<=0;vol_latch<=0;vol_pending<=0;
 for(integer k=0;k<6;k=k+1) begin
 frequency[k]<=0;control[k]<=0;balance[k]<=0;noise[k]<=0;position[k]<=0;dda[k]<=0;
 counter[k]<=8192;period[k]<=8192;noise_count[k]<=1;lfsr[k]<=1;vl[k]<=31;vr[k]<=31;
 end
 end else if(!ready) begin
 if(clear_index==31) ready<=1;else clear_index<=clear_index+1'b1;
 end else begin
 selected<=ns;global_balance<=ng;lfo_freq<=nf;lfo_ctrl<=nl;
 vol_count<=dvc;vol_which<=dvw;vol_latch<=dlat;vol_pending<=dvpend;
 for(integer k=0;k<6;k=k+1) begin
 frequency[k]<=dfrequency[k];control[k]<=dc[k];balance[k]<=db[k];noise[k]<=dn[k];position[k]<=dp[k];dda[k]<=dd[k];
 counter[k]<=dt[k];period[k]<=dr[k];noise_count[k]<=dnc[k];lfsr[k]<=dlfsr[k];vl[k]<=dvl[k];vr[k]<=dvr[k];
 end
 end
 end
endmodule
