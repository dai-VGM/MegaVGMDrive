// SPDX-License-Identifier: GPL-2.0-or-later
// Synchronous dual-read constant ROM. No debug/async read/reset port.
module engine_f_huc6280_gain #(parameter ROM_FILE="rtl/engine_f_vnext/gain.hex")(
 input logic clk, reset, input logic [4:0] sample_code, attenuation_l, attenuation_r,
 input logic enabled, output wire signed [15:0] left, right);
 (* ramstyle="M10K" *) logic [15:0] gain [0:1023];
 logic [15:0] raw_l,raw_r;
 logic output_enabled;
 initial $readmemh(ROM_FILE,gain);
 always @(posedge clk) begin
   raw_l <= gain[{attenuation_l,sample_code}];
   raw_r <= gain[{attenuation_r,sample_code}];
 end
 always @(posedge clk) output_enabled <= enabled && !reset;
 assign left = output_enabled ? $signed(raw_l) : 16'sd0;
 assign right = output_enabled ? $signed(raw_r) : 16'sd0;
endmodule
