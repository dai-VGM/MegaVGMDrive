// SPDX-License-Identifier: GPL-2.0-or-later
// Fixed headroom conversion only; Golden owns filtering, DC blocking and mixing.
module engine_f_audio_adapter(input logic enabled,
 input logic signed [19:0] native_l,native_r,
 output logic signed [15:0] audio_l,audio_r);
 assign audio_l=enabled ? 16'(native_l >>> 1) : 16'sd0;
 assign audio_r=enabled ? 16'(native_r >>> 1) : 16'sd0;
endmodule
