// SPDX-License-Identifier: GPL-2.0-or-later
// F-only attachment. Compatibility ports retain the Golden body ABI.
module engine_f_vnext_profile #(
    parameter int RUN_MODE = 2,
    parameter int COMMAND_SETTLE_CYCLES = 288,
    parameter bit TRANSPORT_LOOP_CONTROL = 1'b0,
    parameter GAIN_FILE="rtl/engine_f_vnext/gain.hex"
) (
    input  logic         clk,
    input  logic         reset,
    input  logic         audio_isolate_step,
    input  logic         audio_gain_boost,
    input  logic         transport_loop_policy_active,
    input  logic         transport_halt_loop,
    input  logic         transport_finish,
    input logic preparation_cancel,
    output logic preparation_cancelled,
    output logic         playback_loop_entry_pulse,
    output logic         playback_loop_boundary_pulse,
    input  logic         ioctl_download,
    input  logic         ioctl_wr,
    input  logic [26:0]  ioctl_addr,
    input  logic [7:0]   ioctl_dout,
    input  logic [15:0]  ioctl_index,
    output logic         ioctl_wait,

    input  logic         ddram_busy,
    output logic [7:0]   ddram_burstcnt,
    output logic [28:0]  ddram_addr,
    input  logic [63:0]  ddram_dout,
    input  logic         ddram_dout_ready,
    output logic         ddram_rd,
    output logic [63:0]  ddram_din,
    output logic [7:0]   ddram_be,
    output logic         ddram_we,

    output logic signed [15:0] audio_l,
    output logic signed [15:0] audio_r,
    output logic         audio_sample_valid,
    output logic         audio_enable,
    output logic         playback_active,
    output logic         playback_done,
    output logic         profile_fatal,
    output logic [7:0]   error_code,
    output logic [2:0]   profile_state,
    output logic         load_busy,
    output logic         load_done,
    output logic         load_error,
    output logic         load_overflow,
    output logic [23:0]  uploaded_file_size,
    output logic [23:0]  accepted_byte_count,
    output logic [3:0]   wait_reason,
    output logic [7:0]   outstanding_fifo,
    output logic         scan_started,
    output logic [31:0]  vgm_sample_time,
    output logic [31:0]  natural_end_count,
    output logic [31:0]  command_deadline_miss_count,
    output logic [22:0]  debug_command_pc,
    output logic [7:0]   debug_last_command,
    output logic [5:0]   debug_parser_state,
    output logic [4:0]   debug_active_count,
    output logic [31:0]  debug_underflow_count,
    output logic [31:0]  debug_descriptor_miss_count,
    output logic [31:0]  debug_stale_response_count,
    output logic [31:0]  debug_raw_fetch_count,
    output logic [31:0]  debug_compressed_fetch_count,
    output logic         debug_first_deadline_valid,
    output logic [22:0]  debug_first_deadline_pc,
    output logic [7:0]   debug_first_deadline_command,
    output logic [5:0]   debug_first_deadline_state,
    output logic [7:0]   debug_first_deadline_flags,
    output logic [31:0]  debug_first_deadline_producer_time,
    output logic [31:0]  debug_first_deadline_playback_time,
    output logic [15:0]  debug_first_deadline_frame_clock,
    output logic [15:0]  debug_first_deadline_retired,
    output logic [7:0]   debug_first_deadline_reason,
    output logic [7:0]   ym2151_activity_event,
    output logic [23:0]  c140_activity_state,
    output logic         profile_system21
);

    localparam int FILE_ADDR_WIDTH=23, DDRAM_ADDR_WIDTH=29, WRITE_FIFO_DEPTH=256;
    localparam logic [7:0] FILE_INDEX=8'd1;
    localparam logic [28:0] DDRAM_BASE_ADDR={4'b0011,25'd0};
    localparam logic [28:0] UNUSED_PCM_BASE=DDRAM_BASE_ADDR+29'h00100000;
    logic power_reset=1'b1;
    always_ff @(posedge clk) power_reset<=1'b0;
    logic download_q, stopped, native_started, admission_fault, sequential_fault;
    logic [31:0] epoch=0, uploaded_clock, uploaded_version, uploaded_data_offset;
    logic [3:0] clock_seen;
    wire selected_download=ioctl_download && ioctl_index==16'd1;
    wire load_begin=selected_download && !download_q;
    wire accepted_upload=selected_download && ioctl_wr && !ioctl_wait;
    wire cancel_now=preparation_cancel && !stopped && !native_started && !core_running &&
        (selected_download || backend_load_busy || backend_load_done) && !load_begin;
    wire lifecycle=reset || selected_download || stopped || cancel_now || transport_finish;
    logic backend_load_busy, backend_load_done, backend_load_error, backend_overflow_error;
    logic [31:0] backend_file_size;
    logic [15:0] backend_fifo_debug, backend_ready_debug;
    logic [7:0] backend_ddram_burstcnt,backend_ddram_be;
    logic [28:0] backend_ddram_addr;
    logic backend_ddram_rd,backend_ddram_we,golden_busy;
    logic [63:0] backend_ddram_din;
    logic load_done_pulse,golden_request,golden_ready,golden_valid;
    logic [22:0] golden_byte_address;
    logic [7:0] golden_data;
    logic command_request,command_ready,command_valid;
    logic [31:0] command_address,source_address,word_address,word_epoch;
    logic [7:0] command_data,source_data;
    logic source_request,source_ready,source_valid,source_fault,source_word_valid;
    logic [63:0] word_data;
    vgm_reader_vnext_pkg::read_response_t fault_response;
    logic logical_active,drain_blocked,boundary_fault;
    logic chip_reset,chip_ready,chip_write,core_running,core_fault,core_finished,core_accepted;
    logic [3:0] chip_address;
    logic [7:0] chip_data;
    logic [5:0] activity;
    logic signed [19:0] native_l,native_r;
    logic [63:0] playback_time,decoded_due,write_due,write_sequence;
    logic [31:0] write_pc,maximum_lateness;
    wire tick,native_ce;
    wire file_overflow=|backend_file_size[31:23];
    wire current_read_fault=!lifecycle && (boundary_fault || (source_fault && fault_response.epoch==epoch));
    // VGM 1.61 A4 clock is PSG input (3,579,545), not the doubled native
    // event grid used by the verified period=2*frequency implementation.
    wire header_ok=clock_seen==4'hf && uploaded_clock==32'd3579545 &&
        uploaded_version>=32'h161 && uploaded_data_offset>=32'h74 &&
        uploaded_data_offset<=32'hffffffcb && uploaded_data_offset+32'h34<backend_file_size &&
        !sequential_fault && backend_file_size>=32'ha8;
    wire start=load_done_pulse && header_ok && !stopped && !cancel_now && !reset;
    always_ff @(posedge clk) begin
        if(power_reset) epoch<=0;
        else if(load_begin || cancel_now || transport_finish) epoch<=epoch+1'b1;
        if(reset) begin
            download_q<=0;stopped<=0;native_started<=0;admission_fault<=0;sequential_fault<=0;
            uploaded_clock<=0;uploaded_version<=0;uploaded_data_offset<=0;clock_seen<=0;
            accepted_byte_count<=0;scan_started<=0;preparation_cancelled<=0;natural_end_count<=0;
        end else begin
            download_q<=selected_download;
            if(load_begin) begin
                stopped<=0;native_started<=0;admission_fault<=0;sequential_fault<=0;
                uploaded_clock<=0;uploaded_version<=0;uploaded_data_offset<=0;clock_seen<=0;
                accepted_byte_count<=0;scan_started<=0;preparation_cancelled<=0;natural_end_count<=0;
            end
            if(accepted_upload) begin
                if(ioctl_addr != (load_begin ? 27'd0 : {3'd0,accepted_byte_count})) sequential_fault<=1;
                accepted_byte_count<=load_begin ? 24'd1 : accepted_byte_count+1'b1;
                case(ioctl_addr)
                8:uploaded_version[7:0]<=ioctl_dout;
                9:uploaded_version[15:8]<=ioctl_dout;
                10:uploaded_version[23:16]<=ioctl_dout;
                11:uploaded_version[31:24]<=ioctl_dout;
                52:uploaded_data_offset[7:0]<=ioctl_dout;
                53:uploaded_data_offset[15:8]<=ioctl_dout;
                54:uploaded_data_offset[23:16]<=ioctl_dout;
                55:uploaded_data_offset[31:24]<=ioctl_dout;
                164:begin uploaded_clock[7:0]<=ioctl_dout;clock_seen[0]<=1;end
                165:begin uploaded_clock[15:8]<=ioctl_dout;clock_seen[1]<=1;end
                166:begin uploaded_clock[23:16]<=ioctl_dout;clock_seen[2]<=1;end
                167:begin uploaded_clock[31:24]<=ioctl_dout;clock_seen[3]<=1;end
                default:begin end
                endcase
            end
            if(load_done_pulse && !header_ok && !stopped) admission_fault<=1;
            if(core_running && !lifecycle && !profile_fatal) native_started<=1;
            if(core_finished && natural_end_count==0) natural_end_count<=1;
            if(command_request && command_ready) scan_started<=1;
            if(cancel_now) begin stopped<=1;native_started<=0;preparation_cancelled<=1;end
            if(transport_finish) begin stopped<=1;native_started<=0;end
        end
    end
    engine_f_vnext_command_client plugin(.clk,.reset(lifecycle),.start,
        .playback_tick(tick),.transport_halt_loop(TRANSPORT_LOOP_CONTROL && transport_loop_policy_active && transport_halt_loop),
        .transport_finish,.strict_fault(current_read_fault),.image_size(backend_file_size),
        .memory_request(command_request),.memory_ready(command_ready),.memory_valid(command_valid),
        .memory_address(command_address),.memory_data(command_data),.chip_ready,.chip_reset,.chip_write,.chip_address,.chip_data,
        .running(core_running),.accepted(core_accepted),.fault(core_fault),.finished(core_finished),
        .loop_entry(playback_loop_entry_pulse),.loop_boundary(playback_loop_boundary_pulse),
        .playback_time,.due_time(decoded_due),.write_due,.write_sequence,.write_pc,.maximum_lateness);
    vgm_scheduler_vnext_tick_enable logical_clock(.clk,.reset(lifecycle || !core_running),
        .enable(core_running),.tick,.phase_debug());
    // Native clock starts with PLAY and continues through the owner's fade.
    wire native_enable=(core_running || native_started) && !profile_fatal && !lifecycle;
    vgm_scheduler_vnext_tick_enable #(.SAMPLE_HZ(7_159_090)) native_clock(
        .clk,.reset(lifecycle || !native_enable),.enable(native_enable),.tick(native_ce),.phase_debug());
    engine_f_huc6280_psg #(.GAIN_FILE(GAIN_FILE)) psg(.clk,.reset(chip_reset || lifecycle),
        .ce_native(native_ce),.write_valid(chip_write),.write_address(chip_address),.write_data(chip_data),
        .ready(chip_ready),.activity,.native_left(native_l),.native_right(native_r));
    engine_b_vnext_command_word_buffer command_cache(.clk,.reset(lifecycle || start),.enable(1'b1),
        .epoch,.file_extent(backend_file_size),.byte_request(command_request),.byte_address(command_address),
        .byte_ready(command_ready),.byte_valid(command_valid),.byte_data(command_data),
        .memory_request(source_request),.memory_address(source_address),.memory_ready(source_ready),
        .memory_valid(source_valid),.memory_data(source_data),.word_valid(source_word_valid),
        .word_address,.word_epoch,.word_data);
    engine_b_vnext_shared_reader_binding reader(.clk,.power_reset,.backend_reset(reset),
        .download_active(selected_download),.session_reload(cancel_now || transport_finish || stopped),.current_epoch(epoch),
        .file_extent(backend_file_size),.backend_loaded(backend_load_done),
        .backend_load_error(backend_load_error || backend_overflow_error || file_overflow),
        .request_valid(source_request),.request_ready(source_ready),.request_address(source_address),
        .response_valid(source_valid),.response_byte(source_data),.fault_valid(source_fault),.fault_response,
        .golden_request,.golden_byte_address,.golden_ready,.golden_valid,
        .golden_read(backend_ddram_rd),.golden_write(backend_ddram_we),.golden_address(backend_ddram_addr),
        .golden_be(backend_ddram_be),.golden_burst(backend_ddram_burstcnt),.golden_busy,
        .avalon_read(ddram_rd),.avalon_address(ddram_addr),.avalon_be(ddram_be),.avalon_burst(ddram_burstcnt),
        .avalon_busy(ddram_busy),.avalon_valid(ddram_dout_ready),.avalon_data(ddram_dout),
        .word_valid(source_word_valid),.word_address,.word_epoch,.word_data,
        .request_captured(),.logical_active,.drain_blocked,.boundary_fault);
    assign ddram_din=backend_ddram_din;assign ddram_we=backend_ddram_we;
    // Verified native range 0..63486; /2 gives 0..31743 without clipping.
    // Keep the native DC domain. Golden audio_out owns IIR/DC blocking/mix.
    engine_f_audio_adapter output_adapter(.enabled(audio_enable),.native_l,.native_r,.audio_l,.audio_r);
    assign playback_active=(core_running || native_started) && !profile_fatal && !lifecycle;
    assign audio_enable=playback_active;
    assign audio_sample_valid=audio_enable && native_ce;
    assign playback_done=core_finished && native_started && !profile_fatal;
    assign load_busy=!stopped && !profile_fatal && (selected_download || backend_load_busy || (backend_load_done && !native_started && !core_running));
    assign load_done=backend_load_done;
    assign load_error=backend_load_error || backend_overflow_error;
    assign load_overflow=file_overflow;
    assign profile_fatal=admission_fault || sequential_fault || core_fault || current_read_fault || load_error || file_overflow;
    assign error_code=admission_fault ? 8'h51 : sequential_fault ? 8'h52 : core_fault ? 8'h53 : current_read_fault ? 8'h40 : load_error ? 8'h31 : file_overflow ? 8'h32 : 0;
    assign uploaded_file_size=backend_file_size[23:0];
    assign vgm_sample_time=playback_time[31:0];
    assign command_deadline_miss_count=maximum_lateness;
    assign profile_state=selected_download ? 1 : profile_fatal ? 5 : stopped ? 4 : playback_active ? 3 : backend_load_done ? 2 : 0;
    assign wait_reason={backend_ready_debug[10],backend_ready_debug[7],backend_ready_debug[6],backend_ready_debug[4]};
    assign outstanding_fifo={backend_ready_debug[6],backend_fifo_debug[6:0]};
    assign ym2151_activity_event={2'b0,activity} & {8{playback_active}};
    assign c140_activity_state=0;assign profile_system21=0;
    assign debug_command_pc=write_pc[22:0];assign debug_last_command=8'hb9;assign debug_parser_state=0;
    always @* begin debug_active_count=0;for(integer v=0;v<6;v=v+1)debug_active_count=debug_active_count+{4'b0,activity[v]};end
    assign debug_underflow_count=0;assign debug_descriptor_miss_count=0;assign debug_stale_response_count=0;
    assign debug_raw_fetch_count=0;assign debug_compressed_fetch_count=0;
    assign debug_first_deadline_valid=maximum_lateness!=0;
    assign debug_first_deadline_pc=write_pc[22:0];assign debug_first_deadline_command=8'hb9;
    assign debug_first_deadline_state=0;assign debug_first_deadline_flags=0;
    assign debug_first_deadline_producer_time=write_due[31:0];assign debug_first_deadline_playback_time=playback_time[31:0];
    assign debug_first_deadline_frame_clock=0;assign debug_first_deadline_retired=0;assign debug_first_deadline_reason=0;
    vgm_ddram_backend #(
        .ADDR_WIDTH(FILE_ADDR_WIDTH),
        .ACCEPT_ANY_INDEX(1'b0),
        .FILE_INDEX(FILE_INDEX),
        .DDRAM_ADDR_WIDTH(DDRAM_ADDR_WIDTH),
        .WRITE_FIFO_DEPTH(WRITE_FIFO_DEPTH),
        .DDRAM_BASE_ADDR(DDRAM_BASE_ADDR),
        .SEGAPCM_ROM_BASE_ADDR(UNUSED_PCM_BASE)
    ) production_backend (
        .clk(clk),
        .reset(reset),
        .ioctl_download(selected_download),
        .ioctl_wr(ioctl_wr && selected_download),
        .ioctl_addr({5'd0, ioctl_addr}),
        .ioctl_dout(ioctl_dout),
        .ioctl_index(ioctl_index[7:0]),
        .ioctl_wait(ioctl_wait),

        .mem_rd_req(golden_request),
        .mem_rd_addr(golden_byte_address),
        .mem_rd_ready(golden_ready),
        .mem_rd_valid(golden_valid),
        .mem_rd_data(golden_data),

        .segapcm_copy_wr_req(1'b0),
        .segapcm_copy_wr_ready(),
        .segapcm_copy_wr_addr(19'd0),
        .segapcm_copy_wr_data(8'd0),
        .segapcm_copy_flush_req(1'b0),
        .segapcm_copy_flush_done(),
        .segapcm_copy_accept_count_debug(),
        .segapcm_copy_write_count_debug(),
        .segapcm_copy_fifo_debug(backend_fifo_debug),
        .segapcm_copy_ready_debug(backend_ready_debug),
        .segapcm_copy_write_req_debug(),
        .segapcm_copy_word_debug(),
        .segapcm_copy_flush_debug(),
        .segapcm_copy_full_detect_count_debug(),
        .segapcm_copy_push_req_count_debug(),
        .segapcm_copy_push_fire_count_debug(),
        .segapcm_copy_fifo_push_count_debug(),
        .segapcm_copy_pack_ready_debug(),
        .segapcm_copy_post_push_debug(),
        .segapcm_read_gate_debug(),
        .segapcm_read_after_copy_count_debug(),

        .load_busy(backend_load_busy),
        .load_done(backend_load_done),
        .load_done_pulse(load_done_pulse),
        .play_ready_pulse(),
        .load_error(backend_load_error),
        .overflow_error(backend_overflow_error),
        .file_size(backend_file_size),
        .magic_debug(),

        .ddram_busy(golden_busy),
        .ddram_burstcnt(backend_ddram_burstcnt),
        .ddram_addr(backend_ddram_addr),
        .ddram_dout(ddram_dout),
        .ddram_dout_ready(ddram_dout_ready),
        .ddram_rd(backend_ddram_rd),
        .ddram_din(backend_ddram_din),
        .ddram_be(backend_ddram_be),
        .ddram_we(backend_ddram_we)
    );
endmodule
