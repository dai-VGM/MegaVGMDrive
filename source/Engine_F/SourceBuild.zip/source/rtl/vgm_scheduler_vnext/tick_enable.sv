module vgm_scheduler_vnext_tick_enable #(
    parameter int unsigned CLOCK_HZ=20_000_000,
    parameter int unsigned SAMPLE_HZ=44_100
) (
    input logic clk, reset, enable,
    output logic tick,
    output logic [31:0] phase_debug
);
    logic [31:0] phase;
    logic [32:0] sum;
    initial begin
        if(SAMPLE_HZ==0 || CLOCK_HZ<SAMPLE_HZ) $fatal(1,"invalid tick rate");
    end
    assign sum={1'b0,phase}+33'(SAMPLE_HZ);
    assign tick=enable && !reset && sum>=33'(CLOCK_HZ);
    assign phase_debug=phase;
    always_ff @(posedge clk) begin
        if(reset) phase<=0;
        else if(enable) phase<=tick ? 32'(sum-33'(CLOCK_HZ)) : sum[31:0];
    end
endmodule
