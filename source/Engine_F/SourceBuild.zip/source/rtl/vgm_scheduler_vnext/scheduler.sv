module vgm_scheduler_vnext #(
    parameter int TARGETS=7,
    parameter int DEPTH=16,
    parameter int PTR_WIDTH=$clog2(DEPTH)
) (
    input logic clk, reset, play_start, playback_tick,
    input logic fact_valid,
    output logic fact_ready,
    input vgm_scheduler_vnext_pkg::normalized_fact_t fact,
    output logic [TARGETS-1:0] commit_valid,
    input logic [TARGETS-1:0] commit_ready,
    output vgm_scheduler_vnext_pkg::scheduled_fact_t commits [TARGETS],
    output logic barrier_valid,
    input logic barrier_ready,
    output vgm_scheduler_vnext_pkg::scheduled_fact_t barrier,
    input logic loop_decision_valid, loop_halt,
    output logic loop_waiting, loop_release_pulse, halted, terminal,
    output logic fault_latched,
    output logic [2:0] fault_reason,
    output logic [63:0] due_time, playback_time, next_sequence,
    output logic [PTR_WIDTH:0] levels [TARGETS]
);
    import vgm_scheduler_vnext_pkg::*;
    scheduled_fact_t queue [TARGETS][DEPTH];
    logic [PTR_WIDTH-1:0] read_pointer [TARGETS], write_pointer [TARGETS];
    scheduled_fact_t barrier_owned;
    scheduled_fact_t head;
    logic barrier_pending, started, empty;
    logic [64:0] next_due;
    logic write_fact, wait_fact, bad_target, accepted;
    initial begin
        if(DEPTH<2 || DEPTH!=(1<<PTR_WIDTH) || TARGETS<1 || TARGETS>8)
            $fatal(1,"invalid candidate queue parameters");
    end
    assign write_fact=fact.kind==S_WRITE || fact.kind==S_DAC;
    assign wait_fact=fact.kind==S_WAIT;
    assign bad_target=write_fact && int'(fact.target)>=TARGETS;
    assign next_due={1'b0,due_time}+{49'd0,((wait_fact || fact.kind==S_DAC) ? fact.time_advance : 16'd0)};
    always @* begin
        head='0;
        fact_ready=!reset && !barrier_pending && !loop_waiting && !halted && !terminal && !fault_latched;
        if(write_fact && !bad_target) fact_ready=fact_ready && int'(levels[fact.target])<DEPTH;
        empty=1;
        for(integer lane=0;lane<TARGETS;lane=lane+1) begin
            if(levels[lane]!=0) empty=0;
            commits[lane]='0;commit_valid[lane]=0;
            if(levels[lane]!=0) begin
                head=queue[lane][read_pointer[lane]];commits[lane]=head;
                commit_valid[lane]=started && !fault_latched && !reset && head.due_time<=playback_time;
            end
        end
        barrier=barrier_pending ? barrier_owned : '0;
        barrier_valid=barrier_pending && empty && started && !fault_latched && !reset && barrier_owned.due_time<=playback_time;
    end
    assign accepted=fact_valid && fact_ready;
    always_ff @(posedge clk) begin
        loop_release_pulse<=0;
        if(reset) begin
            started<=0;due_time<=0;playback_time<=0;next_sequence<=0;
            barrier_pending<=0;barrier_owned<='0;loop_waiting<=0;
            halted<=0;terminal<=0;fault_latched<=0;fault_reason<=0;
            for(integer lane=0;lane<TARGETS;lane=lane+1) begin
                levels[lane]<=0;read_pointer[lane]<=0;write_pointer[lane]<=0;
            end
        end else begin
            if(play_start) started<=1;
            if(playback_tick && started && !terminal && !halted && !fault_latched) begin
                if(playback_time==64'hffffffffffffffff) begin fault_latched<=1;fault_reason<=3;end
                else playback_time<=playback_time+1'b1;
            end
            for(integer lane=0;lane<TARGETS;lane=lane+1) begin
                if(commit_valid[lane] && commit_ready[lane]) read_pointer[lane]<=read_pointer[lane]+1'b1;
                case({(accepted && write_fact && !bad_target && !next_due[64] && (fact.kind==S_DAC || fact.time_advance==0) && next_sequence!=64'hffffffffffffffff && int'(fact.target)==lane),
                      (commit_valid[lane] && commit_ready[lane])})
                    2'b10:levels[lane]<=levels[lane]+1'b1;
                    2'b01:levels[lane]<=levels[lane]-1'b1;
                    default:begin end
                endcase
            end
            if(accepted) begin
                if(next_due[64] || next_sequence==64'hffffffffffffffff || bad_target || (!wait_fact && fact.kind!=S_DAC && fact.time_advance!=0)) begin
                    fault_latched<=1;fault_reason<=(!wait_fact && fact.kind!=S_DAC && fact.time_advance!=0) ? 3'd5 : bad_target ? 3'd4 : next_due[64] ? 3'd1 : 3'd2;
                end else begin
                    next_sequence<=next_sequence+1'b1;
                    due_time<=next_due[63:0];
                    if(write_fact) begin
                        queue[fact.target][write_pointer[fact.target]]<={due_time,next_sequence,fact};
                        write_pointer[fact.target]<=write_pointer[fact.target]+1'b1;
                    end else if(!wait_fact) begin
                        barrier_owned<={due_time,next_sequence,fact};barrier_pending<=1;
                    end
                end
            end
            if(barrier_valid && barrier_ready) begin
                barrier_pending<=0;
                if(barrier_owned.fact.kind==S_LOOP_BOUNDARY) loop_waiting<=1;
                if(barrier_owned.fact.kind==S_END || barrier_owned.fact.kind==S_DIAGNOSTIC) terminal<=1;
            end
            if(loop_waiting && loop_decision_valid) begin
                loop_waiting<=0;
                if(loop_halt) halted<=1;
                else loop_release_pulse<=1;
            end
        end
    end
endmodule
