package vgm_scheduler_vnext_pkg;
    typedef enum logic [2:0] {
        S_WRITE, S_WAIT, S_DATA, S_DAC, S_LOOP_ENTRY, S_LOOP_BOUNDARY, S_END, S_DIAGNOSTIC
    } fact_kind_t;
    // Wrapper only: frozen packed Parser payloads retain every bit.
    typedef struct packed {
        fact_kind_t kind;
        logic [2:0] target;
        logic [15:0] time_advance;
        logic [346:0] payload;
    } normalized_fact_t;
    typedef struct packed {
        logic [63:0] due_time, sequence_id;
        normalized_fact_t fact;
    } scheduled_fact_t;
    function automatic logic [31:0] source_pc(input normalized_fact_t fact);
        vgm_parser_vnext_event_pkg::decode_event_t body;
        vgm_parser_vnext_event_pkg::data_event_t metadata;
        vgm_parser_vnext_event_pkg::dac_stream_fact_t dac;
        body=fact.payload[79:0]; metadata=fact.payload; dac=fact.payload[75:0];
        case(fact.kind)
            S_DATA: return metadata.source_pc;
            S_DAC: return dac.source_pc;
            S_LOOP_ENTRY,S_LOOP_BOUNDARY: return fact.payload[31:0];
            default: return body.source_pc;
        endcase
    endfunction
endpackage
