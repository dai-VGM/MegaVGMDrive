module vgm_scheduler_vnext_normalizer (
    input logic clk, reset,
    input logic event_valid, data_event_valid, dac_fact_valid, loop_terminal_valid,
    input vgm_parser_vnext_event_pkg::decode_event_t event_data,
    input vgm_parser_vnext_event_pkg::write_descriptor_t write_info,
    input vgm_parser_vnext_event_pkg::data_event_t data_event_data,
    input vgm_parser_vnext_event_pkg::dac_stream_fact_t dac_fact_data,
    input logic loop_present,
    input logic [31:0] loop_target, loop_terminal_pc,
    output logic event_ready, fact_valid,
    input logic fact_ready,
    output vgm_scheduler_vnext_pkg::normalized_fact_t fact
);
    import vgm_parser_vnext_event_pkg::*;
    import vgm_scheduler_vnext_pkg::*;
    normalized_fact_t command_fact;
    logic entry_sent, command_valid, entry_needed;
    always @* begin
        command_valid=event_valid || data_event_valid || dac_fact_valid || loop_terminal_valid;
        command_fact='0;
        if(data_event_valid) begin
            command_fact.kind=S_DATA; command_fact.payload=data_event_data;
        end else if(dac_fact_valid) begin
            command_fact.kind=S_DAC; command_fact.target=CHIP_YM2612;
            command_fact.time_advance={12'd0,dac_fact_data.wait_samples};
            command_fact.payload[75:0]=dac_fact_data;
        end else if(loop_terminal_valid) begin
            command_fact.kind=S_LOOP_BOUNDARY;
            command_fact.payload[63:0]={loop_target,loop_terminal_pc};
        end else begin
            command_fact.payload[79:0]=event_data;
            case(event_data.kind)
                EVENT_WRITE: begin
                    command_fact.kind=S_WRITE; command_fact.target=write_info.chip;
                    command_fact.payload[134:80]=write_info;
                end
                EVENT_WAIT: begin command_fact.kind=S_WAIT;command_fact.time_advance=event_data.value;end
                EVENT_END: command_fact.kind=S_END;
                default: command_fact.kind=S_DIAGNOSTIC;
            endcase
        end
        entry_needed=command_valid && command_fact.kind!=S_DIAGNOSTIC && loop_present && !entry_sent && source_pc(command_fact)==loop_target;
        fact=command_fact;
        if(entry_needed) begin
            fact='0; fact.kind=S_LOOP_ENTRY;fact.payload[63:0]={loop_target,loop_target};
        end
        fact_valid=command_valid;
        event_ready=fact_ready && !entry_needed;
    end
    always_ff @(posedge clk) begin
        if(reset) entry_sent<=0;
        else if(fact_valid && fact_ready && entry_needed) entry_sent<=1;
    end
endmodule
