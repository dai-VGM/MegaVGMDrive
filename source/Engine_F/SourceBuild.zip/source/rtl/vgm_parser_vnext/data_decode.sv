// Bounded grammar prefix decoder. Never reads/copies sample payload bytes.
module vgm_parser_vnext_data_decode (
    input logic clk, reset, start,
    input logic [31:0] command_pc, file_extent,
    input logic [7:0] opcode,
    output logic reader_req_valid,
    input logic reader_req_ready,
    output logic [31:0] reader_req_addr,
    input logic reader_rsp_valid,
    input logic [7:0] reader_rsp_byte,
    output logic done,
    output vgm_parser_vnext_event_pkg::diagnostic_reason_t reason,
    output vgm_parser_vnext_event_pkg::data_event_t result
);
    import vgm_parser_vnext_event_pkg::*;
    typedef enum logic [2:0] {IDLE, REQUEST, RESPONSE, SIZE_CHECK, COMPLETE} state_t;
    state_t state;
    logic [4:0] index, required_bytes;
    logic [32:0] body_end;
    logic [31:0] body_length;
    logic [3:0] metadata_length;
    assign reader_req_valid = state == REQUEST;
    assign reader_req_addr = result.source_pc + 32'd1 + {27'd0,index};
    assign done = state == COMPLETE;
    assign body_length = result.block_type[7] ?
                         {1'b0,result.declared_length[30:0]} : result.declared_length;
    assign body_end = {1'b0,result.source_pc} + 33'd7 + {1'b0,body_length};
    always @* begin
        case (result.block_type[7:6])
            2'b00: metadata_length = 0;
            2'b01: metadata_length = result.block_type == 8'h7f ? 4'd6 : 4'd10;
            2'b10: metadata_length = 4'd8;
            default: metadata_length = result.block_type[5] ? 4'd4 : 4'd2;
        endcase
    end
    always_ff @(posedge clk) begin
        if (reset) begin
            state <= IDLE;
            index <= 0;
            required_bytes <= 0;
            reason <= REASON_NONE;
            result <= '0;
        end else case (state)
            IDLE, COMPLETE: if (start) begin
                result <= '0;
                result.source_pc <= command_pc;
                result.opcode <= opcode;
                if (opcode == 8'he0) result.kind <= DATA_SEEK;
                else result.kind <= DATA_BLOCK;
                index <= 0;
                required_bytes <= opcode == 8'he0 ? 5'd4 : 5'd6;
                reason <= REASON_NONE;
                if ({1'b0,command_pc} + (opcode == 8'he0 ? 33'd5 : 33'd7) >
                    {1'b0,file_extent}) begin
                    reason <= REASON_TRUNCATED;
                    state <= COMPLETE;
                end else state <= REQUEST;
            end
            REQUEST: if (reader_req_ready) state <= RESPONSE;
            RESPONSE: if (reader_rsp_valid) begin
                result.operands <= result.operands |
                    ({120'd0,reader_rsp_byte} << (index * 8));
                if (result.kind == DATA_BLOCK && index == 0 && reader_rsp_byte != 8'h66) begin
                    reason <= REASON_BAD_DATA_BLOCK;
                    state <= COMPLETE;
                end else if (result.kind == DATA_BLOCK && index == 1) begin
                    result.block_type <= reader_rsp_byte;
                    index <= index + 1'b1;
                    state <= REQUEST;
                end else if (result.kind == DATA_BLOCK && index == 5) begin
                    result.declared_length <= {reader_rsp_byte,result.operands[39:16]};
                    result.instance_id <= result.block_type[7] && reader_rsp_byte[7];
                    state <= SIZE_CHECK;
                end else if (index + 5'd1 == required_bytes) begin
                    result.operand_count <= required_bytes;
                    if (result.kind == DATA_SEEK) begin
                        result.seek_offset <= {reader_rsp_byte,result.operands[23:0]};
                        result.next_pc <= result.source_pc + 32'd5;
                    end
                    state <= COMPLETE;
                end else begin
                    index <= index + 1'b1;
                    state <= REQUEST;
                end
            end
            SIZE_CHECK: begin
                if (body_end[32] || body_end > {1'b0,file_extent}) begin
                    reason <= REASON_TRUNCATED;
                    state <= COMPLETE;
                end else if (body_length < {28'd0,metadata_length}) begin
                    reason <= REASON_BAD_DATA_BLOCK;
                    state <= COMPLETE;
                end else begin
                    result.metadata_bytes <= metadata_length;
                    result.payload_offset <= result.source_pc + 32'd7 + {28'd0,metadata_length};
                    result.payload_length <= body_length - {28'd0,metadata_length};
                    result.next_pc <= body_end[31:0];
                    required_bytes <= 5'd6 + {1'b0,metadata_length};
                    if (metadata_length == 0) begin
                        result.operand_count <= 6;
                        state <= COMPLETE;
                    end else begin index <= 6; state <= REQUEST; end
                end
            end
            default: state <= IDLE;
        endcase
    end
endmodule
