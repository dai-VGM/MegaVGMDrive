module vgm_parser_vnext_header_decode (
    input logic clk, reset, start,
    input logic [31:0] image_size,
    output logic reader_req_valid,
    input logic reader_req_ready,
    output logic [31:0] reader_req_addr,
    input logic reader_rsp_valid,
    input logic [7:0] reader_rsp_byte,
    output logic done, valid,
    output logic [31:0] file_extent, data_start,
    output logic loop_present,
    output logic [31:0] loop_target,
    output vgm_parser_vnext_event_pkg::diagnostic_reason_t reason,
    output logic [31:0] error_pc
);
    import vgm_parser_vnext_event_pkg::*;
    typedef enum logic [2:0] {IDLE, REQUEST, RESPONSE, CHECK, COMPLETE} state_t;
    state_t state;
    logic [5:0] index;
    logic [31:0] size_latched, magic, eof_offset, version;
    logic [31:0] data_offset, loop_offset;
    logic [32:0] extent_wide, data_wide, loop_wide;

    assign reader_req_valid = (state == REQUEST);
    assign reader_req_addr = {26'd0, index};
    // Widen BEFORE addition. No truncated sum is used for validation.
    assign extent_wide = {1'b0, eof_offset} + 33'd4;
    assign data_wide = ((version < 32'h150) || (data_offset == 0)) ?
                       33'h40 : {1'b0, data_offset} + 33'h34;
    assign loop_wide = {1'b0, loop_offset} + 33'h1c;

    task automatic reject(input diagnostic_reason_t why, input logic [31:0] at);
        reason <= why;
        error_pc <= at;
        done <= 1'b1;
        valid <= 1'b0;
        state <= COMPLETE;
    endtask

    always_ff @(posedge clk) begin
        if (reset) begin
            state <= IDLE;
            index <= 0;
            size_latched <= 0;
            magic <= 0;
            eof_offset <= 0;
            version <= 0;
            data_offset <= 0;
            loop_offset <= 0;
            done <= 0;
            valid <= 0;
            file_extent <= 0;
            data_start <= 0;
            loop_present <= 0;
            loop_target <= 0;
            reason <= REASON_NONE;
            error_pc <= 0;
        end else begin
            case (state)
                IDLE, COMPLETE: if (start) begin
                    done <= 0;
                    valid <= 0;
                    reason <= REASON_NONE;
                    error_pc <= 0;
                    file_extent <= 0;
                    data_start <= 0;
                    loop_present <= 0;
                    loop_target <= 0;
                    index <= 0;
                    magic <= 0;
                    eof_offset <= 0;
                    version <= 0;
                    data_offset <= 0;
                    loop_offset <= 0;
                    size_latched <= image_size;
                    if (image_size < 32'h40)
                        reject(REASON_SHORT_HEADER, image_size);
                    else state <= REQUEST;
                end
                REQUEST: if (reader_req_ready) state <= RESPONSE;
                RESPONSE: if (reader_rsp_valid) begin
                    if (index < 4) magic[index[1:0]*8 +: 8] <= reader_rsp_byte;
                    if (index >= 4 && index < 8)
                        eof_offset[index[1:0]*8 +: 8] <= reader_rsp_byte;
                    if (index >= 8 && index < 12)
                        version[index[1:0]*8 +: 8] <= reader_rsp_byte;
                    if (index >= 28 && index < 32)
                        loop_offset[index[1:0]*8 +: 8] <= reader_rsp_byte;
                    if (index >= 52 && index < 56)
                        data_offset[index[1:0]*8 +: 8] <= reader_rsp_byte;
                    if (index == 63) state <= CHECK;
                    else begin index <= index + 1'b1; state <= REQUEST; end
                end
                CHECK: begin
                    if (magic != 32'h206d6756) reject(REASON_BAD_MAGIC, 0);
                    else if (extent_wide[32] || extent_wide < 33'h40 ||
                             extent_wide > {1'b0, size_latched})
                        reject(REASON_BAD_EXTENT, 4);
                    else if (data_wide[32] || data_wide < 33'h40 ||
                             data_wide >= extent_wide)
                        reject(REASON_BAD_DATA_OFFSET, 32'h34);
                    else if (loop_offset != 0 && (loop_wide[32] ||
                             loop_wide < data_wide || loop_wide >= extent_wide))
                        reject(REASON_BAD_LOOP_OFFSET, 32'h1c);
                    else begin
                        file_extent <= extent_wide[31:0];
                        data_start <= data_wide[31:0];
                        loop_present <= (loop_offset != 0);
                        loop_target <= (loop_offset == 0) ? 0 : loop_wide[31:0];
                        valid <= 1;
                        done <= 1;
                        state <= COMPLETE;
                    end
                end
                default: state <= IDLE;
            endcase
        end
    end
endmodule
